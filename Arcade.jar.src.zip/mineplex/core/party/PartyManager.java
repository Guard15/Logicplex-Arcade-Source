/*     */ package mineplex.core.party;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.party.commands.PartyCommand;
/*     */ import mineplex.core.party.redis.RedisPartyData;
/*     */ import mineplex.core.party.redis.RedisPartyHandler;
/*     */ import mineplex.core.portal.Portal;
/*     */ import mineplex.core.portal.ServerTransferEvent;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import mineplex.serverdata.commands.ServerCommandManager;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ public class PartyManager
/*     */   extends MiniPlugin
/*     */ {
/*     */   private CoreClientManager _clientManager;
/*     */   private PreferencesManager _preferenceManager;
/*     */   private Portal _portal;
/*     */   private String _serverName;
/*  33 */   public NautHashMap<String, Party> _partyLeaderMap = new NautHashMap();
/*     */   
/*     */   public PartyManager(JavaPlugin plugin, Portal portal, CoreClientManager clientManager, PreferencesManager preferenceManager)
/*     */   {
/*  37 */     super("Party Manager", plugin);
/*     */     
/*  39 */     this._portal = portal;
/*  40 */     this._clientManager = clientManager;
/*  41 */     this._preferenceManager = preferenceManager;
/*  42 */     this._serverName = getPlugin().getConfig().getString("serverstatus.name");
/*     */     
/*  44 */     ServerCommandManager.getInstance().registerCommandType("RedisPartyData", RedisPartyData.class, 
/*  45 */       new RedisPartyHandler(this));
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/*  51 */     addCommand(new PartyCommand(this));
/*     */   }
/*     */   
/*     */   public CoreClientManager GetClients()
/*     */   {
/*  56 */     return this._clientManager;
/*     */   }
/*     */   
/*     */   public PreferencesManager getPreferenceManager()
/*     */   {
/*  61 */     return this._preferenceManager;
/*     */   }
/*     */   
/*     */   public Party CreateParty(Player player)
/*     */   {
/*  66 */     Party party = new Party(this);
/*  67 */     party.JoinParty(player);
/*  68 */     this._partyLeaderMap.put(player.getName(), party);
/*     */     
/*  70 */     return party;
/*     */   }
/*     */   
/*     */   public String getServerName()
/*     */   {
/*  75 */     return this._serverName;
/*     */   }
/*     */   
/*     */   public void addParty(Party party)
/*     */   {
/*  80 */     if (this._partyLeaderMap.containsKey(party.GetLeader())) {
/*  81 */       ((Party)this._partyLeaderMap.get(party.GetLeader())).resetWaitingTime();
/*     */     } else {
/*  83 */       this._partyLeaderMap.put(party.GetLeader(), party);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void serverTransfer(ServerTransferEvent event) {
/*  89 */     Party party = (Party)this._partyLeaderMap.get(event.getPlayer().getName());
/*     */     
/*  91 */     if (party != null)
/*     */     {
/*  93 */       party.switchedServer();
/*     */       
/*  95 */       RedisPartyData data = new RedisPartyData(party, this._serverName);
/*  96 */       data.setTargetServers(new String[] { event.getServer() });
/*  97 */       data.publish();
/*     */       
/*  99 */       for (Player player : party.GetPlayersOnline())
/*     */       {
/* 101 */         if (player != event.getPlayer())
/*     */         {
/* 103 */           this._portal.sendPlayerToServer(player, event.getServer(), false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void PlayerJoin(PlayerJoinEvent event)
/*     */   {
/*     */     try
/*     */     {
/* 114 */       for (Party party : this._partyLeaderMap.values())
/*     */       {
/* 116 */         party.PlayerJoin(event.getPlayer());
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 121 */       throw ex;
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void PlayerQuit(PlayerQuitEvent event)
/*     */   {
/* 128 */     for (Party party : this._partyLeaderMap.values())
/*     */     {
/* 130 */       party.PlayerQuit(event.getPlayer());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event)
/*     */   {
/* 137 */     if (event.getType() != UpdateType.FAST) {
/* 138 */       return;
/*     */     }
/* 140 */     ExpireParties();
/*     */     
/* 142 */     for (Party party : this._partyLeaderMap.values())
/*     */     {
/* 144 */       party.ExpireInvitees();
/* 145 */       party.UpdateScoreboard();
/*     */     }
/*     */   }
/*     */   
/*     */   public void ExpireParties()
/*     */   {
/* 151 */     Iterator<Party> partyIterator = this._partyLeaderMap.values().iterator();
/*     */     
/* 153 */     while (partyIterator.hasNext())
/*     */     {
/* 155 */       Party party = (Party)partyIterator.next();
/*     */       
/*     */ 
/* 158 */       if (party.IsDead())
/*     */       {
/* 160 */         party.Announce("Your Party has been closed.");
/* 161 */         partyIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Party GetParty(Player player)
/*     */   {
/* 168 */     for (Party party : this._partyLeaderMap.values())
/*     */     {
/* 170 */       if (party.GetPlayers().contains(player.getName()))
/*     */       {
/* 172 */         return party;
/*     */       }
/*     */     }
/*     */     
/* 176 */     return null;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\party\PartyManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */