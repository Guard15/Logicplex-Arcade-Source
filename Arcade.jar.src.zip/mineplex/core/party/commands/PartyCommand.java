/*     */ package mineplex.core.party.commands;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import mineplex.core.command.CommandBase;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.jsonchat.ChildJsonMessage;
/*     */ import mineplex.core.common.jsonchat.ClickEvent;
/*     */ import mineplex.core.common.jsonchat.JsonMessage;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.party.Party;
/*     */ import mineplex.core.party.PartyManager;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.preferences.UserPreferences;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class PartyCommand extends CommandBase<PartyManager>
/*     */ {
/*     */   public PartyCommand(PartyManager plugin)
/*     */   {
/*  25 */     super(plugin, Rank.ALL, new String[] {"party", "z" });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void Execute(Player caller, String[] args)
/*     */   {
/*  32 */     if ((args == null) || (args.length == 0) || ((args[0].equalsIgnoreCase("kick")) && (args.length < 2)))
/*     */     {
/*  34 */       UtilPlayer.message(caller, F.main("Party", "Listing Party Commands;"));
/*  35 */       UtilPlayer.message(caller, F.value(0, "/party <Player>", "Join/Create/Invite Player"));
/*  36 */       UtilPlayer.message(caller, F.value(0, "/party leave", "Leave your current Party"));
/*  37 */       UtilPlayer.message(caller, F.value(0, "/party kick <Player>", "Kick player from your Party"));
/*     */       
/*  39 */       return;
/*     */     }
/*     */     
/*     */ 
/*  43 */     Party party = ((PartyManager)this.Plugin).GetParty(caller);
/*     */     
/*     */ 
/*  46 */     if (args[0].equalsIgnoreCase("leave"))
/*     */     {
/*  48 */       if (party == null)
/*     */       {
/*  50 */         UtilPlayer.message(caller, F.main("Party", "You are not in a Party."));
/*     */       }
/*     */       else
/*     */       {
/*  54 */         party.LeaveParty(caller);
/*     */       }
/*     */       
/*  57 */       return;
/*     */     }
/*     */     
/*     */ 
/*  61 */     if (args[0].equalsIgnoreCase("kick"))
/*     */     {
/*  63 */       if (party == null)
/*     */       {
/*  65 */         UtilPlayer.message(caller, F.main("Party", "You are not in a Party."));
/*     */ 
/*     */ 
/*     */       }
/*  69 */       else if (party.GetLeader().equals(caller.getName()))
/*     */       {
/*  71 */         String target = UtilPlayer.searchCollection(caller, args[1], party.GetPlayers(), "Party ", true);
/*  72 */         if (target == null) {
/*  73 */           return;
/*     */         }
/*  75 */         if (target.equals(caller.getName()))
/*     */         {
/*  77 */           UtilPlayer.message(caller, F.main("Party", "You cannot kick yourself from the Party."));
/*  78 */           return;
/*     */         }
/*     */         
/*  81 */         party.KickParty(target);
/*     */       }
/*     */       else
/*     */       {
/*  85 */         UtilPlayer.message(caller, F.main("Party", "You are not the Party Leader."));
/*     */       }
/*     */       
/*     */ 
/*  89 */       return;
/*     */     }
/*     */     
/*     */ 
/*  93 */     Player target = UtilPlayer.searchOnline(caller, args[0], true);
/*  94 */     if (target == null) {
/*  95 */       return;
/*     */     }
/*  97 */     if (target.equals(caller))
/*     */     {
/*  99 */       UtilPlayer.message(caller, F.main("Party", "You cannot Party with yourself."));
/* 100 */       return;
/*     */     }
/*     */     
/*     */ 
/* 104 */     if (!((UserPreferences)((PartyManager)this.Plugin).getPreferenceManager().Get(target)).PartyRequests)
/*     */     {
/* 106 */       UtilPlayer.message(
/* 107 */         caller, 
/* 108 */         F.main("Party", "You may not party with " + F.name(UtilEnt.getName(target)) + 
/* 109 */         "! They are not accepting party requests!"));
/* 110 */       return;
/*     */     }
/*     */     
/*     */ 
/* 114 */     if (party != null)
/*     */     {
/* 116 */       if (party.GetPlayers().size() + party.GetInvitees().size() >= 16)
/*     */       {
/* 118 */         UtilPlayer.message(caller, "Your party cannot be larger than 16 players.");
/* 119 */         caller.playSound(caller.getLocation(), Sound.NOTE_BASS, 1.0F, 1.5F);
/*     */ 
/*     */       }
/* 122 */       else if (party.GetPlayers().contains(target.getName()))
/*     */       {
/* 124 */         UtilPlayer.message(caller, F.main("Party", F.name(target.getName()) + " is already in the Party."));
/* 125 */         caller.playSound(caller.getLocation(), Sound.NOTE_BASS, 1.0F, 1.5F);
/*     */ 
/*     */       }
/* 128 */       else if (party.GetInvitees().contains(target.getName()))
/*     */       {
/* 130 */         UtilPlayer.message(caller, F.main("Party", F.name(target.getName()) + " is already invited to the Party."));
/* 131 */         caller.playSound(caller.getLocation(), Sound.NOTE_BASS, 1.0F, 1.5F);
/*     */ 
/*     */       }
/* 134 */       else if (party.GetLeader().equals(caller.getName()))
/*     */       {
/* 136 */         party.InviteParty(target, ((PartyManager)this.Plugin).GetParty(target) != null);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 141 */         party.Announce(F.name(caller.getName()) + " suggested " + F.name(target.getName()) + " be invited to the Party.");
/*     */         
/* 143 */         Player leader = Bukkit.getPlayerExact(party.GetLeader());
/*     */         
/* 145 */         if (leader != null)
/*     */         {
/* 147 */           ChildJsonMessage message = new JsonMessage("").extra(C.mHead + "Party> " + C.mBody + "Type ");
/*     */           
/* 149 */           message.add(F.link("/party " + target.getName())).click(ClickEvent.RUN_COMMAND, "/party " + target.getName());
/*     */           
/* 151 */           message.add(C.mBody + " to invite them.");
/*     */           
/* 153 */           message.sendToPlayer(leader);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 160 */       Party targetParty = ((PartyManager)this.Plugin).GetParty(target);
/*     */       
/*     */ 
/* 163 */       if (targetParty != null)
/*     */       {
/* 165 */         if (targetParty.GetInvitees().contains(caller.getName()))
/*     */         {
/* 167 */           targetParty.JoinParty(caller);
/* 168 */           return;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 173 */       party = ((PartyManager)this.Plugin).CreateParty(caller);
/* 174 */       party.InviteParty(target, ((PartyManager)this.Plugin).GetParty(target) != null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\party\commands\PartyCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */