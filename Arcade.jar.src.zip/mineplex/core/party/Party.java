/*     */ package mineplex.core.party;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.jsonchat.ChildJsonMessage;
/*     */ import mineplex.core.common.jsonchat.ClickEvent;
/*     */ import mineplex.core.common.jsonchat.JsonMessage;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.party.redis.RedisPartyData;
/*     */ import mineplex.serverdata.Region;
/*     */ import mineplex.serverdata.commands.TransferCommand;
/*     */ import mineplex.serverdata.data.ServerGroup;
/*     */ import mineplex.serverdata.servers.ServerManager;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scoreboard.Objective;
/*     */ import org.bukkit.scoreboard.Score;
/*     */ import org.bukkit.scoreboard.Scoreboard;
/*     */ import org.bukkit.scoreboard.ScoreboardManager;
/*     */ import org.bukkit.scoreboard.Team;
/*     */ 
/*     */ public class Party
/*     */ {
/*     */   private PartyManager _manager;
/*     */   private boolean _isHub;
/*     */   private String _creator;
/*     */   private String _previousServer;
/*  40 */   private ArrayList<String> _players = new ArrayList();
/*  41 */   private NautHashMap<String, Long> _invitee = new NautHashMap();
/*     */   
/*     */   private Scoreboard _scoreboard;
/*     */   private Objective _scoreboardObj;
/*  45 */   private ArrayList<String> _scoreboardLast = new ArrayList();
/*     */   
/*  47 */   private long _partyOfflineTimer = -1L;
/*  48 */   private long _informNewLeaderTimer = -1L;
/*     */   
/*     */   public Party(PartyManager manager, RedisPartyData partyData)
/*     */   {
/*  52 */     this(manager);
/*     */     
/*     */ 
/*  55 */     this._creator = partyData.getLeader();
/*  56 */     this._previousServer = partyData.getPreviousServer();
/*     */   }
/*     */   
/*     */   public Party(PartyManager manager)
/*     */   {
/*  61 */     this._manager = manager;
/*  62 */     Region region = manager.getPlugin().getConfig().getBoolean("serverstatus.us") ? Region.US : Region.EU;
/*  63 */     String groupName = manager.getPlugin().getConfig().getString("serverstatus.group");
/*     */     
/*  65 */     ServerGroup serverGroup = ServerManager.getServerRepository(region).getServerGroup(groupName);
/*     */     
/*  67 */     if (serverGroup == null) {
/*  68 */       return;
/*     */     }
/*  70 */     this._isHub = (!serverGroup.getArcadeGroup());
/*     */     
/*  72 */     if (this._isHub)
/*     */     {
/*     */ 
/*  75 */       this._scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
/*  76 */       this._scoreboardObj = this._scoreboard.registerNewObjective("Party", "dummy");
/*  77 */       this._scoreboardObj.setDisplaySlot(org.bukkit.scoreboard.DisplaySlot.SIDEBAR);
/*     */       
/*  79 */       this._scoreboard.registerNewTeam(ChatColor.GREEN + "Members");
/*     */       
/*     */       Rank[] arrayOfRank;
/*  82 */       int j = (arrayOfRank = Rank.values()).length; for (int i = 0; i < j; i++) { Rank rank = arrayOfRank[i];
/*     */         
/*  84 */         if (rank != Rank.ALL) {
/*  85 */           this._scoreboard.registerNewTeam(rank.Name).setPrefix(rank.GetTag(true, false) + ChatColor.RESET + " ");
/*     */         } else {
/*  87 */           this._scoreboard.registerNewTeam(rank.Name).setPrefix("");
/*     */         }
/*     */       }
/*  90 */       this._scoreboard.registerNewTeam("Party").setPrefix(ChatColor.LIGHT_PURPLE + C.Bold + "Party" + ChatColor.RESET + " ");
/*     */       
/*     */ 
/*  93 */       for (Player player : Bukkit.getOnlinePlayers())
/*     */       {
/*  95 */         this._scoreboard.getTeam(this._manager.GetClients().Get(player).GetRank().Name).addPlayer(player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void JoinParty(Player player)
/*     */   {
/* 103 */     if (this._players.isEmpty())
/*     */     {
/* 105 */       this._players.add(player.getName());
/*     */       
/* 107 */       UtilPlayer.message(player, F.main("Party", "You created a new Party."));
/*     */       
/* 109 */       this._creator = player.getName();
/*     */     }
/*     */     else
/*     */     {
/* 113 */       this._players.add(player.getName());
/* 114 */       this._invitee.remove(player.getName());
/*     */       
/* 116 */       Announce(F.elem(player.getName()) + " has joined the party!");
/*     */     }
/*     */     
/* 119 */     if (this._isHub)
/*     */     {
/* 121 */       this._scoreboard.getTeam("Party").addPlayer(player);
/*     */     }
/*     */   }
/*     */   
/*     */   public void InviteParty(Player player, boolean inviteeInParty)
/*     */   {
/* 127 */     this._invitee.put(player.getName(), Long.valueOf(System.currentTimeMillis()));
/*     */     
/*     */ 
/* 130 */     if (this._players.contains(player.getName()))
/*     */     {
/* 132 */       UtilPlayer.message(player, F.main("Party", F.name(player.getName()) + " is already in the Party."));
/* 133 */       player.playSound(player.getLocation(), Sound.NOTE_BASS, 1.0F, 1.5F);
/*     */     }
/*     */     
/*     */ 
/* 137 */     Announce(F.name(player.getName()) + " has been invited to your Party.");
/*     */     
/*     */ 
/* 140 */     UtilPlayer.message(player, F.main("Party", F.name(GetLeader()) + " invited you to their Party."));
/*     */     
/*     */ 
/* 143 */     if (inviteeInParty)
/*     */     {
/* 145 */       ChildJsonMessage message = new JsonMessage("").extra(C.mHead + "Party> " + C.mBody + "Type ");
/*     */       
/* 147 */       message.add(F.link("/party leave")).click(ClickEvent.RUN_COMMAND, "/party leave");
/*     */       
/* 149 */       message.add(C.mBody + " then ");
/*     */       
/* 151 */       message.add(F.link("/party " + GetLeader())).click(ClickEvent.RUN_COMMAND, "/party " + GetLeader());
/*     */       
/* 153 */       message.add(C.mBody + " to join.");
/*     */       
/* 155 */       message.sendToPlayer(player);
/*     */     }
/*     */     else
/*     */     {
/* 159 */       ChildJsonMessage message = new JsonMessage("").extra(C.mHead + "Party> " + C.mBody + "Type ");
/*     */       
/* 161 */       message.add(F.link("/party " + GetLeader())).click(ClickEvent.RUN_COMMAND, "/party " + GetLeader());
/*     */       
/* 163 */       message.add(C.mBody + " to join.");
/*     */       
/* 165 */       message.sendToPlayer(player);
/*     */     }
/*     */     
/* 168 */     player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0F, 1.5F);
/*     */   }
/*     */   
/*     */ 
/*     */   public void LeaveParty(Player player)
/*     */   {
/* 174 */     Announce(F.name(player.getName()) + " has left the Party.");
/*     */     
/* 176 */     boolean leader = player.equals(GetLeader());
/*     */     
/* 178 */     this._players.remove(player.getName());
/*     */     
/* 180 */     if (this._isHub)
/*     */     {
/*     */ 
/* 183 */       this._scoreboard.getTeam(this._manager.GetClients().Get(player).GetRank().Name).addPlayer(player);
/*     */     }
/*     */     
/* 186 */     if ((leader) && (this._players.size() > 0))
/*     */     {
/* 188 */       Announce("Party Leadership passed on to " + F.name(GetLeader()) + ".");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void KickParty(String player)
/*     */   {
/* 195 */     Announce(F.name(player) + " was kicked from the Party.");
/*     */     
/* 197 */     this._players.remove(player);
/*     */   }
/*     */   
/*     */   public void PlayerJoin(Player player)
/*     */   {
/* 202 */     if (this._isHub)
/*     */     {
/*     */ 
/* 205 */       if (this._players.contains(player.getName())) {
/* 206 */         this._scoreboard.getTeam("Party").addPlayer(player);
/* 207 */       } else if (this._manager.GetClients().Get(player) != null) {
/* 208 */         this._scoreboard.getTeam(this._manager.GetClients().Get(player).GetRank().Name).addPlayer(player);
/*     */       }
/*     */     }
/* 211 */     if (this._creator.equals(player.getName()))
/*     */     {
/* 213 */       this._players.remove(player.getName());
/* 214 */       this._players.add(0, player.getName());
/*     */       
/* 216 */       if (this._informNewLeaderTimer < System.currentTimeMillis())
/*     */       {
/* 218 */         Announce("Party Leadership returned to " + F.name(GetLeader()) + ".");
/*     */       }
/*     */       
/* 221 */       if (this._previousServer != null)
/*     */       {
/* 223 */         for (String playerName : this._players)
/*     */         {
/* 225 */           Player p = Bukkit.getPlayerExact(playerName);
/*     */           
/* 227 */           if (p == null)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 232 */             TransferCommand transferCommand = new TransferCommand(
/* 233 */               new mineplex.serverdata.commands.ServerTransfer(playerName, this._manager.getServerName()));
/*     */             
/* 235 */             transferCommand.setTargetServers(new String[] { this._previousServer });
/*     */             
/* 237 */             transferCommand.publish();
/*     */           }
/*     */         }
/* 240 */         this._previousServer = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void PlayerQuit(Player player)
/*     */   {
/* 248 */     if (player.getName().equals(GetLeader()))
/*     */     {
/* 250 */       this._players.remove(player.getName());
/* 251 */       this._players.add(player.getName());
/*     */       
/* 253 */       if (this._informNewLeaderTimer < System.currentTimeMillis())
/*     */       {
/* 255 */         Announce("Party Leadership passed on to " + F.name(GetLeader()) + ".");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void Announce(String message)
/*     */   {
/* 262 */     for (String name : this._players)
/*     */     {
/* 264 */       Player player = UtilPlayer.searchExact(name);
/*     */       
/* 266 */       if ((player != null) && (player.isOnline()))
/*     */       {
/* 268 */         UtilPlayer.message(player, F.main("Party", message));
/* 269 */         player.playSound(player.getLocation(), Sound.NOTE_PLING, 1.0F, 1.5F);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void ExpireInvitees()
/*     */   {
/* 276 */     Iterator<String> inviteeIterator = this._invitee.keySet().iterator();
/*     */     
/* 278 */     while (inviteeIterator.hasNext())
/*     */     {
/* 280 */       String name = (String)inviteeIterator.next();
/*     */       
/* 282 */       if (UtilTime.elapsed(((Long)this._invitee.get(name)).longValue(), 60000L))
/*     */       {
/* 284 */         Announce(F.name(name) + " did not respond to the Party invite.");
/* 285 */         inviteeIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public String GetLeader()
/*     */   {
/* 292 */     if (this._players.isEmpty()) {
/* 293 */       return this._creator;
/*     */     }
/* 295 */     return (String)this._players.get(0);
/*     */   }
/*     */   
/*     */   public Collection<String> GetPlayers()
/*     */   {
/* 300 */     return this._players;
/*     */   }
/*     */   
/*     */   public Collection<Player> GetPlayersOnline()
/*     */   {
/* 305 */     ArrayList<Player> players = new ArrayList();
/*     */     
/* 307 */     for (String name : this._players)
/*     */     {
/* 309 */       Player player = UtilPlayer.searchExact(name);
/* 310 */       if (player != null) {
/* 311 */         players.add(player);
/*     */       }
/*     */     }
/* 314 */     return players;
/*     */   }
/*     */   
/*     */   public Collection<String> GetInvitees()
/*     */   {
/* 319 */     return this._invitee.keySet();
/*     */   }
/*     */   
/*     */   public void UpdateScoreboard()
/*     */   {
/* 324 */     if (this._isHub)
/*     */     {
/* 326 */       this._scoreboardObj.setDisplayName(GetLeader() + "'s Party");
/*     */       
/*     */ 
/* 329 */       for (String pastLine : this._scoreboardLast)
/* 330 */         this._scoreboard.resetScores(pastLine);
/* 331 */       this._scoreboardLast.clear();
/*     */       
/* 333 */       int i = 16;
/*     */       
/*     */       String name;
/* 336 */       for (int j = 0; j < this._players.size(); j++)
/*     */       {
/* 338 */         name = (String)this._players.get(j);
/* 339 */         Player player = UtilPlayer.searchExact(name);
/*     */         
/* 341 */         ChatColor col = ChatColor.GREEN;
/* 342 */         if (player == null) {
/* 343 */           col = ChatColor.RED;
/*     */         }
/* 345 */         String line = col + name;
/*     */         
/* 347 */         if (line.length() > 16) {
/* 348 */           line = line.substring(0, 16);
/*     */         }
/* 350 */         this._scoreboardObj.getScore(line).setScore(i);
/*     */         
/* 352 */         this._scoreboardLast.add(line);
/*     */         
/* 354 */         i--;
/*     */       }
/*     */       
/*     */ 
/* 358 */       for (String name : this._invitee.keySet())
/*     */       {
/* 360 */         int time = 1 + (int)((60000L - (System.currentTimeMillis() - ((Long)this._invitee.get(name)).longValue())) / 1000L);
/*     */         
/* 362 */         String line = time + " " + ChatColor.GRAY + name;
/*     */         
/* 364 */         if (line.length() > 16) {
/* 365 */           line = line.substring(0, 16);
/*     */         }
/* 367 */         this._scoreboardObj.getScore(line).setScore(i);
/*     */         
/* 369 */         this._scoreboardLast.add(line);
/*     */         
/* 371 */         i--;
/*     */       }
/*     */       
/*     */ 
/* 375 */       for (String name : this._players)
/*     */       {
/* 377 */         Player player = UtilPlayer.searchExact(name);
/*     */         
/* 379 */         if (player != null)
/*     */         {
/* 381 */           if (!player.getScoreboard().equals(this._scoreboard))
/*     */           {
/* 383 */             player.setScoreboard(this._scoreboard);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean IsDead()
/*     */   {
/* 392 */     if (this._players.size() == 0) {
/* 393 */       return true;
/*     */     }
/* 395 */     if ((this._players.size() == 1) && (this._invitee.size() == 0)) {
/* 396 */       return true;
/*     */     }
/* 398 */     int online = 0;
/* 399 */     for (String name : this._players)
/*     */     {
/* 401 */       Player player = UtilPlayer.searchExact(name);
/* 402 */       if (player != null) {
/* 403 */         online++;
/*     */       }
/*     */     }
/*     */     
/* 407 */     if (online <= 1)
/*     */     {
/* 409 */       if (this._partyOfflineTimer == -1L)
/*     */       {
/* 411 */         this._partyOfflineTimer = System.currentTimeMillis();
/*     */ 
/*     */ 
/*     */       }
/* 415 */       else if (UtilTime.elapsed(this._partyOfflineTimer, online == 0 ? 5000 : 120000))
/*     */       {
/*     */ 
/* 418 */         return true;
/*     */       }
/*     */       
/*     */     }
/* 422 */     else if (this._partyOfflineTimer > 0L)
/*     */     {
/* 424 */       this._partyOfflineTimer = -1L;
/*     */     }
/*     */     
/* 427 */     return false;
/*     */   }
/*     */   
/*     */   public void resetWaitingTime()
/*     */   {
/* 432 */     this._partyOfflineTimer = -1L;
/*     */   }
/*     */   
/*     */   public void switchedServer()
/*     */   {
/* 437 */     this._informNewLeaderTimer = (System.currentTimeMillis() + 5000L);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\party\Party.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */