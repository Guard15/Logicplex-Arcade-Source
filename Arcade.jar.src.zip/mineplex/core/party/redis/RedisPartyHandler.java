/*    */ package mineplex.core.party.redis;
/*    */ 
/*    */ import mineplex.core.party.Party;
/*    */ import mineplex.core.party.PartyManager;
/*    */ import mineplex.serverdata.commands.CommandCallback;
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ 
/*    */ public class RedisPartyHandler implements CommandCallback
/*    */ {
/*    */   private PartyManager _partyManager;
/*    */   
/*    */   public RedisPartyHandler(PartyManager partyManager)
/*    */   {
/* 14 */     this._partyManager = partyManager;
/*    */   }
/*    */   
/*    */ 
/*    */   public void run(ServerCommand command)
/*    */   {
/* 20 */     final RedisPartyData data = (RedisPartyData)command;
/*    */     
/* 22 */     this._partyManager.getPlugin().getServer().getScheduler().runTask(this._partyManager.getPlugin(), new Runnable()
/*    */     {
/*    */       public void run()
/*    */       {
/* 26 */         RedisPartyHandler.this._partyManager.addParty(new Party(RedisPartyHandler.this._partyManager, data));
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\party\redis\RedisPartyHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */