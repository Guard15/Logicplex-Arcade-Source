/*    */ package mineplex.core.party.redis;
/*    */ 
/*    */ import mineplex.core.party.Party;
/*    */ 
/*    */ public class RedisPartyData extends mineplex.serverdata.commands.ServerCommand
/*    */ {
/*    */   private String[] _players;
/*    */   private String _leader;
/*    */   private String _previousServer;
/*    */   
/*    */   public RedisPartyData(Party party, String previousServer) {
/* 12 */     super(new String[0]);
/*    */     
/* 14 */     this._players = ((String[])party.GetPlayers().toArray(new String[0]));
/* 15 */     this._leader = party.GetLeader();
/* 16 */     this._previousServer = previousServer;
/*    */   }
/*    */   
/*    */   public String getPreviousServer()
/*    */   {
/* 21 */     return this._previousServer;
/*    */   }
/*    */   
/*    */   public String[] getPlayers()
/*    */   {
/* 26 */     return this._players;
/*    */   }
/*    */   
/*    */   public String getLeader()
/*    */   {
/* 31 */     return this._leader;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\party\redis\RedisPartyData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */