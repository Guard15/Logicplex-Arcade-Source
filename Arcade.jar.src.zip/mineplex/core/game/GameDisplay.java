/*     */ package mineplex.core.game;
/*     */ 
/*     */ import org.bukkit.Material;
/*     */ 
/*     */ public enum GameDisplay
/*     */ {
/*   7 */   BaconBrawl(
/*   8 */     "Bacon Brawl", Material.PORK, (byte)0, GameCategory.ARCADE, 1), 
/*   9 */   Barbarians("A Barbarians Life", Material.WOOD_AXE, (byte)0, GameCategory.EXTRA, 2), 
/*  10 */   Bridge("The Bridges", Material.IRON_PICKAXE, (byte)0, GameCategory.SURVIVAL, 3), 
/*  11 */   CastleSiege("Castle Siege", Material.DIAMOND_CHESTPLATE, (byte)0, GameCategory.CLASSICS, 4), 
/*  12 */   ChampionsDominate("Champions Domination", "Champions", Material.BEACON, (byte)0, GameCategory.CHAMPIONS, 6), 
/*  13 */   ChampionsTDM(
/*  14 */     "Champions TDM", "Champions", Material.GOLD_SWORD, (byte)0, GameCategory.CHAMPIONS, 5), 
/*  15 */   Christmas("Christmas Chaos", Material.SNOW_BALL, (byte)0, GameCategory.CLASSICS, 8), 
/*  16 */   DeathTag("Death Tag", Material.SKULL_ITEM, (byte)0, GameCategory.ARCADE, 9), 
/*  17 */   DragonEscape("Dragon Escape", Material.DRAGON_EGG, (byte)0, GameCategory.ARCADE, 10), 
/*  18 */   DragonEscapeTeams("Dragon Escape Teams", Material.DRAGON_EGG, (byte)0, GameCategory.TEAM_VARIANT, 11), 
/*  19 */   DragonRiders("Dragon Riders", Material.DRAGON_EGG, (byte)0, GameCategory.ARCADE, 12), 
/*  20 */   Dragons("Dragons", Material.ENDER_STONE, (byte)0, GameCategory.ARCADE, 13), 
/*  21 */   DragonsTeams("Dragons Teams", Material.ENDER_STONE, (byte)0, GameCategory.TEAM_VARIANT, 14), 
/*  22 */   Draw("Draw My Thing", Material.BOOK_AND_QUILL, (byte)0, GameCategory.CLASSICS, 15), 
/*  23 */   Evolution("Evolution", Material.EMERALD, (byte)0, GameCategory.ARCADE, 16), 
/*  24 */   Gravity(
/*  25 */     "Gravity", Material.ENDER_PORTAL, (byte)0, GameCategory.EXTRA, 18), 
/*  26 */   Halloween("Halloween Horror", Material.PUMPKIN, (byte)0, GameCategory.CLASSICS, 19), 
/*  27 */   HideSeek("Block Hunt", Material.GRASS, (byte)0, GameCategory.CLASSICS, 20), 
/*  28 */   HoleInTheWall("Hole in the Wall", Material.STAINED_GLASS, (byte)2, GameCategory.ARCADE, 52), 
/*  29 */   Horse("Horseback", Material.IRON_BARDING, (byte)0, GameCategory.ARCADE, 21), 
/*  30 */   Lobbers("Bomb Lobbers", Material.FIREBALL, (byte)0, GameCategory.ARCADE, 53), 
/*  31 */   Micro("Micro Battle", Material.LAVA_BUCKET, (byte)0, GameCategory.ARCADE, 24), 
/*  32 */   MilkCow("Milk the Cow", Material.MILK_BUCKET, (byte)0, GameCategory.ARCADE, 27), 
/*  33 */   MineStrike("MineStrike", Material.TNT, (byte)0, GameCategory.CHAMPIONS, 25), 
/*  34 */   MineWare("MineWare", Material.PAPER, (byte)0, GameCategory.EXTRA, 26), 
/*  35 */   OldMineWare("Old MineWare", Material.PAPER, (byte)0, GameCategory.EXTRA, 26), 
/*  36 */   Paintball("Super Paintball", Material.ENDER_PEARL, (byte)0, GameCategory.ARCADE, 28), 
/*  37 */   Quiver("One in the Quiver", Material.ARROW, (byte)0, GameCategory.ARCADE, 29), 
/*  38 */   QuiverTeams("One in the Quiver Teams", Material.ARROW, (byte)0, GameCategory.TEAM_VARIANT, 30), 
/*  39 */   Runner("Runner", Material.LEATHER_BOOTS, (byte)0, GameCategory.ARCADE, 31), 
/*  40 */   SearchAndDestroy("Search and Destroy", Material.TNT, (byte)0, GameCategory.SURVIVAL, 32), 
/*  41 */   Sheep("Sheep Quest", Material.WOOL, (byte)4, GameCategory.ARCADE, 33), 
/*     */   
/*  43 */   Smash("Super Smash Mobs", Material.SKULL_ITEM, (byte)4, GameCategory.CLASSICS, 34), 
/*  44 */   SmashDomination("Super Smash Mobs Domination", "Super Smash Mobs", Material.SKULL_ITEM, (byte)4, GameCategory.EXTRA, 36), 
/*  45 */   SmashTeams("Super Smash Mobs Teams", "Super Smash Mobs", Material.SKULL_ITEM, (byte)4, GameCategory.TEAM_VARIANT, 35), 
/*  46 */   Snake("Snake", Material.WOOL, (byte)0, GameCategory.ARCADE, 37), 
/*  47 */   SneakyAssassins("Sneaky Assassins", Material.INK_SACK, (byte)0, GameCategory.ARCADE, 38), 
/*  48 */   SnowFight("Snow Fight", Material.SNOW_BALL, (byte)0, GameCategory.EXTRA, 39), 
/*  49 */   Spleef("Super Spleef", Material.IRON_SPADE, (byte)0, GameCategory.ARCADE, 40), 
/*  50 */   SpleefTeams("Super Spleef Teams", Material.IRON_SPADE, (byte)0, GameCategory.TEAM_VARIANT, 41), 
/*  51 */   SquidShooter("Squid Shooter", Material.FIREWORK_CHARGE, (byte)0, GameCategory.ARCADE, 43), 
/*  52 */   Stacker("Super Stacker", Material.BOWL, (byte)0, GameCategory.ARCADE, 42), 
/*  53 */   SurvivalGames("Survival Games", Material.IRON_SWORD, (byte)0, GameCategory.SURVIVAL, 22), 
/*  54 */   SurvivalGamesTeams("Survival Games", Material.IRON_SWORD, (byte)0, GameCategory.TEAM_VARIANT, 23), 
/*  55 */   Tug("Tug of Wool", Material.WHEAT, (byte)0, GameCategory.ARCADE, 44), 
/*  56 */   TurfWars("Turf Wars", Material.STAINED_CLAY, (byte)14, GameCategory.ARCADE, 45), 
/*  57 */   UHC("Ultra Hardcore", Material.GOLDEN_APPLE, (byte)0, GameCategory.SURVIVAL, 46), 
/*  58 */   WitherAssault("Wither Assault", Material.SKULL_ITEM, (byte)1, GameCategory.ARCADE, 47), 
/*  59 */   Wizards("Wizards", Material.BLAZE_ROD, (byte)0, GameCategory.SURVIVAL, 48), 
/*  60 */   ZombieSurvival("Zombie Survival", Material.SKULL_ITEM, (byte)2, GameCategory.SURVIVAL, 49), 
/*     */   
/*  62 */   Build("Master Builders", Material.WOOD, (byte)0, GameCategory.CLASSICS, 50), 
/*  63 */   Cards("Craft Against Humanity", Material.MAP, (byte)0, GameCategory.CLASSICS, 51), 
/*  64 */   Skywars("Skywars", "Skywars", Material.FEATHER, (byte)0, GameCategory.SURVIVAL, 52), 
/*  65 */   SkywarsTeams("Skywars Teams", "Skywars", Material.FEATHER, (byte)5, GameCategory.TEAM_VARIANT, 53), 
/*     */   
/*  67 */   Event("Mineplex Event", Material.CAKE, (byte)0, GameCategory.EVENT, 999);
/*     */   
/*     */   String _name;
/*     */   String _lobbyName;
/*     */   Material _mat;
/*     */   byte _data;
/*     */   GameCategory _gameCategory;
/*     */   private int _gameId;
/*     */   
/*  76 */   public int getGameId() { return this._gameId; }
/*     */   
/*     */   private GameDisplay(String name, Material mat, byte data, GameCategory gameCategory, int gameId)
/*     */   {
/*  80 */     this(name, name, mat, data, gameCategory, gameId);
/*     */   }
/*     */   
/*     */   private GameDisplay(String name, String lobbyName, Material mat, byte data, GameCategory gameCategory, int gameId)
/*     */   {
/*  85 */     this._name = name;
/*  86 */     this._lobbyName = lobbyName;
/*  87 */     this._mat = mat;
/*  88 */     this._data = data;
/*  89 */     this._gameCategory = gameCategory;
/*  90 */     this._gameId = gameId;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/*  95 */     return this._name;
/*     */   }
/*     */   
/*     */   public String getLobbyName()
/*     */   {
/* 100 */     return this._lobbyName;
/*     */   }
/*     */   
/*     */   public Material getMaterial()
/*     */   {
/* 105 */     return this._mat;
/*     */   }
/*     */   
/*     */   public byte getMaterialData()
/*     */   {
/* 110 */     return this._data;
/*     */   }
/*     */   
/*     */   public GameCategory getGameCategory()
/*     */   {
/* 115 */     return this._gameCategory;
/*     */   }
/*     */   
/*     */   public static GameDisplay matchName(String name)
/*     */   {
/*     */     GameDisplay[] arrayOfGameDisplay;
/* 121 */     int j = (arrayOfGameDisplay = values()).length; for (int i = 0; i < j; i++) { GameDisplay display = arrayOfGameDisplay[i];
/*     */       
/* 123 */       if (display.getName().equalsIgnoreCase(name))
/* 124 */         return display;
/*     */     }
/* 126 */     return null;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\game\GameDisplay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */