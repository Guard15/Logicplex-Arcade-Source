package mineplex.core.game;

public enum GameCategory
{
  SURVIVAL,  CLASSICS,  CHAMPIONS,  ARCADE,  EVENT,  TEAM_VARIANT,  EXTRA;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\game\GameCategory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */