/*     */ package mineplex.core.friend;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniDbClientPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.jsonchat.ChildJsonMessage;
/*     */ import mineplex.core.common.jsonchat.JsonMessage;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.friend.command.DeleteFriend;
/*     */ import mineplex.core.friend.command.FriendsDisplay;
/*     */ import mineplex.core.friend.data.FriendData;
/*     */ import mineplex.core.friend.data.FriendRepository;
/*     */ import mineplex.core.friend.data.FriendStatus;
/*     */ import mineplex.core.portal.Portal;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.preferences.UserPreferences;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class FriendManager extends MiniDbClientPlugin<FriendData>
/*     */ {
/*  39 */   private static FriendSorter _friendSorter = new FriendSorter();
/*     */   
/*     */   private PreferencesManager _preferenceManager;
/*     */   private FriendRepository _repository;
/*     */   private Portal _portal;
/*     */   
/*     */   public FriendManager(JavaPlugin plugin, CoreClientManager clientManager, PreferencesManager preferences, Portal portal)
/*     */   {
/*  47 */     super("Friends", plugin, clientManager);
/*     */     
/*  49 */     this._preferenceManager = preferences;
/*  50 */     this._repository = new FriendRepository(plugin);
/*  51 */     this._portal = portal;
/*     */   }
/*     */   
/*     */   public PreferencesManager getPreferenceManager()
/*     */   {
/*  56 */     return this._preferenceManager;
/*     */   }
/*     */   
/*     */   public Portal getPortal()
/*     */   {
/*  61 */     return this._portal;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/*  67 */     addCommand(new mineplex.core.friend.command.AddFriend(this));
/*  68 */     addCommand(new DeleteFriend(this));
/*  69 */     addCommand(new FriendsDisplay(this));
/*     */   }
/*     */   
/*     */ 
/*     */   protected FriendData AddPlayer(String player)
/*     */   {
/*  75 */     return new FriendData();
/*     */   }
/*     */   
/*     */   @org.bukkit.event.EventHandler
/*     */   public void updateFriends(UpdateEvent event)
/*     */   {
/*  81 */     if ((event.getType() != UpdateType.SLOW) || (Bukkit.getOnlinePlayers().size() == 0)) {
/*  82 */       return;
/*     */     }
/*  84 */     final Player[] onlinePlayers = UtilServer.getPlayers();
/*     */     
/*  86 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(this._plugin, new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  90 */         final NautHashMap<String, FriendData> newData = FriendManager.this._repository.getFriendsForAll(onlinePlayers);
/*     */         
/*  92 */         Bukkit.getServer().getScheduler().runTask(FriendManager.this._plugin, new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/*  96 */             for (Player player : )
/*     */             {
/*  98 */               if (newData.containsKey(player.getUniqueId().toString()))
/*     */               {
/* 100 */                 ((FriendData)FriendManager.this.Get(player)).setFriends(((FriendData)newData.get(player.getUniqueId().toString())).getFriends());
/*     */               }
/*     */               else
/*     */               {
/* 104 */                 ((FriendData)FriendManager.this.Get(player)).getFriends().clear();
/*     */               }
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void addFriend(final Player caller, final String name)
/*     */   {
/* 115 */     if (caller.getName().equalsIgnoreCase(name))
/*     */     {
/* 117 */       caller.sendMessage(F.main(getName(), ChatColor.GRAY + "You cannot add yourself as a friend"));
/* 118 */       return;
/*     */     }
/*     */     
/* 121 */     boolean update = false;
/* 122 */     for (FriendStatus status : ((FriendData)Get(caller)).getFriends())
/*     */     {
/* 124 */       if (status.Name.equalsIgnoreCase(name))
/*     */       {
/* 126 */         if ((status.Status == FriendStatusType.Pending) || (status.Status == FriendStatusType.Blocked))
/*     */         {
/* 128 */           update = true;
/* 129 */           break;
/*     */         }
/* 131 */         if (status.Status == FriendStatusType.Denied)
/*     */         {
/* 133 */           caller.sendMessage(F.main(getName(), ChatColor.GREEN + name + ChatColor.GRAY + 
/* 134 */             " has denied your friend request."));
/* 135 */           return;
/*     */         }
/* 137 */         if (status.Status == FriendStatusType.Accepted)
/*     */         {
/* 139 */           caller.sendMessage(F.main(getName(), "You are already friends with " + ChatColor.GREEN + name));
/* 140 */           return;
/*     */         }
/* 142 */         if (status.Status == FriendStatusType.Sent)
/*     */         {
/* 144 */           caller.sendMessage(F.main(getName(), ChatColor.GREEN + name + ChatColor.GRAY + 
/* 145 */             " has yet to respond to your friend request."));
/* 146 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 151 */     final boolean updateFinal = update;
/*     */     
/* 153 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 157 */         if (updateFinal)
/*     */         {
/* 159 */           FriendManager.this._repository.updateFriend(caller.getName(), name, "Accepted");
/* 160 */           FriendManager.this._repository.updateFriend(name, caller.getName(), "Accepted");
/*     */           
/* 162 */           Bukkit.getServer().getScheduler().runTask(FriendManager.this._plugin, new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 166 */               Iterator<FriendStatus> statusIterator = ((FriendData)FriendManager.this.Get(this.val$caller)).getFriends().iterator();
/* 167 */               while (statusIterator.hasNext())
/*     */               {
/* 169 */                 FriendStatus status = (FriendStatus)statusIterator.next();
/*     */                 
/* 171 */                 if (status.Name.equalsIgnoreCase(this.val$name))
/*     */                 {
/* 173 */                   status.Status = FriendStatusType.Accepted;
/* 174 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           });
/*     */         }
/*     */         else
/*     */         {
/* 182 */           FriendManager.this._repository.addFriend(caller, name);
/*     */           
/* 184 */           Bukkit.getServer().getScheduler().runTask(FriendManager.this._plugin, new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 188 */               Iterator<FriendStatus> statusIterator = ((FriendData)FriendManager.this.Get(this.val$caller)).getFriends().iterator();
/* 189 */               while (statusIterator.hasNext())
/*     */               {
/* 191 */                 FriendStatus status = (FriendStatus)statusIterator.next();
/*     */                 
/* 193 */                 if (status.Name.equalsIgnoreCase(this.val$name))
/*     */                 {
/* 195 */                   status.Status = FriendStatusType.Sent;
/* 196 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           });
/*     */         }
/*     */         
/* 203 */         Bukkit.getServer().getScheduler().runTask(FriendManager.this._plugin, new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 207 */             if (this.val$updateFinal) {
/* 208 */               this.val$caller.sendMessage(F.main(FriendManager.this.getName(), "You and " + ChatColor.GREEN + this.val$name + ChatColor.GRAY + 
/* 209 */                 " are now friends!"));
/*     */             } else {
/* 211 */               this.val$caller.sendMessage(F.main(FriendManager.this.getName(), "Added " + ChatColor.GREEN + this.val$name + ChatColor.GRAY + 
/* 212 */                 " to your friends list!"));
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void removeFriend(final Player caller, final String name) {
/* 221 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 225 */         FriendManager.this._repository.removeFriend(caller.getName(), name);
/* 226 */         FriendManager.this._repository.removeFriend(name, caller.getName());
/*     */         
/* 228 */         Bukkit.getServer().getScheduler().runTask(FriendManager.this._plugin, new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 232 */             Iterator<FriendStatus> statusIterator = ((FriendData)FriendManager.this.Get(this.val$caller)).getFriends().iterator();
/* 233 */             while (statusIterator.hasNext())
/*     */             {
/* 235 */               FriendStatus status = (FriendStatus)statusIterator.next();
/*     */               
/* 237 */               if (status.Name.equalsIgnoreCase(this.val$name))
/*     */               {
/* 239 */                 status.Status = FriendStatusType.Blocked;
/* 240 */                 break;
/*     */               }
/*     */             }
/*     */             
/* 244 */             this.val$caller.sendMessage(F.main(FriendManager.this.getName(), "Deleted " + ChatColor.GREEN + this.val$name + ChatColor.GRAY + 
/* 245 */               " from your friends list!"));
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void showFriends(Player caller)
/*     */   {
/* 254 */     boolean isStaff = this.ClientManager.Get(caller).GetRank().Has(Rank.HELPER);
/* 255 */     boolean gotAFriend = false;
/* 256 */     List<FriendStatus> friendStatuses = ((FriendData)Get(caller)).getFriends();
/* 257 */     Collections.sort(friendStatuses, _friendSorter);
/*     */     
/* 259 */     caller.sendMessage(C.cAqua + C.Strike + "======================[" + ChatColor.RESET + C.cWhite + C.Bold + "Friends" + 
/* 260 */       ChatColor.RESET + C.cAqua + C.Strike + "]======================");
/*     */     
/* 262 */     ArrayList<ChildJsonMessage> sentLines = new ArrayList();
/* 263 */     ArrayList<ChildJsonMessage> pendingLines = new ArrayList();
/* 264 */     ArrayList<ChildJsonMessage> onlineLines = new ArrayList();
/* 265 */     ArrayList<ChildJsonMessage> offlineLines = new ArrayList();
/*     */     
/* 267 */     for (FriendStatus friend : friendStatuses)
/*     */     {
/* 269 */       if ((friend.Status != FriendStatusType.Blocked) && (friend.Status != FriendStatusType.Denied))
/*     */       {
/*     */ 
/* 272 */         if ((((UserPreferences)this._preferenceManager.Get(caller)).PendingFriendRequests) || (friend.Status != FriendStatusType.Pending))
/*     */         {
/*     */ 
/* 275 */           gotAFriend = true;
/*     */           
/* 277 */           ChildJsonMessage message = new JsonMessage("").color("white").extra("").color("white");
/*     */           
/* 279 */           if (friend.Status == FriendStatusType.Accepted)
/*     */           {
/*     */ 
/* 282 */             if (friend.Online)
/*     */             {
/* 284 */               if ((friend.ServerName.contains("Staff")) || (friend.ServerName.contains("CUST")))
/*     */               {
/* 286 */                 if ((isStaff) && (friend.ServerName.contains("Staff")))
/*     */                 {
/* 288 */                   message.add("Teleport").color("green").bold().click("run_command", "/server " + friend.ServerName).hover("show_text", "Teleport to " + friend.Name + "'s server.");
/*     */                 } else {
/* 290 */                   message.add("No Teleport").color("yellow").bold();
/*     */                 }
/*     */               }
/*     */               else {
/* 294 */                 message.add("Teleport").color("green").bold().click("run_command", "/server " + friend.ServerName).hover("show_text", "Teleport to " + friend.Name + "'s server.");
/*     */               }
/* 296 */               message.add(" - ").color("white");
/* 297 */               message.add("Delete").color("red").bold().click("run_command", "/unfriend " + friend.Name)
/* 298 */                 .hover("show_text", "Remove " + friend.Name + " from your friends list.");
/* 299 */               message.add(" - ").color("white");
/* 300 */               message.add(friend.Name).color(friend.Online ? "green" : "gray");
/* 301 */               message.add(" - ").color("white");
/*     */               
/* 303 */               if ((friend.ServerName.contains("Staff")) || (friend.ServerName.contains("CUST")))
/*     */               {
/* 305 */                 if ((isStaff) && (friend.ServerName.contains("Staff"))) {
/* 306 */                   message.add(friend.ServerName).color("dark_green");
/*     */                 } else {
/* 308 */                   message.add("Private Staff Server").color("dark_green");
/*     */                 }
/*     */               } else {
/* 311 */                 message.add(friend.ServerName).color("dark_green");
/*     */               }
/* 313 */               onlineLines.add(message);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 319 */               message.add("Delete").color("red").bold().click("run_command", "/unfriend " + friend.Name).hover("show_text", "Remove " + friend.Name + " from your friends list.");
/* 320 */               message.add(" - ").color("white");
/* 321 */               message.add(friend.Name).color(friend.Online ? "green" : "gray");
/* 322 */               message.add(" - ").color("white");
/* 323 */               message.add("Offline for ").color("gray").add(mineplex.core.common.util.UtilTime.MakeStr(friend.LastSeenOnline)).color("gray");
/*     */               
/* 325 */               offlineLines.add(message);
/*     */             }
/*     */             
/*     */           }
/* 329 */           else if (friend.Status == FriendStatusType.Pending)
/*     */           {
/*     */ 
/* 332 */             message.add("Accept").color("green").bold().click("run_command", "/friend " + friend.Name).hover("show_text", "Accept " + friend.Name + "'s friend request.");
/* 333 */             message.add(" - ").color("white");
/* 334 */             message.add("Deny").color("red").bold().click("run_command", "/unfriend " + friend.Name)
/* 335 */               .hover("show_text", "Deny " + friend.Name + "'s friend request.");
/* 336 */             message.add(" - ").color("white");
/* 337 */             message.add(friend.Name + " Requested Friendship").color("gray");
/*     */             
/* 339 */             pendingLines.add(message);
/*     */ 
/*     */           }
/* 342 */           else if (friend.Status == FriendStatusType.Sent)
/*     */           {
/*     */ 
/* 345 */             message.add("Cancel").color("red").bold().click("run_command", "/unfriend " + friend.Name).hover("show_text", "Cancel friend request to " + friend.Name);
/* 346 */             message.add(" - ").color("white");
/* 347 */             message.add(friend.Name + " Friendship Request").color("gray");
/*     */             
/* 349 */             sentLines.add(message);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 354 */     for (JsonMessage msg : sentLines) {
/* 355 */       msg.sendToPlayer(caller);
/*     */     }
/* 357 */     for (JsonMessage msg : offlineLines) {
/* 358 */       msg.sendToPlayer(caller);
/*     */     }
/* 360 */     for (JsonMessage msg : pendingLines) {
/* 361 */       msg.sendToPlayer(caller);
/*     */     }
/* 363 */     for (JsonMessage msg : onlineLines) {
/* 364 */       msg.sendToPlayer(caller);
/*     */     }
/* 366 */     if (!gotAFriend)
/*     */     {
/* 368 */       caller.sendMessage(" ");
/* 369 */       caller.sendMessage("Welcome to your Friends List!");
/* 370 */       caller.sendMessage(" ");
/* 371 */       caller.sendMessage("To add friends, type " + C.cGreen + "/friend <Player Name>");
/* 372 */       caller.sendMessage(" ");
/* 373 */       caller.sendMessage("Type " + C.cGreen + "/friend" + ChatColor.RESET + " at any time to interact with your friends!");
/* 374 */       caller.sendMessage(" ");
/*     */     }
/*     */     
/* 377 */     ChildJsonMessage message = new JsonMessage("").extra(C.cAqua + C.Strike + "======================");
/*     */     
/* 379 */     message.add(C.cDAqua + "Toggle GUI").click("run_command", "/friendsdisplay");
/*     */     
/* 381 */     message.hover("show_text", C.cAqua + "Toggle friends to display in a inventory");
/*     */     
/* 383 */     message.add(C.cAqua + C.Strike + "======================");
/*     */     
/* 385 */     message.sendToPlayer(caller);
/*     */   }
/*     */   
/*     */   public boolean isFriends(Player player, String friend)
/*     */   {
/* 390 */     FriendData friendData = (FriendData)Get(player);
/*     */     
/* 392 */     for (FriendStatus friendStatus : friendData.getFriends())
/*     */     {
/* 394 */       if (friendStatus.Name.equalsIgnoreCase(friend))
/*     */       {
/* 396 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 400 */     return false;
/*     */   }
/*     */   
/*     */   public void processLoginResultSet(String playerName, int accountId, ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 406 */     Set(playerName, this._repository.loadClientInformation(resultSet));
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQuery(int accountId, String uuid, String name)
/*     */   {
/* 412 */     return 
/* 413 */       "SELECT tA.Name, status, tA.lastLogin, now() FROM accountFriend INNER Join accounts AS fA ON fA.uuid = uuidSource INNER JOIN accounts AS tA ON tA.uuid = uuidTarget WHERE uuidSource = '" + uuid + "';";
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\FriendManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */