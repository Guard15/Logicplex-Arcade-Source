package mineplex.core.friend.data;

import mineplex.core.friend.FriendStatusType;

public class FriendStatus
{
  public String Name;
  public String ServerName;
  public boolean Online;
  public long LastSeenOnline;
  public FriendStatusType Status;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\data\FriendStatus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */