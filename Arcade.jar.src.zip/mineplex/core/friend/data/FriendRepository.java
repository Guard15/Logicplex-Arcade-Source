/*     */ package mineplex.core.friend.data;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.database.DBPool;
/*     */ import mineplex.core.database.RepositoryBase;
/*     */ import mineplex.core.database.ResultSetCallable;
/*     */ import mineplex.core.database.column.Column;
/*     */ import mineplex.core.database.column.ColumnVarChar;
/*     */ import mineplex.core.friend.FriendStatusType;
/*     */ import mineplex.serverdata.Region;
/*     */ import mineplex.serverdata.data.DataRepository;
/*     */ import mineplex.serverdata.data.PlayerStatus;
/*     */ import mineplex.serverdata.redis.RedisDataRepository;
/*     */ import mineplex.serverdata.servers.ServerManager;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class FriendRepository extends RepositoryBase
/*     */ {
/*  29 */   private static String CREATE_FRIEND_TABLE = "CREATE TABLE IF NOT EXISTS accountFriend (id INT NOT NULL AUTO_INCREMENT, uuidSource VARCHAR(100), uuidTarget VARCHAR(100), status VARCHAR(100), PRIMARY KEY (id), UNIQUE INDEX uuidIndex (uuidSource, uuidTarget));";
/*  30 */   private static String RETRIEVE_MULTIPLE_FRIEND_RECORDS = "SELECT uuidSource, tA.Name, status, tA.lastLogin, now() FROM accountFriend INNER Join accounts AS fA ON fA.uuid = uuidSource INNER JOIN accounts AS tA ON tA.uuid = uuidTarget WHERE uuidSource IN ";
/*  31 */   private static String ADD_FRIEND_RECORD = "INSERT INTO accountFriend (uuidSource, uuidTarget, status, created) SELECT fA.uuid AS uuidSource, tA.uuid AS uuidTarget, ?, now() FROM accounts as fA LEFT JOIN accounts AS tA ON tA.name = ? WHERE fA.name = ?;";
/*  32 */   private static String UPDATE_MUTUAL_RECORD = "UPDATE accountFriend AS aF INNER JOIN accounts as fA ON aF.uuidSource = fA.uuid INNER JOIN accounts AS tA ON aF.uuidTarget = tA.uuid SET aF.status = ? WHERE tA.name = ? AND fA.name = ?;";
/*  33 */   private static String DELETE_FRIEND_RECORD = "DELETE aF FROM accountFriend AS aF INNER JOIN accounts as fA ON aF.uuidSource = fA.uuid INNER JOIN accounts AS tA ON aF.uuidTarget = tA.uuid WHERE fA.name = ? AND tA.name = ?;";
/*     */   
/*     */   private DataRepository<PlayerStatus> _repository;
/*     */   
/*     */ 
/*     */   public FriendRepository(JavaPlugin plugin)
/*     */   {
/*  40 */     super(plugin, DBPool.ACCOUNT);
/*     */     
/*  42 */     this._repository = new RedisDataRepository(ServerManager.getMasterConnection(), ServerManager.getSlaveConnection(), 
/*  43 */       Region.currentRegion(), PlayerStatus.class, "playerStatus");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initialize()
/*     */   {
/*  49 */     executeUpdate(CREATE_FRIEND_TABLE, new Column[0]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void update() {}
/*     */   
/*     */ 
/*     */   public boolean addFriend(Player caller, String name)
/*     */   {
/*  59 */     int rowsAffected = executeUpdate(ADD_FRIEND_RECORD, new Column[] { new ColumnVarChar("status", 100, "Sent"), new ColumnVarChar("name", 100, name), new ColumnVarChar("name", 100, caller.getName()) });
/*     */     
/*  61 */     if (rowsAffected > 0) {
/*  62 */       return executeUpdate(ADD_FRIEND_RECORD, new Column[] { new ColumnVarChar("status", 100, "Pending"), new ColumnVarChar("name", 100, caller.getName()), new ColumnVarChar("uuid", 100, name) }) > 0;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */   
/*     */   public boolean updateFriend(String caller, String name, String status)
/*     */   {
/*  69 */     return executeUpdate(UPDATE_MUTUAL_RECORD, new Column[] { new ColumnVarChar("status", 100, status), new ColumnVarChar("uuid", 100, name), new ColumnVarChar("name", 100, caller) }) > 0;
/*     */   }
/*     */   
/*     */   public boolean removeFriend(String caller, String name)
/*     */   {
/*  74 */     int rowsAffected = executeUpdate(DELETE_FRIEND_RECORD, new Column[] { new ColumnVarChar("name", 100, name), new ColumnVarChar("name", 100, caller) });
/*     */     
/*  76 */     if (rowsAffected > 0) {
/*  77 */       return executeUpdate(DELETE_FRIEND_RECORD, new Column[] { new ColumnVarChar("name", 100, caller), new ColumnVarChar("uuid", 100, name) }) > 0;
/*     */     }
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public NautHashMap<String, FriendData> getFriendsForAll(Player... players)
/*     */   {
/*  84 */     final NautHashMap<String, FriendData> friends = new NautHashMap();
/*     */     
/*  86 */     StringBuilder stringBuilder = new StringBuilder();
/*  87 */     stringBuilder.append(RETRIEVE_MULTIPLE_FRIEND_RECORDS + "(");
/*     */     Player[] arrayOfPlayer;
/*  89 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/*  91 */       stringBuilder.append("'" + player.getUniqueId() + "', ");
/*     */     }
/*     */     
/*  94 */     stringBuilder.delete(stringBuilder.length() - 2, stringBuilder.length());
/*  95 */     stringBuilder.append(");");
/*     */     
/*  97 */     executeQuery(stringBuilder.toString(), new ResultSetCallable()
/*     */     {
/*     */       public void processResultSet(ResultSet resultSet) throws SQLException
/*     */       {
/* 101 */         Set<FriendData> friendDatas = new HashSet();
/* 102 */         String uuidSource; while (resultSet.next())
/*     */         {
/* 104 */           FriendStatus friend = new FriendStatus();
/*     */           
/* 106 */           uuidSource = resultSet.getString(1);
/* 107 */           friend.Name = resultSet.getString(2);
/* 108 */           friend.Status = ((FriendStatusType)Enum.valueOf(FriendStatusType.class, resultSet.getString(3)));
/* 109 */           friend.LastSeenOnline = (resultSet.getTimestamp(5).getTime() - resultSet.getTimestamp(4).getTime());
/*     */           
/* 111 */           if (!friends.containsKey(uuidSource)) {
/* 112 */             friends.put(uuidSource, new FriendData());
/*     */           }
/* 114 */           ((FriendData)friends.get(uuidSource)).getFriends().add(friend);
/*     */           
/* 116 */           friendDatas.add((FriendData)friends.get(uuidSource));
/*     */         }
/*     */         
/*     */ 
/* 120 */         for (FriendData friendData : friendDatas)
/*     */         {
/* 122 */           FriendRepository.this.loadFriendStatuses(friendData); } } }, new Column[0]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 127 */     return friends;
/*     */   }
/*     */   
/*     */   public FriendData loadClientInformation(ResultSet resultSet) throws SQLException
/*     */   {
/* 132 */     FriendData friendData = new FriendData();
/*     */     
/* 134 */     while (resultSet.next())
/*     */     {
/* 136 */       FriendStatus friend = new FriendStatus();
/*     */       
/* 138 */       friend.Name = resultSet.getString(1);
/* 139 */       friend.Status = ((FriendStatusType)Enum.valueOf(FriendStatusType.class, resultSet.getString(2)));
/* 140 */       friend.LastSeenOnline = (resultSet.getTimestamp(4).getTime() - resultSet.getTimestamp(3).getTime());
/* 141 */       friend.ServerName = null;
/* 142 */       friend.Online = (friend.ServerName != null);
/* 143 */       friendData.getFriends().add(friend);
/*     */     }
/*     */     
/* 146 */     loadFriendStatuses(friendData);
/*     */     
/* 148 */     return friendData;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadFriendStatuses(FriendData friendData)
/*     */   {
/* 159 */     Set<String> friendNames = new HashSet();
/* 160 */     for (FriendStatus status : friendData.getFriends())
/*     */     {
/* 162 */       friendNames.add(status.Name);
/*     */     }
/*     */     
/*     */ 
/* 166 */     Collection<PlayerStatus> statuses = this._repository.getElements(friendNames);
/*     */     
/*     */ 
/* 169 */     Object playerStatuses = new HashMap();
/* 170 */     for (PlayerStatus status : statuses)
/*     */     {
/* 172 */       ((Map)playerStatuses).put(status.getName(), status);
/*     */     }
/*     */     
/*     */ 
/* 176 */     for (FriendStatus friend : friendData.getFriends())
/*     */     {
/* 178 */       PlayerStatus status = (PlayerStatus)((Map)playerStatuses).get(friend.Name);
/* 179 */       friend.Online = (status != null);
/* 180 */       friend.ServerName = (friend.Online ? status.getServer() : null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String fetchPlayerServer(String playerName)
/*     */   {
/* 191 */     PlayerStatus status = (PlayerStatus)this._repository.getElement(playerName);
/*     */     
/* 193 */     return status == null ? null : status.getServer();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\data\FriendRepository.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */