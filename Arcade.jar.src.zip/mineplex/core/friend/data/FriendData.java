/*    */ package mineplex.core.friend.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import mineplex.core.friend.ui.FriendsGUI;
/*    */ 
/*    */ public class FriendData
/*    */ {
/*  8 */   private ArrayList<FriendStatus> _friends = new ArrayList();
/*    */   private FriendsGUI _friendsPage;
/*    */   
/*    */   public ArrayList<FriendStatus> getFriends()
/*    */   {
/* 13 */     return this._friends;
/*    */   }
/*    */   
/*    */   public void setFriends(ArrayList<FriendStatus> newFriends)
/*    */   {
/* 18 */     this._friends = newFriends;
/* 19 */     updateGui();
/*    */   }
/*    */   
/*    */   private void updateGui()
/*    */   {
/* 24 */     if (this._friendsPage != null)
/*    */     {
/* 26 */       this._friendsPage.updateGui();
/*    */     }
/*    */   }
/*    */   
/*    */   public void setGui(FriendsGUI friendsPage)
/*    */   {
/* 32 */     this._friendsPage = friendsPage;
/*    */   }
/*    */   
/*    */   public FriendsGUI getGui()
/*    */   {
/* 37 */     return this._friendsPage;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\data\FriendData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */