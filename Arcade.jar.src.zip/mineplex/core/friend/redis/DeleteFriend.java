/*    */ package mineplex.core.friend.redis;
/*    */ 
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ 
/*    */ public class DeleteFriend
/*    */   extends ServerCommand {
/*    */   private String _deleter;
/*    */   private String _deleted;
/*    */   
/* 10 */   public String getDeleter() { return this._deleter; }
/* 11 */   public String getDeleted() { return this._deleted; }
/*    */   
/* 13 */   public DeleteFriend(String deleter, String deleted) { super(new String[0]);
/*    */     
/* 15 */     this._deleter = deleter;
/* 16 */     this._deleted = deleted;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\redis\DeleteFriend.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */