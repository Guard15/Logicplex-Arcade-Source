/*    */ package mineplex.core.friend.redis;
/*    */ 
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ 
/*    */ public class FriendRequest
/*    */   extends ServerCommand {
/*    */   private String _requester;
/*    */   private String _requested;
/*    */   
/* 10 */   public String getRequester() { return this._requester; }
/* 11 */   public String getRequested() { return this._requested; }
/*    */   
/* 13 */   public FriendRequest(String requester, String requested) { super(new String[0]);
/*    */     
/* 15 */     this._requester = requester;
/* 16 */     this._requested = requested;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\redis\FriendRequest.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */