package mineplex.core.friend.redis;

public class FriendRequestHandler {}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\redis\FriendRequestHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */