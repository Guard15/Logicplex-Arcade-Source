/*    */ package mineplex.core.friend;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import mineplex.core.friend.data.FriendStatus;
/*    */ 
/*    */ public class FriendSorter
/*    */   implements Comparator<FriendStatus>
/*    */ {
/*    */   public int compare(FriendStatus a, FriendStatus b)
/*    */   {
/* 11 */     if ((a.Online) && (!b.Online))
/*    */     {
/* 13 */       return 1;
/*    */     }
/*    */     
/* 16 */     if ((b.Online) && (!a.Online))
/*    */     {
/* 18 */       return -1;
/*    */     }
/*    */     
/*    */ 
/* 22 */     if ((a.Online) && (b.Online))
/*    */     {
/* 24 */       if ((a.Status == FriendStatusType.Accepted) && (b.Status != FriendStatusType.Accepted))
/* 25 */         return 1;
/* 26 */       if ((b.Status == FriendStatusType.Accepted) && (a.Status != FriendStatusType.Accepted)) {
/* 27 */         return -1;
/*    */       }
/* 29 */       if (a.Name.compareTo(b.Name) > 0)
/* 30 */         return 1;
/* 31 */       if (b.Name.compareTo(a.Name) > 0) {
/* 32 */         return -1;
/*    */       }
/*    */     }
/* 35 */     if (a.LastSeenOnline < b.LastSeenOnline) {
/* 36 */       return 1;
/*    */     }
/* 38 */     if (b.LastSeenOnline < a.LastSeenOnline) {
/* 39 */       return -1;
/*    */     }
/* 41 */     return 0;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\FriendSorter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */