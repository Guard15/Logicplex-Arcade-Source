/*    */ package mineplex.core.friend.command;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.friend.FriendManager;
/*    */ import mineplex.core.friend.ui.FriendsGUI;
/*    */ import mineplex.core.preferences.PreferencesManager;
/*    */ import mineplex.core.preferences.UserPreferences;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class FriendsDisplay extends CommandBase<FriendManager>
/*    */ {
/*    */   public FriendsDisplay(FriendManager plugin)
/*    */   {
/* 16 */     super(plugin, Rank.ALL, new String[] { "friendsdisplay" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 22 */     UserPreferences preferences = (UserPreferences)((FriendManager)this.Plugin).getPreferenceManager().Get(caller);
/*    */     
/* 24 */     preferences.friendDisplayInventoryUI = (!preferences.friendDisplayInventoryUI);
/*    */     
/* 26 */     ((FriendManager)this.Plugin).getPreferenceManager().savePreferences(caller);
/*    */     
/* 28 */     caller.playSound(caller.getLocation(), Sound.NOTE_PLING, 1.0F, 1.6F);
/*    */     
/* 30 */     if (preferences.friendDisplayInventoryUI)
/*    */     {
/* 32 */       new FriendsGUI((FriendManager)this.Plugin, caller);
/*    */     }
/*    */     else
/*    */     {
/* 36 */       ((FriendManager)this.Plugin).showFriends(caller);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\command\FriendsDisplay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */