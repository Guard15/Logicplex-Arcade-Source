/*    */ package mineplex.core.friend.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.friend.FriendManager;
/*    */ import mineplex.core.friend.ui.FriendsGUI;
/*    */ import mineplex.core.preferences.UserPreferences;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class AddFriend extends CommandBase<FriendManager>
/*    */ {
/*    */   public AddFriend(FriendManager plugin)
/*    */   {
/* 15 */     super(plugin, mineplex.core.common.Rank.ALL, new String[] { "friends", "friend", "f" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 21 */     if ((args == null) || (args.length < 1))
/*    */     {
/* 23 */       if (((UserPreferences)((FriendManager)this.Plugin).getPreferenceManager().Get(caller)).friendDisplayInventoryUI)
/*    */       {
/* 25 */         new FriendsGUI((FriendManager)this.Plugin, caller);
/*    */       }
/*    */       else
/*    */       {
/* 29 */         ((FriendManager)this.Plugin).showFriends(caller);
/*    */       }
/*    */       
/*    */     }
/*    */     else {
/* 34 */       this.CommandCenter.GetClientManager().checkPlayerName(caller, args[0], new Callback()
/*    */       {
/*    */         public void run(String result)
/*    */         {
/* 38 */           if (result != null)
/*    */           {
/* 40 */             ((FriendManager)AddFriend.this.Plugin).addFriend(caller, result);
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\command\AddFriend.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */