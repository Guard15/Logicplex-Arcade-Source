/*    */ package mineplex.core.friend.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.command.CommandCenter;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.friend.FriendManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class DeleteFriend extends CommandBase<FriendManager>
/*    */ {
/*    */   public DeleteFriend(FriendManager plugin)
/*    */   {
/* 15 */     super(plugin, mineplex.core.common.Rank.ALL, new String[] { "unfriend" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null) {
/* 22 */       F.main(((FriendManager)this.Plugin).getName(), "You need to include a player's name.");
/*    */     }
/*    */     else {
/* 25 */       this.CommandCenter.GetClientManager().checkPlayerName(caller, args[0], new Callback()
/*    */       {
/*    */         public void run(String result)
/*    */         {
/* 29 */           if (result != null)
/*    */           {
/* 31 */             ((FriendManager)DeleteFriend.this.Plugin).removeFriend(caller, result);
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\command\DeleteFriend.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */