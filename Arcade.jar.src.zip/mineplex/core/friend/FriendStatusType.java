package mineplex.core.friend;

public enum FriendStatusType
{
  Sent,  Pending,  Accepted,  Denied,  Blocked;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\FriendStatusType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */