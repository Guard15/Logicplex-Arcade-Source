/*     */ package mineplex.core.friend.ui;
/*     */ 
/*     */ import mineplex.core.command.CommandCenter;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.friend.FriendManager;
/*     */ import mineplex.core.itemstack.ItemBuilder;
/*     */ import net.minecraft.server.v1_7_R4.ContainerAnvil;
/*     */ import net.minecraft.server.v1_7_R4.EntityHuman;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.ItemStack;
/*     */ import net.minecraft.server.v1_7_R4.Slot;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ 
/*     */ public class AddFriendPage implements org.bukkit.event.Listener
/*     */ {
/*     */   private FriendManager _friends;
/*     */   private Player _player;
/*     */   private Inventory _currentInventory;
/*     */   
/*     */   private class AnvilContainer extends ContainerAnvil
/*     */   {
/*     */     private String n;
/*     */     
/*     */     public AnvilContainer(EntityHuman entity)
/*     */     {
/*  33 */       super(entity.world, 0, 0, 0, entity);
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean a(EntityHuman entityhuman)
/*     */     {
/*  39 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */     public void a(String origString)
/*     */     {
/*  45 */       this.n = origString;
/*  46 */       AddFriendPage.this._itemName = origString;
/*     */       
/*  48 */       if (getSlot(2).hasItem())
/*     */       {
/*  50 */         ItemStack itemstack = getSlot(2).getItem();
/*     */         
/*  52 */         if (org.apache.commons.lang.StringUtils.isBlank(origString)) {
/*  53 */           itemstack.t();
/*     */         }
/*     */         else {
/*  56 */           itemstack.c(this.n);
/*     */         }
/*     */       }
/*     */       
/*  60 */       e();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   private String _itemName = "";
/*     */   private boolean _searching;
/*     */   
/*     */   public AddFriendPage(FriendManager friends, Player player)
/*     */   {
/*  73 */     this._player = player;
/*  74 */     this._friends = friends;
/*     */     
/*  76 */     openInventory();
/*  77 */     friends.registerEvents(this);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClose(InventoryCloseEvent event)
/*     */   {
/*  83 */     if (event.getPlayer() == this._player)
/*     */     {
/*  85 */       unregisterListener();
/*     */     }
/*     */   }
/*     */   
/*     */   public void unregisterListener()
/*     */   {
/*  91 */     this._currentInventory.clear();
/*  92 */     org.bukkit.event.HandlerList.unregisterAll(this);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent event)
/*     */   {
/*  98 */     if (event.getRawSlot() < 3)
/*     */     {
/* 100 */       event.setCancelled(true);
/*     */       
/* 102 */       if (event.getRawSlot() == 2)
/*     */       {
/* 104 */         if ((this._itemName.length() > 1) && (!this._searching))
/*     */         {
/* 106 */           this._searching = true;
/* 107 */           final String name = this._itemName;
/*     */           
/* 109 */           CommandCenter.Instance.GetClientManager().checkPlayerName(this._player, this._itemName, new mineplex.core.common.util.Callback()
/*     */           {
/*     */             public void run(String result)
/*     */             {
/* 113 */               AddFriendPage.this._searching = false;
/*     */               
/* 115 */               if (result != null)
/*     */               {
/* 117 */                 AddFriendPage.this._friends.addFriend(AddFriendPage.this._player, result);
/* 118 */                 AddFriendPage.this._player.playSound(AddFriendPage.this._player.getLocation(), Sound.NOTE_PLING, 1.0F, 1.6F);
/*     */                 
/* 120 */                 AddFriendPage.this.unregisterListener();
/* 121 */                 new FriendsGUI(AddFriendPage.this._friends, AddFriendPage.this._player);
/*     */               }
/*     */               else
/*     */               {
/* 125 */                 AddFriendPage.this._currentInventory.setItem(
/* 126 */                   2, 
/* 127 */                   new ItemBuilder(Material.PAPER).setTitle(
/* 128 */                   C.cYellow + "0" + C.cGray + " matches for [" + C.cYellow + name + C.cGray + "]")
/* 129 */                   .build());
/* 130 */                 AddFriendPage.this._player.playSound(AddFriendPage.this._player.getLocation(), Sound.ITEM_BREAK, 1.0F, 0.6F);
/*     */               }
/*     */             }
/*     */           });
/*     */         }
/*     */         else
/*     */         {
/* 137 */           this._player.playSound(this._player.getLocation(), Sound.ITEM_BREAK, 1.0F, 0.6F);
/*     */         }
/*     */       }
/*     */     }
/* 141 */     else if (event.isShiftClick())
/*     */     {
/* 143 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void openInventory()
/*     */   {
/* 149 */     this._player.closeInventory();
/*     */     
/* 151 */     EntityPlayer p = ((CraftPlayer)this._player).getHandle();
/*     */     
/* 153 */     AnvilContainer container = new AnvilContainer(p);
/* 154 */     int c = p.nextContainerCounter();
/*     */     
/* 156 */     net.minecraft.server.v1_7_R4.PacketPlayOutOpenWindow packet = new net.minecraft.server.v1_7_R4.PacketPlayOutOpenWindow(c, 8, "Repairing", 0, true);
/*     */     
/* 158 */     p.playerConnection.sendPacket(packet);
/*     */     
/*     */ 
/* 161 */     p.activeContainer = container;
/*     */     
/*     */ 
/* 164 */     p.activeContainer.windowId = c;
/*     */     
/*     */ 
/* 167 */     p.activeContainer.addSlotListener(p);
/* 168 */     this._currentInventory = container.getBukkitView().getTopInventory();
/*     */     
/* 170 */     this._currentInventory.setItem(0, new ItemBuilder(Material.PAPER).setRawTitle("Friend's Name").build());
/* 171 */     this._currentInventory.setItem(2, new ItemBuilder(Material.PAPER).setRawTitle("Search").build());
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\ui\AddFriendPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */