/*     */ package mineplex.core.friend.ui;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.command.CommandCenter;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.friend.FriendManager;
/*     */ import mineplex.core.friend.FriendStatusType;
/*     */ import mineplex.core.friend.data.FriendData;
/*     */ import mineplex.core.friend.data.FriendStatus;
/*     */ import mineplex.core.itemstack.ItemBuilder;
/*     */ import mineplex.core.itemstack.ItemLayout;
/*     */ import mineplex.core.portal.Portal;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.event.CraftEventFactory;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryCloseEvent;
/*     */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class FriendsGUI implements Listener
/*     */ {
/*  40 */   private NautHashMap<Integer, IButton> _buttonMap = new NautHashMap();
/*  41 */   private FriendPage _currentPage = FriendPage.FRIENDS;
/*     */   private FriendPage _previousPage;
/*     */   private Player _player;
/*     */   private FriendManager _plugin;
/*     */   private Inventory _inventory;
/*     */   private int _page;
/*  47 */   private Comparator<FriendStatus> _friendCompare = new Comparator()
/*     */   {
/*     */ 
/*     */     public int compare(FriendStatus o1, FriendStatus o2)
/*     */     {
/*     */ 
/*  53 */       if (o1.Online == o2.Online)
/*     */       {
/*  55 */         return o1.Name.compareToIgnoreCase(o2.Name);
/*     */       }
/*     */       
/*  58 */       if (o1.Online)
/*     */       {
/*  60 */         return -1;
/*     */       }
/*  62 */       return 1;
/*     */     }
/*     */   };
/*     */   
/*     */   public FriendsGUI(FriendManager plugin, Player player)
/*     */   {
/*  68 */     this._plugin = plugin;
/*  69 */     this._player = player;
/*     */     
/*  71 */     buildPage();
/*     */     
/*  73 */     this._plugin.registerEvents(this);
/*     */     
/*  75 */     getFriendData().setGui(this);
/*     */   }
/*     */   
/*     */   private void AddButton(int slot, ItemStack item, IButton button)
/*     */   {
/*  80 */     this._inventory.setItem(slot, item);
/*  81 */     this._buttonMap.put(Integer.valueOf(slot), button);
/*     */   }
/*     */   
/*     */ 
/*     */   public void buildDeleteFriends()
/*     */   {
/*  87 */     ArrayList<FriendStatus> friends = new ArrayList();
/*     */     
/*  89 */     for (FriendStatus friend : getFriendData().getFriends())
/*     */     {
/*  91 */       if (friend.Status == FriendStatusType.Accepted)
/*     */       {
/*  93 */         friends.add(friend);
/*     */       }
/*     */     }
/*     */     
/*  97 */     Collections.sort(friends, this._friendCompare);
/*     */     
/*  99 */     boolean pages = addPages(friends.size(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 103 */         FriendsGUI.this.buildDeleteFriends();
/*     */       }
/*     */     });
/*     */     
/* 107 */     for (int i = 0; i < (pages ? 27 : 36); i++)
/*     */     {
/* 109 */       int friendSlot = this._page * 27 + i;
/* 110 */       int slot = i + 18;
/*     */       
/* 112 */       if (friendSlot >= friends.size())
/*     */       {
/* 114 */         ItemStack item = this._inventory.getItem(slot);
/*     */         
/* 116 */         if ((item == null) || (item.getType() == Material.AIR)) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 122 */         this._inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 128 */         FriendStatus friend = (FriendStatus)friends.get(friendSlot);
/*     */         
/* 130 */         ItemBuilder builder = new ItemBuilder(Material.SKULL_ITEM, 1, (short)(friend.Online ? 3 : 0));
/*     */         
/* 132 */         builder.setTitle(C.cWhite + C.Bold + friend.Name);
/* 133 */         builder.setPlayerHead(friend.Name);
/*     */         
/* 135 */         builder.addLore(new String[] { C.cGray + C.Bold + "Status: " + (friend.Online ? C.cDGreen + "Online" : new StringBuilder(String.valueOf(C.cRed)).append("Offline").toString()) });
/*     */         
/* 137 */         if (friend.Online)
/*     */         {
/* 139 */           builder.addLore(new String[] { C.cGray + C.Bold + "Server: " + C.cYellow + friend.ServerName });
/*     */         }
/*     */         else
/*     */         {
/* 143 */           builder.addLore(new String[] { C.cGray + "Last seen " + UtilTime.MakeStr(friend.LastSeenOnline) + " ago" });
/*     */         }
/*     */         
/* 146 */         builder.addLore(new String[] { "" });
/*     */         
/* 148 */         builder.addLore(new String[] { C.cGray + "Left click to delete from friends" });
/*     */         
/* 150 */         final String name = friend.Name;
/*     */         
/* 152 */         AddButton(slot, builder.build(), new IButton()
/*     */         {
/*     */ 
/*     */           public void onClick(Player player, ClickType clickType)
/*     */           {
/*     */ 
/* 158 */             if (clickType.isLeftClick())
/*     */             {
/* 160 */               CommandCenter.Instance.OnPlayerCommandPreprocess(new PlayerCommandPreprocessEvent(player, "/unfriend " + 
/* 161 */                 name));
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean addPages(int amount, final Runnable runnable) {
/* 170 */     if (amount > 36)
/*     */     {
/* 172 */       if (this._page > 0)
/*     */       {
/* 174 */         AddButton(45, new ItemBuilder(Material.SIGN).setTitle("Previous Page").build(), new IButton()
/*     */         {
/*     */ 
/*     */           public void onClick(Player player, ClickType clickType)
/*     */           {
/*     */ 
/* 180 */             Iterator<Integer> itel = FriendsGUI.this._buttonMap.keySet().iterator();
/*     */             
/* 182 */             while (itel.hasNext())
/*     */             {
/* 184 */               int slot = ((Integer)itel.next()).intValue();
/* 185 */               if (slot > 8)
/*     */               {
/* 187 */                 itel.remove();
/* 188 */                 FriendsGUI.this._inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */               }
/*     */             }
/*     */             
/* 192 */             FriendsGUI.this._page -= 1;
/* 193 */             runnable.run();
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 198 */       if (amount > (this._page + 1) * 27)
/*     */       {
/* 200 */         AddButton(53, new ItemBuilder(Material.SIGN).setTitle("Next Page").build(), new IButton()
/*     */         {
/*     */ 
/*     */           public void onClick(Player player, ClickType clickType)
/*     */           {
/*     */ 
/* 206 */             Iterator<Integer> itel = FriendsGUI.this._buttonMap.keySet().iterator();
/*     */             
/* 208 */             while (itel.hasNext())
/*     */             {
/* 210 */               int slot = ((Integer)itel.next()).intValue();
/* 211 */               if (slot > 8)
/*     */               {
/* 213 */                 itel.remove();
/* 214 */                 FriendsGUI.this._inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */               }
/*     */             }
/*     */             
/* 218 */             FriendsGUI.this._page += 1;
/* 219 */             runnable.run();
/*     */           }
/*     */         });
/*     */       }
/*     */       
/* 224 */       return true;
/*     */     }
/* 226 */     return false;
/*     */   }
/*     */   
/*     */   private void buildFriends()
/*     */   {
/* 231 */     ArrayList<FriendStatus> friends = new ArrayList();
/*     */     
/* 233 */     for (FriendStatus friend : getFriendData().getFriends())
/*     */     {
/* 235 */       if (friend.Status == FriendStatusType.Accepted)
/*     */       {
/* 237 */         friends.add(friend);
/*     */       }
/*     */     }
/*     */     
/* 241 */     Collections.sort(friends, this._friendCompare);
/* 242 */     boolean pages = addPages(friends.size(), new Runnable()
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/*     */ 
/* 248 */         FriendsGUI.this.buildFriends();
/*     */       }
/*     */     });
/*     */     
/* 252 */     for (int i = 0; i < (pages ? 27 : 36); i++)
/*     */     {
/* 254 */       int friendSlot = this._page * 27 + i;
/* 255 */       int slot = i + 18;
/*     */       
/* 257 */       if (friendSlot >= friends.size())
/*     */       {
/* 259 */         ItemStack item = this._inventory.getItem(slot);
/*     */         
/* 261 */         if ((item == null) || (item.getType() == Material.AIR)) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 267 */         this._inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 273 */         FriendStatus friend = (FriendStatus)friends.get(friendSlot);
/*     */         
/* 275 */         ItemBuilder builder = new ItemBuilder(Material.SKULL_ITEM, 1, (short)(friend.Online ? 3 : 0));
/*     */         
/* 277 */         builder.setTitle(C.cWhite + C.Bold + friend.Name);
/* 278 */         builder.setPlayerHead(friend.Name);
/*     */         
/* 280 */         builder.addLore(new String[] { C.cGray + C.Bold + "Status: " + (friend.Online ? C.cDGreen + "Online" : new StringBuilder(String.valueOf(C.cRed)).append("Offline").toString()) });
/*     */         
/* 282 */         if (friend.Online)
/*     */         {
/* 284 */           builder.addLore(new String[] { C.cGray + C.Bold + "Server: " + C.cYellow + friend.ServerName });
/*     */         }
/*     */         else
/*     */         {
/* 288 */           builder.addLore(new String[] { C.cGray + "Last seen " + UtilTime.MakeStr(friend.LastSeenOnline) + " ago" });
/*     */         }
/*     */         
/* 291 */         if (friend.Online)
/*     */         {
/* 293 */           builder.addLore(new String[] { "" });
/* 294 */           builder.addLore(new String[] { C.cGray + "Left click to teleport to their server" });
/*     */           
/* 296 */           final String serverName = friend.ServerName;
/*     */           
/* 298 */           AddButton(slot, builder.build(), new IButton()
/*     */           {
/*     */ 
/*     */             public void onClick(Player player, ClickType clickType)
/*     */             {
/*     */ 
/* 304 */               FriendsGUI.this._plugin.getPortal().sendPlayerToServer(player, serverName);
/*     */             }
/*     */           });
/*     */         }
/*     */         else
/*     */         {
/* 310 */           this._inventory.setItem(slot, builder.build());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateGui() {
/* 317 */     if (this._currentPage == FriendPage.FRIENDS)
/*     */     {
/* 319 */       buildFriends();
/*     */     }
/* 321 */     else if (this._currentPage == FriendPage.FRIEND_REQUESTS)
/*     */     {
/* 323 */       buildRequests();
/*     */     }
/* 325 */     else if (this._currentPage == FriendPage.DELETE_FRIENDS)
/*     */     {
/* 327 */       buildDeleteFriends();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void buildPage()
/*     */   {
/* 334 */     if (this._currentPage != this._previousPage)
/*     */     {
/* 336 */       this._inventory = Bukkit.createInventory(null, 54, this._currentPage.getName());
/*     */     }
/*     */     else
/*     */     {
/* 340 */       this._inventory.setItem(53, new ItemStack(Material.AIR));
/* 341 */       this._inventory.setItem(45, new ItemStack(Material.AIR));
/*     */     }
/*     */     
/* 344 */     this._page = 0;
/* 345 */     this._buttonMap.clear();
/*     */     
/* 347 */     ArrayList<Integer> itemSlots = new ItemLayout(new String[] { "OXOXOXOXO" }).getItemSlots();
/*     */     
/* 349 */     for (int i = 0; i < FriendPage.values().length; i++)
/*     */     {
/* 351 */       final FriendPage page = FriendPage.values()[i];
/*     */       
/* 353 */       ItemStack icon = page == this._currentPage ? 
/*     */       
/* 355 */         new ItemBuilder(page.getIcon()).addEnchantment(UtilInv.getDullEnchantment(), 1).build() : 
/*     */         
/*     */ 
/*     */ 
/* 359 */         page.getIcon();
/*     */       
/* 361 */       AddButton(((Integer)itemSlots.get(i)).intValue(), icon, new IButton()
/*     */       {
/*     */ 
/*     */         public void onClick(Player player, ClickType clickType)
/*     */         {
/*     */ 
/* 367 */           if ((FriendsGUI.this._currentPage != page) || (FriendsGUI.this._page != 0))
/*     */           {
/* 369 */             FriendsGUI.this._currentPage = page;
/* 370 */             FriendsGUI.this.buildPage();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/*     */ 
/* 377 */     if (this._currentPage == FriendPage.FRIENDS)
/*     */     {
/* 379 */       buildFriends();
/*     */     }
/* 381 */     else if (this._currentPage == FriendPage.FRIEND_REQUESTS)
/*     */     {
/* 383 */       buildRequests();
/*     */     }
/* 385 */     else if (this._currentPage == FriendPage.DELETE_FRIENDS)
/*     */     {
/* 387 */       buildDeleteFriends();
/*     */     } else {
/* 389 */       if (this._currentPage == FriendPage.SEND_REQUEST)
/*     */       {
/* 391 */         unregisterListener();
/*     */         
/* 393 */         new AddFriendPage(this._plugin, this._player);
/*     */         
/* 395 */         return;
/*     */       }
/* 397 */       if (this._currentPage == FriendPage.TOGGLE_DISPLAY)
/*     */       {
/* 399 */         this._player.closeInventory();
/*     */         
/* 401 */         CommandCenter.Instance.OnPlayerCommandPreprocess(new PlayerCommandPreprocessEvent(this._player, "/friendsdisplay"));
/*     */         
/* 403 */         return;
/*     */       }
/*     */     }
/* 406 */     if (this._previousPage != this._currentPage)
/*     */     {
/* 408 */       this._previousPage = this._currentPage;
/*     */       
/* 410 */       EntityPlayer nmsPlayer = ((CraftPlayer)this._player).getHandle();
/* 411 */       if (nmsPlayer.activeContainer != nmsPlayer.defaultContainer)
/*     */       {
/*     */ 
/* 414 */         CraftEventFactory.handleInventoryCloseEvent(nmsPlayer);
/* 415 */         nmsPlayer.m();
/*     */       }
/*     */       
/* 418 */       this._player.openInventory(this._inventory);
/*     */     }
/*     */   }
/*     */   
/*     */   private void buildRequests()
/*     */   {
/* 424 */     ArrayList<FriendStatus> friends = new ArrayList();
/*     */     
/* 426 */     for (FriendStatus friend : getFriendData().getFriends())
/*     */     {
/* 428 */       if ((friend.Status == FriendStatusType.Sent) || (friend.Status == FriendStatusType.Pending))
/*     */       {
/* 430 */         friends.add(friend);
/*     */       }
/*     */     }
/*     */     
/* 434 */     Collections.sort(friends, new Comparator()
/*     */     {
/*     */ 
/*     */       public int compare(FriendStatus o1, FriendStatus o2)
/*     */       {
/*     */ 
/* 440 */         if (o1.Status == o2.Status)
/*     */         {
/* 442 */           return o1.Name.compareToIgnoreCase(o2.Name);
/*     */         }
/*     */         
/* 445 */         if (o1.Status == FriendStatusType.Sent)
/*     */         {
/* 447 */           return -1;
/*     */         }
/*     */         
/* 450 */         return 1;
/*     */       }
/*     */       
/* 453 */     });
/* 454 */     boolean pages = addPages(friends.size(), new Runnable()
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/*     */ 
/* 460 */         FriendsGUI.this.buildRequests();
/*     */       }
/*     */     });
/*     */     
/* 464 */     for (int i = 0; i < (pages ? 27 : 36); i++)
/*     */     {
/* 466 */       int friendSlot = this._page * 27 + i;
/* 467 */       final int slot = i + 18;
/*     */       
/* 469 */       if (friendSlot >= friends.size())
/*     */       {
/* 471 */         ItemStack item = this._inventory.getItem(slot);
/*     */         
/* 473 */         if ((item == null) || (item.getType() == Material.AIR)) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 479 */         this._inventory.setItem(slot, new ItemStack(Material.AIR));
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 485 */         FriendStatus friend = (FriendStatus)friends.get(friendSlot);
/*     */         
/*     */ 
/*     */ 
/* 489 */         final boolean isSender = friend.Status == FriendStatusType.Sent;
/*     */         ItemBuilder builder;
/* 491 */         if (isSender)
/*     */         {
/* 493 */           ItemBuilder builder = new ItemBuilder(Material.ENDER_PEARL);
/*     */           
/* 495 */           builder.setTitle(C.cGray + "Friend request to " + C.cWhite + C.Bold + friend.Name);
/*     */         }
/*     */         else
/*     */         {
/* 499 */           builder = new ItemBuilder(Material.PAPER);
/*     */           
/* 501 */           builder.setTitle(C.cGray + "Friend request from " + C.cWhite + C.Bold + friend.Name);
/*     */         }
/*     */         
/* 504 */         builder.addLore(new String[] { "" });
/*     */         
/* 506 */         builder.addLore(new String[] {C.cGray + (isSender ? "C" : "Left c") + "lick to " + (isSender ? "cancel" : "accept") + 
/* 507 */           " friend request" });
/*     */         
/* 509 */         if (!isSender)
/*     */         {
/* 511 */           builder.addLore(new String[] { C.cGray + "Right click to refuse friend request" });
/*     */         }
/*     */         
/* 514 */         final String name = friend.Name;
/*     */         
/* 516 */         AddButton(slot, builder.build(), new IButton()
/*     */         {
/*     */ 
/*     */           public void onClick(Player player, ClickType clickType)
/*     */           {
/*     */ 
/* 522 */             if ((isSender) || (clickType.isRightClick()))
/*     */             {
/* 524 */               FriendsGUI.this._plugin.removeFriend(FriendsGUI.this._player, name);
/*     */               
/*     */ 
/*     */ 
/* 528 */               FriendsGUI.this._inventory.setItem(slot, new ItemStack(Material.AIR));
/* 529 */               FriendsGUI.this._buttonMap.remove(Integer.valueOf(slot));
/*     */             }
/* 531 */             else if ((!isSender) && (clickType.isLeftClick()))
/*     */             {
/* 533 */               FriendsGUI.this._plugin.addFriend(FriendsGUI.this._player, name);
/*     */               
/*     */ 
/*     */ 
/* 537 */               FriendsGUI.this._inventory.setItem(slot, new ItemStack(Material.AIR));
/* 538 */               FriendsGUI.this._buttonMap.remove(Integer.valueOf(slot));
/*     */             }
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private FriendData getFriendData() {
/* 547 */     return (FriendData)this._plugin.Get(this._player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void OnInventoryClick(InventoryClickEvent event)
/*     */   {
/* 553 */     if ((this._inventory.getTitle().equals(event.getInventory().getTitle())) && (event.getWhoClicked() == this._player))
/*     */     {
/* 555 */       if (this._buttonMap.containsKey(Integer.valueOf(event.getRawSlot())))
/*     */       {
/* 557 */         if ((event.getWhoClicked() instanceof Player))
/*     */         {
/* 559 */           IButton button = (IButton)this._buttonMap.get(Integer.valueOf(event.getRawSlot()));
/*     */           
/* 561 */           button.onClick((Player)event.getWhoClicked(), event.getClick());
/*     */           
/* 563 */           this._player.playSound(this._player.getLocation(), Sound.NOTE_PLING, 1.0F, 1.6F);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/*     */       else {
/* 569 */         this._player.playSound(this._player.getLocation(), Sound.ITEM_BREAK, 1.0F, 0.6F);
/*     */       }
/*     */       
/* 572 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void OnInventoryClose(InventoryCloseEvent event)
/*     */   {
/* 579 */     if ((this._inventory.getTitle().equals(event.getInventory().getTitle())) && (event.getPlayer() == this._player))
/*     */     {
/* 581 */       unregisterListener();
/*     */     }
/*     */   }
/*     */   
/*     */   private void unregisterListener()
/*     */   {
/* 587 */     FriendData data = getFriendData();
/*     */     
/* 589 */     if ((data != null) && (data.getGui() == this))
/*     */     {
/* 591 */       data.setGui(null);
/*     */     }
/*     */     
/* 594 */     HandlerList.unregisterAll(this);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\ui\FriendsGUI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */