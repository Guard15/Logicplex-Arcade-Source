/*     */ package mineplex.core.friend.ui;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Listener;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabList
/*     */   implements Listener
/*     */ {
/*  16 */   private static int MAX_SLOTS = 64;
/*  17 */   private static int COLUMN_SLOTS = 16;
/*     */   
/*  19 */   private static NautHashMap<Integer, String> _invisibleHolders = new NautHashMap();
/*     */   
/*  21 */   private NautHashMap<Integer, LineTracker> _tabSlots = new NautHashMap();
/*  22 */   private HashSet<Integer> _updatedSlots = new HashSet();
/*     */   private boolean _update;
/*     */   
/*     */   static
/*     */   {
/*  27 */     String spaces = "";
/*     */     
/*  29 */     for (int i = 0; i < MAX_SLOTS; i++)
/*     */     {
/*  31 */       int markerSymbol = i / COLUMN_SLOTS;
/*  32 */       String symbol = null;
/*     */       
/*  34 */       if (i % COLUMN_SLOTS == 0) {
/*  35 */         spaces = "";
/*     */       } else {
/*  37 */         spaces = spaces + " ";
/*     */       }
/*  39 */       if (markerSymbol == 0)
/*     */       {
/*  41 */         symbol = ChatColor.GREEN;
/*     */       }
/*  43 */       else if (markerSymbol == 1)
/*     */       {
/*  45 */         symbol = ChatColor.RED;
/*     */       }
/*  47 */       else if (markerSymbol == 2)
/*     */       {
/*  49 */         symbol = ChatColor.BLUE;
/*     */       }
/*  51 */       else if (markerSymbol == 3)
/*     */       {
/*  53 */         symbol = ChatColor.BLACK;
/*     */       }
/*     */       
/*  56 */       _invisibleHolders.put(Integer.valueOf(i), symbol + spaces);
/*     */     }
/*     */   }
/*     */   
/*     */   public TabList()
/*     */   {
/*  62 */     for (Integer i = Integer.valueOf(0); i.intValue() < MAX_SLOTS; i = Integer.valueOf(i.intValue() + 1))
/*     */     {
/*  64 */       this._tabSlots.put(i, new LineTracker((String)_invisibleHolders.get(i)));
/*     */     }
/*     */   }
/*     */   
/*     */   public void set(int column, int row, String lineContent)
/*     */   {
/*  70 */     int index = row * 4 + column;
/*     */     
/*  72 */     if (index >= MAX_SLOTS) {
/*  73 */       return;
/*     */     }
/*  75 */     if ((lineContent == null) || (lineContent.isEmpty())) {
/*  76 */       lineContent = (String)_invisibleHolders.get(Integer.valueOf(index));
/*     */     }
/*  78 */     if (((LineTracker)this._tabSlots.get(Integer.valueOf(index))).setLine(lineContent))
/*     */     {
/*  80 */       this._updatedSlots.add(Integer.valueOf(index));
/*  81 */       this._update = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void refreshForPlayer(Player player)
/*     */   {
/*  87 */     EntityPlayer entityPlayer = ((CraftPlayer)player).getHandle();
/*     */     
/*  89 */     int indexChanged = MAX_SLOTS;
/*     */     
/*  91 */     for (int i = 0; i < MAX_SLOTS; i++)
/*     */     {
/*  93 */       if ((indexChanged == MAX_SLOTS) && (this._updatedSlots.contains(Integer.valueOf(i))))
/*     */       {
/*  95 */         indexChanged = i;
/*     */       }
/*  97 */       else if ((indexChanged != MAX_SLOTS) && (!this._updatedSlots.contains(Integer.valueOf(i))))
/*     */       {
/*  99 */         ((LineTracker)this._tabSlots.get(Integer.valueOf(i))).removeLineForPlayer(entityPlayer);
/*     */       }
/*     */     }
/*     */     
/* 103 */     for (int i = indexChanged; i < MAX_SLOTS; i++)
/*     */     {
/* 105 */       ((LineTracker)this._tabSlots.get(Integer.valueOf(i))).displayLineToPlayer(entityPlayer);
/*     */     }
/*     */     
/* 108 */     this._update = false;
/* 109 */     this._updatedSlots.clear();
/*     */   }
/*     */   
/*     */   public boolean shouldUpdate()
/*     */   {
/* 114 */     return this._update;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\ui\TabList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */