/*    */ package mineplex.core.friend.ui;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutPlayerInfo;
/*    */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*    */ import net.minecraft.util.com.mojang.authlib.GameProfile;
/*    */ 
/*    */ public class LineTracker
/*    */ {
/* 11 */   private String _line = null;
/* 12 */   private String _oldLine = null;
/*    */   private PacketPlayOutPlayerInfo _clearOldPacket;
/*    */   private PacketPlayOutPlayerInfo _addNewPacket;
/*    */   private PacketPlayOutPlayerInfo _clearNewPacket;
/*    */   
/*    */   public LineTracker(String line)
/*    */   {
/* 19 */     setLine(line);
/*    */   }
/*    */   
/*    */   public boolean setLine(String s)
/*    */   {
/* 24 */     if ((s != null) && (s.length() > 16)) {
/* 25 */       s = s.substring(0, 16);
/*    */     }
/* 27 */     if ((this._line != null) && (this._line.compareTo(s) == 0)) {
/* 28 */       return false;
/*    */     }
/* 30 */     this._oldLine = this._line;
/* 31 */     this._line = s;
/*    */     
/* 33 */     if (this._oldLine != null)
/*    */     {
/* 35 */       this._clearOldPacket = new PacketPlayOutPlayerInfo();
/* 36 */       this._clearOldPacket.username = this._oldLine;
/* 37 */       this._clearOldPacket.action = 4;
/* 38 */       this._clearOldPacket.ping = 0;
/* 39 */       this._clearOldPacket.player = new GameProfile(UUID.randomUUID(), this._oldLine);
/*    */     }
/*    */     
/* 42 */     if (this._line != null)
/*    */     {
/* 44 */       this._addNewPacket = new PacketPlayOutPlayerInfo();
/* 45 */       this._addNewPacket.username = this._line;
/* 46 */       this._addNewPacket.action = 0;
/* 47 */       this._addNewPacket.ping = 0;
/* 48 */       this._addNewPacket.player = new GameProfile(UUID.randomUUID(), this._line);
/*    */       
/* 50 */       this._clearNewPacket = new PacketPlayOutPlayerInfo();
/* 51 */       this._clearNewPacket.username = this._line;
/* 52 */       this._clearNewPacket.action = 4;
/* 53 */       this._clearNewPacket.ping = 0;
/* 54 */       this._clearNewPacket.player = new GameProfile(UUID.randomUUID(), this._line);
/*    */     }
/*    */     
/* 57 */     return true;
/*    */   }
/*    */   
/*    */   public void displayLineToPlayer(EntityPlayer entityPlayer)
/*    */   {
/* 62 */     if (this._oldLine != null)
/*    */     {
/* 64 */       entityPlayer.playerConnection.sendPacket(this._clearOldPacket);
/*    */     }
/*    */     
/* 67 */     if (this._line != null)
/*    */     {
/* 69 */       entityPlayer.playerConnection.sendPacket(this._addNewPacket);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeLineForPlayer(EntityPlayer entityPlayer)
/*    */   {
/* 75 */     if (this._line != null)
/*    */     {
/* 77 */       entityPlayer.playerConnection.sendPacket(this._clearNewPacket);
/*    */     }
/*    */   }
/*    */   
/*    */   public void clearOldLine()
/*    */   {
/* 83 */     this._oldLine = null;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\friend\ui\LineTracker.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */