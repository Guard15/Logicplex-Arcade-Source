/*    */ package mineplex.core.pet.event;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class PetSpawnEvent extends Event implements Cancellable
/*    */ {
/* 12 */   private static final HandlerList handlers = new HandlerList();
/* 13 */   private boolean _cancelled = false;
/*    */   
/*    */   private Player _player;
/*    */   private EntityType _entityType;
/*    */   private Location _location;
/*    */   
/*    */   public PetSpawnEvent(Player player, EntityType entityType, Location location)
/*    */   {
/* 21 */     this._player = player;
/* 22 */     this._entityType = entityType;
/* 23 */     this._location = location;
/*    */   }
/*    */   
/*    */   public Player GetPlayer()
/*    */   {
/* 28 */     return this._player;
/*    */   }
/*    */   
/*    */   public EntityType GetEntityType()
/*    */   {
/* 33 */     return this._entityType;
/*    */   }
/*    */   
/*    */   public Location GetLocation()
/*    */   {
/* 38 */     return this._location;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 43 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 48 */     return handlers;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 54 */     return this._cancelled;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 60 */     this._cancelled = cancel;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\event\PetSpawnEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */