package mineplex.core.pet.repository.token;

public class PetExtraToken
{
  public String Name;
  public String Material;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\repository\token\PetExtraToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */