package mineplex.core.pet.repository.token;

public class ClientPetTokenWrapper
{
  public String Name;
  public ClientPetToken DonorToken;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\repository\token\ClientPetTokenWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */