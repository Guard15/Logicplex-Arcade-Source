package mineplex.core.pet.repository.token;

import java.util.List;

public class ClientPetToken
{
  public List<PetToken> Pets;
  public int PetNameTagCount;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\repository\token\ClientPetToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */