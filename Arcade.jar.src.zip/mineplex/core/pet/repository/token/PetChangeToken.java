package mineplex.core.pet.repository.token;

public class PetChangeToken
{
  public String Name;
  public String PetName;
  public String PetType;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\repository\token\PetChangeToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */