/*     */ package mineplex.core.pet.types;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.server.v1_7_R4.EntityWither;
/*     */ import net.minecraft.server.v1_7_R4.MethodProfiler;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoalSelector;
/*     */ import net.minecraft.server.v1_7_R4.World;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.SpigotTimings;
/*     */ import org.spigotmc.CustomTimingsHandler;
/*     */ 
/*     */ public class CustomWither extends EntityWither
/*     */ {
/*     */   private int bq;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  20 */       Field f = net.minecraft.server.v1_7_R4.EntityTypes.class.getDeclaredField("f");
/*  21 */       f.setAccessible(true);
/*  22 */       HashMap map = (HashMap)f.get(null);
/*  23 */       map.put(CustomWither.class, Integer.valueOf(org.bukkit.entity.EntityType.WITHER.getTypeId()));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  27 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public CustomWither(World world)
/*     */   {
/*  34 */     super(world);
/*  35 */     s(530);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void bn()
/*     */   {
/*  41 */     this.aU += 1;
/*  42 */     this.world.methodProfiler.a("checkDespawn");
/*  43 */     w();
/*  44 */     this.world.methodProfiler.b();
/*     */     
/*  46 */     if (this.fromMobSpawner)
/*     */     {
/*  48 */       return;
/*     */     }
/*     */     
/*  51 */     this.world.methodProfiler.a("sensing");
/*  52 */     getEntitySenses().a();
/*  53 */     this.world.methodProfiler.b();
/*  54 */     this.world.methodProfiler.a("targetSelector");
/*  55 */     this.targetSelector.a();
/*  56 */     this.world.methodProfiler.b();
/*  57 */     this.world.methodProfiler.a("goalSelector");
/*  58 */     this.goalSelector.a();
/*  59 */     this.world.methodProfiler.b();
/*  60 */     this.world.methodProfiler.a("navigation");
/*  61 */     getNavigation().f();
/*  62 */     this.world.methodProfiler.b();
/*  63 */     this.world.methodProfiler.a("mob tick");
/*  64 */     bp();
/*  65 */     this.world.methodProfiler.b();
/*  66 */     this.world.methodProfiler.a("controls");
/*  67 */     this.world.methodProfiler.a("move");
/*  68 */     getControllerMove().c();
/*  69 */     this.world.methodProfiler.c("look");
/*  70 */     getControllerLook().a();
/*  71 */     this.world.methodProfiler.c("jump");
/*  72 */     getControllerJump().b();
/*  73 */     this.world.methodProfiler.b();
/*  74 */     this.world.methodProfiler.b();
/*     */   }
/*     */   
/*     */ 
/*     */   public void e()
/*     */   {
/*  80 */     if (this.bq > 0)
/*     */     {
/*  82 */       this.bq -= 1;
/*     */     }
/*     */     
/*  85 */     if (this.bg > 0)
/*     */     {
/*  87 */       double d0 = this.locX + (this.bh - this.locX) / this.bg;
/*  88 */       double d1 = this.locY + (this.bi - this.locY) / this.bg;
/*  89 */       double d2 = this.locZ + (this.bj - this.locZ) / this.bg;
/*  90 */       double d3 = net.minecraft.server.v1_7_R4.MathHelper.g(this.bk - this.yaw);
/*     */       
/*  92 */       this.yaw = ((float)(this.yaw + d3 / this.bg));
/*  93 */       this.pitch = ((float)(this.pitch + (this.bl - this.pitch) / this.bg));
/*  94 */       this.bg -= 1;
/*     */       
/*  96 */       if (!this.Vegetated)
/*     */       {
/*  98 */         setPosition(d0, d1, d2);
/*     */       }
/* 100 */       b(this.yaw, this.pitch);
/*     */     }
/* 102 */     else if (!br())
/*     */     {
/* 104 */       this.motX *= 0.98D;
/* 105 */       this.motY *= 0.98D;
/* 106 */       this.motZ *= 0.98D;
/*     */     }
/*     */     
/* 109 */     if (Math.abs(this.motX) < 0.005D)
/*     */     {
/* 111 */       this.motX = 0.0D;
/*     */     }
/*     */     
/* 114 */     if (Math.abs(this.motY) < 0.005D)
/*     */     {
/* 116 */       this.motY = 0.0D;
/*     */     }
/*     */     
/* 119 */     if (Math.abs(this.motZ) < 0.005D)
/*     */     {
/* 121 */       this.motZ = 0.0D;
/*     */     }
/*     */     
/* 124 */     this.world.methodProfiler.a("ai");
/* 125 */     SpigotTimings.timerEntityAI.startTiming();
/* 126 */     if (bh())
/*     */     {
/* 128 */       this.bc = false;
/* 129 */       this.bd = 0.0F;
/* 130 */       this.be = 0.0F;
/* 131 */       this.bf = 0.0F;
/*     */     }
/* 133 */     else if (br())
/*     */     {
/* 135 */       if (bk())
/*     */       {
/* 137 */         this.world.methodProfiler.a("newAi");
/* 138 */         bn();
/* 139 */         this.world.methodProfiler.b();
/*     */       }
/*     */       else
/*     */       {
/* 143 */         this.world.methodProfiler.a("oldAi");
/* 144 */         bq();
/* 145 */         this.world.methodProfiler.b();
/* 146 */         this.aO = this.yaw;
/*     */       }
/*     */     }
/* 149 */     SpigotTimings.timerEntityAI.stopTiming();
/*     */     
/* 151 */     this.world.methodProfiler.b();
/* 152 */     this.world.methodProfiler.a("jump");
/* 153 */     if (this.bc)
/*     */     {
/* 155 */       if ((!M()) && (!P()))
/*     */       {
/* 157 */         if ((this.onGround) && (this.bq == 0))
/*     */         {
/* 159 */           bj();
/* 160 */           this.bq = 10;
/*     */         }
/*     */       }
/*     */       else {
/* 164 */         this.motY += 0.03999999910593033D;
/*     */       }
/*     */     }
/*     */     else {
/* 168 */       this.bq = 0;
/*     */     }
/*     */     
/* 171 */     this.world.methodProfiler.b();
/* 172 */     this.world.methodProfiler.a("travel");
/* 173 */     this.bd *= 0.98F;
/* 174 */     this.be *= 0.98F;
/* 175 */     this.bf *= 0.9F;
/* 176 */     SpigotTimings.timerEntityAIMove.startTiming();
/* 177 */     e(this.bd, this.be);
/* 178 */     SpigotTimings.timerEntityAIMove.stopTiming();
/* 179 */     this.world.methodProfiler.b();
/* 180 */     this.world.methodProfiler.a("push");
/* 181 */     if (!this.world.isStatic)
/*     */     {
/* 183 */       SpigotTimings.timerEntityAICollision.startTiming();
/* 184 */       bo();
/* 185 */       SpigotTimings.timerEntityAICollision.stopTiming();
/*     */     }
/*     */     
/* 188 */     this.world.methodProfiler.b();
/*     */   }
/*     */   
/*     */ 
/*     */   protected float bf()
/*     */   {
/* 194 */     return 0.4F;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\pet\types\CustomWither.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */