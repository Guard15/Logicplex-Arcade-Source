/*     */ package mineplex.core.blood;
/*     */ 
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.Cancellable;
/*     */ import org.bukkit.event.Event;
/*     */ import org.bukkit.event.HandlerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BloodEvent
/*     */   extends Event
/*     */   implements Cancellable
/*     */ {
/*  26 */   private static final HandlerList handlers = new HandlerList();
/*  27 */   private boolean _cancelled = false;
/*     */   private Player _player;
/*     */   private Location _loc;
/*     */   private int _particles;
/*     */   private double _velMult;
/*     */   private Sound _sound;
/*     */   private float _soundVol;
/*     */   private float _soundPitch;
/*     */   private Material _type;
/*     */   private byte _data;
/*     */   private int _ticks;
/*     */   private boolean _bloodStep;
/*     */   
/*     */   public BloodEvent(Player player, Location loc, int particles, double velMult, Sound sound, float soundVol, float soundPitch, Material type, byte data, int ticks, boolean bloodStep) {
/*  41 */     this._player = player;
/*  42 */     this._loc = loc;
/*  43 */     this._particles = particles;
/*  44 */     this._velMult = velMult;
/*  45 */     this._sound = sound;
/*  46 */     this._soundVol = soundVol;
/*  47 */     this._soundPitch = soundPitch;
/*  48 */     this._type = type;
/*  49 */     this._data = data;
/*  50 */     this._ticks = ticks;
/*  51 */     this._bloodStep = bloodStep;
/*     */   }
/*     */   
/*     */   public boolean isCancelled() {
/*  55 */     return this._cancelled;
/*     */   }
/*     */   
/*     */   public void setCancelled(boolean var) {
/*  59 */     this._cancelled = var;
/*     */   }
/*     */   
/*     */   public HandlerList getHandlers() {
/*  63 */     return handlers;
/*     */   }
/*     */   
/*     */   public static HandlerList getHandlerList() {
/*  67 */     return handlers;
/*     */   }
/*     */   
/*     */   public Player getPlayer() {
/*  71 */     return this._player;
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/*  75 */     return this._loc;
/*     */   }
/*     */   
/*     */   public int getParticles() {
/*  79 */     return this._particles;
/*     */   }
/*     */   
/*     */   public double getVelocityMult() {
/*  83 */     return this._velMult;
/*     */   }
/*     */   
/*     */   public Sound getSound() {
/*  87 */     return this._sound;
/*     */   }
/*     */   
/*     */   public float getSoundVolume() {
/*  91 */     return this._soundVol;
/*     */   }
/*     */   
/*     */   public float getSoundPitch() {
/*  95 */     return this._soundPitch;
/*     */   }
/*     */   
/*     */   public Material getMaterial() {
/*  99 */     return this._type;
/*     */   }
/*     */   
/*     */   public byte getMaterialData() {
/* 103 */     return this._data;
/*     */   }
/*     */   
/*     */   public int getTicks() {
/* 107 */     return this._ticks;
/*     */   }
/*     */   
/*     */   public boolean getBloodStep() {
/* 111 */     return this._bloodStep;
/*     */   }
/*     */   
/*     */   public void setItem(Material mat, byte data) {
/* 115 */     this._type = mat;
/* 116 */     this._data = data;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\blood\BloodEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */