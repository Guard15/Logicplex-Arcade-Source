/*    */ package mineplex.core.data;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlockData
/*    */ {
/*    */   public Block Block;
/*    */   public Material Material;
/*    */   public byte Data;
/*    */   public long Time;
/*    */   
/*    */   public BlockData(Block block)
/*    */   {
/* 20 */     this.Block = block;
/* 21 */     this.Material = block.getType();
/* 22 */     this.Data = block.getData();
/* 23 */     this.Time = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void restore() {
/* 27 */     restore(false);
/*    */   }
/*    */   
/*    */   public void restore(boolean requireNotAir) {
/* 31 */     if ((requireNotAir) && (this.Block.getType() == Material.AIR)) {
/* 32 */       return;
/*    */     }
/* 34 */     this.Block.setTypeIdAndData(this.Material.getId(), this.Data, true);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\data\BlockData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */