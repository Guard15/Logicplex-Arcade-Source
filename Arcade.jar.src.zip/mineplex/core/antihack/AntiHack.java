/*     */ package mineplex.core.antihack;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.antihack.types.Fly;
/*     */ import mineplex.core.antihack.types.Idle;
/*     */ import mineplex.core.antihack.types.Reach;
/*     */ import mineplex.core.antihack.types.Speed;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.portal.Portal;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.preferences.UserPreferences;
/*     */ import mineplex.core.punish.Punish;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.event.player.PlayerVelocityEvent;
/*     */ import org.bukkit.event.server.ServerListPingEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AntiHack
/*     */   extends MiniPlugin
/*     */ {
/*     */   public static AntiHack Instance;
/*  82 */   private boolean _enabled = true;
/*  83 */   private boolean _strict = false;
/*  84 */   private boolean _kick = true;
/*     */   public Punish Punish;
/*     */   public Portal Portal;
/*     */   private PreferencesManager _preferences;
/*     */   private CoreClientManager _clientManager;
/*  89 */   private HashMap<Player, HashMap<String, ArrayList<Long>>> _offense = new HashMap();
/*  90 */   private HashMap<Player, Long> _ignore = new HashMap();
/*  91 */   private HashSet<Player> _velocityEvent = new HashSet();
/*  92 */   private HashMap<Player, Long> _lastMoveEvent = new HashMap();
/*  93 */   private HashSet<Player> _hubAttempted = new HashSet();
/*  94 */   public int FloatHackTicks = 10;
/*  95 */   public int HoverHackTicks = 4;
/*  96 */   public int RiseHackTicks = 6;
/*  97 */   public int SpeedHackTicks = 6;
/*  98 */   public int IdleTime = 20000;
/*  99 */   public int KeepOffensesFor = 30000;
/* 100 */   public int FlightTriggerCancel = 2000;
/*     */   public ArrayList<Detector> _movementDetectors;
/*     */   public ArrayList<Detector> _combatDetectors;
/*     */   private AntiHackRepository _repository;
/*     */   public static String _mineplexName;
/*     */   
/*     */   protected AntiHack(JavaPlugin plugin, Punish punish, Portal portal, PreferencesManager preferences, CoreClientManager clientManager, String mineplexName)
/*     */   {
/* 108 */     super("AntiHack", plugin);
/* 109 */     this.Punish = punish;
/* 110 */     this.Portal = portal;
/* 111 */     this._preferences = preferences;
/* 112 */     this._clientManager = clientManager;
/* 113 */     this._repository = new AntiHackRepository(plugin.getConfig().getString("serverstatus.name"));
/* 114 */     this._repository.initialize();
/* 115 */     this._movementDetectors = new ArrayList();
/* 116 */     this._combatDetectors = new ArrayList();
/* 117 */     this._movementDetectors.add(new Fly(this));
/* 118 */     this._movementDetectors.add(new Idle(this));
/* 119 */     this._movementDetectors.add(new Speed(this));
/* 120 */     this._combatDetectors.add(new Reach(this));
/*     */     
/* 122 */     _mineplexName = mineplexName;
/*     */   }
/*     */   
/*     */   public static void Initialize(JavaPlugin plugin, Punish punish, Portal portal, PreferencesManager preferences, CoreClientManager clientManager, String mineplexName) {
/* 126 */     Instance = new AntiHack(plugin, punish, portal, preferences, clientManager, mineplexName);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerMove(PlayerMoveEvent event) {
/* 131 */     if (!this._enabled) {
/* 132 */       return;
/*     */     }
/* 134 */     this._lastMoveEvent.put(event.getPlayer(), Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerTeleport(PlayerTeleportEvent event) {
/* 139 */     if (!this._enabled) {
/* 140 */       return;
/*     */     }
/* 142 */     setIgnore(event.getPlayer(), 2000L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerVelocity(PlayerVelocityEvent event) {
/* 147 */     if (!this._enabled) {
/* 148 */       return;
/*     */     }
/* 150 */     this._velocityEvent.add(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerQuit(PlayerQuitEvent event) {
/* 155 */     if (!this._enabled) {
/* 156 */       return;
/*     */     }
/* 158 */     resetAll(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void startIgnore(PlayerMoveEvent event)
/*     */   {
/* 164 */     if (!this._enabled) {
/* 165 */       return;
/*     */     }
/* 167 */     Player player = event.getPlayer();
/* 168 */     if (this._velocityEvent.remove(player))
/* 169 */       setIgnore(player, 2000L);
/*     */     long timeBetweenPackets;
/* 171 */     if ((this._lastMoveEvent.containsKey(player)) && ((timeBetweenPackets = System.currentTimeMillis() - ((Long)this._lastMoveEvent.get(player)).longValue()) > 500L)) {
/* 172 */       setIgnore(player, Math.min(4000L, timeBetweenPackets));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setIgnore(Player player, long time) {
/* 177 */     for (Detector detector : this._movementDetectors) {
/* 178 */       detector.Reset(player);
/*     */     }
/* 180 */     if ((this._ignore.containsKey(player)) && (((Long)this._ignore.get(player)).longValue() > System.currentTimeMillis() + time)) {
/* 181 */       return;
/*     */     }
/* 183 */     this._ignore.put(player, Long.valueOf(System.currentTimeMillis() + time));
/*     */   }
/*     */   
/*     */   public boolean isValid(Player player, boolean groundValid) { Player[] arrayOfPlayer;
/* 187 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/* 188 */       if ((!player.equals(other)) && (other.getGameMode() == GameMode.SURVIVAL) && (!UtilPlayer.isSpectator(player)) && (other.getVehicle() == null) && (UtilMath.offset(player, other) < 2.0D))
/* 189 */         return true;
/*     */     }
/* 191 */     if ((player.isFlying()) || (player.isInsideVehicle()) || (player.getGameMode() != GameMode.SURVIVAL) || (UtilPlayer.isSpectator(player))) {
/* 192 */       return true;
/*     */     }
/* 194 */     if ((groundValid) && ((UtilEnt.onBlock(player)) || (player.getLocation().getBlock().getType() != Material.AIR))) {
/* 195 */       return true;
/*     */     }
/* 197 */     if ((this._ignore.containsKey(player)) && (System.currentTimeMillis() < ((Long)this._ignore.get(player)).longValue())) {
/* 198 */       return true;
/*     */     }
/* 200 */     return false;
/*     */   }
/*     */   
/*     */   public void addSuspicion(Player player, String type) {
/* 204 */     if (!this._enabled) {
/* 205 */       return;
/*     */     }
/* 207 */     System.out.println(C.cRed + C.Bold + player.getName() + " suspected for " + type + ".");
/* 208 */     if (!this._offense.containsKey(player)) {
/* 209 */       this._offense.put(player, new HashMap());
/*     */     }
/* 211 */     if (!((HashMap)this._offense.get(player)).containsKey(type)) {
/* 212 */       ((HashMap)this._offense.get(player)).put(type, new ArrayList());
/*     */     }
/* 214 */     ((ArrayList)((HashMap)this._offense.get(player)).get(type)).add(Long.valueOf(System.currentTimeMillis()));
/* 215 */     int total = 0;
/* 216 */     for (String curType : ((HashMap)this._offense.get(player)).keySet()) {
/* 217 */       offenseIterator = ((ArrayList)((HashMap)this._offense.get(player)).get(curType)).iterator();
/* 218 */       while (offenseIterator.hasNext()) {
/* 219 */         if (UtilTime.elapsed(((Long)offenseIterator.next()).longValue(), this.KeepOffensesFor))
/* 220 */           offenseIterator.remove();
/*     */       }
/* 222 */       total += ((ArrayList)((HashMap)this._offense.get(player)).get(curType)).size(); }
/*     */     Player[] arrayOfPlayer;
/* 224 */     Iterator<Long> offenseIterator = (arrayOfPlayer = UtilServer.getPlayers()).length; for (Iterator<Long> localIterator1 = 0; localIterator1 < offenseIterator; localIterator1++) { Player admin = arrayOfPlayer[localIterator1];
/* 225 */       if ((this._clientManager.Get(admin).GetRank().Has(Rank.MODERATOR)) && (((UserPreferences)this._preferences.Get(admin)).ShowMacReports))
/* 226 */         UtilPlayer.message(admin, "#" + total + ": " + C.cRed + C.Bold + player.getName() + " suspected for " + type + ".");
/*     */     }
/* 228 */     System.out.println("[Offense] #" + total + ": " + player.getName() + " received suspicion for " + type + ".");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void generateReports(UpdateEvent event) {
/* 233 */     if (!this._enabled) {
/* 234 */       return;
/*     */     }
/* 236 */     if (event.getType() != UpdateType.SEC) {
/* 237 */       return;
/*     */     }
/* 239 */     Iterator<Map.Entry<Player, HashMap<String, ArrayList<Long>>>> playerIterator = this._offense.entrySet().iterator();
/* 240 */     while (playerIterator.hasNext()) {
/* 241 */       Map.Entry<Player, HashMap<String, ArrayList<Long>>> entry = (Map.Entry)playerIterator.next();
/* 242 */       Player player = (Player)entry.getKey();
/* 243 */       String out = "";
/* 244 */       int total = 0;
/* 245 */       for (String type : ((HashMap)entry.getValue()).keySet()) {
/* 246 */         Iterator<Long> offenseIterator = ((ArrayList)((HashMap)entry.getValue()).get(type)).iterator();
/* 247 */         while (offenseIterator.hasNext()) {
/* 248 */           long time = ((Long)offenseIterator.next()).longValue();
/* 249 */           if (UtilTime.elapsed(time, this.KeepOffensesFor))
/* 250 */             offenseIterator.remove();
/*     */         }
/* 252 */         int count = ((ArrayList)((HashMap)entry.getValue()).get(type)).size();
/* 253 */         total += count;
/* 254 */         out = out + count + " " + type + ", ";
/*     */       }
/* 256 */       if (out.length() > 0) {
/* 257 */         out = out.substring(0, out.length() - 2);
/*     */       }
/* 259 */       String severity = "Low";
/* 260 */       if (total > (this._strict ? 6 : 18)) {
/* 261 */         severity = "Extreme";
/* 262 */       } else if (total > (this._strict ? 4 : 12)) {
/* 263 */         severity = "High";
/* 264 */       } else if (total > (this._strict ? 2 : 6)) {
/* 265 */         severity = "Medium";
/*     */       }
/* 267 */       sendReport(player, out, severity);
/* 268 */       if (severity.equalsIgnoreCase("Extreme")) {
/* 269 */         playerIterator.remove();
/* 270 */         resetAll(player, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 275 */   public void sendReport(Player player, String report, String severity) { if (severity.equals("Extreme")) {
/* 276 */       boolean handled = false;
/* 277 */       Player[] arrayOfPlayer; int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player staff = arrayOfPlayer[i];
/* 278 */         if (this._clientManager.Get(staff).GetRank().Has(Rank.MODERATOR)) {
/* 279 */           UtilPlayer.message(staff, C.cAqua + C.Scramble + "A" + ChatColor.RESET + C.cRed + C.Bold + " MAC > " + ChatColor.RESET + C.cYellow + report);
/* 280 */           UtilPlayer.message(staff, C.cAqua + C.Scramble + "A" + ChatColor.RESET + C.cRed + C.Bold + " MAC > " + ChatColor.RESET + C.cGold + player.getName() + C.cYellow + " has extreme violation. Please investigate.");
/* 281 */           handled = true;
/*     */         } }
/* 283 */       if ((!handled) && (this._clientManager.Get(player).GetRank() != Rank.YOUTUBE) && (this._clientManager.Get(player).GetRank() != Rank.TWITCH)) {
/* 284 */         player.playSound(player.getLocation(), Sound.ENDERDRAGON_GROWL, 2.0F, 0.5F);
/* 285 */         if ((this._kick) || (this._hubAttempted.remove(player))) {
/* 286 */           player.kickPlayer(C.cGold + "Mineplex Anti-Cheat\n" + C.cWhite + "You were kicked for suspicious movement.\n" + C.cWhite + "Cheating may result in a " + C.cRed + "Permanent Ban" + C.cWhite + ".\n" + C.cWhite + "If you were not cheating, you will not be banned.");
/*     */         } else {
/* 288 */           this._hubAttempted.add(player);
/* 289 */           UtilPlayer.message(player, C.cGold + C.Strike + "---------------------------------------------");
/* 290 */           UtilPlayer.message(player, "");
/* 291 */           UtilPlayer.message(player, C.cGold + _mineplexName + " Anti-Cheat");
/* 292 */           UtilPlayer.message(player, "");
/* 293 */           UtilPlayer.message(player, "You were kicked from the game for suspicious movement.");
/* 294 */           UtilPlayer.message(player, "Cheating may result in a " + C.cRed + "Permanent Ban" + C.cWhite + ".");
/* 295 */           UtilPlayer.message(player, "If you were not cheating, you will not be banned.");
/* 296 */           UtilPlayer.message(player, "");
/* 297 */           UtilPlayer.message(player, C.cGold + C.Strike + "---------------------------------------------");
/* 298 */           this.Portal.sendPlayerToServer(player, "Lobby");
/*     */         }
/* 300 */         UtilServer.broadcast(F.main("MAC", player.getName() + " was kicked for suspicious movement."));
/*     */       }
/* 302 */       ServerListPingEvent event = new ServerListPingEvent(null, Bukkit.getServer().getMotd(), Bukkit.getServer().getOnlinePlayers().size(), Bukkit.getServer().getMaxPlayers());
/* 303 */       getPluginManager().callEvent(event);
/* 304 */       String motd = event.getMotd();
/* 305 */       String game = "N/A";
/* 306 */       String map = "N/A";
/* 307 */       String[] args = motd.split("\\|");
/* 308 */       if (args.length > 0) {
/* 309 */         motd = args[0];
/*     */       }
/* 311 */       if (args.length > 2) {
/* 312 */         game = args[2];
/*     */       }
/* 314 */       if (args.length > 3) {
/* 315 */         map = args[3];
/*     */       }
/* 317 */       this._repository.saveOffense(player, motd, game, map, report);
/*     */     }
/*     */   }
/*     */   
/*     */   private void reset() { Player[] arrayOfPlayer;
/* 322 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 323 */       resetAll(player);
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetAll(Player player) {
/* 328 */     resetAll(player, true);
/*     */   }
/*     */   
/*     */   private void resetAll(Player player, boolean removeOffenses) {
/* 332 */     this._ignore.remove(player);
/* 333 */     this._velocityEvent.remove(player);
/* 334 */     this._lastMoveEvent.remove(player);
/* 335 */     if (removeOffenses) {
/* 336 */       this._offense.remove(player);
/*     */     }
/* 338 */     for (Detector detector2 : this._movementDetectors) {
/* 339 */       detector2.Reset(player);
/*     */     }
/* 341 */     for (Detector detector2 : this._combatDetectors) {
/* 342 */       detector2.Reset(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void cleanupPlayers(UpdateEvent event)
/*     */   {
/* 349 */     if (!this._enabled) {
/* 350 */       return;
/*     */     }
/* 352 */     if (event.getType() != UpdateType.SLOW)
/* 353 */       return;
/*     */     label197:
/* 355 */     for (Iterator<Map.Entry<Player, Long>> playerIterator = this._ignore.entrySet().iterator(); playerIterator.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 369 */         ???.hasNext())
/*     */     {
/* 357 */       Player player = (Player)((Map.Entry)playerIterator.next()).getKey();
/* 358 */       if ((player.isOnline()) && (!player.isDead()) && (player.isValid()))
/*     */         break label197;
/* 360 */       playerIterator.remove();
/*     */       
/* 362 */       this._velocityEvent.remove(player);
/* 363 */       this._lastMoveEvent.remove(player);
/*     */       
/* 365 */       this._offense.remove(player);
/* 366 */       for (Detector detector : this._movementDetectors) {
/* 367 */         detector.Reset(player);
/*     */       }
/* 369 */       ??? = this._combatDetectors.iterator(); continue;Detector detector = (Detector)???.next();
/* 370 */       detector.Reset(player);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 375 */     for (Iterator<Player> playerIterator = this._hubAttempted.iterator(); playerIterator.hasNext();)
/*     */     {
/* 377 */       Player player1 = (Player)playerIterator.next();
/* 378 */       if ((!player1.isOnline()) || (!player1.isValid())) {
/* 379 */         playerIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean b) {
/* 385 */     this._enabled = b;
/* 386 */     System.out.println("MAC Enabled: " + b);
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 390 */     return this._enabled;
/*     */   }
/*     */   
/*     */   public void setStrict(boolean strict) {
/* 394 */     this._strict = strict;
/* 395 */     reset();
/* 396 */     System.out.println("MAC Strict: " + strict);
/*     */   }
/*     */   
/*     */   public boolean isStrict() {
/* 400 */     return this._strict;
/*     */   }
/*     */   
/*     */   public void setKick(boolean kick) {
/* 404 */     this._kick = kick;
/* 405 */     System.out.println("MAC Kick: " + kick);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\antihack\AntiHack.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */