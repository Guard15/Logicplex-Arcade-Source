/*    */ package mineplex.core.antihack.types;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.antihack.AntiHack;
/*    */ import mineplex.core.antihack.Detector;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.common.util.UtilTime;
/*    */ import mineplex.core.portal.Portal;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Idle
/*    */   extends MiniPlugin
/*    */   implements Detector
/*    */ {
/*    */   private AntiHack Host;
/* 36 */   private HashMap<Player, Long> _idleTime = new HashMap();
/*    */   
/*    */   public Idle(AntiHack host) {
/* 39 */     super("Idle Detector", host.getPlugin());
/* 40 */     this.Host = host;
/*    */   }
/*    */   
/*    */   @EventHandler(priority=EventPriority.MONITOR)
/*    */   public void updateFlyhack(PlayerMoveEvent event) {
/* 45 */     if (!this.Host.isEnabled()) {
/* 46 */       return;
/*    */     }
/* 48 */     Player player = event.getPlayer();
/* 49 */     this._idleTime.put(player, Long.valueOf(System.currentTimeMillis()));
/*    */   }
/*    */   
/*    */   @EventHandler(priority=EventPriority.MONITOR)
/*    */   public void updateFreeCam(UpdateEvent event) {
/* 54 */     if (!this.Host.isEnabled()) {
/* 55 */       return;
/*    */     }
/* 57 */     if (event.getType() != UpdateType.FAST)
/*    */       return;
/*    */     Player[] arrayOfPlayer;
/* 60 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 61 */       if ((!this.Host.isValid(player, true)) && (this._idleTime.containsKey(player)) && (UtilTime.elapsed(((Long)this._idleTime.get(player)).longValue(), this.Host.IdleTime))) {
/* 62 */         UtilPlayer.message(player, C.cRed + C.Bold + AntiHack._mineplexName + " Anti-Cheat detected Lagging / Fly (Idle)");
/* 63 */         UtilPlayer.message(player, C.cRed + C.Bold + "You have been returned to Lobby.");
/* 64 */         this.Host.Portal.sendPlayerToServer(player, "Lobby");
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void Reset(Player player) {
/* 70 */     this._idleTime.remove(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\antihack\types\Idle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */