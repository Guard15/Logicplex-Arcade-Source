/*    */ package mineplex.core.antihack.types;
/*    */ 
/*    */ import java.util.AbstractMap.SimpleEntry;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map.Entry;
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.antihack.AntiHack;
/*    */ import mineplex.core.antihack.Detector;
/*    */ import mineplex.core.common.util.UtilEnt;
/*    */ import mineplex.core.common.util.UtilMath;
/*    */ import mineplex.core.common.util.UtilTime;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.player.PlayerMoveEvent;
/*    */ import org.bukkit.potion.PotionEffect;
/*    */ import org.bukkit.potion.PotionEffectType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Speed
/*    */   extends MiniPlugin
/*    */   implements Detector
/*    */ {
/*    */   private AntiHack Host;
/* 41 */   private HashMap<Player, Map.Entry<Integer, Long>> _speedTicks = new HashMap();
/*    */   
/*    */   public Speed(AntiHack host) {
/* 44 */     super("Speed Detector", host.getPlugin());
/* 45 */     this.Host = host;
/*    */   }
/*    */   
/*    */   @EventHandler(priority=EventPriority.MONITOR)
/*    */   public void updateSpeedhack(PlayerMoveEvent event) {
/* 50 */     if (!this.Host.isEnabled()) {
/* 51 */       return;
/*    */     }
/* 53 */     Player player = event.getPlayer();
/* 54 */     if (this.Host.isValid(player, false)) {
/* 55 */       return;
/*    */     }
/* 57 */     UpdateSpeed(player, event);
/*    */   }
/*    */   
/*    */   private void UpdateSpeed(Player player, PlayerMoveEvent event) {
/* 61 */     int count = 0;
/* 62 */     if (this._speedTicks.containsKey(player)) {
/* 63 */       double offset = event.getFrom().getY() > event.getTo().getY() ? UtilMath.offset2d(event.getFrom(), event.getTo()) : UtilMath.offset(event.getFrom(), event.getTo());
/* 64 */       double limit = 0.74D;
/* 65 */       if (UtilEnt.isGrounded(player)) {
/* 66 */         limit = 0.32D;
/*    */       }
/* 68 */       for (PotionEffect effect : player.getActivePotionEffects()) {
/* 69 */         if (effect.getType().equals(PotionEffectType.SPEED))
/* 70 */           if (UtilEnt.isGrounded(player)) {
/* 71 */             limit += 0.08D * (effect.getAmplifier() + 1);
/*    */           }
/*    */           else
/* 74 */             limit += 0.04D * (effect.getAmplifier() + 1);
/*    */       }
/* 76 */       count = (offset > limit) && (!UtilTime.elapsed(((Long)((Map.Entry)this._speedTicks.get(player)).getValue()).longValue(), 100L)) ? ((Integer)((Map.Entry)this._speedTicks.get(player)).getKey()).intValue() + 1 : 0;
/*    */     }
/* 78 */     if (count > this.Host.SpeedHackTicks) {
/* 79 */       this.Host.addSuspicion(player, "Speed (Fly/Move)");
/* 80 */       count -= 2;
/*    */     }
/* 82 */     this._speedTicks.put(player, new AbstractMap.SimpleEntry(Integer.valueOf(count), Long.valueOf(System.currentTimeMillis())));
/*    */   }
/*    */   
/*    */   public void Reset(Player player)
/*    */   {
/* 87 */     this._speedTicks.remove(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\antihack\types\Speed.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */