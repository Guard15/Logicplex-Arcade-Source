/*     */ package mineplex.core.antihack.types;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.antihack.AntiHack;
/*     */ import mineplex.core.antihack.Detector;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Fly
/*     */   extends MiniPlugin
/*     */   implements Detector
/*     */ {
/*     */   private AntiHack Host;
/*  37 */   private HashMap<Player, Map.Entry<Integer, Double>> _floatTicks = new HashMap();
/*  38 */   private HashMap<Player, Map.Entry<Integer, Double>> _hoverTicks = new HashMap();
/*  39 */   private HashMap<Player, Map.Entry<Integer, Double>> _riseTicks = new HashMap();
/*     */   
/*     */   public Fly(AntiHack host) {
/*  42 */     super("Fly Detector", host.getPlugin());
/*  43 */     this.Host = host;
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void updateFlyhack(PlayerMoveEvent event) {
/*  48 */     if (!this.Host.isEnabled()) {
/*  49 */       return;
/*     */     }
/*  51 */     Player player = event.getPlayer();
/*  52 */     if (this.Host.isValid(player, true)) {
/*  53 */       Reset(player);
/*     */     }
/*  55 */     if (UtilMath.offset(event.getFrom(), event.getTo()) <= 0.0D) {
/*  56 */       updateFloat(player);
/*  57 */       return;
/*     */     }
/*  59 */     this._floatTicks.remove(player);
/*  60 */     updateHover(player);
/*  61 */     updateRise(player);
/*     */   }
/*     */   
/*     */   private void updateFloat(Player player) {
/*  65 */     int count = 0;
/*  66 */     if (this._floatTicks.containsKey(player)) {
/*  67 */       count = player.getLocation().getY() == ((Double)((Map.Entry)this._floatTicks.get(player)).getValue()).doubleValue() ? ((Integer)((Map.Entry)this._floatTicks.get(player)).getKey()).intValue() + 1 : 0;
/*     */     }
/*  69 */     if (count > this.Host.FloatHackTicks) {
/*  70 */       this.Host.addSuspicion(player, "Fly (Float)");
/*  71 */       count -= 2;
/*     */     }
/*  73 */     this._floatTicks.put(player, new AbstractMap.SimpleEntry(Integer.valueOf(count), Double.valueOf(player.getLocation().getY())));
/*     */   }
/*     */   
/*     */   private void updateHover(Player player) {
/*  77 */     int count = 0;
/*  78 */     if (this._hoverTicks.containsKey(player)) {
/*  79 */       count = player.getLocation().getY() == ((Double)((Map.Entry)this._hoverTicks.get(player)).getValue()).doubleValue() ? ((Integer)((Map.Entry)this._hoverTicks.get(player)).getKey()).intValue() + 1 : 0;
/*     */     }
/*  81 */     if (count > this.Host.HoverHackTicks) {
/*  82 */       this.Host.addSuspicion(player, "Fly (Hover)");
/*  83 */       count -= 2;
/*     */     }
/*  85 */     this._hoverTicks.put(player, new AbstractMap.SimpleEntry(Integer.valueOf(count), Double.valueOf(player.getLocation().getY())));
/*     */   }
/*     */   
/*     */   private void updateRise(Player player) {
/*  89 */     int count = 0;
/*  90 */     if (this._riseTicks.containsKey(player)) {
/*  91 */       if (player.getLocation().getY() >= ((Double)((Map.Entry)this._riseTicks.get(player)).getValue()).doubleValue()) {
/*  92 */         boolean nearBlocks = false;
/*  93 */         for (Block block : UtilBlock.getSurrounding(player.getLocation().getBlock(), true))
/*  94 */           if (block.getType() != Material.AIR) {
/*  95 */             nearBlocks = true;
/*  96 */             break;
/*     */           }
/*  98 */         count = nearBlocks ? 0 : ((Integer)((Map.Entry)this._riseTicks.get(player)).getKey()).intValue() + 1;
/*     */       } else {
/* 100 */         count = 0;
/*     */       }
/*     */     }
/* 103 */     if (count > this.Host.RiseHackTicks) {
/* 104 */       if (player.getLocation().getY() > ((Double)((Map.Entry)this._riseTicks.get(player)).getValue()).doubleValue()) {
/* 105 */         this.Host.addSuspicion(player, "Fly (Rise)");
/*     */       }
/* 107 */       count -= 2;
/*     */     }
/* 109 */     this._riseTicks.put(player, new AbstractMap.SimpleEntry(Integer.valueOf(count), Double.valueOf(player.getLocation().getY())));
/*     */   }
/*     */   
/*     */   public void Reset(Player player)
/*     */   {
/* 114 */     this._floatTicks.remove(player);
/* 115 */     this._hoverTicks.remove(player);
/* 116 */     this._riseTicks.remove(player);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\antihack\types\Fly.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */