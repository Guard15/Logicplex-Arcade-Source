package mineplex.core.antihack;

import org.bukkit.entity.Player;

public abstract interface Detector
{
  public abstract void Reset(Player paramPlayer);
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\antihack\Detector.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */