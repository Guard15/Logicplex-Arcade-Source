/*    */ package mineplex.core.packethandler;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketInfo
/*    */ {
/*    */   private Player _player;
/*    */   private Packet _packet;
/*    */   private PacketVerifier _verifier;
/* 15 */   private boolean _cancelled = false;
/*    */   
/*    */   public PacketInfo(Player player, Packet packet, PacketVerifier verifier)
/*    */   {
/* 19 */     this._player = player;
/* 20 */     this._packet = packet;
/* 21 */     this._verifier = verifier;
/*    */   }
/*    */   
/*    */   public Packet getPacket()
/*    */   {
/* 26 */     return this._packet;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 31 */     return this._player;
/*    */   }
/*    */   
/*    */   public PacketVerifier getVerifier()
/*    */   {
/* 36 */     return this._verifier;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 41 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 46 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */