package mineplex.core.packethandler;

public abstract interface IPacketHandler
{
  public abstract void handle(PacketInfo paramPacketInfo);
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\IPacketHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */