/*    */ package mineplex.core.packethandler;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*    */ import net.minecraft.server.v1_7_R4.IPacketVerifier;
/*    */ import net.minecraft.server.v1_7_R4.NetworkManager;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityDestroy;
/*    */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*    */ import net.minecraft.util.io.netty.util.concurrent.GenericFutureListener;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketVerifier
/*    */   implements IPacketVerifier
/*    */ {
/*    */   private static Field _destroyId;
/*    */   private Player _owner;
/* 33 */   private List<IPacketHandler> _packetHandlers = new ArrayList();
/*    */   
/*    */   public PacketVerifier(Player owner)
/*    */   {
/* 37 */     this._owner = owner;
/*    */     
/* 39 */     if (_destroyId == null)
/*    */     {
/*    */       try
/*    */       {
/* 43 */         _destroyId = PacketPlayOutEntityDestroy.class.getDeclaredField("a");
/* 44 */         _destroyId.setAccessible(true);
/*    */       }
/*    */       catch (Exception exception)
/*    */       {
/* 48 */         System.out.println("Field exception in CustomTagFix : ");
/* 49 */         exception.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean verify(Packet o)
/*    */   {
/* 57 */     PacketInfo packetInfo = new PacketInfo(this._owner, o, this);
/*    */     
/* 59 */     for (IPacketHandler handler : this._packetHandlers)
/*    */     {
/* 61 */       handler.handle(packetInfo);
/*    */     }
/*    */     
/* 64 */     return !packetInfo.isCancelled();
/*    */   }
/*    */   
/*    */   public void bypassProcess(Packet packet)
/*    */   {
/* 69 */     ((CraftPlayer)this._owner).getHandle().playerConnection.networkManager.handle(packet, new GenericFutureListener[0]);
/*    */   }
/*    */   
/*    */   public void Deactivate()
/*    */   {
/* 74 */     this._owner = null;
/*    */   }
/*    */   
/*    */   public void process(Packet packet)
/*    */   {
/* 79 */     ((CraftPlayer)this._owner).getHandle().playerConnection.sendPacket(packet);
/*    */   }
/*    */   
/*    */   public void clearHandlers()
/*    */   {
/* 84 */     this._packetHandlers.clear();
/*    */   }
/*    */   
/*    */   public void addPacketHandler(IPacketHandler packetHandler)
/*    */   {
/* 89 */     this._packetHandlers.add(packetHandler);
/*    */   }
/*    */   
/*    */   public void removePacketHandler(IPacketHandler packetHandler)
/*    */   {
/* 94 */     this._packetHandlers.remove(packetHandler);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketVerifier.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */