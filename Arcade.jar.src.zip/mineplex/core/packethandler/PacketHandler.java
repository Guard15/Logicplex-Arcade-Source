/*     */ package mineplex.core.packethandler;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.EnumProtocol;
/*     */ import net.minecraft.server.v1_7_R4.PacketProcessor;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import net.minecraft.util.com.google.common.collect.BiMap;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class PacketHandler extends MiniPlugin
/*     */ {
/*  23 */   private NautHashMap<Player, PacketVerifier> _playerVerifierMap = new NautHashMap();
/*  24 */   private HashSet<IPacketHandler> _packetHandlers = new HashSet();
/*     */   
/*     */   public PacketHandler(JavaPlugin plugin)
/*     */   {
/*  28 */     super("PacketHandler", plugin);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*     */       Class[] arrayOfClass;
/*     */       
/*     */ 
/*  36 */       int j = (arrayOfClass = new Class[] { PacketPlayResourcePackStatus.class, PacketPlayUseEntity.class }).length; for (int i = 0; i < j; i++)
/*     */       {
/*  36 */         Class clss = arrayOfClass[i];
/*     */         
/*     */ 
/*  39 */         Field field = clss.getDeclaredField("_packetHandler");
/*     */         
/*  41 */         field.setAccessible(true);
/*  42 */         field.set(null, this);
/*     */       }
/*     */       
/*  45 */       EnumProtocol.PLAY.a().put(Integer.valueOf(25), PacketPlayResourcePackStatus.class);
/*  46 */       EnumProtocol.PLAY.a().put(PacketPlayResourcePackStatus.class, Integer.valueOf(25));
/*     */       
/*  48 */       EnumProtocol.PLAY.a().put(Integer.valueOf(2), PacketPlayUseEntity.class);
/*  49 */       EnumProtocol.PLAY.a().put(PacketPlayUseEntity.class, Integer.valueOf(2));
/*     */       
/*  51 */       Method method = org.spigotmc.ProtocolInjector.class.getDeclaredMethod("addPacket", new Class[] { EnumProtocol.class, Boolean.TYPE, Integer.TYPE, Class.class });
/*  52 */       method.setAccessible(true);
/*     */       
/*  54 */       method.invoke(null, new Object[] { EnumProtocol.PLAY, Boolean.valueOf(true), Integer.valueOf(68), PacketPlayOutWorldBorder.class });
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/*  61 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onPlayerJoin(PlayerJoinEvent event)
/*     */   {
/*  68 */     this._playerVerifierMap.put(event.getPlayer(), new PacketVerifier(event.getPlayer()));
/*  69 */     ((CraftPlayer)event.getPlayer()).getHandle().playerConnection.PacketVerifier.addPacketVerifier(
/*  70 */       (net.minecraft.server.v1_7_R4.IPacketVerifier)this._playerVerifierMap.get(event.getPlayer()));
/*     */     
/*  72 */     for (IPacketHandler packetHandler : this._packetHandlers)
/*     */     {
/*  74 */       ((PacketVerifier)this._playerVerifierMap.get(event.getPlayer())).addPacketHandler(packetHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onPlayerQuit(PlayerQuitEvent event)
/*     */   {
/*  81 */     ((CraftPlayer)event.getPlayer()).getHandle().playerConnection.PacketVerifier.clearVerifiers();
/*  82 */     ((PacketVerifier)this._playerVerifierMap.remove(event.getPlayer())).clearHandlers();
/*     */   }
/*     */   
/*     */   public PacketVerifier getPacketVerifier(Player player)
/*     */   {
/*  87 */     return (PacketVerifier)this._playerVerifierMap.get(player);
/*     */   }
/*     */   
/*     */   public void addPacketHandler(IPacketHandler packetHandler)
/*     */   {
/*  92 */     this._packetHandlers.add(packetHandler);
/*     */     
/*  94 */     for (PacketVerifier verifier : this._playerVerifierMap.values())
/*     */     {
/*  96 */       verifier.addPacketHandler(packetHandler);
/*     */     }
/*     */   }
/*     */   
/*     */   public HashSet<IPacketHandler> getPacketHandlers()
/*     */   {
/* 102 */     return this._packetHandlers;
/*     */   }
/*     */   
/*     */   public void removePacketHandler(IPacketHandler packetHandler)
/*     */   {
/* 107 */     this._packetHandlers.remove(packetHandler);
/*     */     
/* 109 */     for (PacketVerifier verifier : this._playerVerifierMap.values())
/*     */     {
/* 111 */       verifier.removePacketHandler(packetHandler);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */