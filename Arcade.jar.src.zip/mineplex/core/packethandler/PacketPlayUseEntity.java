/*    */ package mineplex.core.packethandler;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.PacketListener;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayInListener;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayInUseEntity;
/*    */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class PacketPlayUseEntity
/*    */   extends PacketPlayInUseEntity
/*    */ {
/*    */   private static PacketHandler _packetHandler;
/*    */   
/*    */   public void handle(PacketListener packetlistener)
/*    */   {
/* 17 */     Player player = ((PlayerConnection)packetlistener).getPlayer();
/*    */     
/* 19 */     PacketVerifier verifier = _packetHandler.getPacketVerifier(player);
/*    */     
/* 21 */     PacketInfo packetInfo = new PacketInfo(player, this, verifier);
/*    */     
/* 23 */     for (IPacketHandler handler : _packetHandler.getPacketHandlers())
/*    */     {
/* 25 */       handler.handle(packetInfo);
/*    */     }
/*    */     
/* 28 */     if (!packetInfo.isCancelled())
/*    */     {
/* 30 */       a((PacketPlayInListener)packetlistener);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketPlayUseEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */