/*    */ package mineplex.core.packethandler;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketDataSerializer;
/*    */ import net.minecraft.server.v1_7_R4.PacketListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PacketPlayOutWorldBorder
/*    */   extends Packet
/*    */ {
/*    */   public int worldBorderType;
/*    */   public double centerX;
/*    */   public double centerZ;
/*    */   public double newRadius;
/*    */   public double oldRadius;
/*    */   public long speed;
/*    */   public int warningBlocks;
/*    */   public int warningTime;
/*    */   
/*    */   public void a(PacketDataSerializer paramPacketDataSerializer) {}
/*    */   
/*    */   public void b(PacketDataSerializer paramPacketDataSerializer)
/*    */   {
/* 42 */     paramPacketDataSerializer.b(this.worldBorderType);
/*    */     
/* 44 */     switch (this.worldBorderType)
/*    */     {
/*    */     case 0: 
/* 47 */       paramPacketDataSerializer.writeDouble(this.newRadius * 2.0D);
/* 48 */       break;
/*    */     case 1: 
/* 50 */       paramPacketDataSerializer.writeDouble(this.oldRadius * 2.0D);
/* 51 */       paramPacketDataSerializer.writeDouble(this.newRadius * 2.0D);
/* 52 */       paramPacketDataSerializer.b((int)this.speed);
/* 53 */       break;
/*    */     case 2: 
/* 55 */       paramPacketDataSerializer.writeDouble(this.centerX);
/* 56 */       paramPacketDataSerializer.writeDouble(this.centerZ);
/* 57 */       break;
/*    */     case 3: 
/* 59 */       paramPacketDataSerializer.writeDouble(this.centerX);
/* 60 */       paramPacketDataSerializer.writeDouble(this.centerZ);
/* 61 */       paramPacketDataSerializer.writeDouble(this.oldRadius * 2.0D);
/* 62 */       paramPacketDataSerializer.writeDouble(this.newRadius * 2.0D);
/* 63 */       paramPacketDataSerializer.b((int)this.speed);
/*    */       
/*    */ 
/* 66 */       paramPacketDataSerializer.b(29999984);
/* 67 */       paramPacketDataSerializer.b(this.warningTime);
/* 68 */       paramPacketDataSerializer.b(this.warningBlocks);
/* 69 */       break;
/*    */     case 4: 
/* 71 */       paramPacketDataSerializer.b(this.warningTime);
/* 72 */       break;
/*    */     case 5: 
/* 74 */       paramPacketDataSerializer.b(this.warningBlocks);
/*    */     }
/*    */   }
/*    */   
/*    */   public void handle(PacketListener arg0) {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketPlayOutWorldBorder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */