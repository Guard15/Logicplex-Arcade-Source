/*    */ package mineplex.core.packethandler;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.minecraft.server.v1_7_R4.PacketDataSerializer;
/*    */ import net.minecraft.server.v1_7_R4.PacketListener;
/*    */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*    */ 
/*    */ public class PacketPlayResourcePackStatus extends net.minecraft.server.v1_7_R4.Packet
/*    */ {
/*    */   private static PacketHandler _packetHandler;
/*    */   public String ResourcePackUrl;
/*    */   private int _resourcePackStatus;
/*    */   
/*    */   public static enum EnumResourcePackStatus
/*    */   {
/* 16 */     ACCEPTED, 
/*    */     
/* 18 */     DECLINED, 
/*    */     
/* 20 */     FAILED_DOWNLOAD, 
/*    */     
/* 22 */     LOADED;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void a(PacketDataSerializer packetdataserializer)
/*    */     throws IOException
/*    */   {
/* 32 */     this.ResourcePackUrl = packetdataserializer.c(255);
/* 33 */     this._resourcePackStatus = packetdataserializer.a();
/*    */   }
/*    */   
/*    */   public void b(PacketDataSerializer packetdataserializer)
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */   public EnumResourcePackStatus getResourcePackStatus()
/*    */   {
/* 42 */     return EnumResourcePackStatus.values()[this._resourcePackStatus];
/*    */   }
/*    */   
/*    */   public void handle(PacketListener packetListener)
/*    */   {
/* 47 */     org.bukkit.entity.Player player = ((PlayerConnection)packetListener).getPlayer();
/* 48 */     PacketVerifier verifier = _packetHandler.getPacketVerifier(player);
/*    */     
/* 50 */     PacketInfo packetInfo = new PacketInfo(player, this, verifier);
/*    */     
/* 52 */     for (IPacketHandler handler : _packetHandler.getPacketHandlers())
/*    */     {
/* 54 */       handler.handle(packetInfo);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\packethandler\PacketPlayResourcePackStatus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */