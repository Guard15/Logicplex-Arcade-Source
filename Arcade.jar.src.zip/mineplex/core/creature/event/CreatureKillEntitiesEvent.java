/*    */ package mineplex.core.creature.event;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreatureKillEntitiesEvent
/*    */   extends Event
/*    */   implements Cancellable
/*    */ {
/* 21 */   private static final HandlerList handlers = new HandlerList();
/* 22 */   private boolean _cancelled = false;
/*    */   private List<Entity> _entities;
/*    */   
/*    */   public CreatureKillEntitiesEvent(List<Entity> entities) {
/* 26 */     this._entities = entities;
/*    */   }
/*    */   
/*    */   public List<Entity> GetEntities() {
/* 30 */     return this._entities;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 34 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 38 */     return handlers;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 42 */     return this._cancelled;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel) {
/* 46 */     this._cancelled = cancel;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\event\CreatureKillEntitiesEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */