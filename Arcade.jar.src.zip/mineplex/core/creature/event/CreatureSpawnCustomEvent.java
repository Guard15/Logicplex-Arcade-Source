/*    */ package mineplex.core.creature.event;
/*    */ 
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreatureSpawnCustomEvent
/*    */   extends Event
/*    */   implements Cancellable
/*    */ {
/* 20 */   private static final HandlerList handlers = new HandlerList();
/* 21 */   private boolean _cancelled = false;
/*    */   private Location _location;
/*    */   
/*    */   public CreatureSpawnCustomEvent(Location location) {
/* 25 */     this._location = location;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 29 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 33 */     return handlers;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 37 */     return this._cancelled;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel) {
/* 41 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public Location GetLocation() {
/* 45 */     return this._location;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\event\CreatureSpawnCustomEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */