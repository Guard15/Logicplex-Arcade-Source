/*     */ package mineplex.core.creature;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.creature.command.MobCommand;
/*     */ import mineplex.core.creature.event.CreatureSpawnCustomEvent;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Creeper;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Skeleton;
/*     */ import org.bukkit.entity.Skeleton.SkeletonType;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.entity.CreatureSpawnEvent;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.player.PlayerEggThrowEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Creature
/*     */   extends MiniPlugin
/*     */ {
/*  70 */   private boolean _spawnForce = false;
/*  71 */   private boolean _disableCustom = false;
/*     */   
/*     */   public Creature(JavaPlugin plugin) {
/*  74 */     super("Creature", plugin);
/*     */   }
/*     */   
/*     */   public void addCommands()
/*     */   {
/*  79 */     addCommand(new MobCommand(this));
/*     */   }
/*     */   
/*     */   public Entity SpawnEntity(Location location, EntityType entityType) {
/*  83 */     this._spawnForce = true;
/*  84 */     Entity entity = location.getWorld().spawnEntity(location, entityType);
/*  85 */     this._spawnForce = false;
/*  86 */     return entity;
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.HIGHEST)
/*     */   public void eggThrow(PlayerEggThrowEvent event) {
/*  91 */     if (this._spawnForce) {
/*  92 */       return;
/*     */     }
/*  94 */     event.setHatching(false);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Spawn(CreatureSpawnEvent event) {
/*  99 */     if (this._disableCustom) {
/* 100 */       return;
/*     */     }
/* 102 */     if ((event.getEntity() instanceof LivingEntity)) {
/* 103 */       event.getEntity().setCanPickupItems(false);
/*     */     }
/* 105 */     if (this._spawnForce) {
/* 106 */       return;
/*     */     }
/* 108 */     if (event.getEntityType() == EntityType.SQUID) {
/* 109 */       event.setCancelled(true);
/* 110 */       return;
/*     */     }
/* 112 */     CreatureSpawnCustomEvent customEvent = new CreatureSpawnCustomEvent(event.getLocation());
/* 113 */     this._plugin.getServer().getPluginManager().callEvent(customEvent);
/* 114 */     if (customEvent.isCancelled()) {
/* 115 */       event.setCancelled(true);
/* 116 */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Death(EntityDeathEvent event) {
/* 122 */     if (this._disableCustom) {
/* 123 */       return;
/*     */     }
/* 125 */     event.setDroppedExp(0);
/* 126 */     List drops = event.getDrops();
/* 127 */     if (event.getEntityType() == EntityType.PLAYER) {
/* 128 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1));
/*     */     } else {
/* 130 */       drops.clear();
/*     */     }
/* 132 */     if (event.getEntityType() == EntityType.CHICKEN) {
/* 133 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_CHICKEN, 1));
/* 134 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.FEATHER, 2 + UtilMath.r(5)));
/* 135 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1));
/* 136 */     } else if (event.getEntityType() == EntityType.COW) {
/* 137 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_BEEF, 1 + UtilMath.r(4)));
/* 138 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.LEATHER, 2 + UtilMath.r(3)));
/* 139 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 3 + UtilMath.r(4)));
/*     */     }
/* 141 */     if (event.getEntityType() == EntityType.MUSHROOM_COW) {
/* 142 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_BEEF, 1 + UtilMath.r(4)));
/* 143 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RED_MUSHROOM, 2 + UtilMath.r(3)));
/* 144 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 3 + UtilMath.r(4)));
/* 145 */     } else if (event.getEntityType() == EntityType.OCELOT) {
/* 146 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_BEEF, 1 + UtilMath.r(2)));
/* 147 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_FISH, 2 + UtilMath.r(7)));
/* 148 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1 + UtilMath.r(2)));
/* 149 */     } else if (event.getEntityType() == EntityType.PIG) {
/* 150 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.PORK, 1 + UtilMath.r(2)));
/* 151 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 2 + UtilMath.r(2)));
/* 152 */     } else if (event.getEntityType() == EntityType.SHEEP) {
/* 153 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.RAW_BEEF, 1 + UtilMath.r(3)));
/* 154 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.WOOL, 1 + UtilMath.r(4)));
/* 155 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 2 + UtilMath.r(3)));
/* 156 */     } else if (event.getEntityType() == EntityType.VILLAGER) {
/* 157 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 2 + UtilMath.r(3)));
/* 158 */     } else if (event.getEntityType() == EntityType.BLAZE) {
/* 159 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BLAZE_ROD, 1));
/* 160 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 6 + UtilMath.r(7)));
/* 161 */     } else if (event.getEntityType() == EntityType.CAVE_SPIDER) {
/* 162 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.WEB, 2 + UtilMath.r(3)));
/* 163 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.SPIDER_EYE, 1));
/* 164 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 6 + UtilMath.r(7)));
/* 165 */     } else if (event.getEntityType() == EntityType.CREEPER) {
/* 166 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.COAL, 6 + UtilMath.r(13)));
/* 167 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 12 + UtilMath.r(13)));
/* 168 */     } else if (event.getEntityType() == EntityType.ENDERMAN) {
/* 169 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.ENDER_PEARL, 1));
/* 170 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 12 + UtilMath.r(13)));
/* 171 */     } else if (event.getEntityType() == EntityType.GHAST) {
/* 172 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.GHAST_TEAR, 1));
/* 173 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 36 + UtilMath.r(37)));
/* 174 */       for (int i = 0; i < 5 + UtilMath.r(11); i++) {
/* 175 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.EMERALD, 1));
/*     */       }
/* 177 */     } else if (event.getEntityType() == EntityType.IRON_GOLEM) {
/* 178 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.IRON_INGOT, 2 + UtilMath.r(3)));
/* 179 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 12 + UtilMath.r(13)));
/* 180 */     } else if (event.getEntityType() == EntityType.MAGMA_CUBE) {
/* 181 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.MAGMA_CREAM, 1));
/* 182 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1 + UtilMath.r(2)));
/* 183 */     } else if (event.getEntityType() == EntityType.PIG_ZOMBIE) {
/* 184 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.GRILLED_PORK, 1 + UtilMath.r(2)));
/* 185 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.ROTTEN_FLESH, 1 + UtilMath.r(2)));
/* 186 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 2 + UtilMath.r(2)));
/* 187 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.ARROW, 1 + UtilMath.r(12)));
/* 188 */       if (UtilMath.r(100) > 90) {
/* 189 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.GOLD_SWORD, 1));
/*     */       }
/* 191 */     } else if (event.getEntityType() == EntityType.SILVERFISH) {
/* 192 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1 + UtilMath.r(2)));
/* 193 */     } else if (event.getEntityType() == EntityType.SKELETON) {
/* 194 */       if (((Skeleton)event.getEntity()).getSkeletonType() == Skeleton.SkeletonType.NORMAL) {
/* 195 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.ARROW, 4 + UtilMath.r(5)));
/* 196 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 12 + UtilMath.r(13)));
/*     */       } else {
/* 198 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.ARROW, 4 + UtilMath.r(10)));
/* 199 */         drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 12 + UtilMath.r(26)));
/*     */       }
/* 201 */     } else if (event.getEntityType() == EntityType.SLIME) {
/* 202 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 1 + UtilMath.r(2)));
/* 203 */     } else if (event.getEntityType() == EntityType.SPIDER) {
/* 204 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.WEB, 2 + UtilMath.r(3)));
/* 205 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.SPIDER_EYE, 1));
/* 206 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 6 + UtilMath.r(7)));
/* 207 */     } else if (event.getEntityType() == EntityType.ZOMBIE) {
/* 208 */       event.getDrops().add(ItemStackFactory.Instance.CreateStack(Material.ROTTEN_FLESH, 1));
/* 209 */       drops.add(ItemStackFactory.Instance.CreateStack(Material.BONE, 6 + UtilMath.r(7)));
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void CustomCreeperExplode(EntityExplodeEvent event) {
/* 215 */     if (this._disableCustom) {
/* 216 */       return;
/*     */     }
/* 218 */     if (!(event.getEntity() instanceof Creeper)) {
/* 219 */       return;
/*     */     }
/* 221 */     HashMap<Player, Double> players = UtilPlayer.getInRadius(event.getEntity().getLocation(), 8.0D);
/* 222 */     for (Player cur : players.keySet()) {
/* 223 */       Vector vec = UtilAlg.getTrajectory(event.getEntity().getLocation(), cur.getLocation());
/* 224 */       UtilAction.velocity(cur, vec, 1.0D + 2.0D * ((Double)players.get(cur)).doubleValue(), false, 0.0D, 0.5D + 1.0D * ((Double)players.get(cur)).doubleValue(), 2.0D, true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void SetForce(boolean force) {
/* 229 */     this._spawnForce = force;
/*     */   }
/*     */   
/*     */   public void AddEntityName(LivingEntity ent, String name) {
/* 233 */     if (ent == null) {
/* 234 */       return;
/*     */     }
/* 236 */     UtilEnt.GetEntityNames().put(ent, name);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void UpdateEntityNames(UpdateEvent event) {
/* 241 */     if (event.getType() != UpdateType.FAST) {
/* 242 */       return;
/*     */     }
/* 244 */     HashSet<Entity> remove = new HashSet();
/* 245 */     for (Entity ent2 : UtilEnt.GetEntityNames().keySet()) {
/* 246 */       if ((ent2.isDead()) || (!ent2.isValid()))
/* 247 */         remove.add(ent2);
/*     */     }
/* 249 */     for (Entity ent2 : remove) {
/* 250 */       UtilEnt.GetEntityNames().remove(ent2);
/*     */     }
/*     */   }
/*     */   
/*     */   public void SetDisableCustomDrops(boolean var) {
/* 255 */     this._disableCustom = var;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\Creature.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */