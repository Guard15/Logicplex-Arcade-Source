/*    */ package mineplex.core.creature.command;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.creature.Creature;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HelpCommand
/*    */   extends CommandBase<Creature>
/*    */ {
/*    */   public HelpCommand(Creature plugin)
/*    */   {
/* 22 */     super(plugin, Rank.ADMIN, new String[] { "help" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 27 */     UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Commands List;"));
/* 28 */     UtilPlayer.message(caller, F.help("/mob", "List Entities", Rank.MODERATOR));
/* 29 */     UtilPlayer.message(caller, F.help("/mob kill <Type>", "Remove Entities of Type", Rank.ADMIN));
/* 30 */     UtilPlayer.message(caller, F.help("/mob <Type> (# baby lock angry s# <Prof>)", "Create", Rank.ADMIN));
/* 31 */     UtilPlayer.message(caller, F.desc("Professions", "Butcher, Blacksmith, Farmer, Librarian, Priest"));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\command\HelpCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */