/*     */ package mineplex.core.creature.command;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mineplex.core.command.MultiCommandBase;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.creature.Creature;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftLivingEntity;
/*     */ import org.bukkit.entity.Ageable;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Skeleton;
/*     */ import org.bukkit.entity.Skeleton.SkeletonType;
/*     */ import org.bukkit.entity.Slime;
/*     */ import org.bukkit.entity.Villager;
/*     */ import org.bukkit.entity.Villager.Profession;
/*     */ import org.bukkit.entity.Wolf;
/*     */ import org.bukkit.entity.Zombie;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MobCommand
/*     */   extends MultiCommandBase<Creature>
/*     */ {
/*     */   public MobCommand(Creature plugin)
/*     */   {
/*  56 */     super(plugin, Rank.ADMIN, new String[] { "mob" });
/*  57 */     AddCommand(new KillCommand((Creature)this.Plugin));
/*     */   }
/*     */   
/*     */   protected void Help(Player caller, String[] args) {
/*     */     Iterator localIterator2;
/*  62 */     if (args == null) {
/*  63 */       HashMap<EntityType, Integer> entMap = new HashMap();
/*  64 */       int count = 0;
/*  65 */       for (Iterator localIterator1 = UtilServer.getServer().getWorlds().iterator(); localIterator1.hasNext(); 
/*  66 */           localIterator2.hasNext())
/*     */       {
/*  65 */         World world = (World)localIterator1.next();
/*  66 */         localIterator2 = world.getEntities().iterator(); continue;Entity ent = (Entity)localIterator2.next();
/*  67 */         if (!entMap.containsKey(ent.getType())) {
/*  68 */           entMap.put(ent.getType(), Integer.valueOf(0));
/*     */         }
/*  70 */         entMap.put(ent.getType(), Integer.valueOf(1 + ((Integer)entMap.get(ent.getType())).intValue()));
/*  71 */         count++;
/*     */       }
/*     */       
/*  74 */       UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Listing Entities:"));
/*  75 */       for (EntityType cur : entMap.keySet()) {
/*  76 */         UtilPlayer.message(caller, F.desc(UtilEnt.getName(cur), entMap.get(cur)));
/*     */       }
/*  78 */       UtilPlayer.message(caller, F.desc("Total", count));
/*     */     } else {
/*  80 */       EntityType type = UtilEnt.searchEntity(caller, args[0], true);
/*  81 */       if (type == null) {
/*  82 */         return;
/*     */       }
/*  84 */       UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Spawning Creature(s);"));
/*  85 */       HashSet<String> argSet = new HashSet();
/*  86 */       for (int i = 1; i < args.length; i++) {
/*  87 */         if (args[i].length() > 0)
/*  88 */           argSet.add(args[i]);
/*     */       }
/*  90 */       int count = 1;
/*  91 */       Object argHandle = new HashSet();
/*  92 */       for (String arg2 : argSet) {
/*     */         try {
/*  94 */           int newCount = Integer.parseInt(arg2);
/*  95 */           if (newCount > 0) {
/*  96 */             count = newCount;
/*  97 */             UtilPlayer.message(caller, F.desc("Amount", count));
/*  98 */             ((HashSet)argHandle).add(arg2);
/*     */           }
/*     */         }
/*     */         catch (Exception localException1) {}
/*     */       }
/*     */       
/*     */ 
/* 105 */       for (String arg2 : (HashSet)argHandle) {
/* 106 */         argSet.remove(arg2);
/*     */       }
/* 108 */       HashSet<Entity> entSet = new HashSet();
/* 109 */       for (int i2 = 0; i2 < count; i2++) {
/* 110 */         entSet.add(((Creature)this.Plugin).SpawnEntity(caller.getTargetBlock(null, 0).getLocation().add(0.5D, 1.0D, 0.5D), type));
/*     */       }
/* 112 */       for (String arg3 : argSet)
/* 113 */         if (arg3.length() != 0)
/* 114 */           if ((arg3.equalsIgnoreCase("baby")) || (arg3.equalsIgnoreCase("b"))) {
/* 115 */             for (Entity ent2 : entSet) {
/* 116 */               if ((ent2 instanceof Ageable)) {
/* 117 */                 ((Ageable)ent2).setBaby();
/*     */ 
/*     */               }
/* 120 */               else if ((ent2 instanceof Zombie))
/* 121 */                 ((Zombie)ent2).setBaby(true);
/*     */             }
/* 123 */             UtilPlayer.message(caller, F.desc("Baby", "True"));
/* 124 */             ((HashSet)argHandle).add(arg3);
/*     */ 
/*     */           }
/* 127 */           else if ((arg3.equalsIgnoreCase("age")) || (arg3.equalsIgnoreCase("lock"))) {
/* 128 */             for (Entity ent2 : entSet)
/* 129 */               if ((ent2 instanceof Ageable)) {
/* 130 */                 ((Ageable)ent2).setAgeLock(true);
/* 131 */                 UtilPlayer.message(caller, F.desc("Age", "False"));
/*     */               }
/* 133 */             ((HashSet)argHandle).add(arg3);
/*     */ 
/*     */           }
/* 136 */           else if ((arg3.equalsIgnoreCase("angry")) || (arg3.equalsIgnoreCase("a"))) {
/* 137 */             for (Entity ent2 : entSet) {
/* 138 */               if ((ent2 instanceof Wolf))
/* 139 */                 ((Wolf)ent2).setAngry(true);
/*     */             }
/* 141 */             for (Entity ent2 : entSet) {
/* 142 */               if ((ent2 instanceof Skeleton))
/* 143 */                 ((Skeleton)ent2).setSkeletonType(Skeleton.SkeletonType.WITHER);
/*     */             }
/* 145 */             UtilPlayer.message(caller, F.desc("Angry", "True"));
/* 146 */             ((HashSet)argHandle).add(arg3);
/*     */           } else {
/*     */             Entity ent;
/* 149 */             if (arg3.toLowerCase().charAt(0) == 'p') {
/*     */               try {
/* 151 */                 String prof = arg3.substring(1, arg3.length());
/* 152 */                 Villager.Profession profession = null;
/* 153 */                 Villager.Profession[] arrayOfProfession; int j = (arrayOfProfession = Villager.Profession.values()).length; for (int i = 0; i < j; i++) { Villager.Profession cur = arrayOfProfession[i];
/* 154 */                   if (cur.name().toLowerCase().contains(prof.toLowerCase()))
/* 155 */                     profession = cur;
/*     */                 }
/* 157 */                 UtilPlayer.message(caller, F.desc("Profession", profession.name()));
/* 158 */                 for (Iterator localIterator4 = entSet.iterator(); localIterator4.hasNext();) { ent = (Entity)localIterator4.next();
/* 159 */                   if ((ent instanceof Villager)) {
/* 160 */                     ((Villager)ent).setProfession(profession);
/*     */                   }
/*     */                 }
/*     */               } catch (Exception e) {
/* 164 */                 UtilPlayer.message(caller, F.desc("Profession", "Invalid [" + arg3 + "] on " + type.name()));
/*     */               }
/* 166 */               ((HashSet)argHandle).add(arg3);
/*     */ 
/*     */             }
/* 169 */             else if (arg3.toLowerCase().charAt(0) == 's') {
/*     */               try {
/* 171 */                 String size = arg3.substring(1, arg3.length());
/* 172 */                 UtilPlayer.message(caller, F.desc("Size", Integer.parseInt(size)));
/* 173 */                 for (Entity ent : entSet) {
/* 174 */                   if ((ent instanceof Slime)) {
/* 175 */                     ((Slime)ent).setSize(Integer.parseInt(size));
/*     */                   }
/*     */                 }
/*     */               } catch (Exception e) {
/* 179 */                 UtilPlayer.message(caller, F.desc("Size", "Invalid [" + arg3 + "] on " + type.name()));
/*     */               }
/* 181 */               ((HashSet)argHandle).add(arg3);
/*     */ 
/*     */             }
/* 184 */             else if ((arg3.toLowerCase().charAt(0) == 'n') && (arg3.length() > 1)) {
/*     */               try {
/* 186 */                 String name = "";
/* 187 */                 char[] arrayOfChar; Entity localEntity1 = (arrayOfChar = arg3.substring(1, arg3.length()).toCharArray()).length; for (ent = 0; ent < localEntity1; ent++) { char c = arrayOfChar[ent];
/* 188 */                   name = name + " ";
/*     */                 }
/* 190 */                 for (Entity ent : entSet) {
/* 191 */                   if ((ent instanceof CraftLivingEntity)) {
/* 192 */                     CraftLivingEntity cEnt = (CraftLivingEntity)ent;
/* 193 */                     cEnt.setCustomName(name);
/* 194 */                     cEnt.setCustomNameVisible(true);
/*     */                   }
/*     */                 }
/*     */               } catch (Exception e) {
/* 198 */                 UtilPlayer.message(caller, F.desc("Size", "Invalid [" + arg3 + "] on " + type.name()));
/*     */               }
/* 200 */               ((HashSet)argHandle).add(arg3);
/*     */             } }
/* 202 */       for (String arg4 : (HashSet)argHandle) {
/* 203 */         argSet.remove(arg4);
/*     */       }
/* 205 */       for (String arg5 : argSet) {
/* 206 */         UtilPlayer.message(caller, F.desc("Unhandled", arg5));
/*     */       }
/* 208 */       UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Spawned " + count + " " + UtilEnt.getName(type) + "."));
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\command\MobCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */