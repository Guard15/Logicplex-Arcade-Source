/*    */ package mineplex.core.creature.command;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilEnt;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.creature.Creature;
/*    */ import mineplex.core.creature.event.CreatureKillEntitiesEvent;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class KillCommand
/*    */   extends CommandBase<Creature>
/*    */ {
/*    */   public KillCommand(Creature plugin)
/*    */   {
/* 37 */     super(plugin, Rank.ADMIN, new String[] { "kill", "k" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 42 */     if ((args == null) || (args.length == 0)) {
/* 43 */       UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Missing Entity Type Parameter."));
/* 44 */       return;
/*    */     }
/* 46 */     EntityType type = UtilEnt.searchEntity(caller, args[0], true);
/* 47 */     if ((type == null) && (!args[0].equalsIgnoreCase("all"))) {
/* 48 */       return;
/*    */     }
/* 50 */     int count = 0;
/* 51 */     ArrayList<Entity> killList = new ArrayList();
/* 52 */     Iterator localIterator2; Entity ent; for (Iterator localIterator1 = UtilServer.getServer().getWorlds().iterator(); localIterator1.hasNext(); 
/* 53 */         localIterator2.hasNext())
/*    */     {
/* 52 */       World world = (World)localIterator1.next();
/* 53 */       localIterator2 = world.getEntities().iterator(); continue;ent = (Entity)localIterator2.next();
/* 54 */       if ((ent.getType() != EntityType.PLAYER) && ((type == null) || (ent.getType() == type))) {
/* 55 */         killList.add(ent);
/*    */       }
/*    */     }
/* 58 */     CreatureKillEntitiesEvent event = new CreatureKillEntitiesEvent(killList);
/* 59 */     ((Creature)this.Plugin).getPlugin().getServer().getPluginManager().callEvent(event);
/* 60 */     for (Entity entity : event.GetEntities()) {
/* 61 */       entity.remove();
/* 62 */       count++;
/*    */     }
/* 64 */     String target = "ALL";
/* 65 */     if (type != null) {
/* 66 */       target = UtilEnt.getName(type);
/*    */     }
/* 68 */     UtilPlayer.message(caller, F.main(((Creature)this.Plugin).getName(), "Killed " + target + ". " + count + " Removed."));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\creature\command\KillCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */