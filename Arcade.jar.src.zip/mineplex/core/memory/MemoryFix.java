/*    */ package mineplex.core.memory;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import net.minecraft.server.v1_7_R4.CraftingManager;
/*    */ import net.minecraft.server.v1_7_R4.IInventory;
/*    */ import net.minecraft.server.v1_7_R4.WorldServer;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*    */ import org.bukkit.entity.HumanEntity;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class MemoryFix extends MiniPlugin
/*    */ {
/*    */   private static Field _intHashMap;
/*    */   
/*    */   public MemoryFix(JavaPlugin plugin)
/*    */   {
/* 26 */     super("Memory Fix", plugin);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   @EventHandler
/*    */   public void fixInventoryLeaks(UpdateEvent event)
/*    */   {
/* 34 */     if (event.getType() != UpdateType.SLOW)
/*    */       return;
/*    */     Iterator localIterator2;
/* 37 */     for (Iterator localIterator1 = org.bukkit.Bukkit.getWorlds().iterator(); localIterator1.hasNext(); 
/*    */         
/* 39 */         localIterator2.hasNext())
/*    */     {
/* 37 */       World world = (World)localIterator1.next();
/*    */       
/* 39 */       localIterator2 = ((CraftWorld)world).getHandle().tileEntityList.iterator(); continue;Object tileEntity = localIterator2.next();
/*    */       
/* 41 */       if ((tileEntity instanceof IInventory))
/*    */       {
/* 43 */         Iterator<HumanEntity> entityIterator = ((IInventory)tileEntity).getViewers().iterator();
/*    */         
/* 45 */         while (entityIterator.hasNext())
/*    */         {
/* 47 */           HumanEntity entity = (HumanEntity)entityIterator.next();
/*    */           
/* 49 */           if (((entity instanceof CraftPlayer)) && (!((CraftPlayer)entity).isOnline()))
/*    */           {
/* 51 */             entityIterator.remove();
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 58 */     CraftingManager.getInstance().lastCraftView = null;
/* 59 */     CraftingManager.getInstance().lastRecipe = null;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void fixEntityTrackerLeak(UpdateEvent event)
/*    */   {
/* 65 */     if (event.getType() != UpdateType.SLOW) {}
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\memory\MemoryFix.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */