/*    */ package mineplex.core.ignore.data;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class IgnoreData
/*    */ {
/*  7 */   private ArrayList<String> _ignored = new ArrayList();
/*    */   
/*    */   public ArrayList<String> getIgnored()
/*    */   {
/* 11 */     return this._ignored;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\ignore\data\IgnoreData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */