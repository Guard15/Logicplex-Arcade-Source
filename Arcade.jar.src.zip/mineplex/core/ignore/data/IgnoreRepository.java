/*    */ package mineplex.core.ignore.data;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import mineplex.core.database.DBPool;
/*    */ import mineplex.core.database.RepositoryBase;
/*    */ import mineplex.core.database.column.Column;
/*    */ import mineplex.core.database.column.ColumnVarChar;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class IgnoreRepository extends RepositoryBase
/*    */ {
/* 15 */   private static String CREATE_IGNORE_TABLE = "CREATE TABLE IF NOT EXISTS accountIgnore (id INT NOT NULL AUTO_INCREMENT, uuidIgnorer VARCHAR(100), uuidIgnored VARCHAR(100));";
/* 16 */   private static String ADD_IGNORE_RECORD = "INSERT INTO accountIgnore (uuidIgnorer, uuidIgnored) SELECT fA.uuid AS uuidIgnorer, tA.uuid AS uuidIgnored FROM accounts as fA LEFT JOIN accounts AS tA ON tA.name = ? WHERE fA.name = ?;";
/* 17 */   private static String DELETE_IGNORE_RECORD = "DELETE aF FROM accountIgnore AS aF INNER JOIN accounts as fA ON aF.uuidIgnorer = fA.uuid INNER JOIN accounts AS tA ON aF.uuidIgnored = tA.uuid WHERE fA.name = ? AND tA.name = ?;";
/*    */   
/*    */   public IgnoreRepository(JavaPlugin plugin)
/*    */   {
/* 21 */     super(plugin, DBPool.ACCOUNT);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void initialize() {}
/*    */   
/*    */ 
/*    */ 
/*    */   protected void update() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean addIgnore(Player caller, String name)
/*    */   {
/* 36 */     int rowsAffected = executeUpdate(ADD_IGNORE_RECORD, new Column[] { new ColumnVarChar("name", 100, name), new ColumnVarChar("name", 100, 
/* 37 */       caller.getName()) });
/*    */     
/* 39 */     return rowsAffected > 0;
/*    */   }
/*    */   
/*    */   public boolean removeIgnore(String caller, String name)
/*    */   {
/* 44 */     int rowsAffected = executeUpdate(DELETE_IGNORE_RECORD, new Column[] { new ColumnVarChar("name", 100, caller), new ColumnVarChar("name", 
/* 45 */       100, name) });
/*    */     
/* 47 */     return rowsAffected > 0;
/*    */   }
/*    */   
/*    */   public IgnoreData loadClientInformation(ResultSet resultSet) throws SQLException
/*    */   {
/* 52 */     IgnoreData ignoreData = new IgnoreData();
/*    */     
/* 54 */     while (resultSet.next())
/*    */     {
/* 56 */       ignoreData.getIgnored().add(resultSet.getString(1));
/*    */     }
/*    */     
/* 59 */     return ignoreData;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\ignore\data\IgnoreRepository.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */