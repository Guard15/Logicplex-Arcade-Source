/*    */ package mineplex.core.ignore.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.command.CommandCenter;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.ignore.IgnoreManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Ignore extends CommandBase<IgnoreManager>
/*    */ {
/*    */   public Ignore(IgnoreManager plugin)
/*    */   {
/* 14 */     super(plugin, mineplex.core.common.Rank.ALL, new String[] { "ignore" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 20 */     if (args == null)
/*    */     {
/* 22 */       ((IgnoreManager)this.Plugin).showIgnores(caller);
/*    */     }
/*    */     else
/*    */     {
/* 26 */       this.CommandCenter.GetClientManager().checkPlayerName(caller, args[0], new Callback()
/*    */       {
/*    */         public void run(String result)
/*    */         {
/* 30 */           if (result != null)
/*    */           {
/* 32 */             ((IgnoreManager)Ignore.this.Plugin).addIgnore(caller, result);
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\ignore\command\Ignore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */