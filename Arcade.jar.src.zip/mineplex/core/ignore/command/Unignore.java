/*    */ package mineplex.core.ignore.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.command.CommandCenter;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.ignore.IgnoreManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Unignore extends CommandBase<IgnoreManager>
/*    */ {
/*    */   public Unignore(IgnoreManager plugin)
/*    */   {
/* 15 */     super(plugin, mineplex.core.common.Rank.ALL, new String[] { "unignore" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null) {
/* 22 */       caller.sendMessage(F.main(((IgnoreManager)this.Plugin).getName(), "You need to include a player's name."));
/*    */     }
/*    */     else {
/* 25 */       this.CommandCenter.GetClientManager().checkPlayerName(caller, args[0], new Callback()
/*    */       {
/*    */         public void run(String result)
/*    */         {
/* 29 */           if (result != null)
/*    */           {
/* 31 */             ((IgnoreManager)Unignore.this.Plugin).removeIgnore(caller, result);
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\ignore\command\Unignore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */