/*     */ package mineplex.core.ignore;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.MiniDbClientPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.jsonchat.ChildJsonMessage;
/*     */ import mineplex.core.common.jsonchat.JsonMessage;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.ignore.command.Ignore;
/*     */ import mineplex.core.ignore.command.Unignore;
/*     */ import mineplex.core.ignore.data.IgnoreData;
/*     */ import mineplex.core.ignore.data.IgnoreRepository;
/*     */ import mineplex.core.portal.Portal;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class IgnoreManager extends MiniDbClientPlugin<IgnoreData>
/*     */ {
/*     */   private PreferencesManager _preferenceManager;
/*     */   private IgnoreRepository _repository;
/*     */   private Portal _portal;
/*     */   
/*     */   public IgnoreManager(JavaPlugin plugin, CoreClientManager clientManager, PreferencesManager preferences, Portal portal)
/*     */   {
/*  38 */     super("Ignore", plugin, clientManager);
/*     */     
/*  40 */     this._preferenceManager = preferences;
/*  41 */     this._repository = new IgnoreRepository(plugin);
/*  42 */     this._portal = portal;
/*     */   }
/*     */   
/*     */   public PreferencesManager getPreferenceManager()
/*     */   {
/*  47 */     return this._preferenceManager;
/*     */   }
/*     */   
/*     */   public Portal getPortal()
/*     */   {
/*  52 */     return this._portal;
/*     */   }
/*     */   
/*     */   public boolean isIgnoring(Player caller, Player target)
/*     */   {
/*  57 */     return isIgnoring(caller, target.getName());
/*     */   }
/*     */   
/*     */   public boolean isIgnoring(Player caller, String target)
/*     */   {
/*  62 */     IgnoreData data = (IgnoreData)Get(caller);
/*     */     
/*  64 */     for (String ignored : data.getIgnored())
/*     */     {
/*  66 */       if (ignored.equalsIgnoreCase(target))
/*     */       {
/*  68 */         return true;
/*     */       }
/*     */     }
/*     */     
/*  72 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/*  78 */     addCommand(new Ignore(this));
/*  79 */     addCommand(new Unignore(this));
/*     */   }
/*     */   
/*     */ 
/*     */   protected IgnoreData AddPlayer(String player)
/*     */   {
/*  85 */     return new IgnoreData();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onChat(AsyncPlayerChatEvent event)
/*     */   {
/*  91 */     if (this.ClientManager.Get(event.getPlayer()).GetRank().Has(Rank.HELPER)) {
/*  92 */       return;
/*     */     }
/*  94 */     Iterator<Player> itel = event.getRecipients().iterator();
/*     */     
/*  96 */     while (itel.hasNext())
/*     */     {
/*  98 */       Player player = (Player)itel.next();
/*     */       
/* 100 */       IgnoreData info = (IgnoreData)Get(player);
/*     */       
/* 102 */       for (String ignored : info.getIgnored())
/*     */       {
/* 104 */         if (ignored.equalsIgnoreCase(event.getPlayer().getName()))
/*     */         {
/* 106 */           itel.remove();
/*     */           
/* 108 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addIgnore(final Player caller, final String name)
/*     */   {
/* 116 */     if (caller.getName().equalsIgnoreCase(name))
/*     */     {
/* 118 */       caller.sendMessage(F.main(getName(), ChatColor.GRAY + "You cannot ignore yourself"));
/* 119 */       return;
/*     */     }
/*     */     
/* 122 */     for (String status : ((IgnoreData)Get(caller)).getIgnored())
/*     */     {
/* 124 */       if (status.equalsIgnoreCase(name))
/*     */       {
/* 126 */         caller.sendMessage(F.main(getName(), ChatColor.GREEN + name + ChatColor.GRAY + " has already been ignored."));
/* 127 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 132 */     IgnoreData ignoreData = (IgnoreData)Get(caller);
/*     */     
/* 134 */     if (ignoreData != null)
/*     */     {
/* 136 */       ignoreData.getIgnored().add(name);
/*     */     }
/*     */     
/* 139 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 143 */         IgnoreManager.this._repository.addIgnore(caller, name);
/*     */         
/* 145 */         Bukkit.getServer().getScheduler().runTask(IgnoreManager.this._plugin, new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 149 */             this.val$caller.sendMessage(F.main(IgnoreManager.this.getName(), "Now ignoring " + ChatColor.GREEN + this.val$name));
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void removeIgnore(final Player caller, final String name)
/*     */   {
/* 158 */     IgnoreData ignoreData = (IgnoreData)Get(caller);
/*     */     
/* 160 */     if (ignoreData != null)
/*     */     {
/* 162 */       Iterator<String> itel = ignoreData.getIgnored().iterator();
/*     */       
/* 164 */       while (itel.hasNext())
/*     */       {
/* 166 */         String ignored = (String)itel.next();
/*     */         
/* 168 */         if (ignored.equalsIgnoreCase(name))
/*     */         {
/* 170 */           itel.remove();
/* 171 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 176 */     caller.sendMessage(F.main(getName(), "No longer ignoring " + ChatColor.GREEN + name + ChatColor.GRAY + "!"));
/*     */     
/* 178 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 182 */         IgnoreManager.this._repository.removeIgnore(caller.getName(), name);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void showIgnores(Player caller)
/*     */   {
/* 189 */     java.util.List<String> ignoredPlayers = ((IgnoreData)Get(caller)).getIgnored();
/*     */     
/* 191 */     caller.sendMessage(C.cAqua + C.Strike + "=====================[" + ChatColor.RESET + C.cWhite + C.Bold + "Ignoring" + 
/* 192 */       ChatColor.RESET + C.cAqua + C.Strike + "]======================");
/*     */     
/* 194 */     ArrayList<ChildJsonMessage> sentLines = new ArrayList();
/*     */     
/* 196 */     for (String ignored : ignoredPlayers)
/*     */     {
/*     */ 
/* 199 */       ChildJsonMessage message = new JsonMessage("").color("white").extra("").color("white");
/*     */       
/* 201 */       message.add("Ignoring " + ignored).color("gray");
/*     */       
/* 203 */       message.add(" - ").color("white");
/*     */       
/* 205 */       message.add("Unignore").color("red").bold().click("run_command", "/unignore " + ignored)
/* 206 */         .hover("show_text", "Stop ignoring " + ignored);
/*     */       
/* 208 */       sentLines.add(message);
/*     */     }
/*     */     
/*     */ 
/* 212 */     for (JsonMessage msg : sentLines) {
/* 213 */       msg.sendToPlayer(caller);
/*     */     }
/* 215 */     if (sentLines.isEmpty())
/*     */     {
/* 217 */       caller.sendMessage(" ");
/* 218 */       caller.sendMessage("Welcome to your Ignore List!");
/* 219 */       caller.sendMessage(" ");
/* 220 */       caller.sendMessage("To ignore people, type " + C.cGreen + "/ignore <Player Name>");
/* 221 */       caller.sendMessage(" ");
/* 222 */       caller.sendMessage("Type " + C.cGreen + "/ignore" + ChatColor.RESET + " at any time to view the ignored!");
/* 223 */       caller.sendMessage(" ");
/*     */     }
/*     */     
/* 226 */     ChildJsonMessage message = new JsonMessage("").extra(C.cAqua + C.Strike + 
/* 227 */       "=====================================================");
/*     */     
/* 229 */     message.sendToPlayer(caller);
/*     */   }
/*     */   
/*     */   public void processLoginResultSet(String playerName, int accountId, ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 235 */     Set(playerName, this._repository.loadClientInformation(resultSet));
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQuery(int accountId, String uuid, String name)
/*     */   {
/* 241 */     return 
/* 242 */       "SELECT tA.Name FROM accountIgnore INNER Join accounts AS fA ON fA.uuid = uuidIgnorer INNER JOIN accounts AS tA ON tA.uuid = uuidIgnored LEFT JOIN playerMap ON tA.name = playerName WHERE uuidIgnorer = '" + uuid + "';";
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\ignore\IgnoreManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */