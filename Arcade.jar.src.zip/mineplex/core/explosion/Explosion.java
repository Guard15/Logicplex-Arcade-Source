/*     */ package mineplex.core.explosion;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.blockrestore.BlockRestore;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.FallingBlock;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.TNTPrimed;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.entity.ExplosionPrimeEvent;
/*     */ import org.bukkit.event.entity.ItemSpawnEvent;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class Explosion extends MiniPlugin
/*     */ {
/*  41 */   private boolean _regenerateGround = false;
/*  42 */   private boolean _temporaryDebris = true;
/*  43 */   private boolean _enableDebris = false;
/*  44 */   private boolean _tntSpread = true;
/*  45 */   private boolean _liquidDamage = true;
/*  46 */   private HashSet<FallingBlock> _explosionBlocks = new HashSet();
/*     */   
/*     */   private BlockRestore _blockRestore;
/*     */   
/*     */   public Explosion(JavaPlugin plugin, BlockRestore blockRestore)
/*     */   {
/*  52 */     super("Block Restore", plugin);
/*     */     
/*  54 */     this._blockRestore = blockRestore;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void ExplosionPrime(ExplosionPrimeEvent event)
/*     */   {
/*  60 */     if (event.getRadius() >= 5.0F) {
/*  61 */       return;
/*     */     }
/*  63 */     if (this._liquidDamage) {
/*  64 */       for (Block block : UtilBlock.getInRadius(event.getEntity().getLocation(), event.getRadius()).keySet())
/*  65 */         if (block.isLiquid())
/*  66 */           block.setTypeId(0);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void ExplosionEntity(EntityExplodeEvent event) {
/*  72 */     if (event.isCancelled()) {
/*  73 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  77 */       if (event.getEntityType() == EntityType.CREEPER) {
/*  78 */         event.blockList().clear();
/*     */       }
/*  80 */       if (event.getEntityType() == EntityType.WITHER_SKULL) {
/*  81 */         event.blockList().clear();
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*  88 */     if (event.blockList().isEmpty()) {
/*  89 */       return;
/*     */     }
/*     */     
/*  92 */     Player owner = null;
/*  93 */     Entity entity = event.getEntity();
/*  94 */     if (entity.hasMetadata("owner"))
/*     */     {
/*  96 */       FixedMetadataValue ownerData = (FixedMetadataValue)entity.getMetadata("owner").get(0);
/*  97 */       UUID ownerUUID = (UUID)ownerData.value();
/*     */       
/*  99 */       owner = mineplex.core.common.util.UtilPlayer.searchExact(ownerUUID);
/*     */     }
/*     */     
/*     */ 
/* 103 */     ExplosionEvent explodeEvent = new ExplosionEvent(event.blockList(), owner);
/* 104 */     this._plugin.getServer().getPluginManager().callEvent(explodeEvent);
/*     */     
/* 106 */     event.setYield(0.0F);
/*     */     
/*     */ 
/* 109 */     final HashMap<Block, Map.Entry<Integer, Byte>> blocks = new HashMap();
/*     */     
/* 111 */     for (Block cur : event.blockList())
/*     */     {
/* 113 */       if ((cur.getTypeId() != 0) && (!cur.isLiquid()))
/*     */       {
/*     */ 
/* 116 */         if ((cur.getType() == Material.CHEST) || 
/* 117 */           (cur.getType() == Material.IRON_ORE) || 
/* 118 */           (cur.getType() == Material.COAL_ORE) || 
/* 119 */           (cur.getType() == Material.GOLD_ORE) || 
/* 120 */           (cur.getType() == Material.DIAMOND_ORE))
/*     */         {
/* 122 */           cur.breakNaturally();
/*     */         }
/*     */         else
/*     */         {
/* 126 */           blocks.put(cur, new AbstractMap.SimpleEntry(Integer.valueOf(cur.getTypeId()), Byte.valueOf(cur.getData())));
/*     */           
/* 128 */           if (!this._regenerateGround)
/*     */           {
/* 130 */             if ((cur.getTypeId() != 98) || ((cur.getData() != 0) && (cur.getData() != 3))) {
/* 131 */               cur.setTypeId(0);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 136 */             int heightDiff = cur.getLocation().getBlockY() - event.getEntity().getLocation().getBlockY();
/* 137 */             this._blockRestore.Add(cur, 0, (byte)0, (20000 + heightDiff * 3000 + Math.random() * 2900.0D));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 142 */     event.blockList().clear();
/*     */     
/*     */ 
/*     */ 
/* 146 */     final Entity fEnt = event.getEntity();
/* 147 */     final Location fLoc = event.getLocation();
/* 148 */     this._plugin.getServer().getScheduler().runTaskLater(this._plugin, new Runnable()
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/* 153 */         for (Block cur : blocks.keySet())
/*     */         {
/* 155 */           if ((((Integer)((Map.Entry)blocks.get(cur)).getKey()).intValue() != 98) || (
/* 156 */             (((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue() != 0) && (((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue() != 3)))
/*     */           {
/*     */ 
/*     */ 
/* 160 */             if ((Explosion.this._tntSpread) && (((Integer)((Map.Entry)blocks.get(cur)).getKey()).intValue() == 46))
/*     */             {
/* 162 */               TNTPrimed ent = (TNTPrimed)cur.getWorld().spawn(cur.getLocation().add(0.5D, 0.5D, 0.5D), TNTPrimed.class);
/* 163 */               Vector vec = UtilAlg.getTrajectory(fEnt, ent);
/* 164 */               if (vec.getY() < 0.0D) { vec.setY(vec.getY() * -1.0D);
/*     */               }
/* 166 */               UtilAction.velocity(ent, vec, 1.0D, false, 0.0D, 0.6D, 10.0D, false);
/*     */               
/* 168 */               ent.setFuseTicks(10);
/*     */ 
/*     */             }
/*     */             else
/*     */             {
/*     */ 
/* 174 */               double chance = 0.85D + Explosion.this._explosionBlocks.size() / 500.0D;
/* 175 */               if (Math.random() > Math.min(0.975D, chance))
/*     */               {
/* 177 */                 FallingBlock fall = cur.getWorld().spawnFallingBlock(cur.getLocation().add(0.5D, 0.5D, 0.5D), ((Integer)((Map.Entry)blocks.get(cur)).getKey()).intValue(), ((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue());
/*     */                 
/* 179 */                 Vector vec = UtilAlg.getTrajectory(fEnt, fall);
/* 180 */                 if (vec.getY() < 0.0D) { vec.setY(vec.getY() * -1.0D);
/*     */                 }
/* 182 */                 UtilAction.velocity(fall, vec, 0.5D + 0.25D * Math.random(), false, 0.0D, 0.4D + 0.2D * Math.random(), 10.0D, false);
/*     */                 
/* 184 */                 Explosion.this._explosionBlocks.add(fall);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 202 */         for (Block cur : UtilBlock.getInRadius(fLoc, 4.0D).keySet())
/* 203 */           if ((cur.getTypeId() == 98) && (
/* 204 */             (cur.getData() == 0) || (cur.getData() == 3)))
/* 205 */             cur.setTypeIdAndData(98, (byte)2, true);
/*     */       }
/* 207 */     }, 1L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void ExplosionBlockUpdate(UpdateEvent event)
/*     */   {
/* 213 */     if (event.getType() != UpdateType.TICK) {
/* 214 */       return;
/*     */     }
/*     */     
/* 217 */     Iterator<FallingBlock> fallingIterator = this._explosionBlocks.iterator();
/*     */     
/* 219 */     while (fallingIterator.hasNext())
/*     */     {
/* 221 */       FallingBlock cur = (FallingBlock)fallingIterator.next();
/*     */       
/* 223 */       if ((cur.isDead()) || (!cur.isValid()) || (cur.getTicksLived() > 400) || (!cur.getWorld().isChunkLoaded(cur.getLocation().getBlockX() >> 4, cur.getLocation().getBlockZ() >> 4)))
/*     */       {
/* 225 */         fallingIterator.remove();
/*     */         
/*     */ 
/* 228 */         if ((cur.getTicksLived() > 400) || (!cur.getWorld().isChunkLoaded(cur.getLocation().getBlockX() >> 4, cur.getLocation().getBlockZ() >> 4)))
/*     */         {
/* 230 */           cur.remove();
/* 231 */           return;
/*     */         }
/*     */         
/* 234 */         Block block = cur.getLocation().getBlock();
/* 235 */         block.setTypeIdAndData(0, (byte)0, true);
/*     */         
/*     */ 
/* 238 */         if (this._enableDebris)
/*     */         {
/* 240 */           if (this._temporaryDebris)
/*     */           {
/* 242 */             this._blockRestore.Add(block, cur.getBlockId(), cur.getBlockData(), 10000L);
/*     */           }
/*     */           else
/*     */           {
/* 246 */             block.setTypeIdAndData(cur.getBlockId(), cur.getBlockData(), true);
/*     */           }
/*     */           
/*     */         }
/*     */         else {
/* 251 */           cur.getWorld().playEffect(block.getLocation(), org.bukkit.Effect.STEP_SOUND, cur.getBlockId());
/*     */         }
/*     */         
/* 254 */         cur.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void ExplosionItemSpawn(ItemSpawnEvent event)
/*     */   {
/* 262 */     for (FallingBlock block : this._explosionBlocks) {
/* 263 */       if (UtilMath.offset(event.getEntity().getLocation(), block.getLocation()) < 1.0D)
/* 264 */         event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=org.bukkit.event.EventPriority.LOW)
/*     */   public void ExplosionBlocks(EntityExplodeEvent event) {
/* 270 */     if (event.getEntity() == null) {
/* 271 */       event.blockList().clear();
/*     */     }
/*     */   }
/*     */   
/*     */   public void SetRegenerate(boolean regenerate) {
/* 276 */     this._regenerateGround = regenerate;
/*     */   }
/*     */   
/*     */   public void SetDebris(boolean value)
/*     */   {
/* 281 */     this._enableDebris = value;
/*     */   }
/*     */   
/*     */   public void SetLiquidDamage(boolean value)
/*     */   {
/* 286 */     this._liquidDamage = value;
/*     */   }
/*     */   
/*     */   public void SetTNTSpread(boolean value)
/*     */   {
/* 291 */     this._tntSpread = value;
/*     */   }
/*     */   
/*     */   public void SetTemporaryDebris(boolean value)
/*     */   {
/* 296 */     this._temporaryDebris = value;
/*     */   }
/*     */   
/*     */   public HashSet<FallingBlock> GetExplosionBlocks()
/*     */   {
/* 301 */     return this._explosionBlocks;
/*     */   }
/*     */   
/*     */   public void BlockExplosion(Collection<Block> blockSet, Location mid, boolean onlyAbove)
/*     */   {
/* 306 */     BlockExplosion(blockSet, mid, onlyAbove, true);
/*     */   }
/*     */   
/*     */   public void BlockExplosion(Collection<Block> blockSet, Location mid, boolean onlyAbove, boolean removeBlock)
/*     */   {
/* 311 */     if (blockSet.isEmpty()) {
/* 312 */       return;
/*     */     }
/*     */     
/* 315 */     final HashMap<Block, Map.Entry<Integer, Byte>> blocks = new HashMap();
/*     */     
/* 317 */     for (Block cur : blockSet)
/*     */     {
/* 319 */       if (cur.getTypeId() != 0)
/*     */       {
/*     */ 
/* 322 */         if ((!onlyAbove) || (cur.getY() >= mid.getY()))
/*     */         {
/*     */ 
/* 325 */           blocks.put(cur, new AbstractMap.SimpleEntry(Integer.valueOf(cur.getTypeId()), Byte.valueOf(cur.getData())));
/*     */           
/* 327 */           if (removeBlock)
/*     */           {
/* 329 */             cur.setType(Material.AIR);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 334 */     final Location fLoc = mid;
/* 335 */     this._plugin.getServer().getScheduler().runTaskLater(this._plugin, new Runnable()
/*     */     {
/*     */ 
/*     */       public void run()
/*     */       {
/* 340 */         for (Block cur : blocks.keySet())
/*     */         {
/* 342 */           if ((((Integer)((Map.Entry)blocks.get(cur)).getKey()).intValue() != 98) || (
/* 343 */             (((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue() != 0) && (((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue() != 3)))
/*     */           {
/*     */ 
/* 346 */             double chance = 0.2D + Explosion.this._explosionBlocks.size() / 80.0D;
/* 347 */             if (Math.random() > Math.min(0.98D, chance))
/*     */             {
/* 349 */               FallingBlock fall = cur.getWorld().spawnFallingBlock(cur.getLocation().add(0.5D, 0.5D, 0.5D), ((Integer)((Map.Entry)blocks.get(cur)).getKey()).intValue(), ((Byte)((Map.Entry)blocks.get(cur)).getValue()).byteValue());
/*     */               
/* 351 */               Vector vec = UtilAlg.getTrajectory(fLoc, fall.getLocation());
/* 352 */               if (vec.getY() < 0.0D) { vec.setY(vec.getY() * -1.0D);
/*     */               }
/* 354 */               UtilAction.velocity(fall, vec, 0.5D + 0.25D * Math.random(), false, 0.0D, 0.4D + 0.2D * Math.random(), 10.0D, false);
/*     */               
/* 356 */               Explosion.this._explosionBlocks.add(fall);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 361 */     }, 1L);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\explosion\Explosion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */