/*    */ package mineplex.core.explosion;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class ExplosionEvent
/*    */   extends Event
/*    */ {
/* 12 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Player _owner;
/*    */   private Collection<Block> _blocks;
/*    */   
/*    */   public ExplosionEvent(Collection<Block> blocks)
/*    */   {
/* 19 */     this(blocks, null);
/*    */   }
/*    */   
/*    */   public ExplosionEvent(Collection<Block> blocks, Player owner)
/*    */   {
/* 24 */     this._blocks = blocks;
/* 25 */     this._owner = owner;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 30 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 35 */     return handlers;
/*    */   }
/*    */   
/*    */   public Collection<Block> GetBlocks()
/*    */   {
/* 40 */     return this._blocks;
/*    */   }
/*    */   
/*    */   public Player getOwner()
/*    */   {
/* 45 */     return this._owner;
/*    */   }
/*    */   
/*    */   public void setOwner(Player owner)
/*    */   {
/* 50 */     this._owner = owner;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\explosion\ExplosionEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */