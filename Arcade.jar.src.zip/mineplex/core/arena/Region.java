/*     */ package mineplex.core.arena;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Region
/*     */ {
/*     */   private String _name;
/*     */   private transient Vector _pointOne;
/*     */   private transient Vector _pointTwo;
/*     */   private List<String> _owners;
/*  19 */   private Boolean _blockPassage = Boolean.valueOf(false);
/*  20 */   private Boolean _blockChange = Boolean.valueOf(true);
/*     */   private int _priority;
/*     */   private int _minX;
/*     */   private int _minY;
/*     */   private int _minZ;
/*     */   private int _maxX;
/*     */   private int _maxY;
/*     */   private int _maxZ;
/*     */   
/*     */   public Region(String name, Vector pointOne, Vector pointTwo) {
/*  30 */     this._name = name;
/*  31 */     this._pointOne = pointOne;
/*  32 */     this._pointTwo = pointTwo;
/*  33 */     this._priority = 0;
/*  34 */     this._owners = new ArrayList();
/*  35 */     UpdateMinMax();
/*     */   }
/*     */   
/*     */   public Vector GetMaximumPoint() {
/*  39 */     return new Vector(this._maxX, this._maxY, this._maxZ);
/*     */   }
/*     */   
/*     */   public void AdjustRegion(Vector vector) {
/*  43 */     this._minX += vector.getBlockX();
/*  44 */     this._minY += vector.getBlockY();
/*  45 */     this._minZ += vector.getBlockZ();
/*  46 */     this._maxX += vector.getBlockX();
/*  47 */     this._maxY += vector.getBlockY();
/*  48 */     this._maxZ += vector.getBlockZ();
/*     */   }
/*     */   
/*     */   public Vector GetMinimumPoint() {
/*  52 */     return new Vector(this._minX, this._minY, this._minZ);
/*     */   }
/*     */   
/*     */   public Vector GetMidPoint() {
/*  56 */     return new Vector((this._maxX - this._minX) / 2 + this._minX, (this._maxY - this._minY) / 2 + this._minY, (this._maxZ - this._minZ) / 2 + this._minZ);
/*     */   }
/*     */   
/*     */   public void SetPriority(int priority) {
/*  60 */     this._priority = priority;
/*     */   }
/*     */   
/*     */   public int GetPriority() {
/*  64 */     return this._priority;
/*     */   }
/*     */   
/*     */   public Boolean Contains(Vector v) {
/*  68 */     if ((v.getBlockX() >= this._minX) && (v.getBlockX() <= this._maxX) && (v.getBlockY() >= this._minY) && (v.getBlockY() <= this._maxY) && (v.getBlockZ() >= this._minZ) && (v.getBlockZ() <= this._maxZ)) return Boolean.valueOf(true); return Boolean.valueOf(false);
/*     */   }
/*     */   
/*     */   public void AddOwner(String name) {
/*  72 */     if (!this._owners.contains(name.toLowerCase())) {
/*  73 */       this._owners.add(name.toLowerCase());
/*     */     }
/*     */   }
/*     */   
/*     */   public void RemoveOwner(String name) {
/*  78 */     this._owners.remove(name.toLowerCase());
/*     */   }
/*     */   
/*     */   public void SetOwners(List<String> owners) {
/*  82 */     this._owners = owners;
/*  83 */     Iterator<String> iterator = this._owners.iterator();
/*  84 */     while (iterator.hasNext()) {
/*  85 */       String ownerName = (String)iterator.next();
/*  86 */       ownerName = ownerName.toLowerCase();
/*     */     }
/*     */   }
/*     */   
/*     */   public void SetEnter(Boolean canEnter) {
/*  91 */     this._blockPassage = Boolean.valueOf(!canEnter.booleanValue());
/*     */   }
/*     */   
/*     */   public void SetChangeBlocks(Boolean canChangeBlocks) {
/*  95 */     this._blockChange = Boolean.valueOf(!canChangeBlocks.booleanValue());
/*     */   }
/*     */   
/*     */   public Boolean CanEnter(String playerName) {
/*  99 */     if ((this._blockPassage.booleanValue()) && (!this._owners.contains(playerName.toLowerCase()))) {
/* 100 */       return Boolean.valueOf(false);
/*     */     }
/* 102 */     return Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   public Boolean CanChangeBlocks(String playerName) {
/* 106 */     if ((this._blockChange.booleanValue()) && (!this._owners.contains(playerName.toLowerCase()))) {
/* 107 */       return Boolean.valueOf(false);
/*     */     }
/* 109 */     return Boolean.valueOf(true);
/*     */   }
/*     */   
/*     */   public String GetName() {
/* 113 */     return this._name;
/*     */   }
/*     */   
/*     */   private void UpdateMinMax() {
/* 117 */     this._minX = Math.min(this._pointOne.getBlockX(), this._pointTwo.getBlockX());
/* 118 */     this._minY = Math.min(this._pointOne.getBlockY(), this._pointTwo.getBlockY());
/* 119 */     this._minZ = Math.min(this._pointOne.getBlockZ(), this._pointTwo.getBlockZ());
/* 120 */     this._maxX = Math.max(this._pointOne.getBlockX(), this._pointTwo.getBlockX());
/* 121 */     this._maxY = Math.max(this._pointOne.getBlockY(), this._pointTwo.getBlockY());
/* 122 */     this._maxZ = Math.max(this._pointOne.getBlockZ(), this._pointTwo.getBlockZ());
/*     */   }
/*     */   
/*     */   public String toString() {
/* 126 */     return "Maximum point: " + GetMaximumPoint() + " Minimum point: " + GetMinimumPoint();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\arena\Region.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */