/*   */ package mineplex.core.elo;
/*   */ 
/*   */ import mineplex.core.common.util.NautHashMap;
/*   */ 
/*   */ public class EloClientData
/*   */ {
/* 7 */   public NautHashMap<String, Integer> Elos = new NautHashMap();
/*   */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloClientData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */