/*    */ package mineplex.core.elo;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class EloPlayer {
/*    */   public String UniqueId;
/*    */   public int Rating;
/*    */   
/*    */   public void printInfo() {
/* 10 */     System.out.println(this.UniqueId + "'s elo is " + this.Rating);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloPlayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */