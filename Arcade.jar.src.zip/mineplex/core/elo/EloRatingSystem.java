/*    */ package mineplex.core.elo;
/*    */ 
/*    */ 
/*    */ public class EloRatingSystem
/*    */ {
/*    */   private static final int DEFAULT_KFACTOR = 25;
/*    */   
/*    */   public static final double WIN = 1.0D;
/*    */   public static final double DRAW = 0.5D;
/*    */   public static final double LOSS = 0.0D;
/* 11 */   private KFactor[] _kFactors = new KFactor[0];
/*    */   
/*    */   public EloRatingSystem(KFactor... kFactors)
/*    */   {
/* 15 */     this._kFactors = kFactors;
/*    */   }
/*    */   
/*    */   public int getNewRating(int rating, int opponentRating, GameResult result)
/*    */   {
/* 20 */     switch (result)
/*    */     {
/*    */     case Draw: 
/* 23 */       return getNewRating(rating, opponentRating, 1.0D);
/*    */     case Loss: 
/* 25 */       return getNewRating(rating, opponentRating, 0.0D);
/*    */     case Win: 
/* 27 */       return getNewRating(rating, opponentRating, 0.5D);
/*    */     }
/*    */     
/* 30 */     return -1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getNewRating(int rating, int opponentRating, double score)
/*    */   {
/* 48 */     double kFactor = getKFactor(rating);
/* 49 */     double expectedScore = getExpectedScore(rating, opponentRating);
/* 50 */     int newRating = calculateNewRating(rating, score, expectedScore, kFactor);
/*    */     
/* 52 */     return newRating;
/*    */   }
/*    */   
/*    */   private int calculateNewRating(int oldRating, double score, double expectedScore, double kFactor)
/*    */   {
/* 57 */     return oldRating + (int)(kFactor * (score - expectedScore));
/*    */   }
/*    */   
/*    */   private double getKFactor(int rating)
/*    */   {
/* 62 */     for (int i = 0; i < this._kFactors.length; i++)
/*    */     {
/* 64 */       if ((rating >= this._kFactors[i].getStartIndex()) && (rating <= this._kFactors[i].getEndIndex()))
/*    */       {
/* 66 */         return this._kFactors[i].value;
/*    */       }
/*    */     }
/*    */     
/* 70 */     return 25.0D;
/*    */   }
/*    */   
/*    */   private double getExpectedScore(int rating, int opponentRating)
/*    */   {
/* 75 */     return 1.0D / (1.0D + Math.pow(10.0D, (opponentRating - rating) / 400.0D));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloRatingSystem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */