/*     */ package mineplex.core.elo;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniDbClientPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class EloManager extends MiniDbClientPlugin<EloClientData>
/*     */ {
/*  16 */   private static Object _playerEloLock = new Object();
/*     */   
/*     */   private EloRepository _repository;
/*     */   private EloRatingSystem _ratingSystem;
/*     */   private NautHashMap<String, NautHashMap<String, Integer>> _playerElos;
/*     */   
/*     */   public EloManager(JavaPlugin plugin, CoreClientManager clientManager)
/*     */   {
/*  24 */     super("Elo Rating", plugin, clientManager);
/*     */     
/*  26 */     this._repository = new EloRepository(plugin);
/*  27 */     this._ratingSystem = new EloRatingSystem(new KFactor[] { new KFactor(0, 1200, 25.0D), new KFactor(1201, 1600, 20.0D), new KFactor(1601, 2000, 15.0D), new KFactor(2001, 2500, 10.0D) });
/*  28 */     this._playerElos = new NautHashMap();
/*     */   }
/*     */   
/*     */   public int getElo(UUID uuid, String gameType)
/*     */   {
/*  33 */     int elo = 1000;
/*     */     
/*  35 */     synchronized (_playerEloLock)
/*     */     {
/*  37 */       if (this._playerElos.containsKey(uuid.toString()))
/*     */       {
/*  39 */         if (((NautHashMap)this._playerElos.get(uuid.toString())).containsKey(gameType))
/*     */         {
/*  41 */           elo = ((Integer)((NautHashMap)this._playerElos.get(uuid.toString())).get(gameType)).intValue();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  46 */     return elo;
/*     */   }
/*     */   
/*     */   public EloTeam getNewRatings(EloTeam teamA, EloTeam teamB, GameResult result)
/*     */   {
/*  51 */     EloTeam newTeam = new EloTeam();
/*     */     
/*  53 */     System.out.println("Old " + result + " Team Rating:" + teamA.TotalElo);
/*     */     
/*  55 */     int newTotal = this._ratingSystem.getNewRating(teamA.TotalElo / teamA.getPlayers().size(), teamB.TotalElo / teamB.getPlayers().size(), result) * teamA.getPlayers().size();
/*     */     
/*  57 */     System.out.println("New " + result + " Team Rating:" + newTotal);
/*     */     
/*  59 */     for (EloPlayer player : teamA.getPlayers())
/*     */     {
/*  61 */       EloPlayer newPlayer = new EloPlayer();
/*  62 */       newPlayer.UniqueId = player.UniqueId;
/*  63 */       newPlayer.Rating = ((int)(player.Rating + player.Rating / teamA.TotalElo * (newTotal - teamA.TotalElo)));
/*     */       
/*  65 */       System.out.println("Old:");
/*  66 */       player.printInfo();
/*     */       
/*  68 */       System.out.println("New:");
/*  69 */       newPlayer.printInfo();
/*     */       
/*  71 */       newTeam.addPlayer(newPlayer);
/*     */     }
/*     */     
/*  74 */     return newTeam;
/*     */   }
/*     */   
/*     */   public void saveElo(UUID uuid, String gameType, int elo)
/*     */   {
/*  79 */     saveElo(uuid.toString(), gameType, elo);
/*     */   }
/*     */   
/*     */   public void saveElo(final String uuid, final String gameType, final int elo)
/*     */   {
/*  84 */     org.bukkit.Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  88 */         EloManager.this._repository.saveElo(uuid, gameType, elo);
/*     */         
/*  90 */         synchronized (EloManager._playerEloLock)
/*     */         {
/*  92 */           if (EloManager.this._playerElos.containsKey(uuid))
/*     */           {
/*  94 */             if (((NautHashMap)EloManager.this._playerElos.get(uuid)).containsKey(gameType))
/*     */             {
/*  96 */               ((NautHashMap)EloManager.this._playerElos.get(uuid)).put(gameType, Integer.valueOf(elo));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   protected EloClientData AddPlayer(String player)
/*     */   {
/* 107 */     return new EloClientData();
/*     */   }
/*     */   
/*     */   public void processLoginResultSet(String playerName, int accountId, ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 113 */     Set(playerName, this._repository.loadClientInformation(resultSet));
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQuery(int accountId, String uuid, String name)
/*     */   {
/* 119 */     return "SELECT gameType, elo FROM eloRating WHERE uuid = '" + uuid + "';";
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */