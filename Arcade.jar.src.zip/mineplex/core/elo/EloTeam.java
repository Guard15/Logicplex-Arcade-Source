/*    */ package mineplex.core.elo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class EloTeam
/*    */ {
/*  8 */   private List<EloPlayer> _players = new ArrayList();
/*    */   
/* 10 */   public int TotalElo = 0;
/*    */   
/*    */   public void addPlayer(EloPlayer player)
/*    */   {
/* 14 */     this.TotalElo += player.Rating;
/*    */     
/* 16 */     this._players.add(player);
/*    */   }
/*    */   
/*    */   public List<EloPlayer> getPlayers()
/*    */   {
/* 21 */     return this._players;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloTeam.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */