/*    */ package mineplex.core.elo;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ import mineplex.core.database.DBPool;
/*    */ import mineplex.core.database.RepositoryBase;
/*    */ import mineplex.core.database.column.Column;
/*    */ import mineplex.core.database.column.ColumnInt;
/*    */ import mineplex.core.database.column.ColumnVarChar;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class EloRepository extends RepositoryBase
/*    */ {
/* 15 */   private static String CREATE_ELO_TABLE = "CREATE TABLE IF NOT EXISTS eloRating (id INT NOT NULL AUTO_INCREMENT, uuid VARCHAR(256), gameType VARCHAR(256), elo INT, PRIMARY KEY (id), UNIQUE INDEX uuid_gameType_index (uuid, gameType));";
/* 16 */   private static String INSERT_ELO = "INSERT INTO eloRating (uuid, gameType, elo) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE elo=VALUES(elo);";
/*    */   
/*    */   public EloRepository(JavaPlugin plugin)
/*    */   {
/* 20 */     super(plugin, DBPool.ACCOUNT);
/*    */     
/* 22 */     initialize();
/*    */   }
/*    */   
/*    */   public void initialize()
/*    */   {
/* 27 */     executeUpdate(CREATE_ELO_TABLE, new Column[0]);
/*    */   }
/*    */   
/*    */   public void saveElo(String uuid, String gameType, int elo)
/*    */   {
/* 32 */     executeUpdate(INSERT_ELO, new Column[] { new ColumnVarChar("uuid", 100, uuid), new ColumnVarChar("gameType", 100, gameType), new ColumnInt("elo", elo) });
/*    */   }
/*    */   
/*    */   public EloClientData loadClientInformation(ResultSet resultSet) throws SQLException
/*    */   {
/* 37 */     EloClientData clientData = new EloClientData();
/*    */     
/* 39 */     while (resultSet.next())
/*    */     {
/* 41 */       clientData.Elos.put(resultSet.getString(1), Integer.valueOf(resultSet.getInt(2)));
/*    */     }
/*    */     
/* 44 */     return clientData;
/*    */   }
/*    */   
/*    */   protected void update() {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\EloRepository.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */