/*    */ package mineplex.core.elo;
/*    */ 
/*    */ public class KFactor
/*    */ {
/*    */   public int startIndex;
/*    */   public int endIndex;
/*    */   public double value;
/*    */   
/*    */   public KFactor(int startIndex, int endIndex, double value) {
/* 10 */     this.startIndex = startIndex;
/* 11 */     this.endIndex = endIndex;
/* 12 */     this.value = value;
/*    */   }
/*    */   
/*    */   public int getStartIndex()
/*    */   {
/* 17 */     return this.startIndex;
/*    */   }
/*    */   
/*    */   public int getEndIndex()
/*    */   {
/* 22 */     return this.endIndex;
/*    */   }
/*    */   
/*    */   public double getValue()
/*    */   {
/* 27 */     return this.value;
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 32 */     return "kfactor: " + this.startIndex + " " + this.endIndex + " " + this.value;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\elo\KFactor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */