/*     */ package mineplex.core.aprilfools;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTextMiddle;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseCow;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AprilFoolsManager
/*     */   extends MiniPlugin
/*     */ {
/*     */   public static AprilFoolsManager Instance;
/*     */   private boolean _enabled;
/*     */   private DisguiseManager _disguiseManager;
/*     */   private CoreClientManager _clientManager;
/*     */   
/*     */   protected AprilFoolsManager(JavaPlugin plugin, CoreClientManager clientManager, DisguiseManager disguiseManager)
/*     */   {
/*  50 */     super("April Fools", plugin);
/*  51 */     this._disguiseManager = disguiseManager;
/*  52 */     this._clientManager = clientManager;
/*  53 */     Calendar c = Calendar.getInstance();
/*  54 */     this._enabled = ((c.get(2) == 3) && (c.get(5) == 1));
/*     */   }
/*     */   
/*     */   public static void Initialize(JavaPlugin plugin, CoreClientManager clientManager, DisguiseManager disguiseManager) {
/*  58 */     Instance = new AprilFoolsManager(plugin, clientManager, disguiseManager);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateEnabled(UpdateEvent event) {
/*  63 */     if (event.getType() != UpdateType.SLOW) {
/*  64 */       return;
/*     */     }
/*  66 */     Calendar c = Calendar.getInstance();
/*  67 */     this._enabled = ((c.get(2) == 3) && (c.get(5) == 1));
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.LOW)
/*     */   public void chatAdd(AsyncPlayerChatEvent event) {
/*  72 */     if (!this._enabled) {
/*  73 */       return;
/*     */     }
/*  75 */     String[] words = event.getMessage().split(" ");
/*  76 */     String out = "";
/*  77 */     String[] arrayOfString1; int j = (arrayOfString1 = words).length; for (int i = 0; i < j; i++) { String word = arrayOfString1[i];
/*     */       
/*  79 */       if (Math.random() > 0.85D) {
/*  80 */         out = out + "moo";
/*  81 */         for (int i = 0; i < UtilMath.r(2); i++) {
/*  82 */           out = out + "o";
/*     */         }
/*  84 */         out = out + " " + word + " ";
/*     */ 
/*     */       }
/*  87 */       else if (Math.random() > 0.85D) {
/*  88 */         out = out + word + " ";
/*  89 */         out = out + "moo";
/*  90 */         for (int i = 0; i < UtilMath.r(2); i++) {
/*  91 */           out = out + "o";
/*     */         }
/*  93 */         out = out + " ";
/*     */ 
/*     */       }
/*  96 */       else if (Math.random() > 0.99D) {
/*  97 */         out = out + "moo";
/*  98 */         for (int i = 3; i < word.length(); i++) {
/*  99 */           out = out + "o";
/*     */         }
/* 101 */         out = out + " ";
/*     */       }
/*     */       else {
/* 104 */         out = out + word + " ";
/*     */       } }
/* 106 */     event.setMessage(out);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateText(UpdateEvent event) {
/* 111 */     if (!this._enabled) {
/* 112 */       return;
/*     */     }
/* 114 */     if (event.getType() != UpdateType.SLOW) {
/* 115 */       return;
/*     */     }
/* 117 */     if (Math.random() <= 0.99D) {
/* 118 */       return;
/*     */     }
/* 120 */     UtilTextMiddle.display("Moo", null, 5, 20, 5);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateCow(UpdateEvent event) {
/* 125 */     if (!this._enabled) {
/* 126 */       return;
/*     */     }
/* 128 */     if (event.getType() != UpdateType.FAST)
/*     */       return;
/*     */     Player[] arrayOfPlayer;
/* 131 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 132 */       if (this._disguiseManager.getDisguise(player) != null) {
/* 133 */         if ((Math.random() > 0.8D) && ((this._disguiseManager.getDisguise(player) instanceof DisguiseCow))) {
/* 134 */           player.getWorld().playSound(player.getLocation(), Sound.COW_IDLE, (float)Math.random() + 0.5F, (float)Math.random() + 0.5F);
/*     */         }
/*     */       } else {
/* 137 */         DisguiseCow disguise = new DisguiseCow(player);
/* 138 */         disguise.setName(getName(player), this._clientManager.Get(player).GetRank());
/* 139 */         disguise.setCustomNameVisible(true);
/* 140 */         this._disguiseManager.disguise(disguise, new Player[0]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 145 */   public boolean isActive() { return this._enabled; }
/*     */   
/*     */ 
/*     */   public String getName(Player player)
/*     */   {
/* 150 */     int index = 0;
/* 151 */     boolean hitVowel = false;
/* 152 */     for (int i = 0; (i < player.getName().length() - 2) && (i < 5); i++) {
/* 153 */       if ((player.getName().toLowerCase().charAt(i) == 'a') || (player.getName().toLowerCase().charAt(i) == 'e') || (player.getName().toLowerCase().charAt(i) == 'i') || (player.getName().toLowerCase().charAt(i) == 'o') || (player.getName().toLowerCase().charAt(i) == 'u'))
/* 154 */         hitVowel = true; else
/* 155 */         if (hitVowel) break;
/* 156 */       index = i + 1; }
/*     */     String name;
/* 158 */     if ((name = "Moo" + player.getName().substring(index, player.getName().length())).length() > 16) {
/* 159 */       name = name.substring(0, 16);
/*     */     }
/* 161 */     return name;
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean b) {
/* 165 */     Calendar c = Calendar.getInstance();
/* 166 */     this._enabled = ((b) && (c.get(2) == 3) && (c.get(5) == 1));
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\aprilfools\AprilFoolsManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */