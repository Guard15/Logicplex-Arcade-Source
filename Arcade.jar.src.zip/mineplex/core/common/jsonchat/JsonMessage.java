/*     */ package mineplex.core.common.jsonchat;
/*     */ 
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import net.minecraft.server.v1_7_R4.ChatSerializer;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutChat;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class JsonMessage
/*     */ {
/*     */   protected StringBuilder Builder;
/*     */   
/*     */   public JsonMessage(String text)
/*     */   {
/*  17 */     this(new StringBuilder(), text);
/*     */   }
/*     */   
/*     */   public JsonMessage(StringBuilder builder, String text)
/*     */   {
/*  22 */     this.Builder = builder;
/*  23 */     this.Builder.append("{\"text\":\"" + text + "\"");
/*     */   }
/*     */   
/*     */   public JsonMessage color(String color)
/*     */   {
/*  28 */     this.Builder.append(", color:" + color);
/*  29 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage bold()
/*     */   {
/*  34 */     this.Builder.append(", bold:true");
/*     */     
/*  36 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage italic()
/*     */   {
/*  41 */     this.Builder.append(", italic:true");
/*     */     
/*  43 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage underlined()
/*     */   {
/*  48 */     this.Builder.append(", underlined:true");
/*     */     
/*  50 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage strikethrough()
/*     */   {
/*  55 */     this.Builder.append(", strikethrough:true");
/*     */     
/*  57 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage obfuscated()
/*     */   {
/*  62 */     this.Builder.append(", obfuscated:true");
/*     */     
/*  64 */     return this;
/*     */   }
/*     */   
/*     */   public ChildJsonMessage extra(String text)
/*     */   {
/*  69 */     this.Builder.append(", \"extra\":[");
/*  70 */     return new ChildJsonMessage(this, this.Builder, text);
/*     */   }
/*     */   
/*     */   public JsonMessage click(String action, String value)
/*     */   {
/*  75 */     this.Builder.append(", \"clickEvent\":{\"action\":\"" + action + "\",\"value\":\"" + value + "\"}");
/*     */     
/*  77 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage hover(String action, String value)
/*     */   {
/*  82 */     this.Builder.append(", \"hoverEvent\":{\"action\":\"" + action + "\",\"value\":\"" + value + "\"}");
/*     */     
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   public JsonMessage click(ClickEvent event, String value)
/*     */   {
/*  89 */     return click(event.toString(), value);
/*     */   }
/*     */   
/*     */   public JsonMessage hover(HoverEvent event, String value)
/*     */   {
/*  94 */     return hover(event.toString(), value);
/*     */   }
/*     */   
/*     */   public JsonMessage color(Color color)
/*     */   {
/*  99 */     return color(color.toString());
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 104 */     this.Builder.append("}");
/*     */     
/* 106 */     return this.Builder.toString();
/*     */   }
/*     */   
/*     */   public void sendToPlayer(Player player)
/*     */   {
/* 111 */     UtilServer.getServer().dispatchCommand(UtilServer.getServer().getConsoleSender(), "tellraw " + player.getName() + " " + toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(MessageType messageType, Player... players)
/*     */   {
/* 122 */     send(messageType, false, players);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void send(MessageType messageType, boolean defaultToChat, Player... players)
/*     */   {
/* 134 */     PacketPlayOutChat chatPacket = new PacketPlayOutChat(ChatSerializer.a(toString()));
/* 135 */     chatPacket.setChatType(messageType.getId());
/*     */     Player[] arrayOfPlayer;
/* 137 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/* 139 */       if ((defaultToChat) || (messageType != MessageType.ABOVE_HOTBAR) || (mineplex.core.common.util.UtilPlayer.is1_8(player))) {
/* 140 */         ((CraftPlayer)player).getHandle().playerConnection.sendPacket(chatPacket);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static enum MessageType {
/* 146 */     CHAT_BOX((byte)0), 
/* 147 */     SYSTEM_MESSAGE((byte)1), 
/* 148 */     ABOVE_HOTBAR((byte)2);
/*     */     
/*     */     private byte _id;
/*     */     
/*     */     private MessageType(byte id)
/*     */     {
/* 154 */       this._id = id;
/*     */     }
/*     */     
/*     */     public byte getId()
/*     */     {
/* 159 */       return this._id;
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\jsonchat\JsonMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */