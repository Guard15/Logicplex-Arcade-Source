/*    */ package mineplex.core.common.jsonchat;
/*    */ 
/*    */ public class ChildJsonMessage extends JsonMessage
/*    */ {
/*    */   private JsonMessage _parent;
/*    */   
/*    */   public ChildJsonMessage(String text)
/*    */   {
/*  9 */     this(new StringBuilder(), text);
/*    */   }
/*    */   
/*    */   public ChildJsonMessage(StringBuilder builder, String text)
/*    */   {
/* 14 */     this(null, builder, text);
/*    */   }
/*    */   
/*    */   public ChildJsonMessage(JsonMessage parent, StringBuilder builder, String text)
/*    */   {
/* 19 */     super(builder, text);
/*    */     
/* 21 */     this._parent = parent;
/*    */   }
/*    */   
/*    */   public ChildJsonMessage add(String text)
/*    */   {
/* 26 */     this.Builder.append("}, ");
/* 27 */     return new ChildJsonMessage(this._parent, this.Builder, text);
/*    */   }
/*    */   
/*    */ 
/*    */   public ChildJsonMessage color(String color)
/*    */   {
/* 33 */     super.color(color);
/*    */     
/* 35 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public ChildJsonMessage bold()
/*    */   {
/* 41 */     super.bold();
/*    */     
/* 43 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public ChildJsonMessage click(String action, String value)
/*    */   {
/* 49 */     super.click(action, value);
/*    */     
/* 51 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public ChildJsonMessage hover(String action, String value)
/*    */   {
/* 57 */     super.hover(action, value);
/*    */     
/* 59 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 65 */     this.Builder.append("}");
/*    */     
/* 67 */     if (this._parent != null)
/*    */     {
/* 69 */       this.Builder.append("]");
/* 70 */       return (this._parent instanceof ChildJsonMessage) ? ((ChildJsonMessage)this._parent).toString() : this._parent.toString();
/*    */     }
/*    */     
/* 73 */     return this.Builder.toString();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\jsonchat\ChildJsonMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */