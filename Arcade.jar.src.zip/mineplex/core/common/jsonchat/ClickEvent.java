/*    */ package mineplex.core.common.jsonchat;
/*    */ 
/*    */ public enum ClickEvent
/*    */ {
/*  5 */   RUN_COMMAND("run_command"), 
/*  6 */   SUGGEST_COMMAND("suggest_command"), 
/*  7 */   OPEN_URL("open_url"), 
/*  8 */   CHANGE_PAGE("change_page");
/*    */   
/*    */   private String _minecraftString;
/*    */   
/*    */   private ClickEvent(String minecraftString)
/*    */   {
/* 14 */     this._minecraftString = minecraftString;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 20 */     return this._minecraftString;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\jsonchat\ClickEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */