/*    */ package mineplex.core.common.jsonchat;
/*    */ 
/*    */ public enum HoverEvent
/*    */ {
/*  5 */   SHOW_TEXT("show_text"), 
/*  6 */   SHOW_ITEM("show_item"), 
/*  7 */   SHOW_ACHIEVEMENT("show_achievement");
/*    */   
/*    */   private String _minecraftString;
/*    */   
/*    */   private HoverEvent(String minecraftString)
/*    */   {
/* 13 */     this._minecraftString = minecraftString;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 19 */     return this._minecraftString;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\jsonchat\HoverEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */