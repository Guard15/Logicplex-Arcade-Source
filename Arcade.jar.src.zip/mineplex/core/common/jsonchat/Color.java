/*    */ package mineplex.core.common.jsonchat;
/*    */ 
/*    */ public enum Color
/*    */ {
/*  5 */   BLACK("black"), 
/*  6 */   DARK_BLUE("dark_blue"), 
/*  7 */   DARK_GREEN("dark_green"), 
/*  8 */   DARK_AQUA("dark_aqua"), 
/*  9 */   DARK_RED("dark_red"), 
/* 10 */   DARK_PURPLE("dark_purple"), 
/* 11 */   GOLD("gold"), 
/* 12 */   GRAY("gray"), 
/* 13 */   DARK_GRAY("dark_gray"), 
/* 14 */   BLUE("blue"), 
/* 15 */   GREEN("green"), 
/* 16 */   AQUA("aqua"), 
/* 17 */   RED("red"), 
/* 18 */   LIGHT_PURPLE("light_purple"), 
/* 19 */   YELLOW("yellow"), 
/* 20 */   WHITE("white");
/*    */   
/*    */   private String _minecraftString;
/*    */   
/*    */   private Color(String minecraftString)
/*    */   {
/* 26 */     this._minecraftString = minecraftString;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 32 */     return this._minecraftString;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\jsonchat\Color.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */