/*     */ package mineplex.core.common;
/*     */ 
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ public enum Rank
/*     */ {
/*  11 */   LT("Owner", ChatColor.DARK_RED), 
/*  12 */   OWNER("Co.Owner", ChatColor.DARK_RED), 
/*  13 */   DEVELOPER("Sr.Dev", ChatColor.RED), 
/*  14 */   ADMIN("Admin", ChatColor.RED), 
/*  15 */   JNR_DEV("Jr.Dev", ChatColor.RED), 
/*  16 */   SNR_MODERATOR("Sr.Mod", ChatColor.GOLD), 
/*  17 */   MODERATOR("Jr.Mod", ChatColor.GOLD), 
/*  18 */   HELPER("TrialStaff", ChatColor.DARK_AQUA), 
/*  19 */   MAPLEAD("MapLeader", ChatColor.DARK_PURPLE), 
/*  20 */   MAPDEV("Builder", ChatColor.BLUE), 
/*     */   
/*  22 */   EVENT("Event", ChatColor.WHITE), 
/*     */   
/*  24 */   YOUTUBE(
/*     */   
/*  26 */     "YouTube", ChatColor.RED), 
/*  27 */   TWITCH("Twitch", ChatColor.DARK_PURPLE), 
/*  28 */   TITAN("Magician", ChatColor.RED), 
/*  29 */   LEGEND("Blazer", ChatColor.GREEN), 
/*  30 */   HERO("KoolAid", ChatColor.LIGHT_PURPLE), 
/*  31 */   ULTRA("Zero", ChatColor.AQUA), 
/*  32 */   ALL("Player", ChatColor.WHITE);
/*     */   
/*     */   private ChatColor Color;
/*     */   public String Name;
/*     */   
/*     */   private Rank(String name, ChatColor color)
/*     */   {
/*  39 */     this.Color = color;
/*  40 */     this.Name = name;
/*     */   }
/*     */   
/*     */   public boolean Has(Rank rank)
/*     */   {
/*  45 */     return Has(null, rank, false);
/*     */   }
/*     */   
/*     */   public boolean Has(Player player, Rank rank, boolean inform)
/*     */   {
/*  50 */     return Has(player, rank, null, inform);
/*     */   }
/*     */   
/*     */   public boolean Has(Player player, Rank rank, Rank[] specific, boolean inform)
/*     */   {
/*  55 */     if ((player != null) && 
/*  56 */       (player.getName().equals("Chiss"))) {
/*  57 */       return true;
/*     */     }
/*     */     
/*  60 */     if (specific != null) {
/*     */       Rank[] arrayOfRank;
/*  62 */       int j = (arrayOfRank = specific).length; for (int i = 0; i < j; i++) { Rank curRank = arrayOfRank[i];
/*     */         
/*  64 */         if (compareTo(curRank) == 0)
/*     */         {
/*  66 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  72 */     if (compareTo(rank) <= 0) {
/*  73 */       return true;
/*     */     }
/*  75 */     if (inform)
/*     */     {
/*  77 */       UtilPlayer.message(player, C.mHead + "Permissions> " + 
/*  78 */         C.mBody + "This requires Permission Rank [" + 
/*  79 */         C.mHead + rank.Name.toUpperCase() + 
/*  80 */         C.mBody + "].");
/*     */     }
/*     */     
/*  83 */     return false;
/*     */   }
/*     */   
/*     */   public String GetTag(boolean bold, boolean uppercase)
/*     */   {
/*  88 */     if (this.Name.equalsIgnoreCase("ALL")) {
/*  89 */       return "";
/*     */     }
/*  91 */     String name = this.Name;
/*  92 */     if (uppercase) {
/*  93 */       name = this.Name.toUpperCase();
/*     */     }
/*  95 */     if (bold) return this.Color + C.Bold + name;
/*  96 */     return this.Color + name;
/*     */   }
/*     */   
/*     */   public ChatColor GetColor()
/*     */   {
/* 101 */     return this.Color;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\Rank.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */