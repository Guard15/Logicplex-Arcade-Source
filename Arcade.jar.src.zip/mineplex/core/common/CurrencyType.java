/*    */ package mineplex.core.common;
/*    */ 
/*    */ import org.bukkit.Material;
/*    */ 
/*    */ public enum CurrencyType
/*    */ {
/*  7 */   Tokens(" Tokens", Material.EMERALD), 
/*  8 */   Coins(" Shards", Material.DIAMOND), 
/*  9 */   Gems(" Gems", Material.EMERALD);
/*    */   
/*    */   private String _prefix;
/*    */   private Material _displayMaterial;
/*    */   
/*    */   private CurrencyType(String prefix, Material displayMaterial)
/*    */   {
/* 16 */     this._prefix = prefix;
/* 17 */     this._displayMaterial = displayMaterial;
/*    */   }
/*    */   
/*    */   public String Prefix()
/*    */   {
/* 22 */     return this._prefix;
/*    */   }
/*    */   
/*    */   public Material GetDisplayMaterial()
/*    */   {
/* 27 */     return this._displayMaterial;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\CurrencyType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */