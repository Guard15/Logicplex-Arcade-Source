/*    */ package mineplex.core.common;
/*    */ 
/*    */ 
/*    */ public class ProcessRunner
/*    */   extends Thread
/*    */ {
/*    */   private ProcessBuilder _processBuilder;
/*    */   
/*    */   private Process _process;
/*    */   
/*    */   private GenericRunnable<Boolean> _runnable;
/* 12 */   boolean _done = false;
/* 13 */   Boolean _error = Boolean.valueOf(false);
/*    */   
/*    */   public ProcessRunner(String[] args)
/*    */   {
/* 17 */     super("ProcessRunner " + args);
/* 18 */     this._processBuilder = new ProcessBuilder(args);
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public void run()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_0
/*    */     //   2: getfield 50	mineplex/core/common/ProcessRunner:_processBuilder	Ljava/lang/ProcessBuilder;
/*    */     //   5: invokevirtual 60	java/lang/ProcessBuilder:start	()Ljava/lang/Process;
/*    */     //   8: putfield 64	mineplex/core/common/ProcessRunner:_process	Ljava/lang/Process;
/*    */     //   11: aload_0
/*    */     //   12: getfield 64	mineplex/core/common/ProcessRunner:_process	Ljava/lang/Process;
/*    */     //   15: invokevirtual 66	java/lang/Process:waitFor	()I
/*    */     //   18: pop
/*    */     //   19: new 72	java/io/BufferedReader
/*    */     //   22: dup
/*    */     //   23: new 74	java/io/InputStreamReader
/*    */     //   26: dup
/*    */     //   27: aload_0
/*    */     //   28: getfield 64	mineplex/core/common/ProcessRunner:_process	Ljava/lang/Process;
/*    */     //   31: invokevirtual 76	java/lang/Process:getInputStream	()Ljava/io/InputStream;
/*    */     //   34: invokespecial 80	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
/*    */     //   37: invokespecial 83	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
/*    */     //   40: astore_1
/*    */     //   41: aload_1
/*    */     //   42: invokevirtual 86	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*    */     //   45: astore_2
/*    */     //   46: goto +25 -> 71
/*    */     //   49: aload_2
/*    */     //   50: ldc 89
/*    */     //   52: invokevirtual 91	java/lang/String:equals	(Ljava/lang/Object;)Z
/*    */     //   55: ifeq +11 -> 66
/*    */     //   58: aload_0
/*    */     //   59: iconst_1
/*    */     //   60: invokestatic 38	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
/*    */     //   63: putfield 44	mineplex/core/common/ProcessRunner:_error	Ljava/lang/Boolean;
/*    */     //   66: aload_1
/*    */     //   67: invokevirtual 86	java/io/BufferedReader:readLine	()Ljava/lang/String;
/*    */     //   70: astore_2
/*    */     //   71: aload_2
/*    */     //   72: ifnonnull -23 -> 49
/*    */     //   75: goto +70 -> 145
/*    */     //   78: astore_1
/*    */     //   79: getstatic 97	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   82: aload_1
/*    */     //   83: invokevirtual 103	java/lang/Exception:getMessage	()Ljava/lang/String;
/*    */     //   86: invokevirtual 108	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   89: aload_0
/*    */     //   90: iconst_1
/*    */     //   91: putfield 36	mineplex/core/common/ProcessRunner:_done	Z
/*    */     //   94: aload_0
/*    */     //   95: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   98: ifnull +72 -> 170
/*    */     //   101: aload_0
/*    */     //   102: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   105: aload_0
/*    */     //   106: getfield 44	mineplex/core/common/ProcessRunner:_error	Ljava/lang/Boolean;
/*    */     //   109: invokeinterface 115 2 0
/*    */     //   114: goto +56 -> 170
/*    */     //   117: astore_3
/*    */     //   118: aload_0
/*    */     //   119: iconst_1
/*    */     //   120: putfield 36	mineplex/core/common/ProcessRunner:_done	Z
/*    */     //   123: aload_0
/*    */     //   124: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   127: ifnull +16 -> 143
/*    */     //   130: aload_0
/*    */     //   131: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   134: aload_0
/*    */     //   135: getfield 44	mineplex/core/common/ProcessRunner:_error	Ljava/lang/Boolean;
/*    */     //   138: invokeinterface 115 2 0
/*    */     //   143: aload_3
/*    */     //   144: athrow
/*    */     //   145: aload_0
/*    */     //   146: iconst_1
/*    */     //   147: putfield 36	mineplex/core/common/ProcessRunner:_done	Z
/*    */     //   150: aload_0
/*    */     //   151: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   154: ifnull +16 -> 170
/*    */     //   157: aload_0
/*    */     //   158: getfield 113	mineplex/core/common/ProcessRunner:_runnable	Lmineplex/core/common/GenericRunnable;
/*    */     //   161: aload_0
/*    */     //   162: getfield 44	mineplex/core/common/ProcessRunner:_error	Ljava/lang/Boolean;
/*    */     //   165: invokeinterface 115 2 0
/*    */     //   170: return
/*    */     // Line number table:
/*    */     //   Java source line #25	-> byte code offset #0
/*    */     //   Java source line #26	-> byte code offset #11
/*    */     //   Java source line #28	-> byte code offset #19
/*    */     //   Java source line #29	-> byte code offset #41
/*    */     //   Java source line #31	-> byte code offset #46
/*    */     //   Java source line #33	-> byte code offset #49
/*    */     //   Java source line #34	-> byte code offset #58
/*    */     //   Java source line #36	-> byte code offset #66
/*    */     //   Java source line #31	-> byte code offset #71
/*    */     //   Java source line #38	-> byte code offset #75
/*    */     //   Java source line #39	-> byte code offset #78
/*    */     //   Java source line #41	-> byte code offset #79
/*    */     //   Java source line #45	-> byte code offset #89
/*    */     //   Java source line #47	-> byte code offset #94
/*    */     //   Java source line #48	-> byte code offset #101
/*    */     //   Java source line #44	-> byte code offset #117
/*    */     //   Java source line #45	-> byte code offset #118
/*    */     //   Java source line #47	-> byte code offset #123
/*    */     //   Java source line #48	-> byte code offset #130
/*    */     //   Java source line #49	-> byte code offset #143
/*    */     //   Java source line #45	-> byte code offset #145
/*    */     //   Java source line #47	-> byte code offset #150
/*    */     //   Java source line #48	-> byte code offset #157
/*    */     //   Java source line #50	-> byte code offset #170
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	171	0	this	ProcessRunner
/*    */     //   40	27	1	reader	java.io.BufferedReader
/*    */     //   78	5	1	e	Exception
/*    */     //   45	27	2	line	String
/*    */     //   117	27	3	localObject	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   0	75	78	java/lang/Exception
/*    */     //   0	89	117	finally
/*    */   }
/*    */   
/*    */   public void start(GenericRunnable<Boolean> runnable)
/*    */   {
/* 54 */     super.start();
/*    */     
/* 56 */     this._runnable = runnable;
/*    */   }
/*    */   
/*    */   public int exitValue() throws IllegalStateException
/*    */   {
/* 61 */     if (this._process != null)
/*    */     {
/* 63 */       return this._process.exitValue();
/*    */     }
/*    */     
/* 66 */     throw new IllegalStateException("Process not started yet");
/*    */   }
/*    */   
/*    */   public boolean isDone()
/*    */   {
/* 71 */     return this._done;
/*    */   }
/*    */   
/*    */   public void abort()
/*    */   {
/* 76 */     if (!isDone())
/*    */     {
/* 78 */       this._process.destroy();
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\ProcessRunner.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */