/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.apache.commons.lang.math.RandomUtils;
/*    */ import org.bukkit.Color;
/*    */ import org.bukkit.FireworkEffect;
/*    */ import org.bukkit.FireworkEffect.Builder;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Firework;
/*    */ import org.bukkit.inventory.meta.FireworkMeta;
/*    */ 
/*    */ public class FireworkUtil
/*    */ {
/*    */   public static Firework LaunchRandomFirework(Location location)
/*    */   {
/* 15 */     FireworkEffect.Builder builder = FireworkEffect.builder();
/*    */     
/* 17 */     if (RandomUtils.nextInt(3) == 0)
/*    */     {
/* 19 */       builder.withTrail();
/*    */     }
/* 21 */     else if (RandomUtils.nextInt(2) == 0)
/*    */     {
/* 23 */       builder.withFlicker();
/*    */     }
/*    */     
/* 26 */     builder.with(org.bukkit.FireworkEffect.Type.values()[RandomUtils.nextInt(org.bukkit.FireworkEffect.Type.values().length)]);
/*    */     
/* 28 */     int colorCount = 17;
/*    */     
/* 30 */     builder.withColor(Color.fromRGB(RandomUtils.nextInt(255), RandomUtils.nextInt(255), RandomUtils.nextInt(255)));
/*    */     
/* 32 */     while (RandomUtils.nextInt(colorCount) != 0)
/*    */     {
/* 34 */       builder.withColor(Color.fromRGB(RandomUtils.nextInt(255), RandomUtils.nextInt(255), RandomUtils.nextInt(255)));
/* 35 */       colorCount--;
/*    */     }
/*    */     
/* 38 */     Firework firework = (Firework)location.getWorld().spawn(location, Firework.class);
/* 39 */     FireworkMeta data = firework.getFireworkMeta();
/* 40 */     data.addEffects(new FireworkEffect[] { builder.build() });
/* 41 */     data.setPower(RandomUtils.nextInt(3));
/* 42 */     firework.setFireworkMeta(data);
/*    */     
/* 44 */     return firework;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\FireworkUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */