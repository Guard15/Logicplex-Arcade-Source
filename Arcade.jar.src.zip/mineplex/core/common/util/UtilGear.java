/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class UtilGear
/*     */ {
/*  10 */   private static HashSet<Material> _axeSet = new HashSet();
/*  11 */   private static HashSet<Material> _swordSet = new HashSet();
/*  12 */   private static HashSet<Material> _maulSet = new HashSet();
/*  13 */   private static HashSet<Material> pickSet = new HashSet();
/*  14 */   private static HashSet<Material> diamondSet = new HashSet();
/*  15 */   private static HashSet<Material> goldSet = new HashSet();
/*     */   
/*     */   public static boolean isAxe(ItemStack item)
/*     */   {
/*  19 */     if (item == null) {
/*  20 */       return false;
/*     */     }
/*  22 */     if (_axeSet.isEmpty())
/*     */     {
/*  24 */       _axeSet.add(Material.WOOD_AXE);
/*  25 */       _axeSet.add(Material.STONE_AXE);
/*  26 */       _axeSet.add(Material.IRON_AXE);
/*  27 */       _axeSet.add(Material.GOLD_AXE);
/*  28 */       _axeSet.add(Material.DIAMOND_AXE);
/*     */     }
/*     */     
/*  31 */     return _axeSet.contains(item.getType());
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isSword(ItemStack item)
/*     */   {
/*  37 */     if (item == null) {
/*  38 */       return false;
/*     */     }
/*  40 */     if (_swordSet.isEmpty())
/*     */     {
/*  42 */       _swordSet.add(Material.WOOD_SWORD);
/*  43 */       _swordSet.add(Material.STONE_SWORD);
/*  44 */       _swordSet.add(Material.IRON_SWORD);
/*  45 */       _swordSet.add(Material.GOLD_SWORD);
/*  46 */       _swordSet.add(Material.DIAMOND_SWORD);
/*     */     }
/*     */     
/*  49 */     return _swordSet.contains(item.getType());
/*     */   }
/*     */   
/*     */   public static boolean isShovel(ItemStack item)
/*     */   {
/*  54 */     if (item == null) {
/*  55 */       return false;
/*     */     }
/*  57 */     if (_maulSet.isEmpty())
/*     */     {
/*  59 */       _maulSet.add(Material.WOOD_SPADE);
/*  60 */       _maulSet.add(Material.STONE_SPADE);
/*  61 */       _maulSet.add(Material.IRON_SPADE);
/*  62 */       _maulSet.add(Material.GOLD_SPADE);
/*  63 */       _maulSet.add(Material.DIAMOND_SPADE);
/*     */     }
/*     */     
/*  66 */     return _maulSet.contains(item.getType());
/*     */   }
/*     */   
/*  69 */   public static HashSet<Material> scytheSet = new HashSet();
/*     */   
/*     */   public static boolean isHoe(ItemStack item) {
/*  72 */     if (item == null) {
/*  73 */       return false;
/*     */     }
/*  75 */     if (scytheSet.isEmpty())
/*     */     {
/*  77 */       scytheSet.add(Material.WOOD_HOE);
/*  78 */       scytheSet.add(Material.STONE_HOE);
/*  79 */       scytheSet.add(Material.IRON_HOE);
/*  80 */       scytheSet.add(Material.GOLD_HOE);
/*  81 */       scytheSet.add(Material.DIAMOND_HOE);
/*     */     }
/*     */     
/*  84 */     return scytheSet.contains(item.getType());
/*     */   }
/*     */   
/*     */   public static boolean isPickaxe(ItemStack item)
/*     */   {
/*  89 */     if (item == null) {
/*  90 */       return false;
/*     */     }
/*  92 */     if (pickSet.isEmpty())
/*     */     {
/*  94 */       pickSet.add(Material.WOOD_PICKAXE);
/*  95 */       pickSet.add(Material.STONE_PICKAXE);
/*  96 */       pickSet.add(Material.IRON_PICKAXE);
/*  97 */       pickSet.add(Material.GOLD_PICKAXE);
/*  98 */       pickSet.add(Material.DIAMOND_PICKAXE);
/*     */     }
/*     */     
/* 101 */     return pickSet.contains(item.getType());
/*     */   }
/*     */   
/*     */   public static boolean isDiamond(ItemStack item)
/*     */   {
/* 106 */     if (item == null) {
/* 107 */       return false;
/*     */     }
/* 109 */     if (diamondSet.isEmpty())
/*     */     {
/* 111 */       diamondSet.add(Material.DIAMOND_SWORD);
/* 112 */       diamondSet.add(Material.DIAMOND_AXE);
/* 113 */       diamondSet.add(Material.DIAMOND_SPADE);
/* 114 */       diamondSet.add(Material.DIAMOND_HOE);
/*     */     }
/*     */     
/* 117 */     return diamondSet.contains(item.getType());
/*     */   }
/*     */   
/*     */   public static boolean isGold(ItemStack item)
/*     */   {
/* 122 */     if (item == null) {
/* 123 */       return false;
/*     */     }
/* 125 */     if (goldSet.isEmpty())
/*     */     {
/* 127 */       goldSet.add(Material.GOLD_SWORD);
/* 128 */       goldSet.add(Material.GOLD_AXE);
/*     */     }
/*     */     
/* 131 */     return goldSet.contains(item.getType());
/*     */   }
/*     */   
/*     */   public static boolean isBow(ItemStack item)
/*     */   {
/* 136 */     if (item == null) {
/* 137 */       return false;
/*     */     }
/* 139 */     return item.getType() == Material.BOW;
/*     */   }
/*     */   
/*     */   public static boolean isWeapon(ItemStack item)
/*     */   {
/* 144 */     return (isAxe(item)) || (isSword(item));
/*     */   }
/*     */   
/*     */   public static boolean isMat(ItemStack item, Material mat)
/*     */   {
/* 149 */     if (item == null) {
/* 150 */       return false;
/*     */     }
/* 152 */     return item.getType() == mat;
/*     */   }
/*     */   
/*     */   public static boolean isRepairable(ItemStack item)
/*     */   {
/* 157 */     return item.getType().getMaxDurability() > 0;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilGear.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */