/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.server.v1_7_R4.ChatSerializer;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.IChatBaseComponent;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.spigotmc.ProtocolInjector.PacketTabHeader;
/*     */ 
/*     */ public class UtilTabTitle
/*     */ {
/*     */   private static final int PROTOCOL_VERSION = 47;
/*     */   
/*     */   public static void broadcastHeader(String header)
/*     */   {
/*  19 */     broadcastHeaderAndFooter(header, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void broadcastFooter(String footer)
/*     */   {
/*  25 */     broadcastHeaderAndFooter(null, footer);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void broadcastHeaderAndFooter(String header, String footer)
/*     */   {
/*  31 */     for (Player player : ) {
/*  32 */       doHeaderAndFooter(player, header, footer);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void setHeaderAndFooter(Player player, String header, String footer) {
/*  37 */     doHeaderAndFooter(player, header, footer);
/*     */   }
/*     */   
/*     */   public static void setHeader(Player p, String header)
/*     */   {
/*  42 */     doHeaderAndFooter(p, header, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void setFooter(Player p, String footer)
/*     */   {
/*  48 */     doHeaderAndFooter(p, null, footer);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void doHeaderAndFooter(Player p, String rawHeader, String rawFooter)
/*     */   {
/*  54 */     CraftPlayer player = (CraftPlayer)p;
/*  55 */     if (player.getHandle().playerConnection.networkManager.getVersion() != 47) return;
/*  56 */     IChatBaseComponent header = ChatSerializer.a(TextConverter.convert(rawHeader));
/*  57 */     IChatBaseComponent footer = ChatSerializer.a(TextConverter.convert(rawFooter));
/*  58 */     if ((header == null) || (footer == null))
/*     */     {
/*  60 */       TabTitleCache titleCache = TabTitleCache.getTabTitle(p.getUniqueId());
/*  61 */       if (titleCache != null)
/*     */       {
/*  63 */         if (header == null)
/*     */         {
/*  65 */           String headerString = titleCache.getHeader();
/*  66 */           if (headerString != null)
/*     */           {
/*  68 */             rawHeader = headerString;
/*  69 */             header = ChatSerializer.a(TextConverter.convert(headerString));
/*     */           }
/*     */         }
/*  72 */         if (footer == null)
/*     */         {
/*  74 */           String footerString = titleCache.getFooter();
/*  75 */           if (footerString != null)
/*     */           {
/*  77 */             rawHeader = footerString;
/*  78 */             header = ChatSerializer.a(TextConverter.convert(footerString));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  83 */     TabTitleCache.addTabTitle(p.getUniqueId(), new TabTitleCache(rawHeader, rawFooter));
/*  84 */     ProtocolInjector.PacketTabHeader packet = new ProtocolInjector.PacketTabHeader(header, footer);
/*  85 */     player.getHandle().playerConnection.sendPacket(packet);
/*     */   }
/*     */   
/*     */   private static class TextConverter
/*     */   {
/*     */     public static String convert(String text)
/*     */     {
/*  92 */       if ((text == null) || (text.length() == 0))
/*     */       {
/*  94 */         return "\"\"";
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*  99 */       int len = text.length();
/* 100 */       StringBuilder sb = new StringBuilder(len + 4);
/*     */       
/* 102 */       sb.append('"');
/*     */       
/* 104 */       for (int i = 0; i < len; i++)
/*     */       {
/* 106 */         char c = text.charAt(i);
/* 107 */         switch (c)
/*     */         {
/*     */         case '"': 
/*     */         case '\\': 
/* 111 */           sb.append('\\');
/* 112 */           sb.append(c);
/* 113 */           break;
/*     */         case '/': 
/* 115 */           sb.append('\\');
/* 116 */           sb.append(c);
/* 117 */           break;
/*     */         case '\b': 
/* 119 */           sb.append("\\b");
/* 120 */           break;
/*     */         case '\t': 
/* 122 */           sb.append("\\t");
/* 123 */           break;
/*     */         case '\n': 
/* 125 */           sb.append("\\n");
/* 126 */           break;
/*     */         case '\f': 
/* 128 */           sb.append("\\f");
/* 129 */           break;
/*     */         case '\r': 
/* 131 */           sb.append("\\r");
/* 132 */           break;
/*     */         default: 
/* 134 */           if (c < ' ')
/*     */           {
/* 136 */             String t = "000" + Integer.toHexString(c);
/* 137 */             sb.append("\\u").append(t.substring(t.length() - 4));
/*     */           }
/*     */           else
/*     */           {
/* 141 */             sb.append(c);
/*     */           }
/*     */           break; }
/*     */       }
/* 145 */       sb.append('"');
/* 146 */       return sb.toString();
/*     */     }
/*     */     
/*     */     public static String setPlayerName(Player player, String text)
/*     */     {
/* 151 */       return text.replaceAll("(?i)\\{PLAYER\\}", player.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TabTitleCache
/*     */   {
/* 157 */     private static final Map<UUID, TabTitleCache> playerTabTitles = new java.util.HashMap();
/*     */     private String header;
/*     */     private String footer;
/*     */     
/*     */     public TabTitleCache(String header, String footer)
/*     */     {
/* 163 */       this.header = header;
/* 164 */       this.footer = footer;
/*     */     }
/*     */     
/*     */     public static TabTitleCache getTabTitle(UUID uuid)
/*     */     {
/* 169 */       return (TabTitleCache)playerTabTitles.get(uuid);
/*     */     }
/*     */     
/*     */     public static void addTabTitle(UUID uuid, TabTitleCache titleCache)
/*     */     {
/* 174 */       playerTabTitles.put(uuid, titleCache);
/*     */     }
/*     */     
/*     */     public static void removeTabTitle(UUID uuid)
/*     */     {
/* 179 */       playerTabTitles.remove(uuid);
/*     */     }
/*     */     
/*     */     public String getHeader()
/*     */     {
/* 184 */       return this.header;
/*     */     }
/*     */     
/*     */     public String getFooter()
/*     */     {
/* 189 */       return this.footer;
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilTabTitle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */