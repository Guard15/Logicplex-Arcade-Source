/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import mineplex.core.common.Rank;
/*     */ import org.bukkit.ChatColor;
/*     */ 
/*     */ 
/*     */ public class F
/*     */ {
/*     */   public static String main(String module, String body)
/*     */   {
/*  11 */     return C.mHead + module + "> " + C.mBody + body;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String tute(String sender, String body)
/*     */   {
/*  17 */     return C.cGold + sender + "> " + C.cWhite + body;
/*     */   }
/*     */   
/*     */   public static String te(String message)
/*     */   {
/*  22 */     return C.cYellow + message + C.cWhite;
/*     */   }
/*     */   
/*     */   public static String game(String elem)
/*     */   {
/*  27 */     return C.mGame + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String ta(String message)
/*     */   {
/*  32 */     return C.cGreen + message + C.cWhite;
/*     */   }
/*     */   
/*     */   public static String ts(String message)
/*     */   {
/*  37 */     return C.cGold + message + C.cWhite;
/*     */   }
/*     */   
/*     */   public static String sys(String head, String body)
/*     */   {
/*  42 */     return C.sysHead + head + "> " + C.sysBody + body;
/*     */   }
/*     */   
/*     */   public static String elem(String elem)
/*     */   {
/*  47 */     return C.mElem + elem + ChatColor.RESET + C.mBody;
/*     */   }
/*     */   
/*     */   public static String name(String elem)
/*     */   {
/*  52 */     return C.mElem + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String count(String elem)
/*     */   {
/*  57 */     return C.mCount + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String item(String elem)
/*     */   {
/*  62 */     return C.mItem + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String link(String elem)
/*     */   {
/*  67 */     return C.mLink + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String skill(String elem)
/*     */   {
/*  72 */     return C.mSkill + elem + C.mBody;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String skill(String a, String b)
/*     */   {
/*  78 */     return C.cYellow + " " + C.cGreen + b + C.mBody;
/*     */   }
/*     */   
/*     */   public static String time(String elem)
/*     */   {
/*  83 */     return C.mTime + elem + C.mBody;
/*     */   }
/*     */   
/*     */   public static String desc(String head, String body)
/*     */   {
/*  88 */     return C.descHead + head + ": " + C.descBody + body;
/*     */   }
/*     */   
/*     */   public static String wField(String field, String data)
/*     */   {
/*  93 */     return C.wFrame + "[" + C.wField + field + C.wFrame + "] " + C.mBody + data + " ";
/*     */   }
/*     */   
/*     */   public static String help(String cmd, String body, Rank rank)
/*     */   {
/*  98 */     return rank.GetColor() + cmd + " " + C.mBody + body + " " + rank(rank);
/*     */   }
/*     */   
/*     */   public static String rank(Rank rank)
/*     */   {
/* 103 */     if (rank == Rank.ALL) {
/* 104 */       return rank.GetColor() + "Player";
/*     */     }
/* 106 */     return rank.GetTag(false, false);
/*     */   }
/*     */   
/*     */   public static String value(String variable, String value)
/*     */   {
/* 111 */     return value(0, variable, value);
/*     */   }
/*     */   
/*     */   public static String value(int a, String variable, String value)
/*     */   {
/* 116 */     String indent = "";
/* 117 */     while (indent.length() < a) {
/* 118 */       indent = indent + ChatColor.GRAY + ">";
/*     */     }
/* 120 */     return indent + C.listTitle + variable + ": " + C.listValue + value;
/*     */   }
/*     */   
/*     */   public static String value(String variable, String value, boolean on)
/*     */   {
/* 125 */     return value(0, variable, value, on);
/*     */   }
/*     */   
/*     */   public static String value(int a, String variable, String value, boolean on)
/*     */   {
/* 130 */     String indent = "";
/* 131 */     while (indent.length() < a) {
/* 132 */       indent = indent + ChatColor.GRAY + ">";
/*     */     }
/* 134 */     if (on) return indent + C.listTitle + variable + ": " + C.listValueOn + value;
/* 135 */     return indent + C.listTitle + variable + ": " + C.listValueOff + value;
/*     */   }
/*     */   
/*     */   public static String ed(boolean var)
/*     */   {
/* 140 */     if (var)
/* 141 */       return C.listValueOn + "Enabled" + C.mBody;
/* 142 */     return C.listValueOff + "Disabled" + C.mBody;
/*     */   }
/*     */   
/*     */   public static String oo(boolean var)
/*     */   {
/* 147 */     if (var)
/* 148 */       return C.listValueOn + "On" + C.mBody;
/* 149 */     return C.listValueOff + "Off" + C.mBody;
/*     */   }
/*     */   
/*     */   public static String tf(boolean var)
/*     */   {
/* 154 */     if (var)
/* 155 */       return C.listValueOn + "True" + C.mBody;
/* 156 */     return C.listValueOff + "False" + C.mBody;
/*     */   }
/*     */   
/*     */   public static String oo(String variable, boolean value)
/*     */   {
/* 161 */     if (value)
/* 162 */       return C.listValueOn + variable + C.mBody;
/* 163 */     return C.listValueOff + variable + C.mBody;
/*     */   }
/*     */   
/*     */   public static String combine(String[] args, int start, String color, boolean comma)
/*     */   {
/* 168 */     if (args.length == 0) {
/* 169 */       return "";
/*     */     }
/* 171 */     String out = "";
/*     */     
/* 173 */     for (int i = start; i < args.length; i++)
/*     */     {
/* 175 */       if (color != null)
/*     */       {
/* 177 */         String preColor = ChatColor.getLastColors(args[i]);
/* 178 */         out = out + color + args[i] + preColor;
/*     */       }
/*     */       else {
/* 181 */         out = out + args[i];
/*     */       }
/* 183 */       if (comma) {
/* 184 */         out = out + ", ";
/*     */       } else {
/* 186 */         out = out + " ";
/*     */       }
/*     */     }
/* 189 */     if (out.length() > 0) {
/* 190 */       if (comma) out = out.substring(0, out.length() - 2); else
/* 191 */         out = out.substring(0, out.length() - 1);
/*     */     }
/* 193 */     return out;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\F.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */