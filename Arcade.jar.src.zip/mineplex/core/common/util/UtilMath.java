/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.DecimalFormatSymbols;
/*    */ import java.util.Locale;
/*    */ import java.util.Random;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UtilMath
/*    */ {
/*    */   public static double trim(int degree, double d)
/*    */   {
/* 17 */     String format = "#.#";
/*    */     
/* 19 */     for (int i = 1; i < degree; i++) {
/* 20 */       format = format + "#";
/*    */     }
/* 22 */     DecimalFormatSymbols symb = new DecimalFormatSymbols(Locale.US);
/* 23 */     DecimalFormat twoDForm = new DecimalFormat(format, symb);
/* 24 */     return Double.valueOf(twoDForm.format(d)).doubleValue();
/*    */   }
/*    */   
/*    */ 
/* 28 */   public static Random random = new Random();
/*    */   
/*    */   public static int r(int i) {
/* 31 */     return random.nextInt(i);
/*    */   }
/*    */   
/*    */   public static double offset2d(Entity a, Entity b)
/*    */   {
/* 36 */     return offset2d(a.getLocation().toVector(), b.getLocation().toVector());
/*    */   }
/*    */   
/*    */   public static double offset2d(Location a, Location b)
/*    */   {
/* 41 */     return offset2d(a.toVector(), b.toVector());
/*    */   }
/*    */   
/*    */   public static double offset2d(Vector a, Vector b)
/*    */   {
/* 46 */     a.setY(0);
/* 47 */     b.setY(0);
/* 48 */     return a.subtract(b).length();
/*    */   }
/*    */   
/*    */   public static double offset(Entity a, Entity b)
/*    */   {
/* 53 */     return offset(a.getLocation().toVector(), b.getLocation().toVector());
/*    */   }
/*    */   
/*    */   public static double offset(Location a, Location b)
/*    */   {
/* 58 */     return offset(a.toVector(), b.toVector());
/*    */   }
/*    */   
/*    */   public static double offset(Vector a, Vector b)
/*    */   {
/* 63 */     return a.subtract(b).length();
/*    */   }
/*    */   
/*    */   public static double offsetSquared(Entity a, Entity b)
/*    */   {
/* 68 */     return offsetSquared(a.getLocation(), b.getLocation());
/*    */   }
/*    */   
/*    */   public static double offsetSquared(Location a, Location b)
/*    */   {
/* 73 */     return offsetSquared(a.toVector(), b.toVector());
/*    */   }
/*    */   
/*    */   public static double offsetSquared(Vector a, Vector b)
/*    */   {
/* 78 */     return a.distanceSquared(b);
/*    */   }
/*    */   
/*    */   public static double rr(double d, boolean bidirectional)
/*    */   {
/* 83 */     if (bidirectional) {
/* 84 */       return Math.random() * (2.0D * d) - d;
/*    */     }
/* 86 */     return Math.random() * d;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilMath.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */