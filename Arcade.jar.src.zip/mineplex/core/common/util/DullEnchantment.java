/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.enchantments.Enchantment;
/*    */ import org.bukkit.enchantments.EnchantmentTarget;
/*    */ import org.bukkit.enchantments.EnchantmentWrapper;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class DullEnchantment extends EnchantmentWrapper
/*    */ {
/*    */   public DullEnchantment()
/*    */   {
/* 12 */     super(120);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean canEnchantItem(ItemStack item)
/*    */   {
/* 18 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean conflictsWith(Enchantment other)
/*    */   {
/* 24 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public EnchantmentTarget getItemTarget()
/*    */   {
/* 30 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getMaxLevel()
/*    */   {
/* 36 */     return 10;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getName()
/*    */   {
/* 42 */     return "Glow";
/*    */   }
/*    */   
/*    */ 
/*    */   public int getStartLevel()
/*    */   {
/* 48 */     return 1;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\DullEnchantment.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */