/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.entity.Skeleton;
/*    */ 
/*    */ public class UtilSkull
/*    */ {
/*    */   public static byte getSkullData(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     if ((entity instanceof Skeleton))
/*    */     {
/* 11 */       Skeleton sk = (Skeleton)entity;
/* 12 */       if (sk.getSkeletonType() == org.bukkit.entity.Skeleton.SkeletonType.WITHER)
/* 13 */         return 1;
/* 14 */       return 0;
/*    */     }
/* 16 */     if (((entity instanceof org.bukkit.entity.Zombie)) || ((entity instanceof org.bukkit.entity.Giant)))
/*    */     {
/* 18 */       return 2;
/*    */     }
/* 20 */     if ((entity instanceof org.bukkit.entity.Creeper))
/*    */     {
/* 22 */       return 4;
/*    */     }
/*    */     
/* 25 */     return 3;
/*    */   }
/*    */   
/*    */   public static boolean isPlayerHead(byte data)
/*    */   {
/* 30 */     return data == 3;
/*    */   }
/*    */   
/*    */   public static String getPlayerHeadName(org.bukkit.entity.Entity entity)
/*    */   {
/* 35 */     String name = "MHF_Alex";
/*    */     
/*    */ 
/* 38 */     if ((entity instanceof org.bukkit.entity.Blaze)) {
/* 39 */       name = "MHF_Blaze";
/* 40 */     } else if ((entity instanceof org.bukkit.entity.CaveSpider)) {
/* 41 */       name = "MHF_CaveSpider";
/* 42 */     } else if ((entity instanceof org.bukkit.entity.Spider)) {
/* 43 */       name = "MHF_Spider";
/* 44 */     } else if ((entity instanceof org.bukkit.entity.Chicken)) {
/* 45 */       name = "MHF_Chicken";
/* 46 */     } else if ((entity instanceof org.bukkit.entity.MushroomCow)) {
/* 47 */       name = "MHF_MushroomCow";
/* 48 */     } else if ((entity instanceof org.bukkit.entity.Cow)) {
/* 49 */       name = "MHF_Cow";
/* 50 */     } else if ((entity instanceof org.bukkit.entity.Creeper)) {
/* 51 */       name = "MHF_Creeper";
/* 52 */     } else if ((entity instanceof org.bukkit.entity.Enderman)) {
/* 53 */       name = "MHF_Enderman";
/* 54 */     } else if ((entity instanceof org.bukkit.entity.Ghast)) {
/* 55 */       name = "MHF_Ghast";
/* 56 */     } else if ((entity instanceof org.bukkit.entity.Golem)) {
/* 57 */       name = "MHF_Golem";
/* 58 */     } else if ((entity instanceof org.bukkit.entity.PigZombie)) {
/* 59 */       name = "MHF_PigZombie";
/* 60 */     } else if ((entity instanceof org.bukkit.entity.MagmaCube)) {
/* 61 */       name = "MHF_LavaSlime";
/* 62 */     } else if ((entity instanceof org.bukkit.entity.Slime)) {
/* 63 */       name = "MHF_Slime";
/* 64 */     } else if ((entity instanceof org.bukkit.entity.Ocelot)) {
/* 65 */       name = "MHF_Ocelot";
/* 66 */     } else if ((entity instanceof org.bukkit.entity.PigZombie)) {
/* 67 */       name = "MHF_PigZombie";
/* 68 */     } else if ((entity instanceof org.bukkit.entity.Pig)) {
/* 69 */       name = "MHF_Pig";
/* 70 */     } else if ((entity instanceof org.bukkit.entity.Sheep)) {
/* 71 */       name = "MHF_Pig";
/* 72 */     } else if ((entity instanceof org.bukkit.entity.Squid)) {
/* 73 */       name = "MHF_Squid";
/* 74 */     } else if ((entity instanceof org.bukkit.entity.HumanEntity)) {
/* 75 */       name = "MHF_Steve";
/* 76 */     } else if ((entity instanceof org.bukkit.entity.Villager)) {
/* 77 */       name = "MHF_Villager";
/*    */     }
/* 79 */     return name;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilSkull.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */