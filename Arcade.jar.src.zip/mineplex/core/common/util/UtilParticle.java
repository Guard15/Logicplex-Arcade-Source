/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutWorldParticles;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilParticle
/*     */ {
/*     */   public static enum ViewDist
/*     */   {
/*  16 */     SHORT(8), 
/*  17 */     NORMAL(24), 
/*  18 */     LONG(48), 
/*  19 */     LONGER(96), 
/*  20 */     MAX(256);
/*     */     
/*     */     private int _dist;
/*     */     
/*     */     private ViewDist(int dist)
/*     */     {
/*  26 */       this._dist = dist;
/*     */     }
/*     */     
/*     */     public int getDist()
/*     */     {
/*  31 */       return this._dist;
/*     */     }
/*     */   }
/*     */   
/*     */   public static enum ParticleType
/*     */   {
/*  37 */     ANGRY_VILLAGER("angryVillager", "Lightning Cloud", Material.INK_SACK, (byte)11), 
/*     */     
/*  39 */     BLOCK_CRACK("blockcrack_1_0"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */     BLOCK_DUST("blockdust_1_0"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */     BUBBLE("bubble"), 
/*     */     
/*  59 */     CLOUD("cloud", "White Smoke", Material.INK_SACK, (byte)7), 
/*     */     
/*  61 */     CRIT("crit", "Brown Magic", Material.INK_SACK, (byte)14), 
/*     */     
/*  63 */     DEPTH_SUSPEND("depthSuspend"), 
/*     */     
/*  65 */     DRIP_LAVA("dripLava", "Lava Drip", Material.LAVA_BUCKET, (byte)0), 
/*     */     
/*  67 */     DRIP_WATER("dripWater", "Water Drop", Material.WATER_BUCKET, (byte)0), 
/*     */     
/*  69 */     DROPLET("droplet", "Water Splash", Material.INK_SACK, (byte)4), 
/*     */     
/*  71 */     ENCHANTMENT_TABLE("enchantmenttable", "Enchantment Words", Material.BOOK, (byte)0), 
/*     */     
/*  73 */     EXPLODE("explode", "Big White Smoke", Material.INK_SACK, (byte)15), 
/*     */     
/*  75 */     FIREWORKS_SPARK("fireworksSpark", "White Sparkle", Material.GHAST_TEAR, (byte)0), 
/*     */     
/*  77 */     FLAME("flame", "Flame", Material.BLAZE_POWDER, (byte)0), 
/*     */     
/*  79 */     FOOTSTEP("footstep", "Foot Step", Material.LEATHER_BOOTS, (byte)0), 
/*     */     
/*  81 */     HAPPY_VILLAGER("happyVillager", "Emerald Sparkle", Material.EMERALD, (byte)0), 
/*     */     
/*  83 */     HEART("heart", "Love Heart", Material.APPLE, (byte)0), 
/*     */     
/*  85 */     HUGE_EXPLOSION("hugeexplosion", "Huge Explosion", Material.TNT, (byte)0), 
/*     */     
/*  87 */     ICON_CRACK("iconcrack_1_0"), 
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     INSTANT_SPELL("instantSpell"), 
/*     */     
/*  98 */     LARGE_EXPLODE("largeexplode", "Explosion", Material.FIREBALL, (byte)0), 
/*     */     
/* 100 */     LARGE_SMOKE("largesmoke", "Black Smoke", Material.INK_SACK, (byte)0), 
/*     */     
/* 102 */     LAVA("lava", "Lava Debris", Material.LAVA, (byte)0), 
/*     */     
/* 104 */     MAGIC_CRIT("magicCrit", "Teal Magic", Material.INK_SACK, (byte)6), 
/*     */     
/* 106 */     MOB_SPELL(
/*     */     
/*     */ 
/* 109 */       "mobSpell", "Black Swirls", Material.getMaterial(2263), (byte)0), 
/*     */     
/* 111 */     MOB_SPELL_AMBIENT(
/*     */     
/*     */ 
/* 114 */       "mobSpellAmbient", "Transparent Black Swirls", Material.getMaterial(2266), (byte)0), 
/*     */     
/* 116 */     NOTE("note", "Musical Note", Material.JUKEBOX, (byte)0), 
/*     */     
/* 118 */     PORTAL("portal", "Portal Effect", Material.INK_SACK, (byte)5), 
/*     */     
/* 120 */     RED_DUST(
/*     */     
/*     */ 
/* 123 */       "reddust", "Red Smoke", Material.INK_SACK, (byte)1), 
/*     */     
/* 125 */     SLIME("slime", "Slime Particles", Material.SLIME_BALL, (byte)0), 
/*     */     
/* 127 */     SNOW_SHOVEL("snowshovel", "Snow Puffs", Material.SNOW_BALL, (byte)0), 
/*     */     
/* 129 */     SNOWBALL_POOF("snowballpoof"), 
/*     */     
/* 131 */     SPELL("spell", "White Swirls", Material.getMaterial(2264), (byte)0), 
/*     */     
/* 133 */     SPLASH("splash"), 
/*     */     
/* 135 */     SUSPEND("suspended"), 
/*     */     
/* 137 */     TOWN_AURA("townaura", "Black Specks", Material.COAL, (byte)0), 
/*     */     
/* 139 */     WITCH_MAGIC("witchMagic", "Purple Magic", Material.INK_SACK, (byte)13);
/*     */     
/*     */     public String particleName;
/*     */     private boolean _friendlyData;
/*     */     private String _friendlyName;
/*     */     private Material _material;
/*     */     private byte _data;
/*     */     
/*     */     private ParticleType(String particleName)
/*     */     {
/* 149 */       this.particleName = particleName;
/* 150 */       this._friendlyData = false;
/*     */     }
/*     */     
/*     */     private ParticleType(String particleName, String friendlyName, Material material, byte data)
/*     */     {
/* 155 */       this.particleName = particleName;
/* 156 */       this._friendlyData = true;
/* 157 */       this._friendlyName = friendlyName;
/* 158 */       this._material = material;
/* 159 */       this._data = data;
/*     */     }
/*     */     
/*     */     public String getParticle(Material type, int data)
/*     */     {
/* 164 */       return this.particleName;
/*     */     }
/*     */     
/*     */     public boolean hasFriendlyData()
/*     */     {
/* 169 */       return this._friendlyData;
/*     */     }
/*     */     
/*     */     public String getFriendlyName()
/*     */     {
/* 174 */       if (this._friendlyName == null)
/*     */       {
/* 176 */         return toString();
/*     */       }
/*     */       
/* 179 */       return this._friendlyName;
/*     */     }
/*     */     
/*     */     public Material getMaterial()
/*     */     {
/* 184 */       return this._material;
/*     */     }
/*     */     
/*     */     public byte getData()
/*     */     {
/* 189 */       return this._data;
/*     */     }
/*     */     
/*     */     public static ParticleType getFromFriendlyName(String name) {
/*     */       ParticleType[] arrayOfParticleType;
/* 194 */       int j = (arrayOfParticleType = values()).length; for (int i = 0; i < j; i++) { ParticleType type = arrayOfParticleType[i];
/*     */         
/* 196 */         if ((type.hasFriendlyData()) && (type.getFriendlyName().equals(name)))
/* 197 */           return type;
/*     */       }
/* 199 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static PacketPlayOutWorldParticles getPacket(String particleName, Location location, float offsetX, float offsetY, float offsetZ, float speed, int count, boolean displayFar)
/*     */   {
/* 207 */     PacketPlayOutWorldParticles packet = new PacketPlayOutWorldParticles(particleName, (float)location.getX(), (float)location.getY(), (float)location.getZ(), offsetX, offsetY, offsetZ, speed, count, displayFar);
/* 208 */     return packet;
/*     */   }
/*     */   
/*     */ 
/*     */   public static void PlayParticle(ParticleType type, Location location, float offsetX, float offsetY, float offsetZ, float speed, int count, ViewDist dist, Player... players)
/*     */   {
/* 214 */     PlayParticle(type.particleName, location, offsetX, offsetY, offsetZ, speed, count, dist, players);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void PlayParticle(String particle, Location location, float offsetX, float offsetY, float offsetZ, float speed, int count, ViewDist dist, Player... players)
/*     */   {
/* 220 */     PacketPlayOutWorldParticles packet = getPacket(particle, location, offsetX, offsetY, offsetZ, speed, count, true);
/*     */     Player[] arrayOfPlayer;
/* 222 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/*     */ 
/* 225 */       if (UtilMath.offset(player.getLocation(), location) <= dist.getDist())
/*     */       {
/*     */ 
/* 228 */         UtilPlayer.sendPacket(player, new Packet[] { packet });
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilParticle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */