/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilAlg
/*     */ {
/*     */   public static TreeSet<String> sortKey(Set<String> toSort)
/*     */   {
/*  20 */     TreeSet<String> sortedSet = new TreeSet();
/*  21 */     for (String cur : toSort) {
/*  22 */       sortedSet.add(cur);
/*     */     }
/*  24 */     return sortedSet;
/*     */   }
/*     */   
/*     */   public static Location getMidpoint(Location a, Location b)
/*     */   {
/*  29 */     return a.add(b.subtract(a).multiply(0.5D));
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory(Entity from, Entity to)
/*     */   {
/*  34 */     return getTrajectory(from.getLocation().toVector(), to.getLocation().toVector());
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory(Location from, Location to)
/*     */   {
/*  39 */     return getTrajectory(from.toVector(), to.toVector());
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory(Vector from, Vector to)
/*     */   {
/*  44 */     return to.subtract(from).normalize();
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory2d(Entity from, Entity to)
/*     */   {
/*  49 */     return getTrajectory2d(from.getLocation().toVector(), to.getLocation().toVector());
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory2d(Location from, Location to)
/*     */   {
/*  54 */     return getTrajectory2d(from.toVector(), to.toVector());
/*     */   }
/*     */   
/*     */   public static Vector getTrajectory2d(Vector from, Vector to)
/*     */   {
/*  59 */     return to.subtract(from).setY(0).normalize();
/*     */   }
/*     */   
/*     */   public static boolean HasSight(Location from, Player to)
/*     */   {
/*  64 */     return (HasSight(from, to.getLocation())) || (HasSight(from, to.getEyeLocation()));
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean HasSight(Location from, Location to)
/*     */   {
/*  70 */     Location cur = new Location(from.getWorld(), from.getX(), from.getY(), from.getZ());
/*     */     
/*  72 */     double rate = 0.1D;
/*  73 */     Vector vec = getTrajectory(from, to).multiply(0.1D);
/*     */     
/*  75 */     while (UtilMath.offset(cur, to) > rate)
/*     */     {
/*  77 */       cur.add(vec);
/*     */       
/*  79 */       if (!UtilBlock.airFoliage(cur.getBlock())) {
/*  80 */         return false;
/*     */       }
/*     */     }
/*  83 */     return true;
/*     */   }
/*     */   
/*     */   public static float GetPitch(Vector vec)
/*     */   {
/*  88 */     double x = vec.getX();
/*  89 */     double y = vec.getY();
/*  90 */     double z = vec.getZ();
/*  91 */     double xz = Math.sqrt(x * x + z * z);
/*     */     
/*  93 */     double pitch = Math.toDegrees(Math.atan(xz / y));
/*  94 */     if (y <= 0.0D) pitch += 90.0D; else {
/*  95 */       pitch -= 90.0D;
/*     */     }
/*     */     
/*  98 */     if (pitch == 180.0D) {
/*  99 */       pitch = 0.0D;
/*     */     }
/* 101 */     return (float)pitch;
/*     */   }
/*     */   
/*     */   public static float GetYaw(Vector vec)
/*     */   {
/* 106 */     double x = vec.getX();
/* 107 */     double z = vec.getZ();
/*     */     
/* 109 */     double yaw = Math.toDegrees(Math.atan(-x / z));
/* 110 */     if (z < 0.0D) { yaw += 180.0D;
/*     */     }
/* 112 */     return (float)yaw;
/*     */   }
/*     */   
/*     */   public static Vector Normalize(Vector vec)
/*     */   {
/* 117 */     if (vec.length() > 0.0D) {
/* 118 */       vec.normalize();
/*     */     }
/* 120 */     return vec;
/*     */   }
/*     */   
/*     */   public static Vector Clone(Vector vec)
/*     */   {
/* 125 */     return new Vector(vec.getX(), vec.getY(), vec.getZ());
/*     */   }
/*     */   
/*     */   public static <T> T Random(Set<T> set)
/*     */   {
/* 130 */     List<T> list = new ArrayList();
/*     */     
/* 132 */     list.addAll(set);
/*     */     
/* 134 */     return (T)Random(list);
/*     */   }
/*     */   
/*     */ 
/*     */   public static <T> T Random(List<T> list)
/*     */   {
/* 140 */     if (list.isEmpty()) {
/* 141 */       return null;
/*     */     }
/* 143 */     return (T)list.get(UtilMath.r(list.size()));
/*     */   }
/*     */   
/*     */   public static boolean inBoundingBox(Location loc, Location cornerA, Location cornerB)
/*     */   {
/* 148 */     if (loc.getX() <= Math.min(cornerA.getX(), cornerB.getX())) return false;
/* 149 */     if (loc.getX() >= Math.max(cornerA.getX(), cornerB.getX())) { return false;
/*     */     }
/* 151 */     if (cornerA.getY() != cornerB.getY())
/*     */     {
/* 153 */       if (loc.getY() <= Math.min(cornerA.getY(), cornerB.getY())) return false;
/* 154 */       if (loc.getY() >= Math.max(cornerA.getY(), cornerB.getY())) { return false;
/*     */       }
/*     */     }
/* 157 */     if (loc.getZ() <= Math.min(cornerA.getZ(), cornerB.getZ())) return false;
/* 158 */     if (loc.getZ() >= Math.max(cornerA.getZ(), cornerB.getZ())) { return false;
/*     */     }
/* 160 */     return true;
/*     */   }
/*     */   
/*     */   public static Vector cross(Vector a, Vector b)
/*     */   {
/* 165 */     double x = a.getY() * b.getZ() - a.getZ() * b.getY();
/* 166 */     double y = a.getZ() * b.getX() - a.getX() * b.getZ();
/* 167 */     double z = a.getX() * b.getY() - a.getY() * b.getX();
/*     */     
/* 169 */     return new Vector(x, y, z).normalize();
/*     */   }
/*     */   
/*     */   public static Vector getRight(Vector vec)
/*     */   {
/* 174 */     return cross(vec.clone().normalize(), new Vector(0, 1, 0));
/*     */   }
/*     */   
/*     */   public static Vector getLeft(Vector vec)
/*     */   {
/* 179 */     return getRight(vec).multiply(-1);
/*     */   }
/*     */   
/*     */   public static Vector getBehind(Vector vec)
/*     */   {
/* 184 */     return vec.clone().multiply(-1);
/*     */   }
/*     */   
/*     */   public static Vector getUp(Vector vec)
/*     */   {
/* 189 */     return getDown(vec).multiply(-1);
/*     */   }
/*     */   
/*     */   public static Vector getDown(Vector vec)
/*     */   {
/* 194 */     return cross(vec, getRight(vec));
/*     */   }
/*     */   
/*     */   public static Location getAverageLocation(ArrayList<Location> locs)
/*     */   {
/* 199 */     if (locs.isEmpty()) {
/* 200 */       return null;
/*     */     }
/* 202 */     Vector vec = new Vector(0, 0, 0);
/* 203 */     double amount = 0.0D;
/*     */     
/* 205 */     for (Location loc : locs)
/*     */     {
/* 207 */       vec.add(loc.toVector());
/* 208 */       amount += 1.0D;
/*     */     }
/*     */     
/* 211 */     vec.multiply(1.0D / amount);
/*     */     
/* 213 */     return vec.toLocation(((Location)locs.get(0)).getWorld());
/*     */   }
/*     */   
/*     */   public static Vector getAverageBump(Location source, ArrayList<Location> locs)
/*     */   {
/* 218 */     if (locs.isEmpty()) {
/* 219 */       return null;
/*     */     }
/* 221 */     Vector vec = new Vector(0, 0, 0);
/* 222 */     double amount = 0.0D;
/*     */     
/* 224 */     for (Location loc : locs)
/*     */     {
/* 226 */       vec.add(getTrajectory(loc, source));
/* 227 */       amount += 1.0D;
/*     */     }
/*     */     
/* 230 */     vec.multiply(1.0D / amount);
/*     */     
/* 232 */     return vec;
/*     */   }
/*     */   
/*     */   public static Location findClosest(Location mid, ArrayList<Location> locs)
/*     */   {
/* 237 */     Location bestLoc = null;
/* 238 */     double bestDist = 0.0D;
/*     */     
/* 240 */     for (Location loc : locs)
/*     */     {
/* 242 */       double dist = UtilMath.offset(mid, loc);
/*     */       
/* 244 */       if ((bestLoc == null) || (dist < bestDist))
/*     */       {
/* 246 */         bestLoc = loc;
/* 247 */         bestDist = dist;
/*     */       }
/*     */     }
/*     */     
/* 251 */     return bestLoc;
/*     */   }
/*     */   
/*     */   public static boolean isInPyramid(Vector a, Vector b, double angleLimit)
/*     */   {
/* 256 */     return (Math.abs(GetPitch(a) - GetPitch(b)) < angleLimit) && (Math.abs(GetYaw(a) - GetYaw(b)) < angleLimit);
/*     */   }
/*     */   
/*     */   public static boolean isTargetInPlayerPyramid(Player player, Player target, double angleLimit)
/*     */   {
/* 261 */     return (isInPyramid(player.getLocation().getDirection(), getTrajectory(player.getEyeLocation(), target.getEyeLocation()), angleLimit)) || 
/* 262 */       (isInPyramid(player.getLocation().getDirection(), getTrajectory(player.getEyeLocation(), target.getLocation()), angleLimit));
/*     */   }
/*     */   
/*     */   public static Location getLocationAwayFromPlayers(ArrayList<Location> locs, ArrayList<Player> players)
/*     */   {
/* 267 */     Location bestLoc = null;
/* 268 */     double bestDist = 0.0D;
/*     */     
/* 270 */     for (Location loc : locs)
/*     */     {
/* 272 */       double closest = -1.0D;
/*     */       
/* 274 */       for (Player player : players)
/*     */       {
/*     */ 
/* 277 */         if (player.getWorld().equals(loc.getWorld()))
/*     */         {
/*     */ 
/* 280 */           double dist = UtilMath.offsetSquared(player.getLocation(), loc);
/*     */           
/* 282 */           if ((closest == -1.0D) || (dist < closest))
/*     */           {
/* 284 */             closest = dist;
/*     */           }
/*     */         }
/*     */       }
/* 288 */       if (closest != -1.0D)
/*     */       {
/*     */ 
/* 291 */         if ((bestLoc == null) || (closest > bestDist))
/*     */         {
/* 293 */           bestLoc = loc;
/* 294 */           bestDist = closest;
/*     */         }
/*     */       }
/*     */     }
/* 298 */     return bestLoc;
/*     */   }
/*     */   
/*     */   public static Location getLocationNearPlayers(ArrayList<Location> locs, ArrayList<Player> players, ArrayList<Player> dontOverlap)
/*     */   {
/* 303 */     Location bestLoc = null;
/* 304 */     double bestDist = 0.0D;
/*     */     
/* 306 */     for (Location loc : locs)
/*     */     {
/* 308 */       double closest = -1.0D;
/*     */       
/* 310 */       boolean valid = true;
/*     */       
/*     */ 
/* 313 */       for (Player player : dontOverlap)
/*     */       {
/* 315 */         if (player.getWorld().equals(loc.getWorld()))
/*     */         {
/*     */ 
/* 318 */           double dist = UtilMath.offsetSquared(player.getLocation(), loc);
/*     */           
/* 320 */           if (dist < 0.8D)
/*     */           {
/* 322 */             valid = false;
/* 323 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 327 */       if (valid)
/*     */       {
/*     */ 
/*     */ 
/* 331 */         for (Player player : players)
/*     */         {
/* 333 */           if (player.getWorld().equals(loc.getWorld()))
/*     */           {
/*     */ 
/* 336 */             double dist = UtilMath.offsetSquared(player.getLocation(), loc);
/*     */             
/* 338 */             if ((closest == -1.0D) || (dist < closest))
/*     */             {
/* 340 */               closest = dist;
/*     */             }
/*     */           }
/*     */         }
/* 344 */         if (closest != -1.0D)
/*     */         {
/*     */ 
/* 347 */           if ((bestLoc == null) || (closest < bestDist))
/*     */           {
/* 349 */             bestLoc = loc;
/* 350 */             bestDist = closest;
/*     */           } }
/*     */       }
/*     */     }
/* 354 */     return bestLoc;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilAlg.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */