/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class UtilServer
/*    */ {
/*    */   public static Player[] getPlayers()
/*    */   {
/* 12 */     return (Player[])getServer().getOnlinePlayers().toArray(new Player[0]);
/*    */   }
/*    */   
/*    */   public static Server getServer()
/*    */   {
/* 17 */     return org.bukkit.Bukkit.getServer();
/*    */   }
/*    */   
/*    */   public static void broadcast(String message) {
/*    */     Player[] arrayOfPlayer;
/* 22 */     int j = (arrayOfPlayer = getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/* 23 */       UtilPlayer.message(cur, message);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void broadcastSpecial(String event, String message) { Player[] arrayOfPlayer;
/* 28 */     int j = (arrayOfPlayer = getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/*    */       
/* 30 */       UtilPlayer.message(cur, "§b§l" + event);
/* 31 */       UtilPlayer.message(cur, message);
/* 32 */       cur.playSound(cur.getLocation(), Sound.ORB_PICKUP, 2.0F, 0.0F);
/* 33 */       cur.playSound(cur.getLocation(), Sound.ORB_PICKUP, 2.0F, 0.0F);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void broadcast(String sender, String message)
/*    */   {
/* 39 */     broadcast("§f§l" + sender + " " + "§b" + message);
/*    */   }
/*    */   
/*    */   public static void broadcastMagic(String sender, String message)
/*    */   {
/* 44 */     broadcast("§2§k" + message);
/*    */   }
/*    */   
/*    */   public static double getFilledPercent()
/*    */   {
/* 49 */     return getPlayers().length / getServer().getMaxPlayers();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilServer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */