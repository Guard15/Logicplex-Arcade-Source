/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Scanner;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import net.minecraft.util.com.mojang.authlib.GameProfile;
/*     */ import net.minecraft.util.com.mojang.authlib.properties.Property;
/*     */ import net.minecraft.util.com.mojang.authlib.properties.PropertyMap;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.parser.JSONParser;
/*     */ 
/*     */ public class ProfileLoader
/*     */ {
/*     */   private final String uuid;
/*     */   private final String name;
/*     */   private final String skinOwner;
/*     */   
/*     */   public ProfileLoader(String uuid, String name)
/*     */   {
/*  26 */     this(uuid, name, name);
/*     */   }
/*     */   
/*     */   public ProfileLoader(String uuid, String name, String skinOwner)
/*     */   {
/*  31 */     this.uuid = (uuid == null ? null : uuid.replaceAll("-", ""));
/*     */     
/*     */ 
/*  34 */     String displayName = ChatColor.translateAlternateColorCodes('&', name);
/*  35 */     this.name = ChatColor.stripColor(displayName);
/*  36 */     this.skinOwner = skinOwner;
/*     */   }
/*     */   
/*     */   public GameProfile loadProfile()
/*     */   {
/*  41 */     UUID id = this.uuid == null ? parseUUID(getUUID(this.name)) : parseUUID(this.uuid);
/*  42 */     GameProfile profile = new GameProfile(id, this.name);
/*  43 */     addProperties(profile);
/*  44 */     return profile;
/*     */   }
/*     */   
/*     */   private void addProperties(GameProfile profile)
/*     */   {
/*  49 */     String uuid = getUUID(this.skinOwner);
/*     */     
/*     */     try
/*     */     {
/*  53 */       URL url = new URL("https://sessionserver.mojang.com/session/minecraft/profile/" + uuid + "?unsigned=false");
/*  54 */       URLConnection uc = url.openConnection();
/*  55 */       uc.setUseCaches(false);
/*  56 */       uc.setDefaultUseCaches(false);
/*  57 */       uc.addRequestProperty("User-Agent", "Mozilla/5.0");
/*  58 */       uc.addRequestProperty("Cache-Control", "no-cache, no-store, must-revalidate");
/*  59 */       uc.addRequestProperty("Pragma", "no-cache");
/*     */       
/*     */ 
/*  62 */       String json = new Scanner(uc.getInputStream(), "UTF-8").useDelimiter("\\A").next();
/*  63 */       JSONParser parser = new JSONParser();
/*  64 */       Object obj = parser.parse(json);
/*  65 */       JSONArray properties = (JSONArray)((JSONObject)obj).get("properties");
/*  66 */       for (int i = 0; i < properties.size(); i++)
/*     */       {
/*     */         try
/*     */         {
/*  70 */           JSONObject property = (JSONObject)properties.get(i);
/*  71 */           String name = (String)property.get("name");
/*  72 */           String value = (String)property.get("value");
/*  73 */           String signature = property.containsKey("signature") ? (String)property.get("signature") : null;
/*  74 */           if (signature != null)
/*     */           {
/*  76 */             profile.getProperties().put(name, new Property(name, value, signature));
/*     */           }
/*     */           else
/*     */           {
/*  80 */             profile.getProperties().put(name, new Property(value, name));
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  85 */           Bukkit.getLogger().log(Level.WARNING, "Failed to apply auth property", e);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException1) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String getUUID(String name)
/*     */   {
/*  98 */     return Bukkit.getOfflinePlayer(name).getUniqueId().toString().replaceAll("-", "");
/*     */   }
/*     */   
/*     */ 
/*     */   private UUID parseUUID(String uuidStr)
/*     */   {
/* 104 */     String[] uuidComponents = { uuidStr.substring(0, 8), uuidStr.substring(8, 12), 
/* 105 */       uuidStr.substring(12, 16), uuidStr.substring(16, 20), uuidStr.substring(20, uuidStr.length()) };
/*     */     
/*     */ 
/* 108 */     StringBuilder builder = new StringBuilder();
/* 109 */     String[] arrayOfString1; int j = (arrayOfString1 = uuidComponents).length; for (int i = 0; i < j; i++) { String component = arrayOfString1[i];
/*     */       
/* 111 */       builder.append(component).append('-');
/*     */     }
/*     */     
/*     */ 
/* 115 */     builder.setLength(builder.length() - 1);
/* 116 */     return UUID.fromString(builder.toString());
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\ProfileLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */