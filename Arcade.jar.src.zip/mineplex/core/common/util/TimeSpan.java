package mineplex.core.common.util;

public class TimeSpan
{
  public static final long DAY = 86400000L;
  public static final long HOUR = 3600000L;
  public static final long MINUTE = 60000L;
  public static final long SECOND = 1000L;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\TimeSpan.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */