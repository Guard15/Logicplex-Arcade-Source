/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class UtilSystem {
/*    */   public static void printStackTrace() { StackTraceElement[] arrayOfStackTraceElement;
/*  7 */     int j = (arrayOfStackTraceElement = Thread.currentThread().getStackTrace()).length; for (int i = 0; i < j; i++) { StackTraceElement trace = arrayOfStackTraceElement[i];
/*    */       
/*  9 */       System.out.println(trace.toString());
/*    */     }
/*    */   }
/*    */   
/*    */   public static void printStackTrace(StackTraceElement[] stackTrace)
/*    */   {
/* 15 */     StackTraceElement[] arrayOfStackTraceElement = stackTrace;int j = stackTrace.length; for (int i = 0; i < j; i++) { StackTraceElement trace = arrayOfStackTraceElement[i];
/*    */       
/* 17 */       System.out.println(trace.toString());
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilSystem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */