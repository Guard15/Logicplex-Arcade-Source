/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Projectile;
/*    */ import org.bukkit.event.block.Action;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.event.entity.EntityDamageEvent;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ public class UtilEvent
/*    */ {
/*    */   public static enum ActionType
/*    */   {
/* 14 */     L, 
/* 15 */     L_AIR, 
/* 16 */     L_BLOCK, 
/* 17 */     R, 
/* 18 */     R_AIR, 
/* 19 */     R_BLOCK;
/*    */   }
/*    */   
/*    */   public static boolean isAction(PlayerInteractEvent event, ActionType action)
/*    */   {
/* 24 */     if (action == ActionType.L) {
/* 25 */       return (event.getAction() == Action.LEFT_CLICK_AIR) || (event.getAction() == Action.LEFT_CLICK_BLOCK);
/*    */     }
/* 27 */     if (action == ActionType.L_AIR) {
/* 28 */       return event.getAction() == Action.LEFT_CLICK_AIR;
/*    */     }
/* 30 */     if (action == ActionType.L_BLOCK) {
/* 31 */       return event.getAction() == Action.LEFT_CLICK_BLOCK;
/*    */     }
/* 33 */     if (action == ActionType.R) {
/* 34 */       return (event.getAction() == Action.RIGHT_CLICK_AIR) || (event.getAction() == Action.RIGHT_CLICK_BLOCK);
/*    */     }
/* 36 */     if (action == ActionType.R_AIR) {
/* 37 */       return event.getAction() == Action.RIGHT_CLICK_AIR;
/*    */     }
/* 39 */     if (action == ActionType.R_BLOCK) {
/* 40 */       return event.getAction() == Action.RIGHT_CLICK_BLOCK;
/*    */     }
/* 42 */     return false;
/*    */   }
/*    */   
/*    */   public static LivingEntity GetDamagerEntity(EntityDamageEvent event, boolean ranged)
/*    */   {
/* 47 */     if (!(event instanceof EntityDamageByEntityEvent)) {
/* 48 */       return null;
/*    */     }
/* 50 */     EntityDamageByEntityEvent eventEE = (EntityDamageByEntityEvent)event;
/*    */     
/*    */ 
/* 53 */     if ((eventEE.getDamager() instanceof LivingEntity)) {
/* 54 */       return (LivingEntity)eventEE.getDamager();
/*    */     }
/* 56 */     if (!ranged) {
/* 57 */       return null;
/*    */     }
/* 59 */     if (!(eventEE.getDamager() instanceof Projectile)) {
/* 60 */       return null;
/*    */     }
/* 62 */     Projectile projectile = (Projectile)eventEE.getDamager();
/*    */     
/* 64 */     if (projectile.getShooter() == null) {
/* 65 */       return null;
/*    */     }
/* 67 */     if (!(projectile.getShooter() instanceof LivingEntity)) {
/* 68 */       return null;
/*    */     }
/* 70 */     return (LivingEntity)projectile.getShooter();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */