package mineplex.core.common.util;

import org.bukkit.entity.EntityType;

public class EntData
{
  public String Name;
  public EntityType Type;
  public double Height;
  public double Scale;
  
  public EntData(String name, EntityType type, double height, double scale) {}
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\EntData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */