/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ 
/*     */ 
/*     */ public class UtilBlockText
/*     */ {
/*     */   public static enum TextAlign
/*     */   {
/*  17 */     LEFT, 
/*  18 */     RIGHT, 
/*  19 */     CENTER;
/*     */   }
/*     */   
/*  22 */   public static HashMap<Character, int[][]> alphabet = new HashMap();
/*     */   
/*     */   public static ArrayList<Location> GetTextLocations(String string, Location loc, BlockFace face)
/*     */   {
/*  26 */     if (alphabet.isEmpty()) {
/*  27 */       PopulateAlphabet();
/*     */     }
/*  29 */     ArrayList<Location> locs = new ArrayList();
/*     */     
/*  31 */     Block block = loc.getBlock();
/*     */     
/*     */ 
/*  34 */     int width = 0;
/*  35 */     char[] arrayOfChar1; int j = (arrayOfChar1 = string.toLowerCase().toCharArray()).length; for (int i = 0; i < j; i++) { char c = arrayOfChar1[i];
/*     */       
/*  37 */       int[][] letter = (int[][])alphabet.get(Character.valueOf(c));
/*     */       
/*  39 */       if (letter != null)
/*     */       {
/*     */ 
/*  42 */         width += (letter[0].length + 1) * 3;
/*     */       }
/*     */     }
/*     */     
/*  46 */     block = block.getRelative(face, -1 * width / 2 + 1);
/*     */     
/*     */ 
/*     */ 
/*  50 */     World world = block.getWorld();
/*  51 */     int bX = block.getX();
/*  52 */     int bY = block.getY();
/*  53 */     int bZ = block.getZ();
/*     */     
/*     */     char[] arrayOfChar2;
/*  56 */     int m = (arrayOfChar2 = string.toLowerCase().toCharArray()).length; for (int k = 0; k < m; k++) { char c = arrayOfChar2[k];
/*     */       
/*  58 */       int[][] letter = (int[][])alphabet.get(Character.valueOf(c));
/*     */       
/*  60 */       if (letter != null)
/*     */       {
/*     */ 
/*  63 */         for (int x = 0; x < letter.length; x++)
/*     */         {
/*  65 */           for (int y = 0; y < letter[x].length; y++)
/*     */           {
/*  67 */             if (letter[x][y] == 1) {
/*  68 */               locs.add(new Location(world, bX, bY, bZ));
/*     */             }
/*     */             
/*  71 */             bX += face.getModX() * 3;
/*  72 */             bY += face.getModY() * 3;
/*  73 */             bZ += face.getModZ() * 3;
/*     */           }
/*     */           
/*     */ 
/*  77 */           bX += face.getModX() * -3 * letter[x].length;
/*  78 */           bY += face.getModY() * -3 * letter[x].length;
/*  79 */           bZ += face.getModZ() * -3 * letter[x].length;
/*     */           
/*     */ 
/*  82 */           bY -= 3;
/*     */         }
/*     */         
/*  85 */         bY += 15;
/*  86 */         bX += face.getModX() * (letter[0].length + 1) * 3;
/*  87 */         bY += face.getModY() * (letter[0].length + 1) * 3;
/*  88 */         bZ += face.getModZ() * (letter[0].length + 1) * 3;
/*     */       }
/*     */     }
/*  91 */     return locs;
/*     */   }
/*     */   
/*     */   public static Collection<Block> MakeText(String string, Location loc, BlockFace face, int id, byte data, TextAlign align)
/*     */   {
/*  96 */     return MakeText(string, loc, face, id, data, align, true);
/*     */   }
/*     */   
/*     */   public static Collection<Block> MakeText(String string, Location loc, BlockFace face, int id, byte data, TextAlign align, boolean setAir)
/*     */   {
/* 101 */     HashSet<Block> changes = new HashSet();
/*     */     
/* 103 */     if (alphabet.isEmpty()) {
/* 104 */       PopulateAlphabet();
/*     */     }
/* 106 */     Block block = loc.getBlock();
/*     */     
/*     */ 
/* 109 */     int width = 0;
/* 110 */     char[] arrayOfChar1; int j = (arrayOfChar1 = string.toLowerCase().toCharArray()).length; for (int i = 0; i < j; i++) { char c = arrayOfChar1[i];
/*     */       
/* 112 */       int[][] letter = (int[][])alphabet.get(Character.valueOf(c));
/*     */       
/* 114 */       if (letter != null)
/*     */       {
/*     */ 
/* 117 */         width += letter[0].length + 1;
/*     */       }
/*     */     }
/*     */     
/* 121 */     if ((align == TextAlign.CENTER) || (align == TextAlign.RIGHT))
/*     */     {
/* 123 */       int divisor = 1;
/* 124 */       if (align == TextAlign.CENTER) {
/* 125 */         divisor = 2;
/*     */       }
/* 127 */       block = block.getRelative(face, -1 * width / divisor + 1);
/*     */     }
/*     */     
/*     */ 
/* 131 */     if (setAir)
/*     */     {
/* 133 */       World world = loc.getWorld();
/* 134 */       int bX = loc.getBlockX();
/* 135 */       int bY = loc.getBlockY();
/* 136 */       int bZ = loc.getBlockZ();
/* 137 */       for (int y = 0; y < 5; y++)
/*     */       {
/* 139 */         if (align == TextAlign.CENTER) {
/* 140 */           for (int i = -64; i <= 64; i++)
/*     */           {
/* 142 */             if (world.getBlockAt(bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ()).getTypeId() == id) {
/* 143 */               MapUtil.ChunkBlockSet(world, bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ(), 0, (byte)0, true);
/*     */             }
/*     */           }
/*     */         }
/* 147 */         if (align == TextAlign.LEFT) {
/* 148 */           for (int i = 0; i <= 128; i++)
/*     */           {
/* 150 */             if (world.getBlockAt(bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ()).getTypeId() == id) {
/* 151 */               MapUtil.ChunkBlockSet(world, bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ(), 0, (byte)0, true);
/*     */             }
/*     */           }
/*     */         }
/* 155 */         if (align == TextAlign.RIGHT) {
/* 156 */           for (i = -128; i <= 0; i++)
/*     */           {
/* 158 */             if (world.getBlockAt(bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ()).getTypeId() == id) {
/* 159 */               MapUtil.ChunkBlockSet(world, bX + i * face.getModX(), bY + i * face.getModY(), bZ + i * face.getModZ(), 0, (byte)0, true);
/*     */             }
/*     */           }
/*     */         }
/* 163 */         bY--;
/*     */       }
/*     */     }
/*     */     
/* 167 */     World world = block.getWorld();
/* 168 */     int bX = block.getX();
/* 169 */     int bY = block.getY();
/* 170 */     int bZ = block.getZ();
/*     */     
/*     */     char[] arrayOfChar2;
/* 173 */     int k = (arrayOfChar2 = string.toLowerCase().toCharArray()).length; for (int i = 0; i < k; i++) { char c = arrayOfChar2[i];
/*     */       
/* 175 */       int[][] letter = (int[][])alphabet.get(Character.valueOf(c));
/*     */       
/* 177 */       if (letter != null)
/*     */       {
/*     */ 
/* 180 */         for (int x = 0; x < letter.length; x++)
/*     */         {
/* 182 */           for (int y = 0; y < letter[x].length; y++)
/*     */           {
/* 184 */             if (letter[x][y] == 1)
/*     */             {
/* 186 */               changes.add(world.getBlockAt(bX, bY, bZ));
/* 187 */               MapUtil.ChunkBlockSet(world, bX, bY, bZ, id, data, true);
/*     */             }
/*     */             
/*     */ 
/* 191 */             bX += face.getModX();
/* 192 */             bY += face.getModY();
/* 193 */             bZ += face.getModZ();
/*     */           }
/*     */           
/*     */ 
/* 197 */           bX += face.getModX() * -1 * letter[x].length;
/* 198 */           bY += face.getModY() * -1 * letter[x].length;
/* 199 */           bZ += face.getModZ() * -1 * letter[x].length;
/*     */           
/*     */ 
/* 202 */           bY--;
/*     */         }
/*     */         
/* 205 */         bY += 5;
/* 206 */         bX += face.getModX() * (letter[0].length + 1);
/* 207 */         bY += face.getModY() * (letter[0].length + 1);
/* 208 */         bZ += face.getModZ() * (letter[0].length + 1);
/*     */       }
/*     */     }
/* 211 */     return changes;
/*     */   }
/*     */   
/*     */   private static void PopulateAlphabet()
/*     */   {
/* 216 */     alphabet.put(Character.valueOf('0'), new int[][] {
/* 217 */       { 1, 1, 1 }, 
/* 218 */       { 1, 0, 1 }, 
/* 219 */       { 1, 0, 1 }, 
/* 220 */       { 1, 0, 1 }, 
/* 221 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 224 */     alphabet.put(Character.valueOf('1'), new int[][] {
/* 225 */       { 1, 1 }, 
/* 226 */       { 0, 1 }, 
/* 227 */       { 0, 1 }, 
/* 228 */       { 0, 1 }, 
/* 229 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 232 */     alphabet.put(Character.valueOf('2'), new int[][] {
/* 233 */       { 1, 1, 1 }, 
/* 234 */       { 0, 0, 1 }, 
/* 235 */       { 1, 1, 1 }, 
/* 236 */       { 1 }, 
/* 237 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 240 */     alphabet.put(Character.valueOf('3'), new int[][] {
/* 241 */       { 1, 1, 1 }, 
/* 242 */       { 0, 0, 1 }, 
/* 243 */       { 1, 1, 1 }, 
/* 244 */       { 0, 0, 1 }, 
/* 245 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 248 */     alphabet.put(Character.valueOf('4'), new int[][] {
/* 249 */       { 1, 0, 1 }, 
/* 250 */       { 1, 0, 1 }, 
/* 251 */       { 1, 1, 1 }, 
/* 252 */       { 0, 0, 1 }, 
/* 253 */       { 0, 0, 1 } });
/*     */     
/*     */ 
/* 256 */     alphabet.put(Character.valueOf('5'), new int[][] {
/* 257 */       { 1, 1, 1 }, 
/* 258 */       { 1 }, 
/* 259 */       { 1, 1, 1 }, 
/* 260 */       { 0, 0, 1 }, 
/* 261 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 264 */     alphabet.put(Character.valueOf('6'), new int[][] {
/* 265 */       { 1, 1, 1 }, 
/* 266 */       { 1 }, 
/* 267 */       { 1, 1, 1 }, 
/* 268 */       { 1, 0, 1 }, 
/* 269 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 272 */     alphabet.put(Character.valueOf('7'), new int[][] {
/* 273 */       { 1, 1, 1 }, 
/* 274 */       { 0, 0, 1 }, 
/* 275 */       { 0, 0, 1 }, 
/* 276 */       { 0, 0, 1 }, 
/* 277 */       { 0, 0, 1 } });
/*     */     
/*     */ 
/* 280 */     alphabet.put(Character.valueOf('8'), new int[][] {
/* 281 */       { 1, 1, 1 }, 
/* 282 */       { 1, 0, 1 }, 
/* 283 */       { 1, 1, 1 }, 
/* 284 */       { 1, 0, 1 }, 
/* 285 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 288 */     alphabet.put(Character.valueOf('9'), new int[][] {
/* 289 */       { 1, 1, 1 }, 
/* 290 */       { 1, 0, 1 }, 
/* 291 */       { 1, 1, 1 }, 
/* 292 */       { 0, 0, 1 }, 
/* 293 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 296 */     alphabet.put(Character.valueOf('.'), new int[][] {
/* 297 */       new int[1], 
/* 298 */       new int[1], 
/* 299 */       new int[1], 
/* 300 */       new int[1], 
/* 301 */       { 1 } });
/*     */     
/*     */ 
/* 304 */     alphabet.put(Character.valueOf('!'), new int[][] {
/* 305 */       { 1 }, 
/* 306 */       { 1 }, 
/* 307 */       { 1 }, 
/* 308 */       new int[1], 
/* 309 */       { 1 } });
/*     */     
/*     */ 
/* 312 */     alphabet.put(Character.valueOf(' '), new int[][] {
/* 313 */       new int[2], 
/* 314 */       new int[2], 
/* 315 */       new int[2], 
/* 316 */       new int[2], 
/* 317 */       new int[2] });
/*     */     
/*     */ 
/* 320 */     alphabet.put(Character.valueOf('a'), new int[][] {
/* 321 */       { 1, 1, 1, 1 }, 
/* 322 */       { 1, 0, 0, 1 }, 
/* 323 */       { 1, 1, 1, 1 }, 
/* 324 */       { 1, 0, 0, 1 }, 
/* 325 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 328 */     alphabet.put(Character.valueOf('b'), new int[][] {
/* 329 */       { 1, 1, 1 }, 
/* 330 */       { 1, 0, 0, 1 }, 
/* 331 */       { 1, 1, 1 }, 
/* 332 */       { 1, 0, 0, 1 }, 
/* 333 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 336 */     alphabet.put(Character.valueOf('c'), new int[][] {
/* 337 */       { 1, 1, 1, 1 }, 
/* 338 */       { 1 }, 
/* 339 */       { 1 }, 
/* 340 */       { 1 }, 
/* 341 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 344 */     alphabet.put(Character.valueOf('d'), new int[][] {
/* 345 */       { 1, 1, 1 }, 
/* 346 */       { 1, 0, 0, 1 }, 
/* 347 */       { 1, 0, 0, 1 }, 
/* 348 */       { 1, 0, 0, 1 }, 
/* 349 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 352 */     alphabet.put(Character.valueOf('e'), new int[][] {
/* 353 */       { 1, 1, 1, 1 }, 
/* 354 */       { 1 }, 
/* 355 */       { 1, 1, 1 }, 
/* 356 */       { 1 }, 
/* 357 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 360 */     alphabet.put(Character.valueOf('f'), new int[][] {
/* 361 */       { 1, 1, 1, 1 }, 
/* 362 */       { 1 }, 
/* 363 */       { 1, 1, 1 }, 
/* 364 */       { 1 }, 
/* 365 */       { 1 } });
/*     */     
/*     */ 
/* 368 */     alphabet.put(Character.valueOf('g'), new int[][] {
/* 369 */       { 1, 1, 1, 1 }, 
/* 370 */       { 1 }, 
/* 371 */       { 1, 0, 1, 1 }, 
/* 372 */       { 1, 0, 0, 1 }, 
/* 373 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 376 */     alphabet.put(Character.valueOf('h'), new int[][] {
/* 377 */       { 1, 0, 0, 1 }, 
/* 378 */       { 1, 0, 0, 1 }, 
/* 379 */       { 1, 1, 1, 1 }, 
/* 380 */       { 1, 0, 0, 1 }, 
/* 381 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 384 */     alphabet.put(Character.valueOf('i'), new int[][] {
/* 385 */       { 1, 1, 1 }, 
/* 386 */       { 0, 1 }, 
/* 387 */       { 0, 1 }, 
/* 388 */       { 0, 1 }, 
/* 389 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 392 */     alphabet.put(Character.valueOf('j'), new int[][] {
/* 393 */       { 1, 1, 1, 1 }, 
/* 394 */       { 0, 0, 1 }, 
/* 395 */       { 0, 0, 1 }, 
/* 396 */       { 1, 0, 1 }, 
/* 397 */       { 1, 1, 1 } });
/*     */     
/*     */ 
/* 400 */     alphabet.put(Character.valueOf('k'), new int[][] {
/* 401 */       { 1, 0, 0, 1 }, 
/* 402 */       { 1, 0, 1 }, 
/* 403 */       { 1, 1 }, 
/* 404 */       { 1, 0, 1 }, 
/* 405 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 408 */     alphabet.put(Character.valueOf('l'), new int[][] {
/* 409 */       { 1 }, 
/* 410 */       { 1 }, 
/* 411 */       { 1 }, 
/* 412 */       { 1 }, 
/* 413 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 416 */     alphabet.put(Character.valueOf('m'), new int[][] {
/* 417 */       { 1, 1, 1, 1, 1 }, 
/* 418 */       { 1, 0, 1, 0, 1 }, 
/* 419 */       { 1, 0, 1, 0, 1 }, 
/* 420 */       { 1, 0, 0, 0, 1 }, 
/* 421 */       { 1, 0, 0, 0, 1 } });
/*     */     
/*     */ 
/* 424 */     alphabet.put(Character.valueOf('n'), new int[][] {
/* 425 */       { 1, 0, 0, 1 }, 
/* 426 */       { 1, 1, 0, 1 }, 
/* 427 */       { 1, 0, 1, 1 }, 
/* 428 */       { 1, 0, 0, 1 }, 
/* 429 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 432 */     alphabet.put(Character.valueOf('o'), new int[][] {
/* 433 */       { 1, 1, 1, 1 }, 
/* 434 */       { 1, 0, 0, 1 }, 
/* 435 */       { 1, 0, 0, 1 }, 
/* 436 */       { 1, 0, 0, 1 }, 
/* 437 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 440 */     alphabet.put(Character.valueOf('p'), new int[][] {
/* 441 */       { 1, 1, 1, 1 }, 
/* 442 */       { 1, 0, 0, 1 }, 
/* 443 */       { 1, 1, 1, 1 }, 
/* 444 */       { 1 }, 
/* 445 */       { 1 } });
/*     */     
/*     */ 
/* 448 */     alphabet.put(Character.valueOf('q'), new int[][] {
/* 449 */       { 1, 1, 1, 1 }, 
/* 450 */       { 1, 0, 0, 1 }, 
/* 451 */       { 1, 0, 0, 1 }, 
/* 452 */       { 1, 0, 1 }, 
/* 453 */       { 1, 1, 0, 1 } });
/*     */     
/*     */ 
/* 456 */     alphabet.put(Character.valueOf('r'), new int[][] {
/* 457 */       { 1, 1, 1, 1 }, 
/* 458 */       { 1, 0, 0, 1 }, 
/* 459 */       { 1, 1, 1 }, 
/* 460 */       { 1, 0, 0, 1 }, 
/* 461 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 464 */     alphabet.put(Character.valueOf('s'), new int[][] {
/* 465 */       { 1, 1, 1, 1 }, 
/* 466 */       { 1 }, 
/* 467 */       { 1, 1, 1, 1 }, 
/* 468 */       { 0, 0, 0, 1 }, 
/* 469 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 472 */     alphabet.put(Character.valueOf('t'), new int[][] {
/* 473 */       { 1, 1, 1, 1, 1 }, 
/* 474 */       { 0, 0, 1 }, 
/* 475 */       { 0, 0, 1 }, 
/* 476 */       { 0, 0, 1 }, 
/* 477 */       { 0, 0, 1 } });
/*     */     
/*     */ 
/* 480 */     alphabet.put(Character.valueOf('u'), new int[][] {
/* 481 */       { 1, 0, 0, 1 }, 
/* 482 */       { 1, 0, 0, 1 }, 
/* 483 */       { 1, 0, 0, 1 }, 
/* 484 */       { 1, 0, 0, 1 }, 
/* 485 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 488 */     alphabet.put(Character.valueOf('v'), new int[][] {
/* 489 */       { 1, 0, 0, 1 }, 
/* 490 */       { 1, 0, 0, 1 }, 
/* 491 */       { 1, 0, 0, 1 }, 
/* 492 */       { 1, 0, 0, 1 }, 
/* 493 */       { 0, 1, 1 } });
/*     */     
/*     */ 
/* 496 */     alphabet.put(Character.valueOf('w'), new int[][] {
/* 497 */       { 1, 0, 0, 0, 1 }, 
/* 498 */       { 1, 0, 0, 0, 1 }, 
/* 499 */       { 1, 0, 1, 0, 1 }, 
/* 500 */       { 1, 0, 1, 0, 1 }, 
/* 501 */       { 1, 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 504 */     alphabet.put(Character.valueOf('x'), new int[][] {
/* 505 */       { 1, 0, 0, 1 }, 
/* 506 */       { 1, 0, 0, 1 }, 
/* 507 */       { 0, 1, 1 }, 
/* 508 */       { 1, 0, 0, 1 }, 
/* 509 */       { 1, 0, 0, 1 } });
/*     */     
/*     */ 
/* 512 */     alphabet.put(Character.valueOf('y'), new int[][] {
/* 513 */       { 1, 0, 0, 1 }, 
/* 514 */       { 1, 0, 0, 1 }, 
/* 515 */       { 1, 1, 1, 1 }, 
/* 516 */       { 0, 0, 0, 1 }, 
/* 517 */       { 1, 1, 1, 1 } });
/*     */     
/*     */ 
/* 520 */     alphabet.put(Character.valueOf('z'), new int[][] {
/* 521 */       { 1, 1, 1, 1 }, 
/* 522 */       { 0, 0, 0, 1 }, 
/* 523 */       { 0, 0, 1 }, 
/* 524 */       { 0, 1 }, 
/* 525 */       { 1, 1, 1, 1 } });
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilBlockText.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */