/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.Color;
/*    */ import org.bukkit.FireworkEffect;
/*    */ import org.bukkit.FireworkEffect.Builder;
/*    */ import org.bukkit.FireworkEffect.Type;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftFirework;
/*    */ import org.bukkit.entity.Firework;
/*    */ import org.bukkit.inventory.meta.FireworkMeta;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class UtilFirework
/*    */ {
/*    */   public static void playFirework(Location loc, FireworkEffect fe)
/*    */   {
/* 18 */     Firework firework = (Firework)loc.getWorld().spawn(loc, Firework.class);
/*    */     
/* 20 */     FireworkMeta data = firework.getFireworkMeta();
/* 21 */     data.clearEffects();
/* 22 */     data.setPower(1);
/* 23 */     data.addEffect(fe);
/* 24 */     firework.setFireworkMeta(data);
/*    */     
/* 26 */     ((CraftFirework)firework).getHandle().expectedLifespan = 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static Firework launchFirework(Location loc, FireworkEffect fe, Vector dir, int power)
/*    */   {
/*    */     try
/*    */     {
/* 35 */       Firework fw = (Firework)loc.getWorld().spawn(loc, Firework.class);
/*    */       
/* 37 */       FireworkMeta data = fw.getFireworkMeta();
/* 38 */       data.clearEffects();
/* 39 */       data.setPower(power);
/* 40 */       data.addEffect(fe);
/* 41 */       fw.setFireworkMeta(data);
/*    */       
/* 43 */       if (dir != null) {
/* 44 */         fw.setVelocity(dir);
/*    */       }
/* 46 */       return fw;
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 50 */       e.printStackTrace();
/*    */     }
/*    */     
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   public void detonateFirework(Firework firework)
/*    */   {
/* 58 */     ((org.bukkit.craftbukkit.v1_7_R4.CraftWorld)firework.getWorld()).getHandle().broadcastEntityEffect(((CraftEntity)firework).getHandle(), (byte)17);
/*    */     
/* 60 */     firework.remove();
/*    */   }
/*    */   
/*    */   public static Firework launchFirework(Location loc, FireworkEffect.Type type, Color color, boolean flicker, boolean trail, Vector dir, int power)
/*    */   {
/* 65 */     return launchFirework(loc, FireworkEffect.builder().flicker(flicker).withColor(color).with(type).trail(trail).build(), dir, power);
/*    */   }
/*    */   
/*    */   public static void playFirework(Location loc, FireworkEffect.Type type, Color color, boolean flicker, boolean trail)
/*    */   {
/* 70 */     playFirework(loc, FireworkEffect.builder().flicker(flicker).withColor(color).with(type).trail(trail).build());
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilFirework.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */