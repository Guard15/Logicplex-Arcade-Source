/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import net.minecraft.server.v1_7_R4.ChatMessage;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.spigotmc.ProtocolInjector.PacketTitle;
/*     */ import org.spigotmc.ProtocolInjector.PacketTitle.Action;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilTextMiddle
/*     */ {
/*     */   public static void display(String text, String subtitle, Player... players)
/*     */   {
/*  18 */     setSubtitle(subtitle, players);
/*     */     
/*  20 */     showTitle(text, players);
/*     */   }
/*     */   
/*     */   public static void display(String text, String subtitle)
/*     */   {
/*  25 */     setSubtitle(subtitle, UtilServer.getPlayers());
/*     */     
/*  27 */     showTitle(text, UtilServer.getPlayers());
/*     */   }
/*     */   
/*     */   public static void display(String text, String subtitle, int fadeInTicks, int stayTicks, int fadeOutTicks, Player... players)
/*     */   {
/*  32 */     setTimings(fadeInTicks, stayTicks, fadeOutTicks, players);
/*     */     
/*  34 */     display(text, subtitle, players);
/*     */   }
/*     */   
/*     */   public static void display(String text, String subtitle, int fadeInTicks, int stayTicks, int fadeOutTicks)
/*     */   {
/*  39 */     setTimings(fadeInTicks, stayTicks, fadeOutTicks, UtilServer.getPlayers());
/*     */     
/*  41 */     display(text, subtitle, UtilServer.getPlayers());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void showTitle(String text, Player... players)
/*     */   {
/*  51 */     if (text == null) {
/*  52 */       text = "";
/*     */     }
/*  54 */     ChatMessage message = new ChatMessage(text, new Object[0]);
/*  55 */     ProtocolInjector.PacketTitle packet = new ProtocolInjector.PacketTitle(ProtocolInjector.PacketTitle.Action.TITLE, message);
/*  56 */     sendPacket(packet, players);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setSubtitle(String text, Player... players)
/*     */   {
/*  66 */     if (text == null) {
/*  67 */       text = "";
/*     */     }
/*  69 */     ChatMessage message = new ChatMessage(text, new Object[0]);
/*  70 */     ProtocolInjector.PacketTitle packet = new ProtocolInjector.PacketTitle(ProtocolInjector.PacketTitle.Action.SUBTITLE, message);
/*  71 */     sendPacket(packet, players);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setTimings(int fadeInTicks, int stayTicks, int fadeOutTicks, Player... players)
/*     */   {
/*  81 */     ProtocolInjector.PacketTitle packet = new ProtocolInjector.PacketTitle(ProtocolInjector.PacketTitle.Action.TIMES, fadeInTicks, stayTicks, fadeOutTicks);
/*  82 */     sendPacket(packet, players);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void clear(Player... players)
/*     */   {
/*  90 */     ProtocolInjector.PacketTitle packet = new ProtocolInjector.PacketTitle(ProtocolInjector.PacketTitle.Action.CLEAR);
/*  91 */     sendPacket(packet, players);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void reset(Player... players)
/*     */   {
/* 101 */     ProtocolInjector.PacketTitle packet = new ProtocolInjector.PacketTitle(ProtocolInjector.PacketTitle.Action.RESET);
/* 102 */     sendPacket(packet, players);
/*     */   }
/*     */   
/*     */   private static void sendPacket(ProtocolInjector.PacketTitle packet, Player... players) {
/*     */     Player[] arrayOfPlayer;
/* 107 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/* 109 */       if (UtilPlayer.is1_8(player))
/*     */       {
/* 111 */         ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static String progress(float exp)
/*     */   {
/* 118 */     String out = "";
/*     */     
/* 120 */     for (int i = 0; i < 40; i++)
/*     */     {
/* 122 */       float cur = i * 0.025F;
/*     */       
/* 124 */       if (cur < exp) {
/* 125 */         out = out + C.cGreen + C.Bold + "|";
/*     */       } else {
/* 127 */         out = out + C.cGray + C.Bold + "|";
/*     */       }
/*     */     }
/* 130 */     return out;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilTextMiddle.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */