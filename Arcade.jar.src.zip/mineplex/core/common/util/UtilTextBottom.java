/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import mineplex.core.common.jsonchat.JsonMessage;
/*    */ import mineplex.core.common.jsonchat.JsonMessage.MessageType;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class UtilTextBottom
/*    */ {
/*    */   public static void display(String text, Player... players)
/*    */   {
/* 13 */     JsonMessage msg = new JsonMessage(text);
/*    */     
/*    */ 
/* 16 */     msg.send(JsonMessage.MessageType.ABOVE_HOTBAR, players);
/*    */     
/*    */     Player[] arrayOfPlayer;
/* 19 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*    */       
/* 21 */       if (!UtilPlayer.is1_8(player))
/*    */       {
/* 23 */         UtilTextTop.display(text, new Player[] { player });
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public static void displayProgress(double amount, Player... players)
/*    */   {
/* 30 */     displayProgress(null, amount, null, players);
/*    */   }
/*    */   
/*    */   public static void displayProgress(String prefix, double amount, Player... players)
/*    */   {
/* 35 */     displayProgress(prefix, amount, null, players);
/*    */   }
/*    */   
/*    */   public static void displayProgress(String prefix, double amount, String suffix, Player... players)
/*    */   {
/* 40 */     displayProgress(prefix, amount, suffix, false, players);
/*    */   }
/*    */   
/*    */   public static void displayProgress(String prefix, double amount, String suffix, boolean progressDirectionSwap, Player... players)
/*    */   {
/* 45 */     if (progressDirectionSwap) {
/* 46 */       amount = 1.0D - amount;
/*    */     }
/*    */     
/* 49 */     int bars = 24;
/* 50 */     String progressBar = C.cGreen;
/* 51 */     boolean colorChange = false;
/* 52 */     for (int i = 0; i < bars; i++)
/*    */     {
/* 54 */       if ((!colorChange) && (i / bars >= amount))
/*    */       {
/* 56 */         progressBar = progressBar + C.cRed;
/* 57 */         colorChange = true;
/*    */       }
/*    */       
/* 60 */       progressBar = progressBar + "▌";
/*    */     }
/*    */     
/*    */     Player[] arrayOfPlayer;
/* 64 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*    */       
/*    */ 
/* 67 */       if (!UtilPlayer.is1_8(player))
/*    */       {
/* 69 */         UtilTextTop.displayProgress((prefix == null ? "" : new StringBuilder(String.valueOf(C.cYellow)).append(C.Bold).append(prefix).toString()) + (suffix == null ? "" : new StringBuilder().append(ChatColor.RESET).append(C.Bold).append(" - ").append(C.cGreen).append(C.Bold).append(suffix).toString()), 
/* 70 */           amount, new Player[] { player });
/*    */ 
/*    */       }
/*    */       else
/*    */       {
/* 75 */         display((prefix == null ? "" : new StringBuilder(String.valueOf(prefix)).append(ChatColor.RESET).append(" ").toString()) + progressBar + (suffix == null ? "" : new StringBuilder().append(ChatColor.RESET).append(" ").append(suffix).toString()), players);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilTextBottom.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */