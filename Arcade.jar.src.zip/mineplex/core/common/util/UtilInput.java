/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ 
/*     */ 
/*     */ public class UtilInput
/*     */ {
/*   8 */   protected static HashSet<Character> validSet = new HashSet();
/*   9 */   protected static HashSet<String> filterSet = new HashSet();
/*     */   
/*     */   public static boolean valid(String input)
/*     */   {
/*  13 */     if (validSet.isEmpty())
/*  14 */       addChars();
/*     */     char[] arrayOfChar;
/*  16 */     int j = (arrayOfChar = input.toCharArray()).length; for (int i = 0; i < j; i++) { char cur = arrayOfChar[i];
/*  17 */       if (!validSet.contains(Character.valueOf(cur)))
/*  18 */         return false;
/*     */     }
/*  20 */     return true;
/*     */   }
/*     */   
/*     */   public static String filter(String input)
/*     */   {
/*  25 */     if (filterSet.isEmpty()) {
/*  26 */       addDictionary();
/*     */     }
/*  28 */     for (String cur : filterSet)
/*     */     {
/*  30 */       if (input.equalsIgnoreCase(cur))
/*     */       {
/*  32 */         String out = input.charAt(0);
/*  33 */         while (out.length() < input.length())
/*  34 */           out = out + '*';
/*  35 */         return out;
/*     */       }
/*     */     }
/*     */     
/*  39 */     return input;
/*     */   }
/*     */   
/*     */   public static void addDictionary()
/*     */   {
/*  44 */     filterSet.add("fuck");
/*  45 */     filterSet.add("shit");
/*  46 */     filterSet.add("cunt");
/*  47 */     filterSet.add("ass");
/*  48 */     filterSet.add("asshole");
/*  49 */     filterSet.add("faggot");
/*  50 */     filterSet.add("fag");
/*  51 */     filterSet.add("gay");
/*     */   }
/*     */   
/*     */   public static void addChars()
/*     */   {
/*  56 */     validSet.add(Character.valueOf('1'));
/*  57 */     validSet.add(Character.valueOf('2'));
/*  58 */     validSet.add(Character.valueOf('3'));
/*  59 */     validSet.add(Character.valueOf('4'));
/*  60 */     validSet.add(Character.valueOf('5'));
/*  61 */     validSet.add(Character.valueOf('6'));
/*  62 */     validSet.add(Character.valueOf('7'));
/*  63 */     validSet.add(Character.valueOf('8'));
/*  64 */     validSet.add(Character.valueOf('9'));
/*  65 */     validSet.add(Character.valueOf('0'));
/*     */     
/*  67 */     validSet.add(Character.valueOf('a'));
/*  68 */     validSet.add(Character.valueOf('b'));
/*  69 */     validSet.add(Character.valueOf('c'));
/*  70 */     validSet.add(Character.valueOf('d'));
/*  71 */     validSet.add(Character.valueOf('e'));
/*  72 */     validSet.add(Character.valueOf('f'));
/*  73 */     validSet.add(Character.valueOf('g'));
/*  74 */     validSet.add(Character.valueOf('h'));
/*  75 */     validSet.add(Character.valueOf('i'));
/*  76 */     validSet.add(Character.valueOf('j'));
/*  77 */     validSet.add(Character.valueOf('k'));
/*  78 */     validSet.add(Character.valueOf('l'));
/*  79 */     validSet.add(Character.valueOf('m'));
/*  80 */     validSet.add(Character.valueOf('n'));
/*  81 */     validSet.add(Character.valueOf('o'));
/*  82 */     validSet.add(Character.valueOf('p'));
/*  83 */     validSet.add(Character.valueOf('q'));
/*  84 */     validSet.add(Character.valueOf('r'));
/*  85 */     validSet.add(Character.valueOf('s'));
/*  86 */     validSet.add(Character.valueOf('t'));
/*  87 */     validSet.add(Character.valueOf('u'));
/*  88 */     validSet.add(Character.valueOf('v'));
/*  89 */     validSet.add(Character.valueOf('w'));
/*  90 */     validSet.add(Character.valueOf('x'));
/*  91 */     validSet.add(Character.valueOf('y'));
/*  92 */     validSet.add(Character.valueOf('z'));
/*     */     
/*  94 */     validSet.add(Character.valueOf('A'));
/*  95 */     validSet.add(Character.valueOf('B'));
/*  96 */     validSet.add(Character.valueOf('C'));
/*  97 */     validSet.add(Character.valueOf('D'));
/*  98 */     validSet.add(Character.valueOf('E'));
/*  99 */     validSet.add(Character.valueOf('F'));
/* 100 */     validSet.add(Character.valueOf('G'));
/* 101 */     validSet.add(Character.valueOf('H'));
/* 102 */     validSet.add(Character.valueOf('I'));
/* 103 */     validSet.add(Character.valueOf('J'));
/* 104 */     validSet.add(Character.valueOf('K'));
/* 105 */     validSet.add(Character.valueOf('L'));
/* 106 */     validSet.add(Character.valueOf('M'));
/* 107 */     validSet.add(Character.valueOf('N'));
/* 108 */     validSet.add(Character.valueOf('O'));
/* 109 */     validSet.add(Character.valueOf('P'));
/* 110 */     validSet.add(Character.valueOf('Q'));
/* 111 */     validSet.add(Character.valueOf('R'));
/* 112 */     validSet.add(Character.valueOf('S'));
/* 113 */     validSet.add(Character.valueOf('T'));
/* 114 */     validSet.add(Character.valueOf('U'));
/* 115 */     validSet.add(Character.valueOf('V'));
/* 116 */     validSet.add(Character.valueOf('W'));
/* 117 */     validSet.add(Character.valueOf('X'));
/* 118 */     validSet.add(Character.valueOf('Y'));
/* 119 */     validSet.add(Character.valueOf('Z'));
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilInput.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */