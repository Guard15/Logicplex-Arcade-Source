/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import org.bukkit.Chunk;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.World.Environment;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ public class UtilWorld
/*     */ {
/*     */   public static World getWorld(String world)
/*     */   {
/*  16 */     return UtilServer.getServer().getWorld(world);
/*     */   }
/*     */   
/*     */   public static String chunkToStr(Chunk chunk)
/*     */   {
/*  21 */     if (chunk == null) {
/*  22 */       return "";
/*     */     }
/*  24 */     return chunk.getWorld().getName() + "," + chunk.getX() + "," + chunk.getZ();
/*     */   }
/*     */   
/*     */   public static String chunkToStrClean(Chunk chunk)
/*     */   {
/*  29 */     if (chunk == null) {
/*  30 */       return "";
/*     */     }
/*  32 */     return "(" + chunk.getX() + "," + chunk.getZ() + ")";
/*     */   }
/*     */   
/*     */   public static Chunk strToChunk(String string)
/*     */   {
/*     */     try
/*     */     {
/*  39 */       String[] tokens = string.split(",");
/*     */       
/*  41 */       return getWorld(tokens[0]).getChunkAt(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]));
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*  45 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public static String locToStr(Location loc)
/*     */   {
/*  51 */     if (loc == null) {
/*  52 */       return "";
/*     */     }
/*  54 */     return 
/*     */     
/*     */ 
/*  57 */       loc.getWorld().getName() + "," + UtilMath.trim(1, loc.getX()) + "," + UtilMath.trim(1, loc.getY()) + "," + UtilMath.trim(1, loc.getZ());
/*     */   }
/*     */   
/*     */   public static String locToStrClean(Location loc)
/*     */   {
/*  62 */     if (loc == null) {
/*  63 */       return "Null";
/*     */     }
/*  65 */     return "(" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ() + ")";
/*     */   }
/*     */   
/*     */   public static Location strToLoc(String string)
/*     */   {
/*  70 */     if (string.length() == 0) {
/*  71 */       return null;
/*     */     }
/*  73 */     String[] tokens = string.split(",");
/*     */     
/*     */     try
/*     */     {
/*  77 */       for (World cur : UtilServer.getServer().getWorlds())
/*     */       {
/*  79 */         if (cur.getName().equalsIgnoreCase(tokens[0]))
/*     */         {
/*  81 */           return new Location(cur, Double.parseDouble(tokens[1]), Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3]));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  87 */       return null;
/*     */     }
/*     */     
/*  90 */     return null;
/*     */   }
/*     */   
/*     */   public static Location locMerge(Location a, Location b)
/*     */   {
/*  95 */     a.setX(b.getX());
/*  96 */     a.setY(b.getY());
/*  97 */     a.setZ(b.getZ());
/*  98 */     return a;
/*     */   }
/*     */   
/*     */   public static String envToStr(World.Environment env)
/*     */   {
/* 103 */     if (env == World.Environment.NORMAL) return "Overworld";
/* 104 */     if (env == World.Environment.NETHER) return "Nether";
/* 105 */     if (env == World.Environment.THE_END) return "The End";
/* 106 */     return "Unknown";
/*     */   }
/*     */   
/*     */   public static World getWorldType(World.Environment env)
/*     */   {
/* 111 */     for (World cur : UtilServer.getServer().getWorlds()) {
/* 112 */       if (cur.getEnvironment() == env)
/* 113 */         return cur;
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */   
/*     */   public static Location averageLocation(Collection<Location> locs)
/*     */   {
/* 120 */     if (locs.isEmpty()) {
/* 121 */       return null;
/*     */     }
/* 123 */     Vector vec = new Vector(0, 0, 0);
/* 124 */     double count = 0.0D;
/*     */     
/* 126 */     World world = null;
/*     */     
/* 128 */     for (Location spawn : locs)
/*     */     {
/* 130 */       count += 1.0D;
/* 131 */       vec.add(spawn.toVector());
/*     */       
/* 133 */       world = spawn.getWorld();
/*     */     }
/*     */     
/* 136 */     vec.multiply(1.0D / count);
/*     */     
/* 138 */     return vec.toLocation(world);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilWorld.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */