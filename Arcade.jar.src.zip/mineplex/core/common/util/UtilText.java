/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ 
/*    */ public class UtilText {
/*    */   public static <T> String listToString(Collection<T> inputList, boolean comma) {
/*  7 */     String out = "";
/*    */     
/*  9 */     for (T cur : inputList) {
/* 10 */       out = out + cur.toString() + (comma ? ", " : " ");
/*    */     }
/*    */     
/* 13 */     if (out.length() > 0) {
/* 14 */       out = out.substring(0, out.length() - (comma ? 2 : 1));
/*    */     }
/*    */     
/* 17 */     return out;
/*    */   }
/*    */   
/*    */   public static int upperCaseCount(String input) {
/* 21 */     int count = 0;
/*    */     
/* 23 */     for (int k = 0; k < input.length(); k++)
/*    */     {
/*    */ 
/* 26 */       char ch = input.charAt(k);
/* 27 */       if (Character.isUpperCase(ch)) {
/* 28 */         count++;
/*    */       }
/*    */     }
/*    */     
/* 32 */     return count;
/*    */   }
/*    */   
/* 35 */   public static int lowerCaseCount(String input) { int count = 0;
/*    */     
/* 37 */     for (int k = 0; k < input.length(); k++)
/*    */     {
/*    */ 
/* 40 */       char ch = input.charAt(k);
/* 41 */       if (Character.isLowerCase(ch)) {
/* 42 */         count++;
/*    */       }
/*    */     }
/*    */     
/* 46 */     return count;
/*    */   }
/*    */   
/*    */   public static boolean isStringSimilar(String newString, String oldString, float matchRequirement)
/*    */   {
/* 51 */     if (newString.length() <= 3)
/*    */     {
/* 53 */       return newString.toLowerCase().equals(oldString.toLowerCase());
/*    */     }
/*    */     
/* 56 */     for (int i = 0; i < newString.length() * matchRequirement; i++)
/*    */     {
/* 58 */       int matchFromIndex = 0;
/*    */       
/*    */ 
/* 61 */       for (int j = 0; j < oldString.length(); j++)
/*    */       {
/*    */ 
/* 64 */         if (i + j >= newString.length()) {
/*    */           break;
/*    */         }
/*    */         
/*    */ 
/*    */ 
/* 70 */         if (newString.charAt(i + j) != oldString.charAt(j))
/*    */           break;
/* 72 */         matchFromIndex++;
/*    */         
/* 74 */         if (matchFromIndex >= newString.length() * matchRequirement) {
/* 75 */           return true;
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 85 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilText.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */