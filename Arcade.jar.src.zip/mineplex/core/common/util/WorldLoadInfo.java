/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.World;
/*    */ 
/*    */ 
/*    */ public class WorldLoadInfo
/*    */ {
/*    */   private World _world;
/*    */   private int _minChunkX;
/*    */   private int _minChunkZ;
/*    */   private int _maxChunkX;
/*    */   private int _maxChunkZ;
/*    */   public int CurrentChunkX;
/*    */   public int CurrentChunkZ;
/*    */   
/*    */   public WorldLoadInfo(World world, int minChunkX, int minChunkZ, int maxChunkX, int maxChunkZ)
/*    */   {
/* 18 */     this._world = world;
/* 19 */     this._minChunkX = minChunkX;
/* 20 */     this._minChunkZ = minChunkZ;
/* 21 */     this._maxChunkX = maxChunkX;
/* 22 */     this._maxChunkZ = maxChunkZ;
/*    */     
/* 24 */     this.CurrentChunkX = minChunkX;
/* 25 */     this.CurrentChunkZ = minChunkZ;
/*    */   }
/*    */   
/*    */   public World GetWorld()
/*    */   {
/* 30 */     return this._world;
/*    */   }
/*    */   
/*    */   public int GetMinChunkX()
/*    */   {
/* 35 */     return this._minChunkX;
/*    */   }
/*    */   
/*    */   public int GetMinChunkZ()
/*    */   {
/* 40 */     return this._minChunkZ;
/*    */   }
/*    */   
/*    */   public int GetMaxChunkX()
/*    */   {
/* 45 */     return this._maxChunkX;
/*    */   }
/*    */   
/*    */   public int GetMaxChunkZ()
/*    */   {
/* 50 */     return this._maxChunkZ;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\WorldLoadInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */