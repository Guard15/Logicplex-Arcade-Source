/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class UtilPlayer
/*     */ {
/*     */   private static boolean hasIntersection(Vector3D p1, Vector3D p2, Vector3D min, Vector3D max)
/*     */   {
/*  27 */     double epsilon = 9.999999747378752E-5D;
/*     */     
/*  29 */     Vector3D d = Vector3D.access$0(p2, p1).multiply(0.5D);
/*  30 */     Vector3D e = Vector3D.access$0(max, min).multiply(0.5D);
/*  31 */     Vector3D c = Vector3D.access$2(p1, d).subtract(Vector3D.access$1(Vector3D.access$2(min, max), 0.5D));
/*  32 */     Vector3D ad = d.abs();
/*     */     
/*  34 */     if (Math.abs(c.x) > e.x + ad.x)
/*  35 */       return false;
/*  36 */     if (Math.abs(c.y) > e.y + ad.y)
/*  37 */       return false;
/*  38 */     if (Math.abs(c.z) > e.z + ad.z) {
/*  39 */       return false;
/*     */     }
/*  41 */     if (Math.abs(d.y * c.z - d.z * c.y) > e.y * ad.z + e.z * ad.y + 9.999999747378752E-5D)
/*  42 */       return false;
/*  43 */     if (Math.abs(d.z * c.x - d.x * c.z) > e.z * ad.x + e.x * ad.z + 9.999999747378752E-5D)
/*  44 */       return false;
/*  45 */     if (Math.abs(d.x * c.y - d.y * c.x) > e.x * ad.y + e.y * ad.x + 9.999999747378752E-5D) {
/*  46 */       return false;
/*     */     }
/*  48 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   private static class Vector3D
/*     */   {
/*     */     private final double x;
/*     */     
/*     */     private final double y;
/*     */     private final double z;
/*     */     
/*     */     private Vector3D(double x, double y, double z)
/*     */     {
/*  61 */       this.x = x;
/*  62 */       this.y = y;
/*  63 */       this.z = z;
/*     */     }
/*     */     
/*     */     private Vector3D(Location location)
/*     */     {
/*  68 */       this(location.toVector());
/*     */     }
/*     */     
/*     */     private Vector3D(Vector vector)
/*     */     {
/*  73 */       if (vector == null)
/*  74 */         throw new IllegalArgumentException("Vector cannot be NULL.");
/*  75 */       this.x = vector.getX();
/*  76 */       this.y = vector.getY();
/*  77 */       this.z = vector.getZ();
/*     */     }
/*     */     
/*     */     private Vector3D abs()
/*     */     {
/*  82 */       return new Vector3D(Math.abs(this.x), Math.abs(this.y), Math.abs(this.z));
/*     */     }
/*     */     
/*     */     private Vector3D add(double x, double y, double z)
/*     */     {
/*  87 */       return new Vector3D(this.x + x, this.y + y, this.z + z);
/*     */     }
/*     */     
/*     */     private Vector3D add(Vector3D other)
/*     */     {
/*  92 */       if (other == null) {
/*  93 */         throw new IllegalArgumentException("other cannot be NULL");
/*     */       }
/*  95 */       return new Vector3D(this.x + other.x, this.y + other.y, this.z + other.z);
/*     */     }
/*     */     
/*     */     private Vector3D multiply(double factor)
/*     */     {
/* 100 */       return new Vector3D(this.x * factor, this.y * factor, this.z * factor);
/*     */     }
/*     */     
/*     */     private Vector3D multiply(int factor)
/*     */     {
/* 105 */       return new Vector3D(this.x * factor, this.y * factor, this.z * factor);
/*     */     }
/*     */     
/*     */     private Vector3D subtract(Vector3D other)
/*     */     {
/* 110 */       if (other == null)
/* 111 */         throw new IllegalArgumentException("other cannot be NULL");
/* 112 */       return new Vector3D(this.x - other.x, this.y - other.y, this.z - other.z);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Player getPlayerInSight(Player p, int range, boolean lineOfSight)
/*     */   {
/* 118 */     Location observerPos = p.getEyeLocation();
/* 119 */     Vector3D observerDir = new Vector3D(observerPos.getDirection(), null);
/* 120 */     Vector3D observerStart = new Vector3D(observerPos, null);
/* 121 */     Vector3D observerEnd = observerStart.add(Vector3D.access$9(observerDir, range));
/*     */     
/* 123 */     Player hit = null;
/*     */     
/* 125 */     for (org.bukkit.entity.Entity entity : p.getNearbyEntities(range, range, range))
/*     */     {
/*     */ 
/* 128 */       if ((entity != p) && (!isSpectator(entity)))
/*     */       {
/*     */ 
/* 131 */         double theirDist = p.getEyeLocation().distance(entity.getLocation());
/*     */         
/* 133 */         if ((!lineOfSight) || 
/*     */         
/* 135 */           (((Block)p.getLastTwoTargetBlocks(UtilBlock.blockAirFoliageSet, (int)Math.ceil(theirDist)).get(0)).getLocation().distance(p.getEyeLocation()) + 1.0D >= theirDist))
/*     */         {
/*     */ 
/* 138 */           Vector3D targetPos = new Vector3D(entity.getLocation(), null);
/* 139 */           Vector3D minimum = targetPos.add(-0.5D, 0.0D, -0.5D);
/* 140 */           Vector3D maximum = targetPos.add(0.5D, 1.67D, 0.5D);
/*     */           
/* 142 */           if (hasIntersection(observerStart, observerEnd, minimum, maximum))
/*     */           {
/* 144 */             if ((hit == null) || 
/* 145 */               (hit.getLocation().distanceSquared(observerPos) > entity.getLocation().distanceSquared(observerPos)))
/*     */             {
/* 147 */               hit = (Player)entity; } }
/*     */         }
/*     */       }
/*     */     }
/* 151 */     return hit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static org.bukkit.entity.Entity getEntityInSight(Player player, int rangeToScan, boolean avoidAllies, boolean avoidNonLiving, boolean lineOfSight, float expandBoxesPercentage)
/*     */   {
/* 160 */     Location observerPos = player.getEyeLocation();
/* 161 */     Vector3D observerDir = new Vector3D(observerPos.getDirection(), null);
/* 162 */     Vector3D observerStart = new Vector3D(observerPos, null);
/* 163 */     Vector3D observerEnd = observerStart.add(Vector3D.access$9(observerDir, rangeToScan));
/*     */     
/* 165 */     org.bukkit.entity.Entity hit = null;
/*     */     
/* 167 */     for (org.bukkit.entity.Entity entity : player.getNearbyEntities(rangeToScan, rangeToScan, rangeToScan))
/*     */     {
/* 169 */       if ((entity != player) && (!isSpectator(entity)))
/*     */       {
/*     */ 
/* 172 */         if ((!avoidNonLiving) || ((entity instanceof LivingEntity)))
/*     */         {
/*     */ 
/* 175 */           double theirDist = player.getEyeLocation().distance(entity.getLocation());
/* 176 */           if ((!lineOfSight) || 
/*     */           
/* 178 */             (((Block)player.getLastTwoTargetBlocks(UtilBlock.blockAirFoliageSet, (int)Math.ceil(theirDist)).get(0)).getLocation().distance(player.getEyeLocation()) + 1.0D >= theirDist))
/*     */           {
/*     */ 
/* 181 */             Vector3D targetPos = new Vector3D(entity.getLocation(), null);
/*     */             
/* 183 */             float width = ((CraftEntity)entity).getHandle().width / 1.8F * expandBoxesPercentage;
/*     */             
/* 185 */             Vector3D minimum = targetPos.add(-width, -0.1D / expandBoxesPercentage, -width);
/* 186 */             Vector3D maximum = targetPos.add(width, ((CraftEntity)entity).getHandle().length * expandBoxesPercentage, width);
/*     */             
/* 188 */             if (hasIntersection(observerStart, observerEnd, minimum, maximum))
/*     */             {
/* 190 */               if ((hit == null) || 
/* 191 */                 (hit.getLocation().distanceSquared(observerPos) > entity.getLocation().distanceSquared(observerPos)))
/*     */               {
/* 193 */                 hit = entity; } }
/*     */           }
/*     */         } }
/*     */     }
/* 197 */     return hit;
/*     */   }
/*     */   
/*     */   public static void message(org.bukkit.entity.Entity client, LinkedList<String> messageList)
/*     */   {
/* 202 */     message(client, messageList, false);
/*     */   }
/*     */   
/*     */   public static void message(org.bukkit.entity.Entity client, String message)
/*     */   {
/* 207 */     message(client, message, false);
/*     */   }
/*     */   
/*     */   public static void message(org.bukkit.entity.Entity client, LinkedList<String> messageList, boolean wiki)
/*     */   {
/* 212 */     for (String curMessage : messageList)
/*     */     {
/* 214 */       message(client, curMessage, wiki);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void message(org.bukkit.entity.Entity client, String message, boolean wiki)
/*     */   {
/* 220 */     if (client == null) {
/* 221 */       return;
/*     */     }
/* 223 */     if (!(client instanceof Player)) {
/* 224 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */     ((Player)client).sendMessage(message);
/*     */   }
/*     */   
/*     */   public static Player searchExact(String name) {
/*     */     Player[] arrayOfPlayer;
/* 236 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/* 237 */       if (cur.getName().equalsIgnoreCase(name))
/* 238 */         return cur;
/*     */     }
/* 240 */     return null;
/*     */   }
/*     */   
/*     */   public static Player searchExact(UUID uuid)
/*     */   {
/* 245 */     return UtilServer.getServer().getPlayer(uuid);
/*     */   }
/*     */   
/*     */   public static String searchCollection(Player caller, String player, Collection<String> coll, String collName, boolean inform)
/*     */   {
/* 250 */     LinkedList<String> matchList = new LinkedList();
/*     */     
/* 252 */     for (String cur : coll)
/*     */     {
/* 254 */       if (cur.equalsIgnoreCase(player)) {
/* 255 */         return cur;
/*     */       }
/* 257 */       if (cur.toLowerCase().contains(player.toLowerCase())) {
/* 258 */         matchList.add(cur);
/*     */       }
/*     */     }
/*     */     
/* 262 */     if (matchList.size() != 1)
/*     */     {
/* 264 */       if (!inform) {
/* 265 */         return null;
/*     */       }
/*     */       
/* 268 */       message(caller, 
/* 269 */         F.main(collName + " Search", C.mCount + matchList.size() + C.mBody + " matches for [" + C.mElem + player + 
/* 270 */         C.mBody + "]."));
/*     */       
/* 272 */       if (matchList.size() > 0)
/*     */       {
/* 274 */         String matchString = "";
/* 275 */         for (String cur : matchList) {
/* 276 */           matchString = matchString + cur + " ";
/*     */         }
/* 278 */         message(caller, 
/* 279 */           F.main(collName + " Search", C.mBody + " Matches [" + C.mElem + matchString + C.mBody + "]."));
/*     */       }
/*     */       
/* 282 */       return null;
/*     */     }
/*     */     
/* 285 */     return (String)matchList.get(0);
/*     */   }
/*     */   
/*     */   public static Player searchOnline(Player caller, String player, boolean inform)
/*     */   {
/* 290 */     LinkedList<Player> matchList = new LinkedList();
/*     */     Player[] arrayOfPlayer;
/* 292 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/*     */       
/* 294 */       if (cur.getName().equalsIgnoreCase(player)) {
/* 295 */         return cur;
/*     */       }
/* 297 */       if (cur.getName().toLowerCase().contains(player.toLowerCase())) {
/* 298 */         matchList.add(cur);
/*     */       }
/*     */     }
/*     */     
/* 302 */     if (matchList.size() != 1)
/*     */     {
/* 304 */       if (!inform) {
/* 305 */         return null;
/*     */       }
/*     */       
/* 308 */       message(caller, 
/* 309 */         F.main("Online Player Search", C.mCount + matchList.size() + C.mBody + " matches for [" + C.mElem + 
/* 310 */         player + C.mBody + "]."));
/*     */       
/* 312 */       if (matchList.size() > 0)
/*     */       {
/* 314 */         String matchString = "";
/* 315 */         for (Player cur : matchList)
/* 316 */           matchString = matchString + F.elem(cur.getName()) + ", ";
/* 317 */         if (matchString.length() > 1) {
/* 318 */           matchString = matchString.substring(0, matchString.length() - 2);
/*     */         }
/* 320 */         message(caller, 
/* 321 */           F.main("Online Player Search", C.mBody + "Matches [" + C.mElem + matchString + C.mBody + "]."));
/*     */       }
/*     */       
/* 324 */       return null;
/*     */     }
/*     */     
/* 327 */     return (Player)matchList.get(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void searchOffline(List<String> matches, Callback<String> callback, Player caller, String player, boolean inform)
/*     */   {
/* 334 */     if (matches.size() != 1)
/*     */     {
/* 336 */       if ((!inform) || (!caller.isOnline()))
/*     */       {
/* 338 */         callback.run(null);
/* 339 */         return;
/*     */       }
/*     */       
/*     */ 
/* 343 */       message(caller, 
/* 344 */         F.main("Offline Player Search", C.mCount + matches.size() + C.mBody + " matches for [" + C.mElem + 
/* 345 */         player + C.mBody + "]."));
/*     */       
/* 347 */       if (matches.size() > 0)
/*     */       {
/* 349 */         String matchString = "";
/* 350 */         for (String cur : matches)
/* 351 */           matchString = matchString + cur + " ";
/* 352 */         if (matchString.length() > 1) {
/* 353 */           matchString = matchString.substring(0, matchString.length() - 1);
/*     */         }
/* 355 */         message(caller, 
/* 356 */           F.main("Offline Player Search", C.mBody + "Matches [" + C.mElem + matchString + C.mBody + "]."));
/*     */       }
/*     */       
/* 359 */       callback.run(null);
/* 360 */       return;
/*     */     }
/*     */     
/* 363 */     callback.run((String)matches.get(0));
/*     */   }
/*     */   
/*     */   public static LinkedList<Player> matchOnline(Player caller, String players, boolean inform)
/*     */   {
/* 368 */     LinkedList<Player> matchList = new LinkedList();
/*     */     
/* 370 */     String failList = "";
/*     */     String[] arrayOfString;
/* 372 */     int j = (arrayOfString = players.split(",")).length; for (int i = 0; i < j; i++) { String cur = arrayOfString[i];
/*     */       
/* 374 */       Player match = searchOnline(caller, cur, inform);
/*     */       
/* 376 */       if (match != null) {
/* 377 */         matchList.add(match);
/*     */       }
/*     */       else {
/* 380 */         failList = failList + cur + " ";
/*     */       }
/*     */     }
/* 383 */     if ((inform) && (failList.length() > 0))
/*     */     {
/* 385 */       failList = failList.substring(0, failList.length() - 1);
/* 386 */       message(caller, F.main("Online Player(s) Search", C.mBody + "Invalid [" + C.mElem + failList + C.mBody + "]."));
/*     */     }
/*     */     
/* 389 */     return matchList;
/*     */   }
/*     */   
/*     */   public static LinkedList<Player> getNearby(Location loc, double maxDist)
/*     */   {
/* 394 */     LinkedList<Player> nearbyMap = new LinkedList();
/*     */     
/* 396 */     for (Player cur : loc.getWorld().getPlayers())
/*     */     {
/* 398 */       if (!isSpectator(cur))
/*     */       {
/*     */ 
/* 401 */         if (!cur.isDead())
/*     */         {
/*     */ 
/* 404 */           double dist = loc.toVector().subtract(cur.getLocation().toVector()).length();
/*     */           
/* 406 */           if (dist <= maxDist)
/*     */           {
/*     */ 
/* 409 */             for (int i = 0; i < nearbyMap.size(); i++)
/*     */             {
/* 411 */               if (dist < loc.toVector().subtract(((Player)nearbyMap.get(i)).getLocation().toVector()).length())
/*     */               {
/* 413 */                 nearbyMap.add(i, cur);
/* 414 */                 break;
/*     */               }
/*     */             }
/*     */             
/* 418 */             if (!nearbyMap.contains(cur))
/* 419 */               nearbyMap.addLast(cur);
/*     */           }
/*     */         } } }
/* 422 */     return nearbyMap;
/*     */   }
/*     */   
/*     */   public static Player getClosest(Location loc, Collection<Player> ignore)
/*     */   {
/* 427 */     Player best = null;
/* 428 */     double bestDist = 0.0D;
/*     */     
/* 430 */     for (Player cur : loc.getWorld().getPlayers())
/*     */     {
/* 432 */       if (!isSpectator(cur))
/*     */       {
/*     */ 
/* 435 */         if (!cur.isDead())
/*     */         {
/*     */ 
/* 438 */           if ((ignore == null) || (!ignore.contains(cur)))
/*     */           {
/*     */ 
/* 441 */             double dist = UtilMath.offset(cur.getLocation(), loc);
/*     */             
/* 443 */             if ((best == null) || (dist < bestDist))
/*     */             {
/* 445 */               best = cur;
/* 446 */               bestDist = dist;
/*     */             }
/*     */           } } }
/*     */     }
/* 450 */     return best;
/*     */   }
/*     */   
/*     */   public static Player getClosest(Location loc, org.bukkit.entity.Entity ignore)
/*     */   {
/* 455 */     Player best = null;
/* 456 */     double bestDist = 0.0D;
/*     */     
/* 458 */     for (Player cur : loc.getWorld().getPlayers())
/*     */     {
/* 460 */       if (!isSpectator(cur))
/*     */       {
/*     */ 
/* 463 */         if (!cur.isDead())
/*     */         {
/*     */ 
/* 466 */           if ((ignore == null) || (!ignore.equals(cur)))
/*     */           {
/*     */ 
/* 469 */             double dist = UtilMath.offset(cur.getLocation(), loc);
/*     */             
/* 471 */             if ((best == null) || (dist < bestDist))
/*     */             {
/* 473 */               best = cur;
/* 474 */               bestDist = dist;
/*     */             }
/*     */           } } }
/*     */     }
/* 478 */     return best;
/*     */   }
/*     */   
/*     */   public static void kick(Player player, String module, String message)
/*     */   {
/* 483 */     kick(player, module, message, true);
/*     */   }
/*     */   
/*     */   public static void kick(Player player, String module, String message, boolean log)
/*     */   {
/* 488 */     if (player == null) {
/* 489 */       return;
/*     */     }
/* 491 */     String out = ChatColor.RED + module + ChatColor.WHITE + " - " + ChatColor.YELLOW + message;
/* 492 */     player.kickPlayer(out);
/*     */     
/*     */ 
/* 495 */     if (log) {
/* 496 */       System.out.println("Kicked Client [" + player.getName() + "] for [" + module + " - " + message + "]");
/*     */     }
/*     */   }
/*     */   
/*     */   public static HashMap<Player, Double> getInRadius(Location loc, double dR) {
/* 501 */     HashMap<Player, Double> players = new HashMap();
/*     */     
/* 503 */     for (Player cur : loc.getWorld().getPlayers())
/*     */     {
/* 505 */       if (!isSpectator(cur))
/*     */       {
/*     */ 
/* 508 */         double offset = UtilMath.offset(loc, cur.getLocation());
/*     */         
/* 510 */         if (offset < dR)
/* 511 */           players.put(cur, Double.valueOf(1.0D - offset / dR));
/*     */       }
/*     */     }
/* 514 */     return players;
/*     */   }
/*     */   
/*     */   public static HashMap<Player, Double> getPlayersInPyramid(Player player, double angleLimit, double distance)
/*     */   {
/* 519 */     HashMap<Player, Double> players = new HashMap();
/*     */     
/* 521 */     for (Player cur : player.getWorld().getPlayers())
/*     */     {
/* 523 */       if (!isSpectator(cur))
/*     */       {
/*     */ 
/*     */ 
/* 527 */         double offset = Math.min(UtilMath.offset(player.getEyeLocation(), cur.getEyeLocation()), 
/* 528 */           UtilMath.offset(player.getEyeLocation(), cur.getLocation()));
/*     */         
/* 530 */         if ((offset < distance) && (UtilAlg.isTargetInPlayerPyramid(player, cur, angleLimit)))
/* 531 */           players.put(cur, Double.valueOf(1.0D - offset / distance));
/*     */       }
/*     */     }
/* 534 */     return players;
/*     */   }
/*     */   
/*     */   public static void health(Player player, double mod)
/*     */   {
/* 539 */     if (player.isDead()) {
/* 540 */       return;
/*     */     }
/* 542 */     double health = player.getHealth() + mod;
/*     */     
/* 544 */     if (health < 0.0D) {
/* 545 */       health = 0.0D;
/*     */     }
/* 547 */     if (health > player.getMaxHealth()) {
/* 548 */       health = player.getMaxHealth();
/*     */     }
/* 550 */     player.setHealth(health);
/*     */   }
/*     */   
/*     */   public static void hunger(Player player, int mod)
/*     */   {
/* 555 */     if (player.isDead()) {
/* 556 */       return;
/*     */     }
/* 558 */     int hunger = player.getFoodLevel() + mod;
/*     */     
/* 560 */     if (hunger < 0) {
/* 561 */       hunger = 0;
/*     */     }
/* 563 */     if (hunger > 20) {
/* 564 */       hunger = 20;
/*     */     }
/* 566 */     player.setFoodLevel(hunger);
/*     */   }
/*     */   
/*     */   public static boolean isOnline(String name)
/*     */   {
/* 571 */     return searchExact(name) != null;
/*     */   }
/*     */   
/*     */   public static String safeNameLength(String name)
/*     */   {
/* 576 */     if (name.length() > 16) {
/* 577 */       name = name.substring(0, 16);
/*     */     }
/* 579 */     return name;
/*     */   }
/*     */   
/*     */   public static boolean isChargingBow(Player player)
/*     */   {
/* 584 */     if (!UtilGear.isMat(player.getItemInHand(), Material.BOW)) {
/* 585 */       return false;
/*     */     }
/* 587 */     return (((CraftEntity)player).getHandle().getDataWatcher().getByte(0) & 0x10) != 0;
/*     */   }
/*     */   
/*     */   public static boolean is1_8(Player player)
/*     */   {
/* 592 */     return ((CraftPlayer)player).getHandle().playerConnection.networkManager.getVersion() >= 47;
/*     */   }
/*     */   
/*     */   public static void sendPacket(Player player, Packet... packets)
/*     */   {
/* 597 */     PlayerConnection connection = ((CraftPlayer)player).getHandle().playerConnection;
/*     */     Packet[] arrayOfPacket;
/* 599 */     int j = (arrayOfPacket = packets).length; for (int i = 0; i < j; i++) { Packet packet = arrayOfPacket[i];
/*     */       
/* 601 */       connection.sendPacket(packet);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isSpectator(org.bukkit.entity.Entity player)
/*     */   {
/* 607 */     if ((player instanceof Player))
/* 608 */       return ((CraftPlayer)player).getHandle().spectating;
/* 609 */     return false;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilPlayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */