/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class UtilAction
/*    */ {
/*    */   public static void velocity(Entity ent, double str, double yAdd, double yMax, boolean groundBoost)
/*    */   {
/* 14 */     velocity(ent, ent.getLocation().getDirection(), str, false, 0.0D, yAdd, yMax, groundBoost);
/*    */   }
/*    */   
/*    */   public static void velocity(Entity ent, Vector vec, double str, boolean ySet, double yBase, double yAdd, double yMax, boolean groundBoost)
/*    */   {
/* 19 */     if ((Double.isNaN(vec.getX())) || (Double.isNaN(vec.getY())) || (Double.isNaN(vec.getZ())) || (vec.length() == 0.0D)) {
/* 20 */       return;
/*    */     }
/*    */     
/* 23 */     if (ySet) {
/* 24 */       vec.setY(yBase);
/*    */     }
/*    */     
/* 27 */     vec.normalize();
/* 28 */     vec.multiply(str);
/*    */     
/*    */ 
/* 31 */     vec.setY(vec.getY() + yAdd);
/*    */     
/*    */ 
/* 34 */     if (vec.getY() > yMax) {
/* 35 */       vec.setY(yMax);
/*    */     }
/* 37 */     if ((groundBoost) && 
/* 38 */       (UtilEnt.isGrounded(ent))) {
/* 39 */       vec.setY(vec.getY() + 0.2D);
/*    */     }
/*    */     
/* 42 */     ent.setFallDistance(0.0F);
/*    */     
/*    */ 
/*    */ 
/* 46 */     if (((ent instanceof Player)) && (UtilGear.isMat(((Player)ent).getItemInHand(), Material.SUGAR)))
/*    */     {
/* 48 */       Bukkit.broadcastMessage(F.main("Debug", "Velocity Sent: " + vec.length()));
/*    */     }
/*    */     
/* 51 */     ent.setVelocity(vec);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilAction.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */