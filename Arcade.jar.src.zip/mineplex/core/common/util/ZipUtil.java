/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipInputStream;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ 
/*     */ public class ZipUtil
/*     */ {
/*     */   private static void getFileList(List<String> fileList, String sourceFolder, File node)
/*     */   {
/*  20 */     if (node.isFile())
/*     */     {
/*  22 */       fileList.add(generateZipEntry(sourceFolder, node.getAbsoluteFile().toString()));
/*     */     }
/*     */     
/*  25 */     if (node.isDirectory())
/*     */     {
/*  27 */       String[] subNote = node.list();
/*  28 */       String[] arrayOfString1; int j = (arrayOfString1 = subNote).length; for (int i = 0; i < j; i++) { String filename = arrayOfString1[i];
/*     */         
/*  30 */         getFileList(fileList, sourceFolder, new File(node, filename));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static String generateZipEntry(String sourceFolder, String file)
/*     */   {
/*  37 */     System.out.println(sourceFolder + " " + file);
/*  38 */     return file.substring(sourceFolder.length() + 1, file.length());
/*     */   }
/*     */   
/*     */   public static void ZipFolders(String sourceFolder, String zipFilename, List<String> folders, List<String> files)
/*     */   {
/*  43 */     ZipOutputStream zipOutputStream = null;
/*  44 */     FileOutputStream fileOutputStream = null;
/*  45 */     FileInputStream fileInputStream = null;
/*  46 */     BufferedOutputStream bufferedOutputStream = null;
/*     */     
/*  48 */     List<String> fileList = new ArrayList();
/*  49 */     byte[] buffer = new byte['ࠀ'];
/*     */     
/*     */     try
/*     */     {
/*  53 */       fileOutputStream = new FileOutputStream(zipFilename);
/*     */       
/*  55 */       bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
/*  56 */       zipOutputStream = new ZipOutputStream(bufferedOutputStream);
/*     */       
/*     */ 
/*  59 */       for (String file : files)
/*     */       {
/*  61 */         fileList.add(generateZipEntry(sourceFolder, new File(file).getAbsoluteFile().toString()));
/*     */       }
/*     */       
/*  64 */       for (String folder : folders)
/*     */       {
/*  66 */         getFileList(fileList, sourceFolder, new File(folder));
/*     */       }
/*     */       
/*  69 */       for (String file : fileList)
/*     */       {
/*  71 */         ZipEntry entry = new ZipEntry(file);
/*  72 */         zipOutputStream.putNextEntry(entry);
/*     */         
/*  74 */         fileInputStream = new FileInputStream(sourceFolder + File.separator + file);
/*     */         
/*     */         int len;
/*  77 */         while ((len = fileInputStream.read(buffer)) > 0) {
/*     */           int len;
/*  79 */           zipOutputStream.write(buffer, 0, len);
/*     */         }
/*     */         
/*  82 */         fileInputStream.close();
/*     */       }
/*     */       
/*  85 */       zipOutputStream.flush();
/*  86 */       zipOutputStream.close();
/*     */       
/*  88 */       bufferedOutputStream.flush();
/*  89 */       bufferedOutputStream.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  93 */       e.printStackTrace();
/*     */       
/*  95 */       if (fileInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/*  99 */           fileInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 103 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 107 */       if (bufferedOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 111 */           bufferedOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 115 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 119 */       if (zipOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 123 */           zipOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 127 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 131 */       if (fileOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 135 */           fileOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 139 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 143 */       if (bufferedOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 147 */           bufferedOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 151 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void UnzipToDirectory(String zipFilePath, String outputDirectory)
/*     */   {
/* 159 */     FileInputStream fileInputStream = null;
/* 160 */     ZipInputStream zipInputStream = null;
/* 161 */     FileOutputStream fileOutputStream = null;
/* 162 */     BufferedOutputStream bufferedOutputStream = null;
/* 163 */     BufferedInputStream bufferedInputStream = null;
/*     */     
/*     */     try
/*     */     {
/* 167 */       fileInputStream = new FileInputStream(zipFilePath);
/* 168 */       bufferedInputStream = new BufferedInputStream(fileInputStream);
/* 169 */       zipInputStream = new ZipInputStream(bufferedInputStream);
/*     */       
/*     */       ZipEntry entry;
/* 172 */       while ((entry = zipInputStream.getNextEntry()) != null)
/*     */       {
/*     */         ZipEntry entry;
/* 175 */         byte[] buffer = new byte['ࠀ'];
/*     */         
/* 177 */         fileOutputStream = new FileOutputStream(outputDirectory + File.separator + entry.getName());
/* 178 */         bufferedOutputStream = new BufferedOutputStream(fileOutputStream, buffer.length);
/*     */         int size;
/* 180 */         while ((size = zipInputStream.read(buffer, 0, buffer.length)) != -1) {
/*     */           int size;
/* 182 */           bufferedOutputStream.write(buffer, 0, size);
/*     */         }
/*     */         
/* 185 */         bufferedOutputStream.flush();
/* 186 */         bufferedOutputStream.close();
/* 187 */         fileOutputStream.flush();
/* 188 */         fileOutputStream.close();
/*     */       }
/*     */       
/* 191 */       zipInputStream.close();
/* 192 */       bufferedInputStream.close();
/* 193 */       fileInputStream.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 197 */       e.printStackTrace();
/*     */       
/* 199 */       if (fileInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 203 */           fileInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 207 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 211 */       if (bufferedInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 215 */           bufferedInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 219 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 223 */       if (zipInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 227 */           zipInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 231 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 235 */       if (fileOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 239 */           fileOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 243 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 247 */       if (bufferedOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 251 */           bufferedOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 255 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\ZipUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */