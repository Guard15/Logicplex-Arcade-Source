/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.MathHelper;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityDestroy;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class UtilTextTop
/*     */ {
/*     */   public static final int EntityDragonId = 777777;
/*     */   public static final int EntityWitherId = 777778;
/*     */   
/*     */   public static void display(String text, Player... players)
/*     */   {
/*  22 */     displayProgress(text, 1.0D, players);
/*     */   }
/*     */   
/*     */   public static void displayProgress(String text, double progress, Player... players) {
/*     */     Player[] arrayOfPlayer;
/*  27 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*  28 */       displayTextBar(player, progress, text);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void displayTextBar(Player player, double healthPercent, String text)
/*     */   {
/*  38 */     deleteOld(player);
/*     */     
/*  40 */     healthPercent = Math.min(1.0D, healthPercent);
/*  41 */     boolean halfHealth = UtilPlayer.is1_8(player);
/*     */     
/*     */ 
/*     */ 
/*  45 */     Location loc = player.getLocation().subtract(0.0D, 200.0D, 0.0D);
/*     */     
/*  47 */     ((CraftPlayer)player).getHandle().playerConnection.sendPacket(getDragonPacket(text, healthPercent, halfHealth, loc));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  52 */     if (UtilPlayer.is1_8(player))
/*     */     {
/*  54 */       Location loc = player.getEyeLocation().add(player.getLocation().getDirection().multiply(24));
/*     */       
/*  56 */       ((CraftPlayer)player).getHandle().playerConnection.sendPacket(getWitherPacket(text, healthPercent, halfHealth, loc));
/*     */     }
/*     */     
/*     */ 
/*  60 */     org.bukkit.Bukkit.getServer().getScheduler().runTaskLater(org.bukkit.Bukkit.getPluginManager().getPlugins()[0], new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  64 */         UtilTextTop.deleteOld(UtilTextTop.this);
/*     */       }
/*  66 */     }, 20L);
/*     */   }
/*     */   
/*     */ 
/*     */   private static void deleteOld(Player player)
/*     */   {
/*  72 */     PacketPlayOutEntityDestroy destroyDragonPacket = new PacketPlayOutEntityDestroy(new int[] { 777777 });
/*  73 */     ((CraftPlayer)player).getHandle().playerConnection.sendPacket(destroyDragonPacket);
/*     */     
/*     */ 
/*  76 */     if (UtilPlayer.is1_8(player))
/*     */     {
/*  78 */       PacketPlayOutEntityDestroy destroyWitherPacket = new PacketPlayOutEntityDestroy(new int[] { 777778 });
/*  79 */       ((CraftPlayer)player).getHandle().playerConnection.sendPacket(destroyWitherPacket);
/*     */     }
/*     */   }
/*     */   
/*     */   public static PacketPlayOutSpawnEntityLiving getDragonPacket(String text, double healthPercent, boolean halfHealth, Location loc)
/*     */   {
/*  85 */     PacketPlayOutSpawnEntityLiving mobPacket = new PacketPlayOutSpawnEntityLiving();
/*     */     
/*  87 */     mobPacket.a = 777777;
/*  88 */     mobPacket.b = ((byte)EntityType.ENDER_DRAGON.getTypeId());
/*  89 */     mobPacket.c = ((int)Math.floor(loc.getBlockX() * 32.0D));
/*  90 */     mobPacket.d = MathHelper.floor(loc.getBlockY() * 32.0D);
/*  91 */     mobPacket.e = ((int)Math.floor(loc.getBlockZ() * 32.0D));
/*  92 */     mobPacket.f = 0;
/*  93 */     mobPacket.g = 0;
/*  94 */     mobPacket.h = 0;
/*  95 */     mobPacket.i = 0;
/*  96 */     mobPacket.j = 0;
/*  97 */     mobPacket.k = 0;
/*     */     
/*     */ 
/* 100 */     double health = healthPercent * 199.9D + 0.1D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 105 */     DataWatcher watcher = getWatcher(text, health, loc.getWorld());
/* 106 */     mobPacket.l = watcher;
/*     */     
/* 108 */     return mobPacket;
/*     */   }
/*     */   
/*     */   public static PacketPlayOutSpawnEntityLiving getWitherPacket(String text, double healthPercent, boolean halfHealth, Location loc)
/*     */   {
/* 113 */     PacketPlayOutSpawnEntityLiving mobPacket = new PacketPlayOutSpawnEntityLiving();
/*     */     
/* 115 */     mobPacket.a = 777778;
/* 116 */     mobPacket.b = ((byte)EntityType.WITHER.getTypeId());
/* 117 */     mobPacket.c = ((int)Math.floor(loc.getBlockX() * 32.0D));
/* 118 */     mobPacket.d = MathHelper.floor(loc.getBlockY() * 32.0D);
/* 119 */     mobPacket.e = ((int)Math.floor(loc.getBlockZ() * 32.0D));
/* 120 */     mobPacket.f = 0;
/* 121 */     mobPacket.g = 0;
/* 122 */     mobPacket.h = 0;
/* 123 */     mobPacket.i = 0;
/* 124 */     mobPacket.j = 0;
/* 125 */     mobPacket.k = 0;
/*     */     
/*     */ 
/* 128 */     double health = healthPercent * 299.9D + 0.1D;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 133 */     DataWatcher watcher = getWatcher(text, health, loc.getWorld());
/* 134 */     mobPacket.l = watcher;
/*     */     
/* 136 */     return mobPacket;
/*     */   }
/*     */   
/*     */   public static DataWatcher getWatcher(String text, double health, org.bukkit.World world)
/*     */   {
/* 141 */     DataWatcher watcher = new DataWatcher(new mineplex.core.common.DummyEntity(((CraftWorld)world).getHandle()));
/*     */     
/* 143 */     watcher.a(0, Byte.valueOf((byte)0));
/* 144 */     watcher.a(6, Float.valueOf((float)health));
/* 145 */     watcher.a(2, text);
/* 146 */     watcher.a(10, text);
/* 147 */     watcher.a(3, Byte.valueOf((byte)0));
/* 148 */     watcher.a(11, Byte.valueOf((byte)0));
/* 149 */     watcher.a(16, Integer.valueOf((int)health));
/* 150 */     watcher.a(20, Integer.valueOf(881));
/*     */     
/* 152 */     int i1 = watcher.getInt(0);
/* 153 */     watcher.watch(0, Byte.valueOf((byte)(i1 | 0x20)));
/*     */     
/* 155 */     return watcher;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilTextTop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */