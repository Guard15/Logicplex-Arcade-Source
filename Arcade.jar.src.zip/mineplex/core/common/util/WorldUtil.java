/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import net.minecraft.server.v1_7_R4.ConvertProgressUpdater;
/*     */ import net.minecraft.server.v1_7_R4.Convertable;
/*     */ import net.minecraft.server.v1_7_R4.EntityTracker;
/*     */ import net.minecraft.server.v1_7_R4.EnumGamemode;
/*     */ import net.minecraft.server.v1_7_R4.MinecraftServer;
/*     */ import net.minecraft.server.v1_7_R4.ServerNBTManager;
/*     */ import net.minecraft.server.v1_7_R4.WorldManager;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.WorldCreator;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftServer;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.scoreboard.CraftScoreboard;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.scoreboard.CraftScoreboardManager;
/*     */ import org.bukkit.event.world.WorldInitEvent;
/*     */ import org.bukkit.event.world.WorldLoadEvent;
/*     */ import org.bukkit.generator.ChunkGenerator;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ public class WorldUtil
/*     */ {
/*     */   public static World LoadWorld(WorldCreator creator)
/*     */   {
/*  30 */     CraftServer server = (CraftServer)org.bukkit.Bukkit.getServer();
/*  31 */     if (creator == null)
/*     */     {
/*  33 */       throw new IllegalArgumentException("Creator may not be null");
/*     */     }
/*     */     
/*  36 */     String name = creator.name();
/*  37 */     System.out.println("Loading world '" + name + "'");
/*  38 */     ChunkGenerator generator = creator.generator();
/*  39 */     File folder = new File(server.getWorldContainer(), name);
/*  40 */     World world = server.getWorld(name);
/*  41 */     net.minecraft.server.v1_7_R4.WorldType type = net.minecraft.server.v1_7_R4.WorldType.getType(creator.type().getName());
/*  42 */     boolean generateStructures = creator.generateStructures();
/*     */     
/*  44 */     if (world != null)
/*     */     {
/*  46 */       return world;
/*     */     }
/*     */     
/*  49 */     if ((folder.exists()) && (!folder.isDirectory()))
/*     */     {
/*  51 */       throw new IllegalArgumentException("File exists with the name '" + name + "' and isn't a folder");
/*     */     }
/*     */     
/*  54 */     if (generator == null)
/*     */     {
/*  56 */       generator = server.getGenerator(name);
/*     */     }
/*     */     
/*  59 */     Convertable converter = new net.minecraft.server.v1_7_R4.WorldLoaderServer(server.getWorldContainer());
/*  60 */     if (converter.isConvertable(name))
/*     */     {
/*  62 */       server.getLogger().info("Converting world '" + name + "'");
/*  63 */       converter.convert(name, new ConvertProgressUpdater(server.getServer()));
/*     */     }
/*     */     
/*  66 */     int dimension = server.getWorlds().size() + 1;
/*  67 */     boolean used = false;
/*     */     do
/*     */     {
/*  70 */       for (WorldServer worldServer : server.getServer().worlds)
/*     */       {
/*  72 */         used = worldServer.dimension == dimension;
/*  73 */         if (used)
/*     */         {
/*  75 */           dimension++;
/*  76 */           break;
/*     */         }
/*     */       }
/*  79 */     } while (used);
/*  80 */     boolean hardcore = false;
/*     */     
/*  82 */     System.out.println("Loaded world with dimension : " + dimension);
/*     */     
/*  84 */     WorldServer internal = new WorldServer(server.getServer(), new ServerNBTManager(server.getWorldContainer(), name, true), name, dimension, new net.minecraft.server.v1_7_R4.WorldSettings(creator.seed(), EnumGamemode.getById(server.getDefaultGameMode().getValue()), generateStructures, hardcore, type), server.getServer().methodProfiler, creator.environment(), generator);
/*     */     
/*  86 */     boolean containsWorld = false;
/*  87 */     for (World otherWorld : server.getWorlds())
/*     */     {
/*  89 */       if (otherWorld.getName().equalsIgnoreCase(name.toLowerCase()))
/*     */       {
/*  91 */         containsWorld = true;
/*  92 */         break;
/*     */       }
/*     */     }
/*     */     
/*  96 */     if (!containsWorld) {
/*  97 */       return null;
/*     */     }
/*  99 */     System.out.println("Created world with dimension : " + dimension);
/*     */     
/* 101 */     internal.scoreboard = server.getScoreboardManager().getMainScoreboard().getHandle();
/* 102 */     internal.worldMaps = ((WorldServer)server.getServer().worlds.get(0)).worldMaps;
/* 103 */     internal.tracker = new EntityTracker(internal);
/* 104 */     internal.addIWorldAccess(new WorldManager(server.getServer(), internal));
/* 105 */     internal.difficulty = net.minecraft.server.v1_7_R4.EnumDifficulty.HARD;
/* 106 */     internal.setSpawnFlags(true, true);
/* 107 */     internal.savingDisabled = true;
/* 108 */     server.getServer().worlds.add(internal);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 117 */     if (generator != null)
/*     */     {
/* 119 */       internal.getWorld().getPopulators().addAll(generator.getDefaultPopulators(internal.getWorld()));
/*     */     }
/*     */     
/* 122 */     server.getPluginManager().callEvent(new WorldInitEvent(internal.getWorld()));
/* 123 */     server.getPluginManager().callEvent(new WorldLoadEvent(internal.getWorld()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     return internal.getWorld();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\WorldUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */