/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ public class C
/*    */ {
/*  7 */   public static String Scramble = "§k";
/*  8 */   public static String Bold = "§l";
/*  9 */   public static String Strike = "§m";
/* 10 */   public static String BoldStrike = "§l§m";
/* 11 */   public static String Line = "§n";
/* 12 */   public static String Italics = "§o";
/*    */   
/* 14 */   public static String cAqua = ChatColor.AQUA;
/* 15 */   public static String cBlack = ChatColor.BLACK;
/* 16 */   public static String cBlue = ChatColor.BLUE;
/* 17 */   public static String cDAqua = ChatColor.DARK_AQUA;
/* 18 */   public static String cDBlue = ChatColor.DARK_BLUE;
/* 19 */   public static String cDGray = ChatColor.DARK_GRAY;
/* 20 */   public static String cDGreen = ChatColor.DARK_GREEN;
/* 21 */   public static String cDPurple = ChatColor.DARK_PURPLE;
/* 22 */   public static String cDRed = ChatColor.DARK_RED;
/* 23 */   public static String cGold = ChatColor.GOLD;
/* 24 */   public static String cGray = ChatColor.GRAY;
/* 25 */   public static String cGreen = ChatColor.GREEN;
/* 26 */   public static String cPurple = ChatColor.LIGHT_PURPLE;
/* 27 */   public static String cRed = ChatColor.RED;
/* 28 */   public static String cWhite = ChatColor.WHITE;
/* 29 */   public static String cYellow = ChatColor.YELLOW;
/*    */   
/* 31 */   public static String mHead = ChatColor.BLUE;
/* 32 */   public static String mBody = ChatColor.GRAY;
/* 33 */   public static String mChat = ChatColor.WHITE;
/* 34 */   public static String mElem = ChatColor.YELLOW;
/* 35 */   public static String mCount = ChatColor.YELLOW;
/* 36 */   public static String mTime = ChatColor.GREEN;
/* 37 */   public static String mItem = ChatColor.YELLOW;
/* 38 */   public static String mSkill = ChatColor.GREEN;
/* 39 */   public static String mLink = ChatColor.GREEN;
/* 40 */   public static String mLoot = ChatColor.RED;
/* 41 */   public static String mGame = ChatColor.LIGHT_PURPLE;
/*    */   
/* 43 */   public static String wField = ChatColor.WHITE;
/* 44 */   public static String wFrame = ChatColor.DARK_GRAY;
/*    */   
/* 46 */   public static String descHead = ChatColor.DARK_GREEN;
/* 47 */   public static String descBody = ChatColor.WHITE;
/*    */   
/* 49 */   public static String chatPMHead = ChatColor.DARK_GREEN;
/* 50 */   public static String chatPMBody = ChatColor.GREEN;
/*    */   
/* 52 */   public static String chatClanHead = ChatColor.DARK_AQUA;
/* 53 */   public static String chatClanBody = ChatColor.AQUA;
/*    */   
/* 55 */   public static String chatAdminHead = ChatColor.DARK_PURPLE;
/* 56 */   public static String chatAdminBody = ChatColor.LIGHT_PURPLE;
/*    */   
/* 58 */   public static String listTitle = ChatColor.WHITE;
/* 59 */   public static String listValue = ChatColor.YELLOW;
/* 60 */   public static String listValueOn = ChatColor.GREEN;
/* 61 */   public static String listValueOff = ChatColor.RED;
/*    */   
/* 63 */   public static String consoleHead = ChatColor.RED;
/* 64 */   public static String consoleFill = ChatColor.WHITE;
/* 65 */   public static String consoleBody = ChatColor.YELLOW;
/*    */   
/* 67 */   public static String sysHead = ChatColor.DARK_GRAY;
/* 68 */   public static String sysBody = ChatColor.GRAY;
/*    */   
/* 70 */   public static String chat = ChatColor.WHITE;
/*    */   
/* 72 */   public static String xBorderlands = ChatColor.GOLD;
/* 73 */   public static String xWilderness = ChatColor.YELLOW;
/* 74 */   public static String xMid = ChatColor.WHITE;
/* 75 */   public static String xNone = ChatColor.GRAY;
/*    */   
/* 77 */   public static ChatColor xAdmin = ChatColor.WHITE;
/* 78 */   public static ChatColor xSafe = ChatColor.AQUA;
/*    */   
/* 80 */   public static ChatColor xSelf = ChatColor.AQUA;
/* 81 */   public static ChatColor xAlly = ChatColor.GREEN;
/* 82 */   public static ChatColor xEnemy = ChatColor.YELLOW;
/* 83 */   public static ChatColor xWar = ChatColor.RED;
/* 84 */   public static ChatColor xPillage = ChatColor.LIGHT_PURPLE;
/*    */   
/* 86 */   public static ChatColor xdSelf = ChatColor.DARK_AQUA;
/* 87 */   public static ChatColor xdAlly = ChatColor.DARK_GREEN;
/* 88 */   public static ChatColor xdEnemy = ChatColor.GOLD;
/* 89 */   public static ChatColor xdWar = ChatColor.DARK_RED;
/* 90 */   public static ChatColor xdPillage = ChatColor.DARK_PURPLE;
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\C.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */