/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Random;
/*     */ import net.minecraft.server.v1_7_R4.Blocks;
/*     */ import net.minecraft.server.v1_7_R4.MathHelper;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ 
/*     */ public class UtilBlock
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*     */     Material[] arrayOfMaterial;
/*  24 */     int j = (arrayOfMaterial = Material.values()).length; for (int i = 0; i < j; i++) { Material m = arrayOfMaterial[i];
/*     */       
/*  26 */       boolean thisSolid = fullSolid(m.getId());
/*  27 */       boolean solid = m.isSolid();
/*  28 */       if (thisSolid != solid) {
/*  29 */         StringBuilder sb = new StringBuilder();
/*  30 */         sb.append("Failed: ");
/*  31 */         sb.append(m.name());
/*  32 */         int amount = 40 - sb.length();
/*  33 */         for (int i = 0; i < amount; i++) {
/*  34 */           sb.append(" ");
/*     */         }
/*  36 */         sb.append(thisSolid);
/*  37 */         System.out.println(sb);
/*     */       }
/*     */     }
/*     */     
/*  41 */     System.out.println("done!");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */   public static HashSet<Byte> blockUseSet = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*  53 */   public static HashSet<Byte> fullSolid = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*  57 */   public static HashSet<Byte> blockPassSet = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*  61 */   public static HashSet<Byte> blockAirFoliageSet = new HashSet();
/*     */   
/*     */   static {
/*  64 */     blockAirFoliageSet.add(Byte.valueOf((byte)0));
/*  65 */     blockAirFoliageSet.add(Byte.valueOf((byte)6));
/*  66 */     blockAirFoliageSet.add(Byte.valueOf((byte)31));
/*  67 */     blockAirFoliageSet.add(Byte.valueOf((byte)32));
/*  68 */     blockAirFoliageSet.add(Byte.valueOf((byte)37));
/*  69 */     blockAirFoliageSet.add(Byte.valueOf((byte)38));
/*  70 */     blockAirFoliageSet.add(Byte.valueOf((byte)39));
/*  71 */     blockAirFoliageSet.add(Byte.valueOf((byte)40));
/*  72 */     blockAirFoliageSet.add(Byte.valueOf((byte)51));
/*  73 */     blockAirFoliageSet.add(Byte.valueOf((byte)59));
/*  74 */     blockAirFoliageSet.add(Byte.valueOf((byte)104));
/*  75 */     blockAirFoliageSet.add(Byte.valueOf((byte)105));
/*  76 */     blockAirFoliageSet.add(Byte.valueOf((byte)115));
/*  77 */     blockAirFoliageSet.add(Byte.valueOf((byte)-115));
/*  78 */     blockAirFoliageSet.add(Byte.valueOf((byte)-114));
/*     */     
/*     */ 
/*  81 */     blockPassSet.add(Byte.valueOf((byte)0));
/*  82 */     blockPassSet.add(Byte.valueOf((byte)6));
/*  83 */     blockPassSet.add(Byte.valueOf((byte)8));
/*  84 */     blockPassSet.add(Byte.valueOf((byte)9));
/*  85 */     blockPassSet.add(Byte.valueOf((byte)10));
/*  86 */     blockPassSet.add(Byte.valueOf((byte)11));
/*  87 */     blockPassSet.add(Byte.valueOf((byte)26));
/*  88 */     blockPassSet.add(Byte.valueOf((byte)27));
/*  89 */     blockPassSet.add(Byte.valueOf((byte)28));
/*  90 */     blockPassSet.add(Byte.valueOf((byte)30));
/*  91 */     blockPassSet.add(Byte.valueOf((byte)31));
/*  92 */     blockPassSet.add(Byte.valueOf((byte)32));
/*  93 */     blockPassSet.add(Byte.valueOf((byte)37));
/*  94 */     blockPassSet.add(Byte.valueOf((byte)38));
/*  95 */     blockPassSet.add(Byte.valueOf((byte)39));
/*  96 */     blockPassSet.add(Byte.valueOf((byte)40));
/*  97 */     blockPassSet.add(Byte.valueOf((byte)50));
/*  98 */     blockPassSet.add(Byte.valueOf((byte)51));
/*  99 */     blockPassSet.add(Byte.valueOf((byte)55));
/* 100 */     blockPassSet.add(Byte.valueOf((byte)59));
/* 101 */     blockPassSet.add(Byte.valueOf((byte)63));
/* 102 */     blockPassSet.add(Byte.valueOf((byte)64));
/* 103 */     blockPassSet.add(Byte.valueOf((byte)65));
/* 104 */     blockPassSet.add(Byte.valueOf((byte)66));
/* 105 */     blockPassSet.add(Byte.valueOf((byte)68));
/* 106 */     blockPassSet.add(Byte.valueOf((byte)69));
/* 107 */     blockPassSet.add(Byte.valueOf((byte)70));
/* 108 */     blockPassSet.add(Byte.valueOf((byte)71));
/* 109 */     blockPassSet.add(Byte.valueOf((byte)72));
/* 110 */     blockPassSet.add(Byte.valueOf((byte)75));
/* 111 */     blockPassSet.add(Byte.valueOf((byte)76));
/* 112 */     blockPassSet.add(Byte.valueOf((byte)77));
/* 113 */     blockPassSet.add(Byte.valueOf((byte)78));
/* 114 */     blockPassSet.add(Byte.valueOf((byte)83));
/* 115 */     blockPassSet.add(Byte.valueOf((byte)90));
/* 116 */     blockPassSet.add(Byte.valueOf((byte)92));
/* 117 */     blockPassSet.add(Byte.valueOf((byte)93));
/* 118 */     blockPassSet.add(Byte.valueOf((byte)94));
/* 119 */     blockPassSet.add(Byte.valueOf((byte)96));
/* 120 */     blockPassSet.add(Byte.valueOf((byte)101));
/* 121 */     blockPassSet.add(Byte.valueOf((byte)102));
/* 122 */     blockPassSet.add(Byte.valueOf((byte)104));
/* 123 */     blockPassSet.add(Byte.valueOf((byte)105));
/* 124 */     blockPassSet.add(Byte.valueOf((byte)106));
/* 125 */     blockPassSet.add(Byte.valueOf((byte)107));
/* 126 */     blockPassSet.add(Byte.valueOf((byte)111));
/* 127 */     blockPassSet.add(Byte.valueOf((byte)115));
/* 128 */     blockPassSet.add(Byte.valueOf((byte)116));
/* 129 */     blockPassSet.add(Byte.valueOf((byte)117));
/* 130 */     blockPassSet.add(Byte.valueOf((byte)118));
/* 131 */     blockPassSet.add(Byte.valueOf((byte)119));
/* 132 */     blockPassSet.add(Byte.valueOf((byte)120));
/* 133 */     blockPassSet.add(Byte.valueOf((byte)-85));
/*     */     
/* 135 */     fullSolid.add(Byte.valueOf((byte)1));
/* 136 */     fullSolid.add(Byte.valueOf((byte)2));
/* 137 */     fullSolid.add(Byte.valueOf((byte)3));
/* 138 */     fullSolid.add(Byte.valueOf((byte)4));
/* 139 */     fullSolid.add(Byte.valueOf((byte)5));
/* 140 */     fullSolid.add(Byte.valueOf((byte)7));
/* 141 */     fullSolid.add(Byte.valueOf((byte)12));
/* 142 */     fullSolid.add(Byte.valueOf((byte)13));
/* 143 */     fullSolid.add(Byte.valueOf((byte)14));
/* 144 */     fullSolid.add(Byte.valueOf((byte)15));
/* 145 */     fullSolid.add(Byte.valueOf((byte)16));
/* 146 */     fullSolid.add(Byte.valueOf((byte)17));
/* 147 */     fullSolid.add(Byte.valueOf((byte)19));
/* 148 */     fullSolid.add(Byte.valueOf((byte)20));
/* 149 */     fullSolid.add(Byte.valueOf((byte)21));
/* 150 */     fullSolid.add(Byte.valueOf((byte)22));
/* 151 */     fullSolid.add(Byte.valueOf((byte)23));
/* 152 */     fullSolid.add(Byte.valueOf((byte)24));
/* 153 */     fullSolid.add(Byte.valueOf((byte)25));
/* 154 */     fullSolid.add(Byte.valueOf((byte)29));
/* 155 */     fullSolid.add(Byte.valueOf((byte)33));
/* 156 */     fullSolid.add(Byte.valueOf((byte)35));
/* 157 */     fullSolid.add(Byte.valueOf((byte)41));
/* 158 */     fullSolid.add(Byte.valueOf((byte)42));
/* 159 */     fullSolid.add(Byte.valueOf((byte)43));
/* 160 */     fullSolid.add(Byte.valueOf((byte)44));
/* 161 */     fullSolid.add(Byte.valueOf((byte)45));
/* 162 */     fullSolid.add(Byte.valueOf((byte)46));
/* 163 */     fullSolid.add(Byte.valueOf((byte)47));
/* 164 */     fullSolid.add(Byte.valueOf((byte)48));
/* 165 */     fullSolid.add(Byte.valueOf((byte)49));
/* 166 */     fullSolid.add(Byte.valueOf((byte)56));
/* 167 */     fullSolid.add(Byte.valueOf((byte)57));
/* 168 */     fullSolid.add(Byte.valueOf((byte)58));
/* 169 */     fullSolid.add(Byte.valueOf((byte)60));
/* 170 */     fullSolid.add(Byte.valueOf((byte)61));
/* 171 */     fullSolid.add(Byte.valueOf((byte)62));
/* 172 */     fullSolid.add(Byte.valueOf((byte)73));
/* 173 */     fullSolid.add(Byte.valueOf((byte)74));
/* 174 */     fullSolid.add(Byte.valueOf((byte)79));
/* 175 */     fullSolid.add(Byte.valueOf((byte)80));
/* 176 */     fullSolid.add(Byte.valueOf((byte)82));
/* 177 */     fullSolid.add(Byte.valueOf((byte)84));
/* 178 */     fullSolid.add(Byte.valueOf((byte)86));
/* 179 */     fullSolid.add(Byte.valueOf((byte)87));
/* 180 */     fullSolid.add(Byte.valueOf((byte)88));
/* 181 */     fullSolid.add(Byte.valueOf((byte)89));
/* 182 */     fullSolid.add(Byte.valueOf((byte)91));
/* 183 */     fullSolid.add(Byte.valueOf((byte)95));
/* 184 */     fullSolid.add(Byte.valueOf((byte)97));
/* 185 */     fullSolid.add(Byte.valueOf((byte)98));
/* 186 */     fullSolid.add(Byte.valueOf((byte)99));
/* 187 */     fullSolid.add(Byte.valueOf((byte)100));
/* 188 */     fullSolid.add(Byte.valueOf((byte)103));
/* 189 */     fullSolid.add(Byte.valueOf((byte)110));
/* 190 */     fullSolid.add(Byte.valueOf((byte)112));
/* 191 */     fullSolid.add(Byte.valueOf((byte)121));
/* 192 */     fullSolid.add(Byte.valueOf((byte)123));
/* 193 */     fullSolid.add(Byte.valueOf((byte)124));
/* 194 */     fullSolid.add(Byte.valueOf((byte)125));
/* 195 */     fullSolid.add(Byte.valueOf((byte)126));
/* 196 */     fullSolid.add(Byte.valueOf((byte)-127));
/* 197 */     fullSolid.add(Byte.valueOf((byte)-123));
/* 198 */     fullSolid.add(Byte.valueOf((byte)-119));
/* 199 */     fullSolid.add(Byte.valueOf((byte)-118));
/* 200 */     fullSolid.add(Byte.valueOf((byte)-104));
/* 201 */     fullSolid.add(Byte.valueOf((byte)-103));
/* 202 */     fullSolid.add(Byte.valueOf((byte)-101));
/* 203 */     fullSolid.add(Byte.valueOf((byte)-98));
/*     */     
/* 205 */     blockUseSet.add(Byte.valueOf((byte)23));
/* 206 */     blockUseSet.add(Byte.valueOf((byte)26));
/* 207 */     blockUseSet.add(Byte.valueOf((byte)33));
/* 208 */     blockUseSet.add(Byte.valueOf((byte)47));
/* 209 */     blockUseSet.add(Byte.valueOf((byte)54));
/* 210 */     blockUseSet.add(Byte.valueOf((byte)58));
/* 211 */     blockUseSet.add(Byte.valueOf((byte)61));
/* 212 */     blockUseSet.add(Byte.valueOf((byte)62));
/* 213 */     blockUseSet.add(Byte.valueOf((byte)64));
/* 214 */     blockUseSet.add(Byte.valueOf((byte)69));
/* 215 */     blockUseSet.add(Byte.valueOf((byte)71));
/* 216 */     blockUseSet.add(Byte.valueOf((byte)77));
/* 217 */     blockUseSet.add(Byte.valueOf((byte)85));
/* 218 */     blockUseSet.add(Byte.valueOf((byte)93));
/* 219 */     blockUseSet.add(Byte.valueOf((byte)94));
/* 220 */     blockUseSet.add(Byte.valueOf((byte)96));
/* 221 */     blockUseSet.add(Byte.valueOf((byte)107));
/* 222 */     blockUseSet.add(Byte.valueOf((byte)113));
/* 223 */     blockUseSet.add(Byte.valueOf((byte)116));
/* 224 */     blockUseSet.add(Byte.valueOf((byte)117));
/* 225 */     blockUseSet.add(Byte.valueOf((byte)-126));
/* 226 */     blockUseSet.add(Byte.valueOf((byte)-111));
/* 227 */     blockUseSet.add(Byte.valueOf((byte)-110));
/* 228 */     blockUseSet.add(Byte.valueOf((byte)-102));
/* 229 */     blockUseSet.add(Byte.valueOf((byte)-98));
/*     */     
/* 231 */     blockUseSet.add(Byte.valueOf((byte)-72));
/* 232 */     blockUseSet.add(Byte.valueOf((byte)-71));
/* 233 */     blockUseSet.add(Byte.valueOf((byte)-70));
/* 234 */     blockUseSet.add(Byte.valueOf((byte)-69));
/* 235 */     blockUseSet.add(Byte.valueOf((byte)-68));
/* 236 */     blockUseSet.add(Byte.valueOf((byte)-67));
/* 237 */     blockUseSet.add(Byte.valueOf((byte)-66));
/* 238 */     blockUseSet.add(Byte.valueOf((byte)-65));
/* 239 */     blockUseSet.add(Byte.valueOf((byte)-64));
/*     */     
/* 241 */     blockUseSet.add(Byte.valueOf((byte)-63));
/* 242 */     blockUseSet.add(Byte.valueOf((byte)-62));
/* 243 */     blockUseSet.add(Byte.valueOf((byte)-61));
/* 244 */     blockUseSet.add(Byte.valueOf((byte)-60));
/* 245 */     blockUseSet.add(Byte.valueOf((byte)-59));
/*     */   }
/*     */   
/*     */   public static boolean solid(org.bukkit.block.Block block)
/*     */   {
/* 250 */     if (block == null) return false;
/* 251 */     return solid(block.getTypeId());
/*     */   }
/*     */   
/*     */   public static boolean solid(int block) {
/* 255 */     return solid((byte)block);
/*     */   }
/*     */   
/*     */   public static boolean solid(byte block) {
/* 259 */     return !blockPassSet.contains(Byte.valueOf(block));
/*     */   }
/*     */   
/*     */   public static boolean airFoliage(org.bukkit.block.Block block)
/*     */   {
/* 264 */     if (block == null) return false;
/* 265 */     return airFoliage(block.getTypeId());
/*     */   }
/*     */   
/*     */   public static boolean airFoliage(int block) {
/* 269 */     return airFoliage((byte)block);
/*     */   }
/*     */   
/*     */   public static boolean airFoliage(byte block) {
/* 273 */     return blockAirFoliageSet.contains(Byte.valueOf(block));
/*     */   }
/*     */   
/*     */   public static boolean fullSolid(org.bukkit.block.Block block)
/*     */   {
/* 278 */     if (block == null) {
/* 279 */       return false;
/*     */     }
/* 281 */     return fullSolid(block.getTypeId());
/*     */   }
/*     */   
/*     */   public static boolean fullSolid(int block) {
/* 285 */     return fullSolid((byte)block);
/*     */   }
/*     */   
/*     */   public static boolean fullSolid(byte block) {
/* 289 */     return fullSolid.contains(Byte.valueOf(block));
/*     */   }
/*     */   
/*     */   public static boolean usable(org.bukkit.block.Block block)
/*     */   {
/* 294 */     if (block == null) {
/* 295 */       return false;
/*     */     }
/* 297 */     return usable(block.getTypeId());
/*     */   }
/*     */   
/*     */   public static boolean usable(int block) {
/* 301 */     return usable((byte)block);
/*     */   }
/*     */   
/*     */   public static boolean usable(byte block) {
/* 305 */     return blockUseSet.contains(Byte.valueOf(block));
/*     */   }
/*     */   
/*     */   public static HashMap<org.bukkit.block.Block, Double> getInRadius(Location loc, double dR)
/*     */   {
/* 310 */     return getInRadius(loc, dR, 9999.0D);
/*     */   }
/*     */   
/*     */   public static HashMap<org.bukkit.block.Block, Double> getInRadius(Location loc, double dR, double maxHeight)
/*     */   {
/* 315 */     HashMap<org.bukkit.block.Block, Double> blockList = new HashMap();
/* 316 */     int iR = (int)dR + 1;
/*     */     
/* 318 */     for (int x = -iR; x <= iR; x++) {
/* 319 */       for (int z = -iR; z <= iR; z++)
/* 320 */         for (int y = -iR; y <= iR; y++)
/*     */         {
/* 322 */           if (Math.abs(y) <= maxHeight)
/*     */           {
/*     */ 
/* 325 */             org.bukkit.block.Block curBlock = loc.getWorld().getBlockAt((int)(loc.getX() + x), (int)(loc.getY() + y), (int)(loc.getZ() + z));
/*     */             
/* 327 */             double offset = UtilMath.offset(loc, curBlock.getLocation().add(0.5D, 0.5D, 0.5D));
/*     */             
/* 329 */             if (offset <= dR)
/* 330 */               blockList.put(curBlock, Double.valueOf(1.0D - offset / dR));
/*     */           } }
/*     */     }
/* 333 */     return blockList;
/*     */   }
/*     */   
/*     */ 
/*     */   public static HashMap<org.bukkit.block.Block, Double> getInRadius(org.bukkit.block.Block block, double dR)
/*     */   {
/* 339 */     return getInRadius(block, dR, false);
/*     */   }
/*     */   
/*     */   public static HashMap<org.bukkit.block.Block, Double> getInRadius(org.bukkit.block.Block block, double dR, boolean hollow)
/*     */   {
/* 344 */     HashMap<org.bukkit.block.Block, Double> blockList = new HashMap();
/* 345 */     int iR = (int)dR + 1;
/*     */     
/* 347 */     for (int x = -iR; x <= iR; x++) {
/* 348 */       for (int z = -iR; z <= iR; z++) {
/* 349 */         for (int y = -iR; y <= iR; y++)
/*     */         {
/* 351 */           org.bukkit.block.Block curBlock = block.getRelative(x, y, z);
/*     */           
/* 353 */           double offset = UtilMath.offset(block.getLocation(), curBlock.getLocation());
/*     */           
/* 355 */           if ((offset <= dR) && ((!hollow) || (offset >= dR - 1.0D)))
/*     */           {
/* 357 */             blockList.put(curBlock, Double.valueOf(1.0D - offset / dR)); }
/*     */         }
/*     */       }
/*     */     }
/* 361 */     return blockList;
/*     */   }
/*     */   
/*     */   public static ArrayList<org.bukkit.block.Block> getInSquare(org.bukkit.block.Block block, double dR)
/*     */   {
/* 366 */     ArrayList<org.bukkit.block.Block> blockList = new ArrayList();
/* 367 */     int iR = (int)dR + 1;
/*     */     
/* 369 */     for (int x = -iR; x <= iR; x++) {
/* 370 */       for (int z = -iR; z <= iR; z++) {
/* 371 */         for (int y = -iR; y <= iR; y++)
/*     */         {
/* 373 */           blockList.add(block.getRelative(x, y, z)); }
/*     */       }
/*     */     }
/* 376 */     return blockList;
/*     */   }
/*     */   
/*     */   public static boolean isBlock(ItemStack item)
/*     */   {
/* 381 */     if (item == null) {
/* 382 */       return false;
/*     */     }
/* 384 */     return (item.getTypeId() > 0) && (item.getTypeId() < 256);
/*     */   }
/*     */   
/*     */   public static org.bukkit.block.Block getHighest(World world, int x, int z)
/*     */   {
/* 389 */     return getHighest(world, x, z, null);
/*     */   }
/*     */   
/*     */   public static org.bukkit.block.Block getHighest(World world, int x, int z, HashSet<Material> ignore)
/*     */   {
/* 394 */     org.bukkit.block.Block block = world.getHighestBlockAt(x, z);
/*     */     
/*     */ 
/* 397 */     while ((block.getY() > 0) && (
/*     */     
/* 399 */       (airFoliage(block)) || 
/* 400 */       (block.getType() == Material.LEAVES) || (
/* 401 */       (ignore != null) && (ignore.contains(block.getType())))))
/*     */     {
/*     */ 
/* 404 */       block = block.getRelative(BlockFace.DOWN);
/*     */     }
/*     */     
/* 407 */     return block.getRelative(BlockFace.UP);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ArrayList<org.bukkit.block.Block> getExplosionBlocks(Location location, float strength, boolean damageBlocksEqually)
/*     */   {
/* 420 */     ArrayList<org.bukkit.block.Block> toExplode = new ArrayList();
/* 421 */     WorldServer world = ((CraftWorld)location.getWorld()).getHandle();
/*     */     
/* 423 */     for (int i = 0; i < 16; i++)
/*     */     {
/* 425 */       for (int j = 0; j < 16; j++)
/*     */       {
/* 427 */         for (int k = 0; k < 16; k++)
/*     */         {
/* 429 */           if ((i == 0) || (i == 15) || (j == 0) || (j == 15) || (k == 0) || (k == 15))
/*     */           {
/* 431 */             double d3 = i / 15.0F * 2.0F - 1.0F;
/* 432 */             double d4 = j / 15.0F * 2.0F - 1.0F;
/* 433 */             double d5 = k / 15.0F * 2.0F - 1.0F;
/* 434 */             double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
/*     */             
/* 436 */             d3 /= d6;
/* 437 */             d4 /= d6;
/* 438 */             d5 /= d6;
/* 439 */             float f1 = strength * (0.7F + UtilMath.random.nextFloat() * 0.6F);
/*     */             
/* 441 */             double d0 = location.getX();
/* 442 */             double d1 = location.getY();
/* 443 */             double d2 = location.getZ();
/*     */             
/* 445 */             for (float f2 = 0.3F; f1 > 0.0F; f1 -= f2 * 0.75F)
/*     */             {
/* 447 */               int l = MathHelper.floor(d0);
/* 448 */               int i1 = MathHelper.floor(d1);
/* 449 */               int j1 = MathHelper.floor(d2);
/* 450 */               org.bukkit.block.Block block = location.getWorld().getBlockAt(l, i1, j1);
/*     */               
/* 452 */               if (block.getType() != Material.AIR)
/*     */               {
/* 454 */                 float f3 = (damageBlocksEqually ? Blocks.DIRT : world.getType(block.getX(), block.getY(), 
/* 455 */                   block.getZ())).a(null);
/*     */                 
/* 457 */                 f1 -= (f3 + 0.3F) * f2;
/*     */               }
/*     */               
/* 460 */               if ((f1 > 0.0F) && (i1 < 256) && (i1 >= 0))
/*     */               {
/* 462 */                 toExplode.add(block);
/*     */               }
/*     */               
/* 465 */               d0 += d3 * f2;
/* 466 */               d1 += d4 * f2;
/* 467 */               d2 += d5 * f2;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 474 */     return toExplode;
/*     */   }
/*     */   
/*     */   public static ArrayList<org.bukkit.block.Block> getSurrounding(org.bukkit.block.Block block, boolean diagonals)
/*     */   {
/* 479 */     ArrayList<org.bukkit.block.Block> blocks = new ArrayList();
/*     */     
/* 481 */     if (diagonals)
/*     */     {
/* 483 */       for (int x = -1; x <= 1; x++) {
/* 484 */         for (int y = -1; y <= 1; y++) {
/* 485 */           for (int z = -1; z <= 1; z++)
/*     */           {
/* 487 */             if ((x != 0) || (y != 0) || (z != 0))
/*     */             {
/*     */ 
/* 490 */               blocks.add(block.getRelative(x, y, z)); }
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 495 */       blocks.add(block.getRelative(BlockFace.UP));
/* 496 */       blocks.add(block.getRelative(BlockFace.DOWN));
/* 497 */       blocks.add(block.getRelative(BlockFace.NORTH));
/* 498 */       blocks.add(block.getRelative(BlockFace.SOUTH));
/* 499 */       blocks.add(block.getRelative(BlockFace.EAST));
/* 500 */       blocks.add(block.getRelative(BlockFace.WEST));
/*     */     }
/*     */     
/* 503 */     return blocks;
/*     */   }
/*     */   
/*     */   public static boolean isVisible(org.bukkit.block.Block block)
/*     */   {
/* 508 */     for (org.bukkit.block.Block other : getSurrounding(block, false))
/*     */     {
/* 510 */       if (!other.getType().isOccluding())
/*     */       {
/* 512 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 516 */     return false;
/*     */   }
/*     */   
/*     */   public static ArrayList<org.bukkit.block.Block> getInBoundingBox(Location a, Location b) {
/* 520 */     ArrayList<org.bukkit.block.Block> blocks = new ArrayList();
/*     */     
/* 522 */     for (int x = Math.min(a.getBlockX(), b.getBlockX()); x <= Math.max(a.getBlockX(), b.getBlockX()); x++) {
/* 523 */       for (int y = Math.min(a.getBlockY(), b.getBlockY()); y <= Math.max(a.getBlockY(), b.getBlockY()); y++)
/* 524 */         for (int z = Math.min(a.getBlockZ(), b.getBlockZ()); z <= Math.max(a.getBlockZ(), b.getBlockZ()); z++)
/*     */         {
/* 526 */           org.bukkit.block.Block block = a.getWorld().getBlockAt(x, y, z);
/*     */           
/* 528 */           if (block.getType() != Material.AIR)
/* 529 */             blocks.add(block);
/*     */         }
/*     */     }
/* 532 */     return blocks;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilBlock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */