/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map.Entry;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.material.MaterialData;
/*     */ 
/*     */ public class UtilItem
/*     */ {
/*     */   public static LinkedList<Map.Entry<Material, Byte>> matchItem(Player caller, String items, boolean inform)
/*     */   {
/*  15 */     LinkedList<Map.Entry<Material, Byte>> matchList = new LinkedList();
/*     */     
/*  17 */     String failList = "";
/*     */     
/*     */     String[] arrayOfString;
/*  20 */     int j = (arrayOfString = items.split(",")).length; for (int i = 0; i < j; i++) { String cur = arrayOfString[i];
/*     */       
/*  22 */       Map.Entry<Material, Byte> match = searchItem(caller, cur, inform);
/*     */       
/*  24 */       if (match != null) {
/*  25 */         matchList.add(match);
/*     */       }
/*     */       else {
/*  28 */         failList = failList + cur + " ";
/*     */       }
/*     */     }
/*  31 */     if ((inform) && (failList.length() > 0))
/*     */     {
/*  33 */       failList = failList.substring(0, failList.length() - 1);
/*  34 */       UtilPlayer.message(caller, F.main("Item(s) Search", 
/*  35 */         C.mBody + " Invalid [" + 
/*  36 */         C.mElem + failList + 
/*  37 */         C.mBody + "]."));
/*     */     }
/*     */     
/*  40 */     return matchList;
/*     */   }
/*     */   
/*     */   public static Map.Entry<Material, Byte> searchItem(Player caller, String args, boolean inform)
/*     */   {
/*  45 */     LinkedList<Map.Entry<Material, Byte>> matchList = new LinkedList();
/*     */     Material[] arrayOfMaterial;
/*  47 */     int j = (arrayOfMaterial = Material.values()).length; for (int i = 0; i < j; i++) { Material cur = arrayOfMaterial[i];
/*     */       
/*     */ 
/*  50 */       if (cur.toString().equalsIgnoreCase(args)) {
/*  51 */         return new AbstractMap.SimpleEntry(cur, Byte.valueOf((byte)0));
/*     */       }
/*  53 */       if (cur.toString().toLowerCase().contains(args.toLowerCase())) {
/*  54 */         matchList.add(new AbstractMap.SimpleEntry(cur, Byte.valueOf((byte)0)));
/*     */       }
/*     */       
/*  57 */       String[] arg = args.split(":");
/*     */       
/*     */ 
/*  60 */       int id = 0;
/*     */       try
/*     */       {
/*  63 */         if (arg.length > 0) {
/*  64 */           id = Integer.parseInt(arg[0]);
/*     */         }
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */         continue;
/*     */       }
/*  71 */       if (id == cur.getId())
/*     */       {
/*     */ 
/*     */ 
/*  75 */         byte data = 0;
/*     */         try
/*     */         {
/*  78 */           if (arg.length > 1) {
/*  79 */             data = Byte.parseByte(arg[1]);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */           continue;
/*     */         }
/*  86 */         return new AbstractMap.SimpleEntry(cur, Byte.valueOf(data));
/*     */       }
/*     */     }
/*     */     
/*  90 */     if (matchList.size() != 1)
/*     */     {
/*  92 */       if (!inform) {
/*  93 */         return null;
/*     */       }
/*     */       
/*  96 */       UtilPlayer.message(caller, F.main("Item Search", 
/*  97 */         C.mCount + matchList.size() + 
/*  98 */         C.mBody + " matches for [" + 
/*  99 */         C.mElem + args + 
/* 100 */         C.mBody + "]."));
/*     */       
/* 102 */       if (matchList.size() > 0)
/*     */       {
/* 104 */         String matchString = "";
/* 105 */         for (Object cur : matchList)
/* 106 */           matchString = matchString + F.elem(((Material)((Map.Entry)cur).getKey()).toString()) + ", ";
/* 107 */         if (matchString.length() > 1) {
/* 108 */           matchString = matchString.substring(0, matchString.length() - 2);
/*     */         }
/* 110 */         UtilPlayer.message(caller, F.main("Item Search", 
/* 111 */           C.mBody + "Matches [" + 
/* 112 */           C.mElem + matchString + 
/* 113 */           C.mBody + "]."));
/*     */       }
/*     */       
/* 116 */       return null;
/*     */     }
/*     */     
/* 119 */     return (Map.Entry)matchList.get(0);
/*     */   }
/*     */   
/*     */   public static String itemToStr(ItemStack item)
/*     */   {
/* 124 */     String data = "0";
/* 125 */     if (item.getData() != null) {
/* 126 */       data = item.getData().getData();
/*     */     }
/* 128 */     return item.getType() + ":" + item.getAmount() + ":" + item.getDurability() + ":" + data;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */