/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.ChatColor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UtilColor
/*    */ {
/*    */   public static byte chatColorToClayData(ChatColor chatColor)
/*    */   {
/* 14 */     return 1;
/*    */   }
/*    */   
/*    */   public static byte chatColorToWoolData(ChatColor chatColor)
/*    */   {
/* 19 */     switch (chatColor)
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     case AQUA: 
/* 38 */       return 1;
/*    */     case BLACK: 
/* 40 */       return 11;
/*    */     case BLUE: 
/* 42 */       return 13;
/*    */     case BOLD: 
/* 44 */       return 9;
/*    */     case DARK_BLUE: 
/* 46 */       return 10;
/*    */     case DARK_GRAY: 
/* 48 */       return 1;
/*    */     case DARK_GREEN: 
/* 50 */       return 8;
/*    */     case DARK_PURPLE: 
/* 52 */       return 7;
/*    */     case DARK_RED: 
/* 54 */       return 11;
/*    */     case GOLD: 
/* 56 */       return 5;
/*    */     case GRAY: 
/* 58 */       return 3;
/*    */     case GREEN: 
/* 60 */       return 14;
/*    */     case ITALIC: 
/* 62 */       return 2;
/*    */     case LIGHT_PURPLE: 
/* 64 */       return 4; }
/*    */     
/* 66 */     return 0;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilColor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */