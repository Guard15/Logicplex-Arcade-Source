/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UtilShapes
/*     */ {
/*  13 */   private static final BlockFace[] radial = {
/*  14 */     BlockFace.SOUTH, BlockFace.SOUTH_WEST, BlockFace.WEST, BlockFace.NORTH_WEST, BlockFace.NORTH, 
/*  15 */     BlockFace.NORTH_EAST, BlockFace.EAST, BlockFace.SOUTH_EAST };
/*     */   
/*     */ 
/*     */   public static ArrayList<Location> getCircle(Location loc, boolean hollow, double radius)
/*     */   {
/*  20 */     return getCircleBlocks(loc, radius, 0.0D, hollow, false);
/*     */   }
/*     */   
/*     */   public static ArrayList<Location> getSphereBlocks(Location loc, double radius, double height, boolean hollow)
/*     */   {
/*  25 */     return getCircleBlocks(loc, radius, height, hollow, true);
/*     */   }
/*     */   
/*     */   private static ArrayList<Location> getCircleBlocks(Location loc, double radius, double height, boolean hollow, boolean sphere)
/*     */   {
/*  30 */     ArrayList<Location> circleblocks = new ArrayList();
/*  31 */     double cx = loc.getBlockX();
/*  32 */     double cy = loc.getBlockY();
/*  33 */     double cz = loc.getBlockZ();
/*     */     
/*  35 */     for (double y = sphere ? cy - radius : cy; y < (sphere ? cy + radius : cy + height + 1.0D); y += 1.0D)
/*     */     {
/*  37 */       for (double x = cx - radius; x <= cx + radius; x += 1.0D)
/*     */       {
/*  39 */         for (double z = cz - radius; z <= cz + radius; z += 1.0D)
/*     */         {
/*  41 */           double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0.0D);
/*     */           
/*  43 */           if ((dist < radius * radius) && ((!hollow) || (dist >= (radius - 1.0D) * (radius - 1.0D))))
/*     */           {
/*  45 */             Location l = new Location(loc.getWorld(), x, y, z);
/*  46 */             circleblocks.add(l);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  52 */     return circleblocks;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BlockFace[] getCornerBlockFaces(Block b, BlockFace facing)
/*     */   {
/*  62 */     BlockFace left = null;
/*  63 */     BlockFace right = null;
/*  64 */     for (int i = 0; i < radial.length; i++)
/*     */     {
/*  66 */       if (radial[i] == facing)
/*     */       {
/*  68 */         int high = i + 2;
/*  69 */         if (high >= radial.length)
/*  70 */           high -= radial.length;
/*  71 */         int low = i - 2;
/*  72 */         if (low < 0)
/*  73 */           low = radial.length + low;
/*  74 */         left = radial[low];
/*  75 */         right = radial[high];
/*  76 */         return 
/*  77 */           new BlockFace[] {
/*  78 */           left, right };
/*     */       }
/*     */     }
/*     */     
/*  82 */     return null;
/*     */   }
/*     */   
/*     */   public static Block[] getCornerBlocks(Block b, BlockFace facing)
/*     */   {
/*  87 */     BlockFace[] faces = getSideBlockFaces(facing);
/*  88 */     return 
/*  89 */       new Block[] {
/*  90 */       b.getRelative(faces[0]), b.getRelative(faces[1]) };
/*     */   }
/*     */   
/*     */ 
/*     */   public static BlockFace getFacing(float yaw)
/*     */   {
/*  96 */     return radial[(Math.round(yaw / 45.0F) & 0x7)];
/*     */   }
/*     */   
/*     */ 
/*     */   public static ArrayList<Location> getLinesDistancedPoints(Location startingPoint, Location endingPoint, double distanceBetweenParticles)
/*     */   {
/* 102 */     return getLinesLimitedPoints(startingPoint, endingPoint, 
/* 103 */       (int)Math.ceil(startingPoint.distance(endingPoint) / distanceBetweenParticles));
/*     */   }
/*     */   
/*     */   public static ArrayList<Location> getLinesLimitedPoints(Location startingPoint, Location endingPoint, int amountOfPoints)
/*     */   {
/* 108 */     startingPoint = startingPoint.clone();
/* 109 */     Vector vector = endingPoint.toVector().subtract(startingPoint.toVector());
/* 110 */     vector.normalize();
/* 111 */     vector.multiply(startingPoint.distance(endingPoint) / (amountOfPoints + 1.0D));
/*     */     
/* 113 */     ArrayList<Location> locs = new ArrayList();
/* 114 */     for (int i = 0; i < amountOfPoints; i++)
/*     */     {
/* 116 */       locs.add(startingPoint.add(vector).clone());
/*     */     }
/* 118 */     return locs;
/*     */   }
/*     */   
/*     */   public static ArrayList<Location> getPointsInCircle(Location center, int pointsAmount, double circleRadius)
/*     */   {
/* 123 */     ArrayList<Location> locs = new ArrayList();
/*     */     
/* 125 */     for (int i = 0; i < pointsAmount; i++)
/*     */     {
/* 127 */       double angle = 6.283185307179586D / pointsAmount * i;
/* 128 */       double x = circleRadius * Math.cos(angle);
/* 129 */       double z = circleRadius * Math.sin(angle);
/* 130 */       Location loc = center.clone().add(x, 0.0D, z);
/* 131 */       locs.add(loc);
/*     */     }
/* 133 */     return locs;
/*     */   }
/*     */   
/*     */   public static ArrayList<Location> getDistancedCircle(Location center, double pointsDistance, double circleRadius)
/*     */   {
/* 138 */     return getPointsInCircle(center, (int)(circleRadius * 3.141592653589793D * 2.0D / pointsDistance), circleRadius);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BlockFace[] getSideBlockFaces(BlockFace facing)
/*     */   {
/* 146 */     return getSideBlockFaces(facing, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static BlockFace[] getSideBlockFaces(BlockFace facing, boolean allowDiagonal)
/*     */   {
/* 153 */     allowDiagonal = (!allowDiagonal) && (facing.getModX() != 0) && (facing.getModZ() != 0);
/*     */     
/* 155 */     int[][] facesXZ = 
/* 156 */       {
/*     */       
/*     */ 
/* 159 */       {
/* 160 */       allowDiagonal ? facing.getModX() : facing.getModZ(), allowDiagonal ? 0 : -facing.getModX() }, 
/*     */       
/*     */ 
/*     */ 
/* 164 */       {
/* 165 */       allowDiagonal ? 0 : -facing.getModZ(), allowDiagonal ? facing.getModZ() : facing.getModX() } };
/*     */     
/*     */ 
/*     */ 
/* 169 */     BlockFace[] faces = new BlockFace[2];
/*     */     
/* 171 */     for (int i = 0; i < 2; i++)
/*     */     {
/* 173 */       int[] f = facesXZ[i];
/*     */       BlockFace[] arrayOfBlockFace1;
/* 175 */       int j = (arrayOfBlockFace1 = BlockFace.values()).length; for (int i = 0; i < j; i++) { BlockFace face = arrayOfBlockFace1[i];
/*     */         
/* 177 */         if (face.getModY() == 0)
/*     */         {
/* 179 */           if ((f[0] == face.getModX()) && (f[1] == face.getModZ()))
/*     */           {
/* 181 */             faces[i] = face;
/* 182 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 188 */     if ((allowDiagonal) && ((facing == BlockFace.NORTH_EAST) || (facing == BlockFace.SOUTH_WEST)))
/*     */     {
/* 190 */       faces = 
/* 191 */         new BlockFace[] {
/* 192 */         faces[1], faces[0] };
/*     */     }
/*     */     
/*     */ 
/* 196 */     return faces;
/*     */   }
/*     */   
/*     */   public static ArrayList<Block> getDiagonalBlocks(Block block, BlockFace facing, int blockWidth)
/*     */   {
/* 201 */     ArrayList<Block> blocks = new ArrayList();
/*     */     
/* 203 */     if ((facing.getModX() == 0) || (facing.getModZ() == 0))
/*     */     {
/* 205 */       return blocks;
/*     */     }
/*     */     
/* 208 */     BlockFace[] faces = getSideBlockFaces(facing);
/*     */     BlockFace[] arrayOfBlockFace1;
/* 210 */     int j = (arrayOfBlockFace1 = faces).length; for (int i = 0; i < j; i++) { BlockFace face = arrayOfBlockFace1[i];
/*     */       
/* 212 */       Location loc = block.getLocation().add(0.5D + facing.getModX() / 2.0D, 0.0D, 0.5D + facing.getModZ() / 2.0D);
/*     */       
/* 214 */       blocks.add(loc.add(face.getModX() / 2.0D, 0.0D, face.getModZ() / 2.0D).getBlock());
/*     */       
/* 216 */       for (int i = 1; i < blockWidth; i++)
/*     */       {
/* 218 */         blocks.add(loc.add(face.getModX(), 0.0D, face.getModZ()).getBlock());
/*     */       }
/*     */     }
/*     */     
/* 222 */     return blocks;
/*     */   }
/*     */   
/*     */   public static Block[] getSideBlocks(Block b, BlockFace facing)
/*     */   {
/* 227 */     BlockFace[] faces = getSideBlockFaces(facing);
/*     */     
/* 229 */     return 
/* 230 */       new Block[] {
/* 231 */       b.getRelative(faces[0]), b.getRelative(faces[1]) };
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilShapes.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */