/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import net.minecraft.server.v1_7_R4.ControllerMove;
/*     */ import net.minecraft.server.v1_7_R4.EntityBat;
/*     */ import net.minecraft.server.v1_7_R4.EntityCreature;
/*     */ import net.minecraft.server.v1_7_R4.EntityEnderDragon;
/*     */ import net.minecraft.server.v1_7_R4.EntityHuman;
/*     */ import net.minecraft.server.v1_7_R4.EntityInsentient;
/*     */ import net.minecraft.server.v1_7_R4.Navigation;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoal;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoalLookAtPlayer;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoalMoveTowardsRestriction;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoalRandomLookaround;
/*     */ import net.minecraft.server.v1_7_R4.PathfinderGoalSelector;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftCreature;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftLivingEntity;
/*     */ import org.bukkit.entity.Creature;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Giant;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ public class UtilEnt
/*     */ {
/*  42 */   private static HashMap<org.bukkit.entity.Entity, String> _nameMap = new HashMap();
/*  43 */   private static HashMap<String, EntityType> creatureMap = new HashMap();
/*     */   
/*     */   private static Field _goalSelector;
/*     */   private static Field _targetSelector;
/*     */   private static Field _bsRestrictionGoal;
/*     */   private static Field _pathfinderBList;
/*     */   private static Field _pathfinderCList;
/*     */   
/*     */   public static HashMap<org.bukkit.entity.Entity, String> GetEntityNames()
/*     */   {
/*  53 */     return _nameMap;
/*     */   }
/*     */   
/*     */   public static void silence(org.bukkit.entity.Entity entity, boolean silence)
/*     */   {
/*  58 */     ((CraftEntity)entity).getHandle().Silent = silence;
/*     */   }
/*     */   
/*     */   public static void ghost(org.bukkit.entity.Entity entity, boolean ghost, boolean invisible)
/*     */   {
/*  63 */     if ((entity instanceof LivingEntity))
/*     */     {
/*  65 */       ((CraftLivingEntity)entity).getHandle().ghost = ghost;
/*     */     }
/*     */     
/*  68 */     ((CraftEntity)entity).getHandle().Invisible = invisible;
/*  69 */     ((CraftEntity)entity).getHandle().setInvisible(invisible);
/*     */   }
/*     */   
/*     */   public static void Leash(LivingEntity leashed, org.bukkit.entity.Entity holder, boolean pull, boolean breakable)
/*     */   {
/*  74 */     if ((((CraftEntity)leashed).getHandle() instanceof EntityInsentient))
/*     */     {
/*  76 */       EntityInsentient creature = (EntityInsentient)((CraftEntity)leashed).getHandle();
/*     */       
/*  78 */       creature.PullWhileLeashed = pull;
/*  79 */       creature.BreakLeash = breakable;
/*     */     }
/*     */     
/*  82 */     leashed.setLeashHolder(holder);
/*     */   }
/*     */   
/*     */   public static void addLookAtPlayerAI(org.bukkit.entity.Entity entity, float dist)
/*     */   {
/*  87 */     if ((((CraftEntity)entity).getHandle() instanceof EntityInsentient))
/*     */     {
/*  89 */       addAI(entity, 7, new PathfinderGoalLookAtPlayer((EntityInsentient)((CraftEntity)entity).getHandle(), EntityHuman.class, dist));
/*  90 */       addAI(entity, 8, new PathfinderGoalRandomLookaround((EntityInsentient)((CraftEntity)entity).getHandle()));
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addAI(org.bukkit.entity.Entity entity, int value, PathfinderGoal ai)
/*     */   {
/*  96 */     if ((((CraftEntity)entity).getHandle() instanceof EntityInsentient))
/*     */     {
/*  98 */       EntityInsentient ei = (EntityInsentient)((CraftEntity)entity).getHandle();
/*     */       
/* 100 */       if (_goalSelector == null)
/*     */       {
/*     */         try
/*     */         {
/* 104 */           _goalSelector = EntityInsentient.class.getDeclaredField("goalSelector");
/*     */         }
/*     */         catch (NoSuchFieldException e)
/*     */         {
/* 108 */           e.printStackTrace();
/* 109 */           return;
/*     */         }
/* 111 */         _goalSelector.setAccessible(true);
/*     */       }
/*     */       
/*     */       try
/*     */       {
/* 116 */         ((PathfinderGoalSelector)_goalSelector.get(ei)).a(value, ai);
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 120 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static void Vegetate(org.bukkit.entity.Entity entity)
/*     */   {
/* 128 */     Vegetate(entity, false);
/*     */   }
/*     */   
/*     */   public static void Vegetate(org.bukkit.entity.Entity entity, boolean mute)
/*     */   {
/*     */     try
/*     */     {
/* 135 */       if (_goalSelector == null)
/*     */       {
/* 137 */         _goalSelector = EntityInsentient.class.getDeclaredField("goalSelector");
/* 138 */         _goalSelector.setAccessible(true);
/*     */       }
/*     */       
/* 141 */       if (_targetSelector == null)
/*     */       {
/* 143 */         _targetSelector = EntityInsentient.class.getDeclaredField("targetSelector");
/* 144 */         _targetSelector.setAccessible(true);
/*     */       }
/*     */       
/* 147 */       if (_pathfinderBList == null)
/*     */       {
/* 149 */         _pathfinderBList = PathfinderGoalSelector.class.getDeclaredField("b");
/* 150 */         _pathfinderBList.setAccessible(true);
/*     */       }
/*     */       
/* 153 */       if (_pathfinderCList == null)
/*     */       {
/* 155 */         _pathfinderCList = PathfinderGoalSelector.class.getDeclaredField("c");
/* 156 */         _pathfinderCList.setAccessible(true);
/*     */       }
/*     */       
/* 159 */       if ((entity instanceof CraftCreature))
/*     */       {
/* 161 */         EntityCreature creature = ((CraftCreature)entity).getHandle();
/*     */         
/* 163 */         if (_bsRestrictionGoal == null)
/*     */         {
/* 165 */           _bsRestrictionGoal = EntityCreature.class.getDeclaredField("bs");
/* 166 */           _bsRestrictionGoal.setAccessible(true);
/*     */         }
/*     */         
/* 169 */         _bsRestrictionGoal.set(creature, new PathfinderGoalMoveTowardsRestriction(creature, 0.0D));
/*     */       }
/*     */       
/* 172 */       if ((((CraftEntity)entity).getHandle() instanceof EntityInsentient))
/*     */       {
/* 174 */         EntityInsentient creature = (EntityInsentient)((CraftEntity)entity).getHandle();
/*     */         
/* 176 */         creature.Vegetated = true;
/* 177 */         creature.Silent = mute;
/*     */         
/* 179 */         ((List)_pathfinderBList.get((PathfinderGoalSelector)_goalSelector.get(creature))).clear();
/* 180 */         ((List)_pathfinderCList.get((PathfinderGoalSelector)_goalSelector.get(creature))).clear();
/*     */         
/* 182 */         ((List)_pathfinderBList.get((PathfinderGoalSelector)_targetSelector.get(creature))).clear();
/* 183 */         ((List)_pathfinderCList.get((PathfinderGoalSelector)_targetSelector.get(creature))).clear();
/*     */       }
/*     */       
/* 186 */       if ((((CraftEntity)entity).getHandle() instanceof EntityBat))
/*     */       {
/* 188 */         ((EntityBat)((CraftEntity)entity).getHandle()).Vegetated = true;
/*     */       }
/*     */       
/* 191 */       if ((((CraftEntity)entity).getHandle() instanceof EntityEnderDragon))
/*     */       {
/* 193 */         EntityEnderDragon creature = (EntityEnderDragon)((CraftEntity)entity).getHandle();
/*     */         
/* 195 */         creature.Vegetated = true;
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 200 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 204 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchFieldException e)
/*     */     {
/* 208 */       e.printStackTrace();
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/* 212 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void removeGoalSelectors(org.bukkit.entity.Entity entity)
/*     */   {
/*     */     try
/*     */     {
/* 220 */       if (_goalSelector == null)
/*     */       {
/* 222 */         _goalSelector = EntityInsentient.class.getDeclaredField("goalSelector");
/* 223 */         _goalSelector.setAccessible(true);
/*     */       }
/*     */       
/* 226 */       if ((((CraftEntity)entity).getHandle() instanceof EntityInsentient))
/*     */       {
/* 228 */         EntityInsentient creature = (EntityInsentient)((CraftEntity)entity).getHandle();
/*     */         
/* 230 */         PathfinderGoalSelector goalSelector = new PathfinderGoalSelector(((CraftWorld)entity.getWorld()).getHandle().methodProfiler);
/*     */         
/* 232 */         _goalSelector.set(creature, goalSelector);
/*     */       }
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 237 */       e.printStackTrace();
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 241 */       e.printStackTrace();
/*     */     }
/*     */     catch (NoSuchFieldException e)
/*     */     {
/* 245 */       e.printStackTrace();
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/* 249 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void populate()
/*     */   {
/* 255 */     if (creatureMap.isEmpty())
/*     */     {
/* 257 */       creatureMap.put("Bat", EntityType.BAT);
/* 258 */       creatureMap.put("Blaze", EntityType.BLAZE);
/* 259 */       creatureMap.put("Arrow", EntityType.ARROW);
/* 260 */       creatureMap.put("Cave Spider", EntityType.CAVE_SPIDER);
/* 261 */       creatureMap.put("Chicken", EntityType.CHICKEN);
/* 262 */       creatureMap.put("Cow", EntityType.COW);
/* 263 */       creatureMap.put("Creeper", EntityType.CREEPER);
/* 264 */       creatureMap.put("Ender Dragon", EntityType.ENDER_DRAGON);
/* 265 */       creatureMap.put("Enderman", EntityType.ENDERMAN);
/* 266 */       creatureMap.put("Ghast", EntityType.GHAST);
/* 267 */       creatureMap.put("Giant", EntityType.GIANT);
/* 268 */       creatureMap.put("Horse", EntityType.HORSE);
/* 269 */       creatureMap.put("Iron Golem", EntityType.IRON_GOLEM);
/* 270 */       creatureMap.put("Item", EntityType.DROPPED_ITEM);
/* 271 */       creatureMap.put("Magma Cube", EntityType.MAGMA_CUBE);
/* 272 */       creatureMap.put("Mooshroom", EntityType.MUSHROOM_COW);
/* 273 */       creatureMap.put("Ocelot", EntityType.OCELOT);
/* 274 */       creatureMap.put("Pig", EntityType.PIG);
/* 275 */       creatureMap.put("Pig Zombie", EntityType.PIG_ZOMBIE);
/* 276 */       creatureMap.put("Sheep", EntityType.SHEEP);
/* 277 */       creatureMap.put("Silverfish", EntityType.SILVERFISH);
/* 278 */       creatureMap.put("Skeleton", EntityType.SKELETON);
/* 279 */       creatureMap.put("Slime", EntityType.SLIME);
/* 280 */       creatureMap.put("Snowman", EntityType.SNOWMAN);
/* 281 */       creatureMap.put("Spider", EntityType.SPIDER);
/* 282 */       creatureMap.put("Squid", EntityType.SQUID);
/* 283 */       creatureMap.put("Villager", EntityType.VILLAGER);
/* 284 */       creatureMap.put("Witch", EntityType.WITCH);
/* 285 */       creatureMap.put("Wither", EntityType.WITHER);
/* 286 */       creatureMap.put("WitherSkull", EntityType.WITHER_SKULL);
/* 287 */       creatureMap.put("Wolf", EntityType.WOLF);
/* 288 */       creatureMap.put("Zombie", EntityType.ZOMBIE);
/*     */       
/* 290 */       creatureMap.put("Item", EntityType.DROPPED_ITEM);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getName(org.bukkit.entity.Entity ent)
/*     */   {
/* 296 */     if (ent == null) {
/* 297 */       return "Null";
/*     */     }
/* 299 */     if (ent.getType() == EntityType.PLAYER) {
/* 300 */       return ((Player)ent).getName();
/*     */     }
/* 302 */     if (GetEntityNames().containsKey(ent)) {
/* 303 */       return (String)GetEntityNames().get(ent);
/*     */     }
/* 305 */     if ((ent instanceof LivingEntity))
/*     */     {
/* 307 */       LivingEntity le = (LivingEntity)ent;
/* 308 */       if (le.getCustomName() != null) {
/* 309 */         return le.getCustomName();
/*     */       }
/*     */     }
/* 312 */     return getName(ent.getType());
/*     */   }
/*     */   
/*     */   public static String getName(EntityType type)
/*     */   {
/* 317 */     for (String cur : creatureMap.keySet()) {
/* 318 */       if (creatureMap.get(cur) == type)
/* 319 */         return cur;
/*     */     }
/* 321 */     return type.getName();
/*     */   }
/*     */   
/*     */   public static String searchName(Player caller, String arg, boolean inform)
/*     */   {
/* 326 */     populate();
/*     */     
/* 328 */     arg = arg.toLowerCase().replaceAll("_", " ");
/* 329 */     LinkedList<String> matchList = new LinkedList();
/* 330 */     for (String cur : creatureMap.keySet())
/*     */     {
/* 332 */       if (cur.equalsIgnoreCase(arg)) {
/* 333 */         return cur;
/*     */       }
/* 335 */       if (cur.toLowerCase().contains(arg)) {
/* 336 */         matchList.add(cur);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 341 */     if (matchList.size() != 1)
/*     */     {
/* 343 */       if (!inform) {
/* 344 */         return null;
/*     */       }
/*     */       
/* 347 */       UtilPlayer.message(caller, F.main("Creature Search", 
/* 348 */         C.mCount + matchList.size() + 
/* 349 */         C.mBody + " matches for [" + 
/* 350 */         C.mElem + arg + 
/* 351 */         C.mBody + "]."));
/*     */       
/* 353 */       if (matchList.size() > 0)
/*     */       {
/* 355 */         String matchString = "";
/* 356 */         for (String cur : matchList)
/* 357 */           matchString = matchString + F.elem(cur) + ", ";
/* 358 */         if (matchString.length() > 1) {
/* 359 */           matchString = matchString.substring(0, matchString.length() - 2);
/*     */         }
/* 361 */         UtilPlayer.message(caller, F.main("Creature Search", 
/* 362 */           C.mBody + "Matches [" + 
/* 363 */           C.mElem + matchString + 
/* 364 */           C.mBody + "]."));
/*     */       }
/*     */       
/* 367 */       return null;
/*     */     }
/*     */     
/* 370 */     return (String)matchList.get(0);
/*     */   }
/*     */   
/*     */   public static EntityType searchEntity(Player caller, String arg, boolean inform)
/*     */   {
/* 375 */     populate();
/*     */     
/* 377 */     arg = arg.toLowerCase();
/* 378 */     LinkedList<EntityType> matchList = new LinkedList();
/* 379 */     for (String cur : creatureMap.keySet())
/*     */     {
/* 381 */       if (cur.equalsIgnoreCase(arg)) {
/* 382 */         return (EntityType)creatureMap.get(cur);
/*     */       }
/* 384 */       if (cur.toLowerCase().contains(arg)) {
/* 385 */         matchList.add((EntityType)creatureMap.get(cur));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 390 */     if (matchList.size() != 1)
/*     */     {
/* 392 */       if (!inform) {
/* 393 */         return null;
/*     */       }
/*     */       
/* 396 */       UtilPlayer.message(caller, F.main("Creature Search", 
/* 397 */         C.mCount + matchList.size() + 
/* 398 */         C.mBody + " matches for [" + 
/* 399 */         C.mElem + arg + 
/* 400 */         C.mBody + "]."));
/*     */       
/* 402 */       if (matchList.size() > 0)
/*     */       {
/* 404 */         String matchString = "";
/* 405 */         for (EntityType cur : matchList)
/* 406 */           matchString = matchString + F.elem(cur.getName()) + ", ";
/* 407 */         if (matchString.length() > 1) {
/* 408 */           matchString = matchString.substring(0, matchString.length() - 2);
/*     */         }
/* 410 */         UtilPlayer.message(caller, F.main("Creature Search", 
/* 411 */           C.mBody + "Matches [" + 
/* 412 */           C.mElem + matchString + 
/* 413 */           C.mBody + "]."));
/*     */       }
/*     */       
/* 416 */       return null;
/*     */     }
/*     */     
/* 419 */     return (EntityType)matchList.get(0);
/*     */   }
/*     */   
/*     */   public static HashMap<LivingEntity, Double> getInRadius(Location loc, double dR)
/*     */   {
/* 424 */     HashMap<LivingEntity, Double> ents = new HashMap();
/*     */     
/* 426 */     for (org.bukkit.entity.Entity cur : loc.getWorld().getEntities())
/*     */     {
/* 428 */       if (((cur instanceof LivingEntity)) && (!UtilPlayer.isSpectator(cur)))
/*     */       {
/*     */ 
/* 431 */         LivingEntity ent = (LivingEntity)cur;
/*     */         
/* 433 */         double offset = UtilMath.offset(loc, ent.getLocation());
/*     */         
/* 435 */         if (offset < dR)
/* 436 */           ents.put(ent, Double.valueOf(1.0D - offset / dR));
/*     */       }
/*     */     }
/* 439 */     return ents;
/*     */   }
/*     */   
/*     */   public static boolean hitBox(Location loc, LivingEntity ent, double mult, EntityType disguise)
/*     */   {
/* 444 */     if (disguise != null)
/*     */     {
/* 446 */       if (disguise == EntityType.SQUID)
/*     */       {
/* 448 */         if (UtilMath.offset(loc, ent.getLocation().add(0.0D, 0.4D, 0.0D)) < 0.6D * mult) {
/* 449 */           return true;
/*     */         }
/* 451 */         return false;
/*     */       }
/*     */     }
/*     */     
/* 455 */     if ((ent instanceof Player))
/*     */     {
/* 457 */       Player player = (Player)ent;
/*     */       
/* 459 */       if (UtilMath.offset(loc, player.getEyeLocation()) < 0.4D * mult)
/*     */       {
/* 461 */         return true;
/*     */       }
/* 463 */       if (UtilMath.offset2d(loc, player.getLocation()) < 0.6D * mult)
/*     */       {
/* 465 */         if ((loc.getY() > player.getLocation().getY()) && (loc.getY() < player.getEyeLocation().getY()))
/*     */         {
/* 467 */           return true;
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     }
/* 473 */     else if ((ent instanceof Giant))
/*     */     {
/* 475 */       if ((loc.getY() > ent.getLocation().getY()) && (loc.getY() < ent.getLocation().getY() + 12.0D) && 
/* 476 */         (UtilMath.offset2d(loc, ent.getLocation()) < 4.0D)) {
/* 477 */         return true;
/*     */       }
/*     */       
/*     */     }
/* 481 */     else if ((loc.getY() > ent.getLocation().getY()) && (loc.getY() < ent.getLocation().getY() + 2.0D) && 
/* 482 */       (UtilMath.offset2d(loc, ent.getLocation()) < 0.5D * mult)) {
/* 483 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 489 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isGrounded(org.bukkit.entity.Entity ent)
/*     */   {
/* 494 */     if ((ent instanceof CraftEntity)) {
/* 495 */       return ((CraftEntity)ent).getHandle().onGround;
/*     */     }
/* 497 */     return UtilBlock.solid(ent.getLocation().getBlock().getRelative(BlockFace.DOWN));
/*     */   }
/*     */   
/*     */   public static void PlayDamageSound(LivingEntity damagee)
/*     */   {
/* 502 */     Sound sound = Sound.HURT_FLESH;
/*     */     
/* 504 */     if (damagee.getType() == EntityType.BAT) { sound = Sound.BAT_HURT;
/* 505 */     } else if (damagee.getType() == EntityType.BLAZE) { sound = Sound.BLAZE_HIT;
/* 506 */     } else if (damagee.getType() == EntityType.CAVE_SPIDER) { sound = Sound.SPIDER_IDLE;
/* 507 */     } else if (damagee.getType() == EntityType.CHICKEN) { sound = Sound.CHICKEN_HURT;
/* 508 */     } else if (damagee.getType() == EntityType.COW) { sound = Sound.COW_HURT;
/* 509 */     } else if (damagee.getType() == EntityType.CREEPER) { sound = Sound.CREEPER_HISS;
/* 510 */     } else if (damagee.getType() == EntityType.ENDER_DRAGON) { sound = Sound.ENDERDRAGON_GROWL;
/* 511 */     } else if (damagee.getType() == EntityType.ENDERMAN) { sound = Sound.ENDERMAN_HIT;
/* 512 */     } else if (damagee.getType() == EntityType.GHAST) { sound = Sound.GHAST_SCREAM;
/* 513 */     } else if (damagee.getType() == EntityType.GIANT) { sound = Sound.ZOMBIE_HURT;
/*     */     }
/* 515 */     else if (damagee.getType() == EntityType.IRON_GOLEM) { sound = Sound.IRONGOLEM_HIT;
/* 516 */     } else if (damagee.getType() == EntityType.MAGMA_CUBE) { sound = Sound.MAGMACUBE_JUMP;
/* 517 */     } else if (damagee.getType() == EntityType.MUSHROOM_COW) { sound = Sound.COW_HURT;
/* 518 */     } else if (damagee.getType() == EntityType.OCELOT) { sound = Sound.CAT_MEOW;
/* 519 */     } else if (damagee.getType() == EntityType.PIG) { sound = Sound.PIG_IDLE;
/* 520 */     } else if (damagee.getType() == EntityType.PIG_ZOMBIE) { sound = Sound.ZOMBIE_HURT;
/* 521 */     } else if (damagee.getType() == EntityType.SHEEP) { sound = Sound.SHEEP_IDLE;
/* 522 */     } else if (damagee.getType() == EntityType.SILVERFISH) { sound = Sound.SILVERFISH_HIT;
/* 523 */     } else if (damagee.getType() == EntityType.SKELETON) { sound = Sound.SKELETON_HURT;
/* 524 */     } else if (damagee.getType() == EntityType.SLIME) { sound = Sound.SLIME_ATTACK;
/* 525 */     } else if (damagee.getType() == EntityType.SNOWMAN) { sound = Sound.STEP_SNOW;
/* 526 */     } else if (damagee.getType() == EntityType.SPIDER) { sound = Sound.SPIDER_IDLE;
/*     */ 
/*     */ 
/*     */     }
/* 530 */     else if (damagee.getType() == EntityType.WITHER) { sound = Sound.WITHER_HURT;
/* 531 */     } else if (damagee.getType() == EntityType.WOLF) { sound = Sound.WOLF_HURT;
/* 532 */     } else if (damagee.getType() == EntityType.ZOMBIE) { sound = Sound.ZOMBIE_HURT;
/*     */     }
/* 534 */     damagee.getWorld().playSound(damagee.getLocation(), sound, 1.5F + (float)(0.5D * Math.random()), 0.8F + (float)(0.4000000059604645D * Math.random()));
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean onBlock(Player player)
/*     */   {
/* 540 */     double xMod = player.getLocation().getX() % 1.0D;
/* 541 */     if (player.getLocation().getX() < 0.0D) {
/* 542 */       xMod += 1.0D;
/*     */     }
/* 544 */     double zMod = player.getLocation().getZ() % 1.0D;
/* 545 */     if (player.getLocation().getZ() < 0.0D) {
/* 546 */       zMod += 1.0D;
/*     */     }
/* 548 */     int xMin = 0;
/* 549 */     int xMax = 0;
/* 550 */     int zMin = 0;
/* 551 */     int zMax = 0;
/*     */     
/* 553 */     if (xMod < 0.3D) xMin = -1;
/* 554 */     if (xMod > 0.7D) { xMax = 1;
/*     */     }
/* 556 */     if (zMod < 0.3D) zMin = -1;
/* 557 */     if (zMod > 0.7D) { zMax = 1;
/*     */     }
/* 559 */     for (int x = xMin; x <= xMax; x++)
/*     */     {
/* 561 */       for (int z = zMin; z <= zMax; z++)
/*     */       {
/*     */ 
/* 564 */         if ((player.getLocation().add(x, -0.5D, z).getBlock().getType() != Material.AIR) && (!player.getLocation().add(x, -0.5D, z).getBlock().isLiquid())) {
/* 565 */           return true;
/*     */         }
/*     */         
/* 568 */         if (player.getLocation().add(x, 0.0D, z).getBlock().getType() == Material.WATER_LILY) {
/* 569 */           return true;
/*     */         }
/*     */         
/* 572 */         Material beneath = player.getLocation().add(x, -1.5D, z).getBlock().getType();
/* 573 */         if ((player.getLocation().getY() % 0.5D == 0.0D) && (
/* 574 */           (beneath == Material.FENCE) || 
/* 575 */           (beneath == Material.FENCE_GATE) || 
/* 576 */           (beneath == Material.NETHER_FENCE) || 
/* 577 */           (beneath == Material.COBBLE_WALL))) {
/* 578 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 582 */     return false;
/*     */   }
/*     */   
/*     */   public static void CreatureMove(org.bukkit.entity.Entity ent, Location target, float speed)
/*     */   {
/* 587 */     if (!(ent instanceof Creature)) {
/* 588 */       return;
/*     */     }
/* 590 */     if (UtilMath.offset(ent.getLocation(), target) < 0.1D) {
/* 591 */       return;
/*     */     }
/* 593 */     EntityCreature ec = ((CraftCreature)ent).getHandle();
/* 594 */     Navigation nav = ec.getNavigation();
/*     */     
/* 596 */     if (UtilMath.offset(ent.getLocation(), target) > 16.0D)
/*     */     {
/* 598 */       Location newTarget = ent.getLocation();
/*     */       
/* 600 */       newTarget.add(UtilAlg.getTrajectory(ent.getLocation(), target).multiply(16));
/*     */       
/* 602 */       nav.a(newTarget.getX(), newTarget.getY(), newTarget.getZ(), speed);
/*     */     }
/*     */     else
/*     */     {
/* 606 */       nav.a(target.getX(), target.getY(), target.getZ(), speed);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean CreatureMoveFast(org.bukkit.entity.Entity ent, Location target, float speed)
/*     */   {
/* 612 */     return CreatureMoveFast(ent, target, speed, true);
/*     */   }
/*     */   
/*     */   public static boolean CreatureMoveFast(org.bukkit.entity.Entity ent, Location target, float speed, boolean slow)
/*     */   {
/* 617 */     if (!(ent instanceof Creature)) {
/* 618 */       return false;
/*     */     }
/* 620 */     if (UtilMath.offset(ent.getLocation(), target) < 0.1D) {
/* 621 */       return false;
/*     */     }
/* 623 */     if (UtilMath.offset(ent.getLocation(), target) < 2.0D) {
/* 624 */       speed = Math.min(speed, 1.0F);
/*     */     }
/* 626 */     EntityCreature ec = ((CraftCreature)ent).getHandle();
/* 627 */     ec.getControllerMove().a(target.getX(), target.getY(), target.getZ(), speed);
/*     */     
/* 629 */     return true;
/*     */   }
/*     */   
/*     */   public static int getNewEntityId()
/*     */   {
/* 634 */     return getNewEntityId(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getNewEntityId(boolean modifynumber)
/*     */   {
/*     */     try
/*     */     {
/* 646 */       Field field = net.minecraft.server.v1_7_R4.Entity.class.getDeclaredField("entityCount");
/* 647 */       field.setAccessible(true);
/* 648 */       int entityId = field.getInt(null);
/* 649 */       if (modifynumber) {
/* 650 */         field.set(null, Integer.valueOf(entityId + 1));
/*     */       }
/* 652 */       return entityId;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 656 */       ex.printStackTrace();
/*     */     }
/* 658 */     return -1;
/*     */   }
/*     */   
/*     */   public static org.bukkit.entity.Entity getEntityById(int entityId) {
/*     */     Iterator localIterator2;
/* 663 */     for (Iterator localIterator1 = Bukkit.getWorlds().iterator(); localIterator1.hasNext(); 
/*     */         
/* 665 */         localIterator2.hasNext())
/*     */     {
/* 663 */       World world = (World)localIterator1.next();
/*     */       
/* 665 */       localIterator2 = world.getEntities().iterator(); continue;org.bukkit.entity.Entity entity = (org.bukkit.entity.Entity)localIterator2.next();
/*     */       
/* 667 */       if (entity.getEntityId() == entityId)
/*     */       {
/* 669 */         return entity;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 674 */     return null;
/*     */   }
/*     */   
/*     */   public static boolean inWater(LivingEntity ent)
/*     */   {
/* 679 */     return (ent.getLocation().getBlock().getTypeId() == 8) || (ent.getLocation().getBlock().getTypeId() == 9);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilEnt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */