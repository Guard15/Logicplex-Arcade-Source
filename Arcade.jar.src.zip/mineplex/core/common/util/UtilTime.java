/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ public class UtilTime
/*     */ {
/*     */   public static final String DATE_FORMAT_NOW = "MM-dd-yyyy HH:mm:ss";
/*     */   public static final String DATE_FORMAT_DAY = "MM-dd-yyyy";
/*     */   
/*     */   public static String now()
/*     */   {
/*  13 */     Calendar cal = Calendar.getInstance();
/*  14 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
/*  15 */     return sdf.format(cal.getTime());
/*     */   }
/*     */   
/*     */   public static String when(long time)
/*     */   {
/*  20 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
/*  21 */     return sdf.format(Long.valueOf(time));
/*     */   }
/*     */   
/*     */ 
/*     */   public static String date()
/*     */   {
/*  27 */     Calendar cal = Calendar.getInstance();
/*  28 */     SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
/*  29 */     return sdf.format(cal.getTime());
/*     */   }
/*     */   
/*     */   public static enum TimeUnit
/*     */   {
/*  34 */     FIT, 
/*  35 */     DAYS, 
/*  36 */     HOURS, 
/*  37 */     MINUTES, 
/*  38 */     SECONDS, 
/*  39 */     MILLISECONDS;
/*     */   }
/*     */   
/*     */   public static String since(long epoch)
/*     */   {
/*  44 */     return "Took " + convertString(System.currentTimeMillis() - epoch, 1, TimeUnit.FIT) + ".";
/*     */   }
/*     */   
/*     */   public static double convert(long time, int trim, TimeUnit type)
/*     */   {
/*  49 */     if (type == TimeUnit.FIT)
/*     */     {
/*  51 */       if (time < 60000L) { type = TimeUnit.SECONDS;
/*  52 */       } else if (time < 3600000L) { type = TimeUnit.MINUTES;
/*  53 */       } else if (time < 86400000L) type = TimeUnit.HOURS; else {
/*  54 */         type = TimeUnit.DAYS;
/*     */       }
/*     */     }
/*  57 */     if (type == TimeUnit.DAYS) return UtilMath.trim(trim, time / 8.64E7D);
/*  58 */     if (type == TimeUnit.HOURS) return UtilMath.trim(trim, time / 3600000.0D);
/*  59 */     if (type == TimeUnit.MINUTES) return UtilMath.trim(trim, time / 60000.0D);
/*  60 */     if (type == TimeUnit.SECONDS) return UtilMath.trim(trim, time / 1000.0D);
/*  61 */     return UtilMath.trim(trim, time);
/*     */   }
/*     */   
/*     */   public static String MakeStr(long time)
/*     */   {
/*  66 */     return convertString(time, 1, TimeUnit.FIT);
/*     */   }
/*     */   
/*     */   public static String MakeStr(long time, int trim)
/*     */   {
/*  71 */     return convertString(Math.max(0L, time), trim, TimeUnit.FIT);
/*     */   }
/*     */   
/*     */   public static String convertString(long time, int trim, TimeUnit type)
/*     */   {
/*  76 */     if (time == -1L) { return "Permanent";
/*     */     }
/*  78 */     if (type == TimeUnit.FIT)
/*     */     {
/*  80 */       if (time < 60000L) { type = TimeUnit.SECONDS;
/*  81 */       } else if (time < 3600000L) { type = TimeUnit.MINUTES;
/*  82 */       } else if (time < 86400000L) type = TimeUnit.HOURS; else
/*  83 */         type = TimeUnit.DAYS;
/*     */     }
/*     */     String text;
/*     */     double num;
/*     */     String text;
/*  88 */     if (trim == 0) {
/*     */       String text;
/*  90 */       if (type == TimeUnit.DAYS) { double num; text = (num = UtilMath.trim(trim, time / 8.64E7D)) + " Day"; } else { String text;
/*  91 */         if (type == TimeUnit.HOURS) { double num; text = (num = UtilMath.trim(trim, time / 3600000.0D)) + " Hour"; } else { String text;
/*  92 */           if (type == TimeUnit.MINUTES) { double num; text = (num = UtilMath.trim(trim, time / 60000.0D)) + " Minute"; } else { String text;
/*  93 */             if (type == TimeUnit.SECONDS) { double num; text = (int)(num = (int)UtilMath.trim(trim, time / 1000.0D)) + " Second"; } else { double num;
/*  94 */               text = (int)(num = (int)UtilMath.trim(trim, time)) + " Millisecond";
/*     */             }
/*     */           }
/*     */         } } } else { String text;
/*  98 */       if (type == TimeUnit.DAYS) { double num; text = (num = UtilMath.trim(trim, time / 8.64E7D)) + " Day"; } else { String text;
/*  99 */         if (type == TimeUnit.HOURS) { double num; text = (num = UtilMath.trim(trim, time / 3600000.0D)) + " Hour"; } else { String text;
/* 100 */           if (type == TimeUnit.MINUTES) { double num; text = (num = UtilMath.trim(trim, time / 60000.0D)) + " Minute"; } else { String text;
/* 101 */             if (type == TimeUnit.SECONDS) { double num; text = (num = UtilMath.trim(trim, time / 1000.0D)) + " Second";
/* 102 */             } else { text = (int)(num = (int)UtilMath.trim(0, time)) + " Millisecond";
/*     */             }
/*     */           } } } }
/* 105 */     if (num != 1.0D) {
/* 106 */       text = text + "s";
/*     */     }
/* 108 */     return text;
/*     */   }
/*     */   
/*     */   public static boolean elapsed(long from, long required)
/*     */   {
/* 113 */     return System.currentTimeMillis() - from > required;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilTime.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */