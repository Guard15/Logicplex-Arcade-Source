/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ public class UtilEnum
/*    */ {
/*    */   public static <T extends Enum<T>> T fromString(Class<T> t, String text) {
/*    */     Enum[] arrayOfEnum;
/*  7 */     int j = (arrayOfEnum = (Enum[])t.getEnumConstants()).length; for (int i = 0; i < j; i++) { T value = arrayOfEnum[i];
/*    */       
/*  9 */       if (text.equalsIgnoreCase(value.name()))
/*    */       {
/* 11 */         return value;
/*    */       }
/*    */     }
/*    */     
/* 15 */     throw new IllegalArgumentException("There is no value with name '" + text + " in Enum " + t.getClass().getName());
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilEnum.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */