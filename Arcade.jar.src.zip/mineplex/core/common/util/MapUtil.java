/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.minecraft.server.v1_7_R4.ChunkCoordIntPair;
/*     */ import net.minecraft.server.v1_7_R4.ChunkProviderServer;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.ExceptionWorldConflict;
/*     */ import net.minecraft.server.v1_7_R4.MinecraftServer;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutMultiBlockChange;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import net.minecraft.server.v1_7_R4.RegionFile;
/*     */ import net.minecraft.server.v1_7_R4.RegionFileCache;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftChunk;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftServer;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.util.LongHashSet;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.util.LongObjectHashMap;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.world.WorldUnloadEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapUtil
/*     */ {
/*     */   public static void ReplaceOreInChunk(org.bukkit.Chunk chunk, Material replacee, Material replacer)
/*     */   {
/*  45 */     net.minecraft.server.v1_7_R4.Chunk c = ((CraftChunk)chunk).getHandle();
/*     */     
/*  47 */     for (int x = 0; x < 16; x++)
/*     */     {
/*  49 */       for (int z = 0; z < 16; z++)
/*     */       {
/*  51 */         for (int y = 0; y < 18; y++)
/*     */         {
/*  53 */           int bX = c.locX << 4 | x & 0xF;
/*  54 */           int bY = y & 0xFF;
/*  55 */           int bZ = c.locZ << 4 | z & 0xF;
/*     */           
/*  57 */           if (c.getType(bX & 0xF, bY, bZ & 0xF).k() == replacee.getId())
/*     */           {
/*  59 */             c.b(bX & 0xF, bY, bZ & 0xF, replacer.getId());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  65 */     c.initLighting();
/*     */   }
/*     */   
/*     */   public static void QuickChangeBlockAt(Location location, Material setTo)
/*     */   {
/*  70 */     QuickChangeBlockAt(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), setTo);
/*     */   }
/*     */   
/*     */   public static void QuickChangeBlockAt(Location location, int id, byte data)
/*     */   {
/*  75 */     QuickChangeBlockAt(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), id, 
/*  76 */       data);
/*     */   }
/*     */   
/*     */   public static void QuickChangeBlockAt(World world, int x, int y, int z, Material setTo)
/*     */   {
/*  81 */     QuickChangeBlockAt(world, x, y, z, setTo, 0);
/*     */   }
/*     */   
/*     */   public static void QuickChangeBlockAt(World world, int x, int y, int z, Material setTo, int data)
/*     */   {
/*  86 */     QuickChangeBlockAt(world, x, y, z, setTo.getId(), data);
/*     */   }
/*     */   
/*     */   public static void QuickChangeBlockAt(World world, int x, int y, int z, int id, int data)
/*     */   {
/*  91 */     org.bukkit.Chunk chunk = world.getChunkAt(x >> 4, z >> 4);
/*  92 */     net.minecraft.server.v1_7_R4.Chunk c = ((CraftChunk)chunk).getHandle();
/*     */     
/*  94 */     c.a(x & 0xF, y, z & 0xF, net.minecraft.server.v1_7_R4.Block.getById(id), data);
/*  95 */     ((CraftWorld)world).getHandle().notify(x, y, z);
/*     */   }
/*     */   
/*     */   public static int GetHighestBlockInCircleAt(World world, int bx, int bz, int radius)
/*     */   {
/* 100 */     int count = 0;
/* 101 */     int totalHeight = 0;
/*     */     
/* 103 */     double invRadiusX = 1 / radius;
/* 104 */     double invRadiusZ = 1 / radius;
/*     */     
/* 106 */     int ceilRadiusX = (int)Math.ceil(radius);
/* 107 */     int ceilRadiusZ = (int)Math.ceil(radius);
/*     */     
/* 109 */     double nextXn = 0.0D;
/* 110 */     for (int x = 0; x <= ceilRadiusX; x++)
/*     */     {
/* 112 */       double xn = nextXn;
/* 113 */       nextXn = (x + 1) * invRadiusX;
/* 114 */       double nextZn = 0.0D;
/* 115 */       for (int z = 0; z <= ceilRadiusZ; z++)
/*     */       {
/* 117 */         double zn = nextZn;
/* 118 */         nextZn = (z + 1) * invRadiusZ;
/*     */         
/* 120 */         double distanceSq = xn * xn + zn * zn;
/* 121 */         if (distanceSq > 1.0D)
/*     */         {
/* 123 */           if (z != 0) {
/*     */             break;
/*     */           }
/*     */           
/*     */           break label155;
/*     */         }
/*     */         
/* 130 */         totalHeight += world.getHighestBlockAt(bx + x, bz + z).getY();
/* 131 */         count++;
/*     */       }
/*     */     }
/*     */     label155:
/* 135 */     return totalHeight / count;
/*     */   }
/*     */   
/*     */   public static void ChunkBlockChange(Location location, int id, byte data, boolean notifyPlayers)
/*     */   {
/* 140 */     ChunkBlockChange(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), id, 
/* 141 */       data, notifyPlayers);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void ChunkBlockChange(World world, int x, int y, int z, int id, byte data, boolean notifyPlayers)
/*     */   {
/* 147 */     if (changeChunkBlock(x & 0xF, y, z & 0xF, ((CraftWorld)world).getHandle().getChunkAt(x >> 4, z >> 4), net.minecraft.server.v1_7_R4.Block.getById(id), data))
/*     */     {
/* 149 */       if (notifyPlayers) {
/* 150 */         ((CraftWorld)world).getHandle().notify(x, y, z);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static void ChunkBlockSet(World world, int x, int y, int z, int id, byte data, boolean notifyPlayers) {
/* 156 */     world.getBlockAt(x, y, z).setTypeIdAndData(id, data, notifyPlayers);
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean changeChunkBlock(int x, int y, int z, net.minecraft.server.v1_7_R4.Chunk chunk, net.minecraft.server.v1_7_R4.Block block, byte data)
/*     */   {
/* 162 */     return chunk.a(x, y, z, block, data);
/*     */   }
/*     */   
/*     */   public static void SendChunkForPlayer(net.minecraft.server.v1_7_R4.Chunk chunk, Player player)
/*     */   {
/* 167 */     SendChunkForPlayer(chunk.locX, chunk.locZ, player);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void SendChunkForPlayer(int x, int z, Player player)
/*     */   {
/* 174 */     ((CraftPlayer)player).getHandle().chunkCoordIntPairQueue.add(new ChunkCoordIntPair(x, z));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void SendMultiBlockForPlayer(int x, int z, short[] dirtyBlocks, int dirtyCount, World world, Player player)
/*     */   {
/* 182 */     ((CraftPlayer)player).getHandle().playerConnection.sendPacket(new PacketPlayOutMultiBlockChange(dirtyCount, 
/* 183 */       dirtyBlocks, ((CraftWorld)world).getHandle().getChunkAt(x, z)));
/*     */   }
/*     */   
/*     */   public static void UnloadWorld(JavaPlugin plugin, World world)
/*     */   {
/* 188 */     UnloadWorld(plugin, world, false);
/*     */   }
/*     */   
/*     */   public static void UnloadWorld(JavaPlugin plugin, World world, boolean save)
/*     */   {
/* 193 */     if (save)
/*     */     {
/*     */       try
/*     */       {
/* 197 */         ((CraftWorld)world).getHandle().save(true, null);
/*     */       }
/*     */       catch (ExceptionWorldConflict e)
/*     */       {
/* 201 */         e.printStackTrace();
/*     */       }
/*     */       
/* 204 */       ((CraftWorld)world).getHandle().saveLevel();
/*     */     }
/*     */     
/* 207 */     world.setAutoSave(save);
/*     */     
/* 209 */     CraftServer server = (CraftServer)plugin.getServer();
/* 210 */     CraftWorld craftWorld = (CraftWorld)world;
/*     */     
/* 212 */     Bukkit.getPluginManager().callEvent(new WorldUnloadEvent(((CraftWorld)world).getHandle().getWorld()));
/*     */     
/* 214 */     Iterator<net.minecraft.server.v1_7_R4.Chunk> chunkIterator = ((CraftWorld)world).getHandle().chunkProviderServer.chunks
/* 215 */       .values().iterator();
/*     */     
/* 217 */     for (Entity entity : world.getEntities())
/*     */     {
/* 219 */       entity.remove();
/*     */     }
/*     */     
/* 222 */     while (chunkIterator.hasNext())
/*     */     {
/* 224 */       net.minecraft.server.v1_7_R4.Chunk chunk = (net.minecraft.server.v1_7_R4.Chunk)chunkIterator.next();
/* 225 */       chunk.removeEntities();
/*     */     }
/*     */     
/* 228 */     ((CraftWorld)world).getHandle().chunkProviderServer.chunks.clear();
/* 229 */     ((CraftWorld)world).getHandle().chunkProviderServer.unloadQueue.clear();
/*     */     
/*     */     try
/*     */     {
/* 233 */       Field f = server.getClass().getDeclaredField("worlds");
/* 234 */       f.setAccessible(true);
/*     */       
/* 236 */       Object worlds = (Map)f.get(server);
/* 237 */       ((Map)worlds).remove(world.getName().toLowerCase());
/* 238 */       f.setAccessible(false);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 242 */       System.out.println("Error removing world from bukkit master list: " + ex.getMessage());
/*     */     }
/*     */     catch (NoSuchFieldException ex)
/*     */     {
/* 246 */       System.out.println("Error removing world from bukkit master list: " + ex.getMessage());
/*     */     }
/*     */     
/* 249 */     MinecraftServer ms = null;
/*     */     
/*     */     try
/*     */     {
/* 253 */       Field f = server.getClass().getDeclaredField("console");
/* 254 */       f.setAccessible(true);
/* 255 */       ms = (MinecraftServer)f.get(server);
/* 256 */       f.setAccessible(false);
/*     */     }
/*     */     catch (IllegalAccessException ex)
/*     */     {
/* 260 */       System.out.println("Error getting minecraftserver variable: " + ex.getMessage());
/*     */     }
/*     */     catch (NoSuchFieldException ex)
/*     */     {
/* 264 */       System.out.println("Error getting minecraftserver variable: " + ex.getMessage());
/*     */     }
/*     */     
/* 267 */     ms.worlds.remove(ms.worlds.indexOf(craftWorld.getHandle()));
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean ClearWorldReferences(String worldName)
/*     */   {
/* 273 */     HashMap regionfiles = (HashMap)RegionFileCache.a;
/*     */     
/*     */     try
/*     */     {
/* 277 */       for (Iterator<Object> iterator = regionfiles.entrySet().iterator(); iterator.hasNext();)
/*     */       {
/* 279 */         Map.Entry e = (Map.Entry)iterator.next();
/* 280 */         RegionFile file = (RegionFile)e.getValue();
/*     */         
/*     */         try
/*     */         {
/* 284 */           file.c();
/* 285 */           iterator.remove();
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 289 */           ex.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 295 */       System.out.println("Exception while removing world reference for '" + worldName + "'!");
/* 296 */       ex.printStackTrace();
/*     */     }
/*     */     
/* 299 */     return true;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\MapUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */