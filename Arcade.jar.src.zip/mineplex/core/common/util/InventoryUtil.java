/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.inventory.CraftInventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public class InventoryUtil
/*     */ {
/*     */   public static HashMap<Integer, ItemStack> removeItem(CraftInventory inventory, int endingSlot, ItemStack... items)
/*     */   {
/*  12 */     HashMap<Integer, ItemStack> leftover = new HashMap();
/*     */     
/*  14 */     if (endingSlot >= 54) {
/*  15 */       return leftover;
/*     */     }
/*  17 */     for (int i = 0; i < items.length; i++)
/*     */     {
/*  19 */       ItemStack item = items[i];
/*  20 */       int toDelete = item.getAmount();
/*     */       
/*     */       do
/*     */       {
/*  24 */         int first = first(inventory, endingSlot, item, false);
/*     */         
/*  26 */         if (first == -1)
/*     */         {
/*  28 */           item.setAmount(toDelete);
/*  29 */           leftover.put(Integer.valueOf(i), item);
/*  30 */           break;
/*     */         }
/*     */         
/*     */ 
/*  34 */         ItemStack itemStack = inventory.getItem(first);
/*  35 */         int amount = itemStack.getAmount();
/*     */         
/*  37 */         if (amount <= toDelete)
/*     */         {
/*  39 */           toDelete -= amount;
/*  40 */           inventory.clear(first);
/*     */         }
/*     */         else
/*     */         {
/*  44 */           itemStack.setAmount(amount - toDelete);
/*  45 */           inventory.setItem(first, itemStack);
/*  46 */           toDelete = 0;
/*     */         }
/*     */         
/*     */       }
/*  50 */       while (toDelete > 0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  55 */     return leftover;
/*     */   }
/*     */   
/*     */   public static int first(CraftInventory craftInventory, int endingSlot, ItemStack item, boolean withAmount)
/*     */   {
/*  60 */     if (endingSlot >= 54) {
/*  61 */       return -1;
/*     */     }
/*  63 */     ItemStack[] inventory = craftInventory.getContents();
/*     */     
/*  65 */     for (int i = 0; i < endingSlot; i++)
/*     */     {
/*  67 */       if (inventory[i] == null)
/*     */       {
/*  69 */         if (item == null) {
/*  70 */           return i;
/*     */         }
/*     */         
/*     */       }
/*  74 */       else if (item != null)
/*     */       {
/*     */ 
/*  77 */         boolean equals = (item.getTypeId() == inventory[i].getTypeId()) && (item.getDurability() == inventory[i].getDurability()) && (item.getEnchantments().equals(inventory[i].getEnchantments()));
/*     */         
/*  79 */         if ((equals) && (withAmount))
/*     */         {
/*  81 */           equals = inventory[i].getAmount() >= item.getAmount();
/*     */         }
/*     */         
/*  84 */         if (equals)
/*     */         {
/*  86 */           return i;
/*     */         }
/*     */       }
/*     */     }
/*  90 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getCountOfObjectsRemoved(CraftInventory getInventory, int i, ItemStack itemStack)
/*     */   {
/*  95 */     int count = 0;
/*     */     
/*     */     do
/*     */     {
/*  99 */       count++;
/*  97 */       if (!getInventory.contains(itemStack.getType(), itemStack.getAmount())) break; } while (removeItem(getInventory, i, new ItemStack[] { itemStack }).size() == 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 102 */     return count;
/*     */   }
/*     */   
/*     */   public static int GetCountOfObjectsRemovedInSlot(CraftInventory getInventory, int slot, ItemStack itemStack)
/*     */   {
/* 107 */     int count = 0;
/* 108 */     ItemStack slotStack = getInventory.getItem(slot);
/*     */     
/* 110 */     while ((slotStack.getType() == itemStack.getType()) && (slotStack.getAmount() >= itemStack.getAmount()))
/*     */     {
/* 112 */       slotStack.setAmount(slotStack.getAmount() - itemStack.getAmount());
/* 113 */       count++;
/*     */     }
/*     */     
/* 116 */     if (slotStack.getAmount() == 0) {
/* 117 */       getInventory.setItem(slot, null);
/*     */     }
/* 119 */     return count;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\InventoryUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */