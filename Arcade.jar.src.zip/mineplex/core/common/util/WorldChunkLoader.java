/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.scheduler.BukkitScheduler;
/*    */ 
/*    */ public class WorldChunkLoader implements Runnable
/*    */ {
/* 10 */   private static WorldChunkLoader _worldChunkLoader = null;
/*    */   
/* 12 */   private NautHashMap<WorldLoadInfo, Runnable> _worldRunnableMap = new NautHashMap();
/*    */   
/*    */   private long _loadPassStart;
/* 15 */   private long _maxPassTime = 25L;
/*    */   
/*    */   private WorldChunkLoader()
/*    */   {
/* 19 */     org.bukkit.Bukkit.getScheduler().scheduleAsyncRepeatingTask(org.bukkit.Bukkit.getPluginManager().getPlugins()[0], this, 0L, 1L);
/*    */   }
/*    */   
/*    */   public static void AddWorld(WorldLoadInfo worldInfo, Runnable runnable)
/*    */   {
/* 24 */     if (_worldChunkLoader == null)
/*    */     {
/* 26 */       _worldChunkLoader = new WorldChunkLoader();
/*    */     }
/*    */     
/* 29 */     _worldChunkLoader._worldRunnableMap.put(worldInfo, runnable);
/*    */   }
/*    */   
/*    */ 
/*    */   public void run()
/*    */   {
/* 35 */     this._loadPassStart = System.currentTimeMillis();
/*    */     
/* 37 */     Iterator<WorldLoadInfo> worldInfoIterator = this._worldRunnableMap.keySet().iterator();
/*    */     
/* 39 */     while (worldInfoIterator.hasNext())
/*    */     {
/* 41 */       WorldLoadInfo worldInfo = (WorldLoadInfo)worldInfoIterator.next();
/* 42 */       System.out.println("Loading chunks for " + worldInfo.GetWorld().getName());
/*    */       
/* 44 */       while (worldInfo.CurrentChunkX <= worldInfo.GetMaxChunkX())
/*    */       {
/* 46 */         while (worldInfo.CurrentChunkZ <= worldInfo.GetMaxChunkZ())
/*    */         {
/* 48 */           if (System.currentTimeMillis() - this._loadPassStart >= this._maxPassTime) {
/* 49 */             return;
/*    */           }
/* 51 */           worldInfo.GetWorld().loadChunk(worldInfo.CurrentChunkX, worldInfo.CurrentChunkZ);
/* 52 */           worldInfo.CurrentChunkZ += 1;
/*    */         }
/*    */         
/* 55 */         worldInfo.CurrentChunkZ = worldInfo.GetMinChunkZ();
/* 56 */         worldInfo.CurrentChunkX += 1;
/*    */       }
/*    */       
/* 59 */       ((Runnable)this._worldRunnableMap.get(worldInfo)).run();
/* 60 */       worldInfoIterator.remove();
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\WorldChunkLoader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */