/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class PlayerInfo
/*    */ {
/*    */   private String _name;
/*    */   private UUID _uuid;
/*    */   
/*    */   public PlayerInfo(String name, UUID uuid)
/*    */   {
/* 12 */     this._name = name;
/* 13 */     this._uuid = uuid;
/*    */   }
/*    */   
/*    */   public String getName()
/*    */   {
/* 18 */     return this._name;
/*    */   }
/*    */   
/*    */   public UUID getUUID()
/*    */   {
/* 23 */     return this._uuid;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\PlayerInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */