/*    */ package mineplex.core.common.util;
/*    */ 
/*    */ import org.bukkit.Note;
/*    */ 
/*    */ public class UtilSound
/*    */ {
/*    */   public static float GetPitch(Note note)
/*    */   {
/*  9 */     int o = note.getOctave();
/* 10 */     switch (note.getTone()) {
/*    */     case G: 
/* 12 */       if (note.isSharped()) {
/* 13 */         switch (o) {
/* 14 */         case 0:  return 0.5F;
/* 15 */         case 1:  return 1.0F;
/* 16 */         case 2:  return 2.0F;
/*    */         }
/*    */       } else {
/* 19 */         switch (o) {
/* 20 */         case 0:  return 0.943874F;
/* 21 */         case 1:  return 1.887749F;
/*    */         }
/*    */       }
/* 24 */       break;
/*    */     case A: 
/* 26 */       if (note.isSharped()) {
/* 27 */         switch (o) {
/* 28 */         case 0:  return 0.561231F;
/* 29 */         case 1:  return 1.122462F;
/*    */         }
/*    */       } else {
/* 32 */         switch (o) {
/* 33 */         case 0:  return 0.529732F;
/* 34 */         case 1:  return 1.059463F;
/*    */         }
/*    */       }
/* 37 */       break;
/*    */     case B: 
/* 39 */       if (note.isSharped()) {
/* 40 */         switch (o) {
/* 41 */         case 0:  return 0.629961F;
/* 42 */         case 1:  return 1.259921F;
/*    */         }
/*    */       } else {
/* 45 */         switch (o) {
/* 46 */         case 0:  return 0.594604F;
/* 47 */         case 1:  return 1.189207F;
/*    */         }
/*    */       }
/* 50 */       break;
/*    */     case C: 
/* 52 */       switch (o) {
/* 53 */       case 0:  return 0.66742F;
/* 54 */       case 1:  return 1.33484F;
/*    */       }
/* 56 */       break;
/*    */     case D: 
/* 58 */       if (note.isSharped()) {
/* 59 */         switch (o) {
/* 60 */         case 0:  return 0.749154F;
/* 61 */         case 1:  return 1.498307F;
/*    */         }
/*    */       } else {
/* 64 */         switch (o) {
/* 65 */         case 0:  return 0.707107F;
/* 66 */         case 1:  return 1.414214F;
/*    */         }
/*    */       }
/* 69 */       break;
/*    */     
/*    */     case E: 
/* 72 */       if (note.isSharped()) {
/* 73 */         switch (o) {
/* 74 */         case 0:  return 0.840896F;
/* 75 */         case 1:  return 1.681793F;
/*    */         }
/*    */       } else {
/* 78 */         switch (o) {
/* 79 */         case 0:  return 0.793701F;
/* 80 */         case 1:  return 1.587401F;
/*    */         }
/*    */       }
/* 83 */       break;
/*    */     case F: 
/* 85 */       switch (o) {
/* 86 */       case 0:  return 0.890899F;
/* 87 */       case 1:  return 1.781797F;
/*    */       }
/*    */       break; }
/* 90 */     return -1.0F;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilSound.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */