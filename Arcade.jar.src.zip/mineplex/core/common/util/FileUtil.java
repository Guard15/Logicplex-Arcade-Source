/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class FileUtil
/*     */ {
/*     */   public static void DeleteFolder(File folder)
/*     */   {
/*  14 */     if (!folder.exists())
/*     */     {
/*  16 */       System.out.println("Delete target does not exist: " + folder);
/*  17 */       return;
/*     */     }
/*     */     
/*     */ 
/*  21 */     File[] files = folder.listFiles();
/*     */     
/*  23 */     if (files != null) {
/*     */       File[] arrayOfFile1;
/*  25 */       int j = (arrayOfFile1 = files).length; for (int i = 0; i < j; i++) { File f = arrayOfFile1[i];
/*     */         
/*  27 */         if (f.isDirectory()) {
/*  28 */           DeleteFolder(f);
/*     */         }
/*     */         else {
/*  31 */           f.delete();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  36 */     folder.delete();
/*     */   }
/*     */   
/*     */   public static void CopyToDirectory(File file, String outputDirectory)
/*     */   {
/*  41 */     FileInputStream fileInputStream = null;
/*  42 */     FileOutputStream fileOutputStream = null;
/*  43 */     BufferedOutputStream bufferedOutputStream = null;
/*  44 */     BufferedInputStream bufferedInputStream = null;
/*     */     
/*     */     try
/*     */     {
/*  48 */       fileInputStream = new FileInputStream(file);
/*  49 */       bufferedInputStream = new BufferedInputStream(fileInputStream);
/*     */       
/*     */ 
/*  52 */       byte[] buffer = new byte['ࠀ'];
/*     */       
/*  54 */       fileOutputStream = new FileOutputStream(outputDirectory + "\\" + file.getName());
/*  55 */       bufferedOutputStream = new BufferedOutputStream(fileOutputStream, buffer.length);
/*     */       int size;
/*  57 */       while ((size = bufferedInputStream.read(buffer, 0, buffer.length)) != -1) {
/*     */         int size;
/*  59 */         bufferedOutputStream.write(buffer, 0, size);
/*     */       }
/*     */       
/*  62 */       bufferedOutputStream.flush();
/*  63 */       bufferedOutputStream.close();
/*  64 */       fileOutputStream.flush();
/*  65 */       fileOutputStream.close();
/*     */       
/*  67 */       bufferedInputStream.close();
/*  68 */       fileInputStream.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  72 */       e.printStackTrace();
/*     */       
/*  74 */       if (fileInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/*  78 */           fileInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/*  82 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/*  86 */       if (bufferedInputStream != null)
/*     */       {
/*     */         try
/*     */         {
/*  90 */           bufferedInputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/*  94 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/*  98 */       if (fileOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 102 */           fileOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 106 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 110 */       if (bufferedOutputStream != null)
/*     */       {
/*     */         try
/*     */         {
/* 114 */           bufferedOutputStream.close();
/*     */         }
/*     */         catch (IOException e1)
/*     */         {
/* 118 */           e1.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\FileUtil.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */