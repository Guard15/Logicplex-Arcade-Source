/*     */ package mineplex.core.common.util;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.InventoryAction;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.material.MaterialData;
/*     */ 
/*     */ public class UtilInv
/*     */ {
/*     */   private static Field _enchantmentNew;
/*     */   private static DullEnchantment _enchantment;
/*     */   
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  27 */       _enchantmentNew = org.bukkit.enchantments.Enchantment.class.getDeclaredField("acceptingNew");
/*  28 */       _enchantmentNew.setAccessible(true);
/*  29 */       _enchantmentNew.set(null, Boolean.valueOf(true));
/*     */       
/*  31 */       _enchantment = new DullEnchantment();
/*  32 */       org.bukkit.enchantments.EnchantmentWrapper.registerEnchantment(_enchantment);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  36 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void addDullEnchantment(ItemStack itemStack)
/*     */   {
/*  42 */     itemStack.addEnchantment(_enchantment, 1);
/*     */   }
/*     */   
/*     */   public static void removeDullEnchantment(ItemStack itemStack)
/*     */   {
/*  47 */     itemStack.removeEnchantment(_enchantment);
/*     */   }
/*     */   
/*     */   public static DullEnchantment getDullEnchantment()
/*     */   {
/*  52 */     return _enchantment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static boolean insert(Player player, ItemStack stack)
/*     */   {
/*  61 */     player.getInventory().addItem(new ItemStack[] { stack });
/*  62 */     player.updateInventory();
/*  63 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean contains(Player player, Material item, byte data, int required)
/*     */   {
/*  68 */     return contains(player, null, item, data, required);
/*     */   }
/*     */   
/*     */   public static boolean contains(Player player, String itemNameContains, Material item, byte data, int required)
/*     */   {
/*  73 */     return contains(player, itemNameContains, item, data, required, true, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean contains(Player player, String itemNameContains, Material item, byte data, int required, boolean checkArmor, boolean checkCursor)
/*     */   {
/*  79 */     for (ItemStack stack : getItems(player, checkArmor, checkCursor))
/*     */     {
/*  81 */       if (required <= 0)
/*     */       {
/*  83 */         return true;
/*     */       }
/*     */       
/*  86 */       if (stack != null)
/*     */       {
/*     */ 
/*  89 */         if (stack.getType() == item)
/*     */         {
/*     */ 
/*  92 */           if (stack.getAmount() > 0)
/*     */           {
/*     */ 
/*  95 */             if ((data < 0) || 
/*  96 */               (stack.getData() == null) || (stack.getData().getData() == data))
/*     */             {
/*     */ 
/*  99 */               if ((itemNameContains == null) || (
/* 100 */                 (stack.getItemMeta().getDisplayName() != null) && (stack.getItemMeta().getDisplayName().contains(itemNameContains))))
/*     */               {
/*     */ 
/* 103 */                 required -= stack.getAmount(); } } } }
/*     */       }
/*     */     }
/* 106 */     if (required <= 0)
/*     */     {
/* 108 */       return true;
/*     */     }
/*     */     
/* 111 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean remove(Player player, Material item, byte data, int toRemove)
/*     */   {
/* 117 */     if (!contains(player, item, data, toRemove)) {
/* 118 */       return false;
/*     */     }
/* 120 */     for (Iterator localIterator = player.getInventory().all(item).keySet().iterator(); localIterator.hasNext();) { int i = ((Integer)localIterator.next()).intValue();
/*     */       
/* 122 */       if (toRemove > 0)
/*     */       {
/*     */ 
/* 125 */         ItemStack stack = player.getInventory().getItem(i);
/*     */         
/* 127 */         if ((stack.getData() == null) || (stack.getData().getData() == data))
/*     */         {
/* 129 */           int foundAmount = stack.getAmount();
/*     */           
/* 131 */           if (toRemove >= foundAmount)
/*     */           {
/* 133 */             toRemove -= foundAmount;
/* 134 */             player.getInventory().setItem(i, null);
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 139 */             stack.setAmount(foundAmount - toRemove);
/* 140 */             player.getInventory().setItem(i, stack);
/* 141 */             toRemove = 0;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 146 */     player.updateInventory();
/* 147 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void Clear(Player player)
/*     */   {
/* 154 */     PlayerInventory inv = player.getInventory();
/*     */     
/* 156 */     inv.clear();
/* 157 */     inv.setArmorContents(new ItemStack[4]);
/* 158 */     player.setItemOnCursor(new ItemStack(Material.AIR));
/*     */     
/* 160 */     player.saveData();
/*     */   }
/*     */   
/*     */   public static ArrayList<ItemStack> getItems(Player player)
/*     */   {
/* 165 */     return getItems(player, true, true);
/*     */   }
/*     */   
/*     */   public static ArrayList<ItemStack> getItems(Player player, boolean getArmor, boolean getCursor)
/*     */   {
/* 170 */     ArrayList<ItemStack> items = new ArrayList();
/* 171 */     PlayerInventory inv = player.getInventory();
/*     */     ItemStack[] arrayOfItemStack;
/* 173 */     int j = (arrayOfItemStack = inv.getContents()).length; for (int i = 0; i < j; i++) { ItemStack item = arrayOfItemStack[i];
/*     */       
/* 175 */       if ((item != null) && (item.getType() != Material.AIR))
/*     */       {
/* 177 */         items.add(item.clone());
/*     */       }
/*     */     }
/*     */     
/* 181 */     if (getArmor)
/*     */     {
/* 183 */       j = (arrayOfItemStack = inv.getArmorContents()).length; for (i = 0; i < j; i++) { ItemStack item = arrayOfItemStack[i];
/*     */         
/* 185 */         if ((item != null) && (item.getType() != Material.AIR))
/*     */         {
/* 187 */           items.add(item.clone());
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 192 */     if (getCursor)
/*     */     {
/* 194 */       ItemStack cursorItem = player.getItemOnCursor();
/*     */       
/* 196 */       if ((cursorItem != null) && (cursorItem.getType() != Material.AIR)) {
/* 197 */         items.add(cursorItem.clone());
/*     */       }
/*     */     }
/* 200 */     return items;
/*     */   }
/*     */   
/*     */   public static void drop(Player player, boolean clear)
/*     */   {
/* 205 */     for (ItemStack cur : getItems(player))
/*     */     {
/* 207 */       player.getWorld().dropItemNaturally(player.getLocation(), cur);
/*     */     }
/*     */     
/* 210 */     if (clear) {
/* 211 */       Clear(player);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void Update(Entity player)
/*     */   {
/* 217 */     if (!(player instanceof Player)) {
/* 218 */       return;
/*     */     }
/* 220 */     ((Player)player).updateInventory();
/*     */   }
/*     */   
/*     */   public static int removeAll(Player player, Material type, byte data)
/*     */   {
/* 225 */     HashSet<ItemStack> remove = new HashSet();
/* 226 */     int count = 0;
/*     */     ItemStack[] arrayOfItemStack;
/* 228 */     int j = (arrayOfItemStack = player.getInventory().getContents()).length; for (int i = 0; i < j; i++) { ItemStack item = arrayOfItemStack[i];
/* 229 */       if ((item != null) && 
/* 230 */         (item.getType() == type) && (
/* 231 */         (data == -1) || (item.getData() == null) || ((item.getData() != null) && (item.getData().getData() == data))))
/*     */       {
/* 233 */         count += item.getAmount();
/* 234 */         remove.add(item);
/*     */       }
/*     */     }
/* 237 */     for (ItemStack item : remove) {
/* 238 */       player.getInventory().remove(item);
/*     */     }
/* 240 */     return count;
/*     */   }
/*     */   
/*     */   public static byte GetData(ItemStack stack)
/*     */   {
/* 245 */     if (stack == null) {
/* 246 */       return 0;
/*     */     }
/* 248 */     if (stack.getData() == null) {
/* 249 */       return 0;
/*     */     }
/* 251 */     return stack.getData().getData();
/*     */   }
/*     */   
/*     */   public static boolean IsItem(ItemStack item, Material type, byte data)
/*     */   {
/* 256 */     return IsItem(item, null, type.getId(), data);
/*     */   }
/*     */   
/*     */   public static boolean IsItem(ItemStack item, String name, Material type, byte data)
/*     */   {
/* 261 */     return IsItem(item, name, type.getId(), data);
/*     */   }
/*     */   
/*     */   public static boolean IsItem(ItemStack item, String name, int id, byte data)
/*     */   {
/* 266 */     if (item == null) {
/* 267 */       return false;
/*     */     }
/* 269 */     if (item.getTypeId() != id) {
/* 270 */       return false;
/*     */     }
/* 272 */     if ((data != -1) && (GetData(item) != data)) {
/* 273 */       return false;
/*     */     }
/* 275 */     if ((name != null) && ((item.getItemMeta().getDisplayName() == null) || (!item.getItemMeta().getDisplayName().contains(name)))) {
/* 276 */       return false;
/*     */     }
/* 278 */     return true;
/*     */   }
/*     */   
/*     */   public static void DisallowMovementOf(InventoryClickEvent event, String name, Material type, byte data, boolean inform)
/*     */   {
/* 283 */     DisallowMovementOf(event, name, type, data, inform, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void DisallowMovementOf(InventoryClickEvent event, String name, Material type, byte data, boolean inform, boolean allInventorties)
/*     */   {
/* 306 */     if ((!allInventorties) && (event.getInventory().getType() == org.bukkit.event.inventory.InventoryType.CRAFTING)) {
/* 307 */       return;
/*     */     }
/*     */     
/* 310 */     if ((event.getAction() == InventoryAction.HOTBAR_SWAP) || 
/* 311 */       (event.getAction() == InventoryAction.HOTBAR_MOVE_AND_READD))
/*     */     {
/* 313 */       boolean match = false;
/*     */       
/* 315 */       if (IsItem(event.getCurrentItem(), name, type, data)) {
/* 316 */         match = true;
/*     */       }
/* 318 */       if (IsItem(event.getWhoClicked().getInventory().getItem(event.getHotbarButton()), name, type, data)) {
/* 319 */         match = true;
/*     */       }
/* 321 */       if (!match) {
/* 322 */         return;
/*     */       }
/*     */       
/* 325 */       UtilPlayer.message(event.getWhoClicked(), F.main("Inventory", "You cannot hotbar swap " + F.item(name) + "."));
/* 326 */       event.setCancelled(true);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 331 */       if (event.getCurrentItem() == null) {
/* 332 */         return;
/*     */       }
/* 334 */       IsItem(event.getCurrentItem(), name, type, data);
/*     */       
/*     */ 
/* 337 */       if (!IsItem(event.getCurrentItem(), name, type, data)) {
/* 338 */         return;
/*     */       }
/* 340 */       UtilPlayer.message(event.getWhoClicked(), F.main("Inventory", "You cannot move " + F.item(name) + "."));
/* 341 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void UseItemInHand(Player player)
/*     */   {
/* 347 */     if (player.getItemInHand().getAmount() > 1) {
/* 348 */       player.getItemInHand().setAmount(player.getItemInHand().getAmount() - 1);
/*     */     } else {
/* 350 */       player.setItemInHand(null);
/*     */     }
/* 352 */     Update(player);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\util\UtilInv.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */