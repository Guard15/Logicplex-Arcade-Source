/*    */ package mineplex.core.common;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.Entity;
/*    */ import net.minecraft.server.v1_7_R4.NBTTagCompound;
/*    */ import net.minecraft.server.v1_7_R4.World;
/*    */ 
/*    */ public class DummyEntity extends Entity
/*    */ {
/*    */   public DummyEntity(World world)
/*    */   {
/* 11 */     super(world);
/*    */   }
/*    */   
/*    */   protected void c() {}
/*    */   
/*    */   protected void a(NBTTagCompound nbttagcompound) {}
/*    */   
/*    */   protected void b(NBTTagCompound nbttagcompound) {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\DummyEntity.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */