/*    */ package mineplex.core.common;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Pair<L, R>
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -7631968541502978704L;
/*    */   private L left;
/*    */   private R right;
/*    */   
/*    */   public static <L, R> Pair<L, R> create(L left, R right)
/*    */   {
/* 14 */     return new Pair(left, right);
/*    */   }
/*    */   
/*    */   private Pair(L left, R right) {
/* 18 */     setLeft(left);
/* 19 */     setRight(right);
/*    */   }
/*    */   
/*    */   public L getLeft()
/*    */   {
/* 24 */     return (L)this.left;
/*    */   }
/*    */   
/*    */   public void setLeft(L left)
/*    */   {
/* 29 */     this.left = left;
/*    */   }
/*    */   
/*    */   public R getRight()
/*    */   {
/* 34 */     return (R)this.right;
/*    */   }
/*    */   
/*    */   public void setRight(R right)
/*    */   {
/* 39 */     this.right = right;
/*    */   }
/*    */   
/*    */ 
/*    */   public String toString()
/*    */   {
/* 45 */     return getLeft().toString() + ":" + getRight().toString();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 52 */     if (this == obj)
/* 53 */       return true;
/* 54 */     if (!(obj instanceof Pair)) {
/* 55 */       return false;
/*    */     }
/* 57 */     Pair localPair = (Pair)obj;
/*    */     
/* 59 */     if (getLeft() != null ? !getLeft().equals(localPair.getLeft()) : localPair.getLeft() != null)
/* 60 */       return false;
/* 61 */     if (getRight() != null ? !getRight().equals(localPair.getRight()) : localPair.getRight() != null)
/* 62 */       return false;
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\common\Pair.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */