/*    */ package mineplex.core.database;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.file.Files;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.sql.DataSource;
/*    */ import mineplex.serverdata.servers.ConnectionData;
/*    */ import org.apache.commons.dbcp2.BasicDataSource;
/*    */ 
/*    */ public final class DBPool
/*    */ {
/* 14 */   public static final DataSource ACCOUNT = getDs("Account");
/* 15 */   public static final DataSource QUEUE = getDs("Queue");
/* 16 */   public static final DataSource MINEPLEX = getDs("Mineplex");
/* 17 */   public static final DataSource STATS_MINEPLEX = getDs("Stats_Mineplex");
/*    */   
/*    */   private static String getLine(Integer lineNo)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       File configFile = new File("mysql-config.dat");
/* 24 */       if (configFile.exists())
/*    */       {
/* 26 */         List<ConnectionData> connections = new ArrayList();
/* 27 */         List<String> lines = Files.readAllLines(configFile.toPath(), Charset.defaultCharset());
/* 28 */         return (String)lines.get(lineNo.intValue());
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 33 */       return "Failed to parse";
/*    */     }
/* 35 */     return "sht";
/*    */   }
/*    */   
/*    */   public static String getUrl()
/*    */   {
/* 40 */     return "jdbc:mysql://" + getLine(Integer.valueOf(0));
/*    */   }
/*    */   
/*    */   public static String getUser()
/*    */   {
/* 45 */     return getLine(Integer.valueOf(1));
/*    */   }
/*    */   
/*    */   public static String getPass()
/*    */   {
/* 50 */     return getLine(Integer.valueOf(2));
/*    */   }
/*    */   
/*    */   private static DataSource getDs(String part)
/*    */   {
/* 55 */     if (part == "Account") {
/* 56 */       return openDataSource(getUrl() + "/Account", getUser(), getPass());
/*    */     }
/* 58 */     if (part == "Queue") {
/* 59 */       return openDataSource(getUrl() + "/Queue", getUser(), getPass());
/*    */     }
/* 61 */     if (part == "Mineplex") {
/* 62 */       return openDataSource(getUrl() + "/Mineplex", getUser(), getPass());
/*    */     }
/* 64 */     if (part == "Stats_Mineplex") {
/* 65 */       return openDataSource(getUrl() + "/Mineplex", getUser(), getPass());
/*    */     }
/* 67 */     return openDataSource(getUrl() + "/Account", getUser(), getPass());
/*    */   }
/*    */   
/*    */   private static DataSource openDataSource(String url, String username, String password)
/*    */   {
/* 72 */     BasicDataSource source = new BasicDataSource();
/* 73 */     source.addConnectionProperty("autoReconnect", "true");
/* 74 */     source.addConnectionProperty("allowMultiQueries", "true");
/* 75 */     source.setDefaultTransactionIsolation(2);
/* 76 */     source.setDriverClassName("com.mysql.jdbc.Driver");
/* 77 */     source.setUrl(url);
/* 78 */     source.setUsername(username);
/* 79 */     source.setPassword(password);
/* 80 */     source.setMaxTotal(4);
/* 81 */     source.setMaxIdle(4);
/* 82 */     source.setTimeBetweenEvictionRunsMillis(180000L);
/* 83 */     source.setSoftMinEvictableIdleTimeMillis(180000L);
/*    */     
/* 85 */     return source;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\DBPool.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */