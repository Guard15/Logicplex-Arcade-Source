/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnVarChar extends Column<String>
/*    */ {
/*  9 */   public int Length = 25;
/*    */   
/*    */   public ColumnVarChar(String name, int length)
/*    */   {
/* 13 */     this(name, length, "");
/*    */   }
/*    */   
/*    */   public ColumnVarChar(String name, int length, String value)
/*    */   {
/* 18 */     super(name);
/*    */     
/* 20 */     this.Length = length;
/* 21 */     this.Value = value;
/*    */   }
/*    */   
/*    */   public String getCreateString()
/*    */   {
/* 26 */     return this.Name + " VARCHAR(" + this.Length + ")";
/*    */   }
/*    */   
/*    */   public String getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 32 */     return resultSet.getString(this.Name);
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 38 */     preparedStatement.setString(columnNumber, (String)this.Value);
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnVarChar clone()
/*    */   {
/* 44 */     return new ColumnVarChar(this.Name, this.Length, (String)this.Value);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnVarChar.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */