/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnByte extends Column<Byte>
/*    */ {
/*    */   public ColumnByte(String name)
/*    */   {
/* 11 */     super(name);
/* 12 */     this.Value = Byte.valueOf((byte)0);
/*    */   }
/*    */   
/*    */   public ColumnByte(String name, Byte value)
/*    */   {
/* 17 */     super(name, value);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 23 */     return this.Name + " TINYINT";
/*    */   }
/*    */   
/*    */   public Byte getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 29 */     return Byte.valueOf(resultSet.getByte(this.Name));
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 35 */     preparedStatement.setLong(columnNumber, ((Byte)this.Value).byteValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnByte clone()
/*    */   {
/* 41 */     return new ColumnByte(this.Name, (Byte)this.Value);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnByte.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */