/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnBoolean extends Column<Boolean>
/*    */ {
/*    */   public ColumnBoolean(String name)
/*    */   {
/* 11 */     super(name);
/*    */   }
/*    */   
/*    */   public ColumnBoolean(String name, boolean value)
/*    */   {
/* 16 */     super(name, Boolean.valueOf(value));
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 22 */     return this.Name + " BOOLEAN";
/*    */   }
/*    */   
/*    */   public Boolean getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 28 */     return Boolean.valueOf(resultSet.getBoolean(this.Name));
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 34 */     preparedStatement.setBoolean(columnNumber, ((Boolean)this.Value).booleanValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnBoolean clone()
/*    */   {
/* 40 */     return new ColumnBoolean(this.Name, ((Boolean)this.Value).booleanValue());
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnBoolean.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */