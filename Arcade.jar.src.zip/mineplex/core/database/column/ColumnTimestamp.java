/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class ColumnTimestamp extends Column<Timestamp>
/*    */ {
/*    */   public ColumnTimestamp(String name)
/*    */   {
/* 12 */     super(name);
/*    */   }
/*    */   
/*    */   public ColumnTimestamp(String name, Timestamp value)
/*    */   {
/* 17 */     super(name, value);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 23 */     return this.Name + " TIMESTAMP";
/*    */   }
/*    */   
/*    */   public Timestamp getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 29 */     return resultSet.getTimestamp(this.Name);
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 35 */     preparedStatement.setTimestamp(columnNumber, (Timestamp)this.Value);
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnTimestamp clone()
/*    */   {
/* 41 */     return new ColumnTimestamp(this.Name, (Timestamp)this.Value);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnTimestamp.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */