/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnLong extends Column<Long>
/*    */ {
/*    */   public ColumnLong(String name)
/*    */   {
/* 11 */     super(name);
/* 12 */     this.Value = Long.valueOf(0L);
/*    */   }
/*    */   
/*    */   public ColumnLong(String name, Long value)
/*    */   {
/* 17 */     super(name, value);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 23 */     return this.Name + " LONG";
/*    */   }
/*    */   
/*    */   public Long getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 29 */     return Long.valueOf(resultSet.getLong(this.Name));
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 35 */     preparedStatement.setLong(columnNumber, ((Long)this.Value).longValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnLong clone()
/*    */   {
/* 41 */     return new ColumnLong(this.Name, (Long)this.Value);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnLong.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */