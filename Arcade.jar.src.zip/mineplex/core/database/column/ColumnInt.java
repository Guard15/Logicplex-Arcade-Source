/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnInt extends Column<Integer>
/*    */ {
/*    */   public ColumnInt(String name)
/*    */   {
/* 11 */     super(name);
/* 12 */     this.Value = Integer.valueOf(0);
/*    */   }
/*    */   
/*    */   public ColumnInt(String name, int value)
/*    */   {
/* 17 */     super(name, Integer.valueOf(value));
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 23 */     return this.Name + " INT";
/*    */   }
/*    */   
/*    */   public Integer getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 29 */     return Integer.valueOf(resultSet.getInt(this.Name));
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 35 */     preparedStatement.setInt(columnNumber, ((Integer)this.Value).intValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnInt clone()
/*    */   {
/* 41 */     return new ColumnInt(this.Name, ((Integer)this.Value).intValue());
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnInt.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */