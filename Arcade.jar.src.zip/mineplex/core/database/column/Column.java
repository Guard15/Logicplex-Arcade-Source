/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public abstract class Column<Type>
/*    */ {
/*    */   public String Name;
/*    */   public Type Value;
/*    */   
/*    */   public Column(String name)
/*    */   {
/* 14 */     this.Name = name;
/*    */   }
/*    */   
/*    */   public Column(String name, Type value)
/*    */   {
/* 19 */     this.Name = name;
/* 20 */     this.Value = value;
/*    */   }
/*    */   
/*    */   public abstract String getCreateString();
/*    */   
/*    */   public abstract Type getValue(ResultSet paramResultSet)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract void setValue(PreparedStatement paramPreparedStatement, int paramInt)
/*    */     throws SQLException;
/*    */   
/*    */   public abstract Column<Type> clone();
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\Column.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */