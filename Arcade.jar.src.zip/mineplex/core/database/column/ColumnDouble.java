/*    */ package mineplex.core.database.column;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ColumnDouble extends Column<Double>
/*    */ {
/*    */   public ColumnDouble(String name)
/*    */   {
/* 11 */     super(name);
/* 12 */     this.Value = Double.valueOf(0.0D);
/*    */   }
/*    */   
/*    */   public ColumnDouble(String name, Double value)
/*    */   {
/* 17 */     super(name, value);
/*    */   }
/*    */   
/*    */ 
/*    */   public String getCreateString()
/*    */   {
/* 23 */     return this.Name + " DOUBLE";
/*    */   }
/*    */   
/*    */   public Double getValue(ResultSet resultSet)
/*    */     throws SQLException
/*    */   {
/* 29 */     return Double.valueOf(resultSet.getDouble(this.Name));
/*    */   }
/*    */   
/*    */   public void setValue(PreparedStatement preparedStatement, int columnNumber)
/*    */     throws SQLException
/*    */   {
/* 35 */     preparedStatement.setDouble(columnNumber, ((Double)this.Value).doubleValue());
/*    */   }
/*    */   
/*    */ 
/*    */   public ColumnDouble clone()
/*    */   {
/* 41 */     return new ColumnDouble(this.Name, (Double)this.Value);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\column\ColumnDouble.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */