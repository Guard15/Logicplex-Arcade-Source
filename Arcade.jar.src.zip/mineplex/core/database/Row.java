/*    */ package mineplex.core.database;
/*    */ 
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ import mineplex.core.database.column.Column;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Row
/*    */ {
/* 10 */   public NautHashMap<String, Column<?>> Columns = new NautHashMap();
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\Row.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */