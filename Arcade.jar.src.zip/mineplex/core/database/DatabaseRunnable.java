/*    */ package mineplex.core.database;
/*    */ 
/*    */ 
/*    */ public class DatabaseRunnable
/*    */ {
/*    */   private Runnable _runnable;
/*    */   
/*  8 */   private int _failedAttempts = 0;
/*    */   
/*    */   public DatabaseRunnable(Runnable runnable) {
/* 11 */     this._runnable = runnable;
/*    */   }
/*    */   
/*    */   public void run() {
/* 15 */     this._runnable.run();
/*    */   }
/*    */   
/*    */   public void incrementFailCount() {
/* 19 */     this._failedAttempts += 1;
/*    */   }
/*    */   
/*    */   public int getFailedCounts() {
/* 23 */     return this._failedAttempts;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\DatabaseRunnable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */