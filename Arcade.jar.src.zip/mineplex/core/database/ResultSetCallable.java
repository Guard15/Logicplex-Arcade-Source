package mineplex.core.database;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface ResultSetCallable
{
  public abstract void processResultSet(ResultSet paramResultSet)
    throws SQLException;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\database\ResultSetCallable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */