/*    */ package mineplex.core.loot;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import mineplex.core.common.util.UtilMath;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ import org.bukkit.inventory.meta.ItemMeta.Spigot;
/*    */ 
/*    */ 
/*    */ public class ChestLoot
/*    */ {
/* 13 */   private ArrayList<RandomItem> _randomItems = new ArrayList();
/*    */   private int _totalLoot;
/*    */   private boolean _unbreakableLoot;
/*    */   
/*    */   public ChestLoot()
/*    */   {
/* 19 */     this(false);
/*    */   }
/*    */   
/*    */   public ChestLoot(boolean unbreakableLoot)
/*    */   {
/* 24 */     this._unbreakableLoot = unbreakableLoot;
/*    */   }
/*    */   
/*    */   public void cloneLoot(ChestLoot loot)
/*    */   {
/* 29 */     this._totalLoot += loot._totalLoot;
/* 30 */     this._randomItems.addAll(loot._randomItems);
/*    */   }
/*    */   
/*    */   public ItemStack getLoot()
/*    */   {
/* 35 */     int no = UtilMath.r(this._totalLoot);
/*    */     
/* 37 */     for (RandomItem item : this._randomItems)
/*    */     {
/* 39 */       no -= item.getAmount();
/*    */       
/* 41 */       if (no < 0)
/*    */       {
/* 43 */         ItemStack itemstack = item.getItemStack();
/*    */         
/* 45 */         if ((this._unbreakableLoot) && (itemstack.getType().getMaxDurability() > 16))
/*    */         {
/* 47 */           ItemMeta meta = itemstack.getItemMeta();
/* 48 */           meta.spigot().setUnbreakable(true);
/* 49 */           itemstack.setItemMeta(meta);
/*    */         }
/*    */         
/* 52 */         return itemstack;
/*    */       }
/*    */     }
/*    */     
/* 56 */     return null;
/*    */   }
/*    */   
/*    */   public void addLoot(ItemStack item, int amount)
/*    */   {
/* 61 */     addLoot(item, amount, item.getAmount(), item.getAmount());
/*    */   }
/*    */   
/*    */   public void addLoot(ItemStack item, int amount, int minStackSize, int maxStackSize)
/*    */   {
/* 66 */     addLoot(new RandomItem(item, amount, minStackSize, maxStackSize));
/*    */   }
/*    */   
/*    */   public void addLoot(Material material, int amount)
/*    */   {
/* 71 */     addLoot(material, amount, 1, 1);
/*    */   }
/*    */   
/*    */   public void addLoot(Material material, int amount, int minStackSize, int maxStackSize)
/*    */   {
/* 76 */     addLoot(new ItemStack(material), amount, minStackSize, maxStackSize);
/*    */   }
/*    */   
/*    */   public void addLoot(RandomItem item)
/*    */   {
/* 81 */     this._totalLoot += item.getAmount();
/* 82 */     this._randomItems.add(item);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\loot\ChestLoot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */