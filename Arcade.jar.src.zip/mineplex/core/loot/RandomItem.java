/*    */ package mineplex.core.loot;
/*    */ 
/*    */ import java.util.Random;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ public class RandomItem
/*    */ {
/*    */   private int _amount;
/*    */   private ItemStack _item;
/*    */   private int _min;
/*    */   private int _max;
/*    */   
/*    */   public RandomItem(ItemStack item, int amount)
/*    */   {
/* 16 */     this(item, amount, item.getAmount(), item.getAmount());
/*    */   }
/*    */   
/*    */   public RandomItem(ItemStack item, int amount, int minStackSize, int maxStackSize)
/*    */   {
/* 21 */     this._amount = amount;
/* 22 */     this._item = item;
/* 23 */     this._min = minStackSize;
/* 24 */     this._max = maxStackSize;
/*    */   }
/*    */   
/*    */   public RandomItem(Material material, int amount)
/*    */   {
/* 29 */     this(material, amount, 1, 1);
/*    */   }
/*    */   
/*    */   public RandomItem(Material material, int amount, int minStackSize, int maxStackSize)
/*    */   {
/* 34 */     this._amount = amount;
/* 35 */     this._item = new ItemStack(material);
/* 36 */     this._min = minStackSize;
/* 37 */     this._max = maxStackSize;
/*    */   }
/*    */   
/*    */   public int getAmount()
/*    */   {
/* 42 */     return this._amount;
/*    */   }
/*    */   
/*    */   public ItemStack getItemStack()
/*    */   {
/* 47 */     this._item.setAmount(new Random().nextInt(Math.max(1, this._max - this._min + 1)) + this._min);
/*    */     
/* 49 */     return this._item;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\loot\RandomItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */