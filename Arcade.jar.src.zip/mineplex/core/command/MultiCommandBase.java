/*    */ package mineplex.core.command;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MultiCommandBase<PluginType extends MiniPlugin>
/*    */   extends CommandBase<PluginType>
/*    */ {
/* 26 */   protected NautHashMap<String, ICommand> Commands = new NautHashMap();
/*    */   
/*    */   public MultiCommandBase(PluginType plugin, Rank rank, String... aliases) {
/* 29 */     super(plugin, rank, aliases);
/*    */   }
/*    */   
/*    */   public MultiCommandBase(PluginType plugin, Rank rank, Rank[] specificRanks, String... aliases) {
/* 33 */     super(plugin, rank, specificRanks, aliases);
/*    */   }
/*    */   
/*    */   public void AddCommand(ICommand command) {
/* 37 */     for (String commandRoot : command.Aliases()) {
/* 38 */       this.Commands.put(commandRoot, command);
/* 39 */       command.SetCommandCenter(this.CommandCenter);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 46 */     String commandName = null;
/* 47 */     String[] newArgs = null;
/* 48 */     if ((args != null) && (args.length > 0)) {
/* 49 */       commandName = args[0];
/* 50 */       if (args.length > 1) {
/* 51 */         newArgs = new String[args.length - 1];
/* 52 */         for (int i = 0; i < newArgs.length; i++)
/* 53 */           newArgs[i] = args[(i + 1)];
/*    */       }
/*    */     }
/*    */     ICommand command;
/* 57 */     if (((command = (ICommand)this.Commands.get(commandName)) != null) && (this.CommandCenter.ClientManager.Get(caller).GetRank().Has(caller, command.GetRequiredRank(), command.GetSpecificRanks(), true))) {
/* 58 */       command.SetAliasUsed(commandName);
/* 59 */       command.Execute(caller, newArgs);
/*    */     } else {
/* 61 */       Help(caller, args);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public List<String> onTabComplete(CommandSender sender, String commandLabel, String[] args)
/*    */   {
/* 69 */     if (args.length == 1) {
/* 70 */       ArrayList<String> possibleMatches = new ArrayList();
/* 71 */       for (ICommand command2 : this.Commands.values()) {
/* 72 */         possibleMatches.addAll(command2.Aliases());
/*    */       }
/* 74 */       return getMatches(args[0], possibleMatches); }
/*    */     String commandName;
/* 76 */     ICommand command; if ((args.length > 1) && ((command = (ICommand)this.Commands.get(commandName = args[0])) != null)) {
/* 77 */       return command.onTabComplete(sender, commandLabel, args);
/*    */     }
/* 79 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract void Help(Player paramPlayer, String[] paramArrayOfString);
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\command\MultiCommandBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */