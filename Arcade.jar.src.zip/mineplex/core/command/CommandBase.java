/*     */ package mineplex.core.command;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CommandBase<PluginType extends MiniPlugin>
/*     */   implements ICommand
/*     */ {
/*     */   private Rank _requiredRank;
/*     */   private Rank[] _specificRank;
/*     */   private List<String> _aliases;
/*     */   protected PluginType Plugin;
/*     */   protected String AliasUsed;
/*     */   protected CommandCenter CommandCenter;
/*     */   
/*     */   public CommandBase(PluginType plugin, Rank requiredRank, String... aliases)
/*     */   {
/*  33 */     this.Plugin = plugin;
/*  34 */     this._requiredRank = requiredRank;
/*  35 */     this._aliases = Arrays.asList(aliases);
/*     */   }
/*     */   
/*     */   public CommandBase(PluginType plugin, Rank requiredRank, Rank[] specificRank, String... aliases) {
/*  39 */     this.Plugin = plugin;
/*  40 */     this._requiredRank = requiredRank;
/*  41 */     this._specificRank = specificRank;
/*  42 */     this._aliases = Arrays.asList(aliases);
/*     */   }
/*     */   
/*     */   public Collection<String> Aliases()
/*     */   {
/*  47 */     return this._aliases;
/*     */   }
/*     */   
/*     */   public void SetAliasUsed(String alias)
/*     */   {
/*  52 */     this.AliasUsed = alias;
/*     */   }
/*     */   
/*     */   public Rank GetRequiredRank()
/*     */   {
/*  57 */     return this._requiredRank;
/*     */   }
/*     */   
/*     */   public Rank[] GetSpecificRanks()
/*     */   {
/*  62 */     return this._specificRank;
/*     */   }
/*     */   
/*     */   public void SetCommandCenter(CommandCenter commandCenter)
/*     */   {
/*  67 */     this.CommandCenter = commandCenter;
/*     */   }
/*     */   
/*     */   protected void resetCommandCharge(Player caller) {
/*  71 */     Recharge.Instance.recharge(caller, "Command");
/*     */   }
/*     */   
/*     */   public List<String> onTabComplete(CommandSender sender, String commandLabel, String[] args)
/*     */   {
/*  76 */     return null;
/*     */   }
/*     */   
/*     */   protected List<String> getMatches(String start, List<String> possibleMatches) {
/*  80 */     ArrayList<String> matches = new ArrayList();
/*  81 */     for (String possibleMatch : possibleMatches) {
/*  82 */       if (possibleMatch.toLowerCase().startsWith(start.toLowerCase()))
/*  83 */         matches.add(possibleMatch);
/*     */     }
/*  85 */     return matches;
/*     */   }
/*     */   
/*     */   protected List<String> getMatches(String start, Enum[] numerators) {
/*  89 */     ArrayList<String> matches = new ArrayList();
/*  90 */     Enum[] arrayOfEnum; int j = (arrayOfEnum = numerators).length; for (int i = 0; i < j; i++) { Enum e = arrayOfEnum[i];
/*  91 */       String s = e.toString();
/*  92 */       if (s.toLowerCase().startsWith(start.toLowerCase()))
/*  93 */         matches.add(s);
/*     */     }
/*  95 */     return matches;
/*     */   }
/*     */   
/*     */   protected List<String> getPlayerMatches(Player sender, String start) {
/*  99 */     ArrayList<String> matches = new ArrayList();
/* 100 */     Player[] arrayOfPlayer; int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 101 */       if ((sender.canSee(player)) && (player.getName().toLowerCase().startsWith(start.toLowerCase())))
/* 102 */         matches.add(player.getName());
/*     */     }
/* 104 */     return matches;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\command\CommandBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */