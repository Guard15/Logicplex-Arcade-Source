/*    */ package mineplex.core.benefit.benefits;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.benefit.BenefitManager;
/*    */ import mineplex.core.benefit.BenefitManagerRepository;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.scheduler.BukkitScheduler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BenefitBase
/*    */ {
/*    */   private BenefitManager _plugin;
/*    */   private String _name;
/*    */   private BenefitManagerRepository _repository;
/*    */   
/*    */   protected BenefitBase(BenefitManager plugin, String name, BenefitManagerRepository repository)
/*    */   {
/* 32 */     this._plugin = plugin;
/* 33 */     this._name = name;
/* 34 */     this._repository = repository;
/*    */   }
/*    */   
/*    */   public JavaPlugin getPlugin() {
/* 38 */     return this._plugin.getPlugin();
/*    */   }
/*    */   
/*    */   public BenefitManagerRepository getRepository() {
/* 42 */     return this._repository;
/*    */   }
/*    */   
/*    */   public abstract void rewardPlayer(Player paramPlayer);
/*    */   
/*    */   public void recordBenefit(final Player player, final Callback<Boolean> callback) {
/* 48 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(this._plugin.getPlugin(), new Runnable()
/*    */     {
/*    */       public void run()
/*    */       {
/* 52 */         boolean success = BenefitBase.this._repository.addBenefit(BenefitBase.this._plugin.getClientManager().Get(player).getAccountId(), BenefitBase.this._name);
/* 53 */         callback.run(Boolean.valueOf(success));
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public String getName() {
/* 59 */     return this._name;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\benefit\benefits\BenefitBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */