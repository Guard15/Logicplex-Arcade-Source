/*    */ package mineplex.core.benefit.benefits;
/*    */ 
/*    */ import mineplex.core.benefit.BenefitManager;
/*    */ import mineplex.core.benefit.BenefitManagerRepository;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.inventory.InventoryManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Players40k
/*    */   extends BenefitBase
/*    */ {
/*    */   private InventoryManager _inventoryManager;
/*    */   
/*    */   public Players40k(BenefitManager plugin, BenefitManagerRepository repository, InventoryManager inventoryManager)
/*    */   {
/* 25 */     super(plugin, "Players40k", repository);
/* 26 */     this._inventoryManager = inventoryManager;
/*    */   }
/*    */   
/*    */   public void rewardPlayer(final Player player)
/*    */   {
/* 31 */     this._inventoryManager.addItemToInventory(new Callback()
/*    */     {
/*    */       public void run(Boolean success)
/*    */       {
/* 35 */         if (success.booleanValue()) {
/* 36 */           UtilPlayer.message(player, C.cGold + C.Strike + "=============================================");
/* 37 */           UtilPlayer.message(player, "");
/* 38 */           UtilPlayer.message(player, "To celebrate hitting 40,000 players online,");
/* 39 */           UtilPlayer.message(player, "everyone receives a prize! You're awesome!");
/* 40 */           UtilPlayer.message(player, "");
/* 41 */           UtilPlayer.message(player, "You received 1 Ancient Chest!");
/* 42 */           UtilPlayer.message(player, "");
/* 43 */           UtilPlayer.message(player, C.cGold + C.Strike + "=============================================");
/*    */         }
/*    */       }
/* 46 */     }, player, "Treasure", "Ancient Chest", 1);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\benefit\benefits\Players40k.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */