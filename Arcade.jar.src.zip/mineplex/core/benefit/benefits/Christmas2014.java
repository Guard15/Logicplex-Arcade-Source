/*    */ package mineplex.core.benefit.benefits;
/*    */ 
/*    */ import mineplex.core.benefit.BenefitManager;
/*    */ import mineplex.core.benefit.BenefitManagerRepository;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.inventory.InventoryManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Christmas2014
/*    */   extends BenefitBase
/*    */ {
/*    */   private InventoryManager _inventoryManager;
/*    */   
/*    */   public Christmas2014(BenefitManager plugin, BenefitManagerRepository repository, InventoryManager inventoryManager)
/*    */   {
/* 25 */     super(plugin, "Christmas2014", repository);
/* 26 */     this._inventoryManager = inventoryManager;
/*    */   }
/*    */   
/*    */   public void rewardPlayer(final Player player)
/*    */   {
/* 31 */     this._inventoryManager.addItemToInventory(new Callback()
/*    */     {
/*    */       public void run(Boolean success)
/*    */       {
/* 35 */         if (success.booleanValue()) {
/* 36 */           UtilPlayer.message(player, C.cPurple + C.Strike + "=============================================");
/* 37 */           UtilPlayer.message(player, "");
/* 38 */           UtilPlayer.message(player, C.cRed + "MERRY CHRISTMAS");
/* 39 */           UtilPlayer.message(player, "You received 2 Treasure Keys!");
/* 40 */           UtilPlayer.message(player, "");
/* 41 */           UtilPlayer.message(player, C.cPurple + C.Strike + "=============================================");
/*    */         }
/*    */       }
/* 44 */     }, player, "Treasure", "Treasure Key", 2);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\benefit\benefits\Christmas2014.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */