/*    */ package mineplex.core.benefit;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BenefitData
/*    */ {
/*  9 */   public HashSet<String> Benefits = new HashSet();
/* 10 */   public boolean Loaded = false;
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\benefit\BenefitData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */