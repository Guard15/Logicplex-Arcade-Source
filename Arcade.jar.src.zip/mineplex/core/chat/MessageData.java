/*    */ package mineplex.core.chat;
/*    */ 
/*    */ 
/*    */ public class MessageData
/*    */ {
/*    */   private String _message;
/*    */   private long _timeSent;
/*    */   
/*    */   public MessageData(String message)
/*    */   {
/* 11 */     this(message, System.currentTimeMillis());
/*    */   }
/*    */   
/*    */   public MessageData(String message, long timeSent) {
/* 15 */     this._message = message;
/* 16 */     this._timeSent = timeSent;
/*    */   }
/*    */   
/*    */   public String getMessage() {
/* 20 */     return this._message;
/*    */   }
/*    */   
/*    */   public long getTimeSent() {
/* 24 */     return this._timeSent;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\MessageData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */