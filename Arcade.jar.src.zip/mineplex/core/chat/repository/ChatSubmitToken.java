/*    */ package mineplex.core.chat.repository;
/*    */ 
/*    */ 
/*    */ public class ChatSubmitToken
/*    */ {
/*    */   public String player_display_name;
/*    */   
/*    */   public String player;
/*    */   public String text;
/*    */   public String server;
/*    */   public String room;
/* 12 */   public String language = "en";
/*    */   public String rule;
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\repository\ChatSubmitToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */