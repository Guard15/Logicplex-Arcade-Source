package mineplex.core.chat.repository;

public class ChatClientToken {}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\repository\ChatClientToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */