package mineplex.core.chat.repository;

public class ChatEvent
{
  public String id;
  public String message;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\repository\ChatEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */