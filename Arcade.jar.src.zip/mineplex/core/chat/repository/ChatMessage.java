package mineplex.core.chat.repository;

public class ChatMessage
{
  public String PlayerName;
  public String Message;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\repository\ChatMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */