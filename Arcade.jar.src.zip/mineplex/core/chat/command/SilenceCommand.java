/*    */ package mineplex.core.chat.command;
/*    */ 
/*    */ import mineplex.core.chat.Chat;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SilenceCommand
/*    */   extends CommandBase<Chat>
/*    */ {
/*    */   public SilenceCommand(Chat plugin)
/*    */   {
/* 22 */     super(plugin, Rank.ADMIN, new String[] { "silence" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/*    */     try {
/* 28 */       if (args.length == 0) {
/* 29 */         if (((Chat)this.Plugin).Silenced() != 0L) {
/* 30 */           ((Chat)this.Plugin).Silence(0L, true);
/*    */         } else {
/* 32 */           ((Chat)this.Plugin).Silence(-1L, true);
/*    */         }
/*    */       } else {
/* 35 */         long time = (Double.valueOf(args[0]).doubleValue() * 3600000.0D);
/* 36 */         ((Chat)this.Plugin).Silence(time, true);
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 40 */       UtilPlayer.message(caller, F.main("Chat", "Invalid Time Parameter."));
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\command\SilenceCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */