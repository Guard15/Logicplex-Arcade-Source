/*    */ package mineplex.core.chat.command;
/*    */ 
/*    */ import mineplex.core.chat.Chat;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BroadcastCommand
/*    */   extends CommandBase<Chat>
/*    */ {
/*    */   public BroadcastCommand(Chat plugin)
/*    */   {
/* 18 */     super(plugin, Rank.MODERATOR, new String[] { "s" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 23 */     String announcement = "";
/* 24 */     String[] arrayOfString; int j = (arrayOfString = args).length; for (int i = 0; i < j; i++) { String arg = arrayOfString[i];
/* 25 */       announcement = announcement + arg + " ";
/*    */     }
/* 27 */     if (announcement.length() > 0) {
/* 28 */       announcement = announcement.substring(0, announcement.length() - 1);
/*    */     }
/* 30 */     UtilServer.broadcast(caller.getName(), announcement);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\command\BroadcastCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */