/*    */ package mineplex.core.chat.command;
/*    */ 
/*    */ import mineplex.core.chat.Chat;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChatSlowCommand
/*    */   extends CommandBase<Chat>
/*    */ {
/*    */   public ChatSlowCommand(Chat plugin)
/*    */   {
/* 22 */     super(plugin, Rank.SNR_MODERATOR, new String[] { "chatslow" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 27 */     if ((args != null) && (args.length == 1)) {
/*    */       try {
/* 29 */         int seconds = Integer.parseInt(args[0]);
/* 30 */         if (seconds < 0) {
/* 31 */           UtilPlayer.message(caller, F.main("Chat", "Seconds must be a positive integer"));
/* 32 */           return;
/*    */         }
/* 34 */         ((Chat)this.Plugin).setChatSlow(seconds, true);
/* 35 */         UtilPlayer.message(caller, F.main("Chat", "Set chat slow to " + F.time(new StringBuilder().append(seconds).append(" seconds").toString())));
/*    */       }
/*    */       catch (Exception e) {
/* 38 */         showUsage(caller);
/*    */       }
/*    */     }
/* 41 */     showUsage(caller);
/*    */   }
/*    */   
/*    */   private void showUsage(Player caller)
/*    */   {
/* 46 */     UtilPlayer.message(caller, F.main("Chat", "Usage: /chatslow <seconds>"));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\chat\command\ChatSlowCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */