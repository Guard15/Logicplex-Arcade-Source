/*      */ package mineplex.core.disguise;
/*      */ 
/*      */ import java.lang.reflect.Field;
/*      */ import java.util.AbstractMap.SimpleEntry;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.UUID;
/*      */ import mineplex.core.MiniPlugin;
/*      */ import mineplex.core.common.util.NautHashMap;
/*      */ import mineplex.core.common.util.UtilEnt;
/*      */ import mineplex.core.common.util.UtilPlayer;
/*      */ import mineplex.core.disguise.disguises.DisguiseBase;
/*      */ import mineplex.core.disguise.disguises.DisguiseBlock;
/*      */ import mineplex.core.disguise.disguises.DisguiseInsentient;
/*      */ import mineplex.core.disguise.disguises.DisguiseLiving;
/*      */ import mineplex.core.disguise.disguises.DisguisePlayer;
/*      */ import mineplex.core.disguise.disguises.DisguiseRabbit;
/*      */ import mineplex.core.packethandler.PacketHandler;
/*      */ import mineplex.core.packethandler.PacketInfo;
/*      */ import mineplex.core.packethandler.PacketVerifier;
/*      */ import mineplex.core.timing.TimingManager;
/*      */ import mineplex.core.updater.UpdateType;
/*      */ import mineplex.core.updater.event.UpdateEvent;
/*      */ import net.minecraft.server.v1_7_R4.ChunkAddEntityEvent;
/*      */ import net.minecraft.server.v1_7_R4.ChunkSection;
/*      */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*      */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*      */ import net.minecraft.server.v1_7_R4.EntityTrackerEntry;
/*      */ import net.minecraft.server.v1_7_R4.IntHashMap;
/*      */ import net.minecraft.server.v1_7_R4.Packet;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutAnimation;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutBed;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityDestroy;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityEquipment;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityMetadata;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityStatus;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityTeleport;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityVelocity;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutMapChunk;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutNamedEntitySpawn;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutNamedSoundEffect;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutPlayerInfo;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutRelEntityMove;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutRelEntityMoveLook;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntity;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*      */ import net.minecraft.server.v1_7_R4.PacketPlayOutUpdateAttributes;
/*      */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*      */ import net.minecraft.server.v1_7_R4.WorldServer;
/*      */ import org.bukkit.Bukkit;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.Material;
/*      */ import org.bukkit.Server;
/*      */ import org.bukkit.World;
/*      */ import org.bukkit.block.BlockFace;
/*      */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*      */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*      */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*      */ import org.bukkit.entity.LivingEntity;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.EventPriority;
/*      */ import org.bukkit.event.player.PlayerChangedWorldEvent;
/*      */ import org.bukkit.event.player.PlayerJoinEvent;
/*      */ import org.bukkit.event.player.PlayerMoveEvent;
/*      */ import org.bukkit.event.player.PlayerQuitEvent;
/*      */ import org.bukkit.event.player.PlayerTeleportEvent;
/*      */ import org.bukkit.event.world.ChunkUnloadEvent;
/*      */ import org.bukkit.plugin.java.JavaPlugin;
/*      */ import org.bukkit.scheduler.BukkitScheduler;
/*      */ 
/*      */ public class DisguiseManager extends MiniPlugin implements mineplex.core.packethandler.IPacketHandler
/*      */ {
/*   80 */   private NautHashMap<Integer, DisguiseBase> _spawnPacketMap = new NautHashMap();
/*   81 */   private NautHashMap<Integer, PacketPlayOutEntityVelocity> _movePacketMap = new NautHashMap();
/*   82 */   private NautHashMap<Integer, PacketPlayOutEntityVelocity> _moveTempMap = new NautHashMap();
/*   83 */   private HashSet<Integer> _goingUp = new HashSet();
/*   84 */   private NautHashMap<String, DisguiseBase> _entityDisguiseMap = new NautHashMap();
/*   85 */   private NautHashMap<DisguiseBase, HashSet<Player>> _disguisePlayerMap = new NautHashMap();
/*   86 */   private HashSet<String> _blockedNames = new HashSet();
/*   87 */   private NautHashMap<Integer, Map.Entry<DisguiseBase, Player[]>> _futureDisguises = new NautHashMap();
/*   88 */   private NautHashMap<Integer, NautHashMap<Integer, Long>> _lastRabbitHop = new NautHashMap();
/*      */   
/*   90 */   private boolean _handlingPacket = false;
/*      */   
/*      */   private Field _attributesA;
/*      */   
/*      */   private Field _attributesB;
/*      */   private Field _soundB;
/*      */   private Field _soundC;
/*      */   private Field _soundD;
/*      */   private Field _bedA;
/*      */   private Field _bedB;
/*      */   private Field _bedD;
/*      */   private Field _xChunk;
/*      */   private Field _zChunk;
/*      */   private Field _eStatusId;
/*      */   private Field _eStatusState;
/*      */   private net.minecraft.server.v1_7_R4.Chunk _bedChunk;
/*      */   private boolean _bedPackets;
/*      */   
/*      */   public DisguiseManager(JavaPlugin plugin, PacketHandler packetHandler)
/*      */   {
/*  110 */     super("Disguise Manager", plugin);
/*      */     
/*  112 */     packetHandler.addPacketHandler(this);
/*      */     
/*      */     try
/*      */     {
/*  116 */       this._attributesA = PacketPlayOutUpdateAttributes.class.getDeclaredField("a");
/*  117 */       this._attributesA.setAccessible(true);
/*  118 */       this._attributesB = PacketPlayOutUpdateAttributes.class.getDeclaredField("b");
/*  119 */       this._attributesB.setAccessible(true);
/*  120 */       this._soundB = PacketPlayOutNamedSoundEffect.class.getDeclaredField("b");
/*  121 */       this._soundB.setAccessible(true);
/*  122 */       this._soundC = PacketPlayOutNamedSoundEffect.class.getDeclaredField("c");
/*  123 */       this._soundC.setAccessible(true);
/*  124 */       this._soundD = PacketPlayOutNamedSoundEffect.class.getDeclaredField("d");
/*  125 */       this._soundD.setAccessible(true);
/*  126 */       this._bedA = PacketPlayOutBed.class.getDeclaredField("a");
/*  127 */       this._bedA.setAccessible(true);
/*  128 */       this._bedB = PacketPlayOutBed.class.getDeclaredField("b");
/*  129 */       this._bedB.setAccessible(true);
/*  130 */       this._bedD = PacketPlayOutBed.class.getDeclaredField("d");
/*  131 */       this._bedD.setAccessible(true);
/*  132 */       this._eStatusId = PacketPlayOutEntityStatus.class.getDeclaredField("a");
/*  133 */       this._eStatusId.setAccessible(true);
/*  134 */       this._eStatusState = PacketPlayOutEntityStatus.class.getDeclaredField("b");
/*  135 */       this._eStatusState.setAccessible(true);
/*      */       
/*  137 */       this._bedChunk = new net.minecraft.server.v1_7_R4.Chunk(null, 0, 0);
/*  138 */       Field cSection = net.minecraft.server.v1_7_R4.Chunk.class.getDeclaredField("sections");
/*  139 */       cSection.setAccessible(true);
/*      */       
/*  141 */       ChunkSection chunkSection = new ChunkSection(0, false);
/*  142 */       net.minecraft.server.v1_7_R4.Block block = net.minecraft.server.v1_7_R4.Block.getById(Material.BED_BLOCK.getId());
/*      */       
/*      */ 
/*      */ 
/*      */       BlockFace[] arrayOfBlockFace;
/*      */       
/*      */ 
/*  149 */       int j = (arrayOfBlockFace = new BlockFace[] { BlockFace.EAST, BlockFace.WEST, BlockFace.NORTH, BlockFace.SOUTH }).length; for (int i = 0; i < j; i++)
/*      */       {
/*  149 */         BlockFace face = arrayOfBlockFace[i];
/*      */         
/*      */ 
/*  152 */         chunkSection.setTypeId(1 + face.getModX(), 0, 1 + face.getModZ(), block);
/*  153 */         chunkSection.setData(1 + face.getModX(), 0, 1 + face.getModZ(), face.ordinal());
/*  154 */         chunkSection.setSkyLight(1 + face.getModX(), 0, 1 + face.getModZ(), 0);
/*  155 */         chunkSection.setEmittedLight(1 + face.getModX(), 0, 1 + face.getModZ(), 0);
/*      */       }
/*      */       
/*  158 */       ChunkSection[] chunkSections = new ChunkSection[16];
/*  159 */       chunkSections[0] = chunkSection;
/*  160 */       cSection.set(this._bedChunk, chunkSections);
/*      */       
/*  162 */       this._bedChunk.world = ((CraftWorld)Bukkit.getWorlds().get(0)).getHandle();
/*      */       
/*  164 */       this._xChunk = net.minecraft.server.v1_7_R4.Chunk.class.getField("locX");
/*  165 */       this._xChunk.setAccessible(true);
/*      */       
/*  167 */       this._zChunk = net.minecraft.server.v1_7_R4.Chunk.class.getField("locZ");
/*  168 */       this._zChunk.setAccessible(true);
/*      */     }
/*      */     catch (IllegalArgumentException e)
/*      */     {
/*  172 */       e.printStackTrace();
/*      */     }
/*      */     catch (NoSuchFieldException e)
/*      */     {
/*  176 */       e.printStackTrace();
/*      */     }
/*      */     catch (SecurityException e)
/*      */     {
/*  180 */       e.printStackTrace();
/*      */     }
/*      */     catch (IllegalAccessException e)
/*      */     {
/*  184 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   public void addFutureDisguise(DisguiseBase disguise, Player... players)
/*      */   {
/*  190 */     final int entityId = UtilEnt.getNewEntityId(false);
/*      */     
/*  192 */     this._futureDisguises.put(Integer.valueOf(entityId), new AbstractMap.SimpleEntry(disguise, players));
/*      */     
/*  194 */     Bukkit.getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */     {
/*      */       public void run()
/*      */       {
/*  198 */         if (DisguiseManager.this._futureDisguises.containsKey(Integer.valueOf(entityId)))
/*      */         {
/*  200 */           Map.Entry<DisguiseBase, Player[]> entry = (Map.Entry)DisguiseManager.this._futureDisguises.remove(Integer.valueOf(entityId));
/*      */           
/*  202 */           org.bukkit.entity.Entity entity = UtilEnt.getEntityById(entityId);
/*      */           
/*  204 */           if (entity != null)
/*      */           {
/*  206 */             ((DisguiseBase)entry.getKey()).setEntity(entity);
/*      */             
/*  208 */             DisguiseManager.this.disguise((DisguiseBase)entry.getKey(), (Player[])entry.getValue());
/*      */           }
/*      */         }
/*      */       }
/*  212 */     }, 4L);
/*      */   }
/*      */   
/*      */   public void addViewerToDisguise(DisguiseBase disguise, Player player, boolean reapply)
/*      */   {
/*  217 */     ((HashSet)this._disguisePlayerMap.get(disguise)).add(player);
/*      */     
/*  219 */     if (reapply) {
/*  220 */       refreshTrackers(disguise.GetEntity().getBukkitEntity(), 
/*  221 */         new Player[] {
/*  222 */         player });
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void ChunkAddEntity(ChunkAddEntityEvent event)
/*      */   {
/*  229 */     DisguiseBase disguise = (DisguiseBase)this._entityDisguiseMap.get(event.GetEntity().getUniqueId().toString());
/*      */     
/*  231 */     if (disguise != null)
/*      */     {
/*  233 */       disguise.setEntity(event.GetEntity());
/*  234 */       this._spawnPacketMap.put(Integer.valueOf(event.GetEntity().getEntityId()), disguise);
/*  235 */       this._entityDisguiseMap.remove(event.GetEntity().getUniqueId().toString());
/*      */       
/*  237 */       if ((disguise instanceof DisguiseRabbit))
/*      */       {
/*  239 */         this._lastRabbitHop.put(Integer.valueOf(disguise.GetEntityId()), new NautHashMap());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void chunkJoin(PlayerJoinEvent event)
/*      */   {
/*  247 */     if (!this._bedPackets) {
/*  248 */       return;
/*      */     }
/*  250 */     chunkMove(event.getPlayer(), event.getPlayer().getLocation(), null);
/*      */   }
/*      */   
/*      */   private void chunkMove(Player player, Location newLoc, Location oldLoc)
/*      */   {
/*  255 */     for (Packet packet : getChunkMovePackets(player, newLoc, oldLoc))
/*      */     {
/*  257 */       UtilPlayer.sendPacket(player, new Packet[] { packet });
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*      */   public void chunkMove(PlayerMoveEvent event)
/*      */   {
/*  264 */     if (!this._bedPackets) {
/*  265 */       return;
/*      */     }
/*  267 */     Location to = event.getTo();
/*  268 */     Location from = event.getFrom();
/*      */     
/*  270 */     int x1 = getChunk(to.getX());
/*  271 */     int z1 = getChunk(to.getZ());
/*  272 */     int x2 = getChunk(from.getX());
/*  273 */     int z2 = getChunk(from.getZ());
/*      */     
/*  275 */     if ((x1 != x2) || (z1 != z2))
/*      */     {
/*  277 */       chunkMove(event.getPlayer(), to, from);
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*      */   public void chunkTeleport(PlayerTeleportEvent event)
/*      */   {
/*  284 */     if (!this._bedPackets) {
/*  285 */       return;
/*      */     }
/*  287 */     Location to = event.getTo();
/*  288 */     Location from = event.getFrom();
/*      */     
/*  290 */     if (to.getWorld() == from.getWorld())
/*      */     {
/*  292 */       int x1 = getChunk(to.getX());
/*  293 */       int z1 = getChunk(to.getZ());
/*      */       
/*  295 */       int x2 = getChunk(from.getX());
/*  296 */       int z2 = getChunk(from.getZ());
/*      */       
/*  298 */       if ((x1 != x2) || (z1 != z2))
/*      */       {
/*  300 */         final Player player = event.getPlayer();
/*  301 */         final Location prev = new Location(to.getWorld(), x1, 0.0D, z1);
/*      */         
/*  303 */         chunkMove(player, null, from);
/*      */         
/*  305 */         Bukkit.getScheduler().scheduleSyncDelayedTask(this._plugin, new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*  309 */             if (!player.isOnline())
/*      */             {
/*  311 */               return;
/*      */             }
/*      */             
/*  314 */             Location loc = player.getLocation();
/*      */             
/*  316 */             if (player.getWorld() != loc.getWorld())
/*      */             {
/*  318 */               return;
/*      */             }
/*      */             
/*  321 */             int x2 = DisguiseManager.this.getChunk(loc.getX());
/*  322 */             int z2 = DisguiseManager.this.getChunk(loc.getZ());
/*      */             
/*  324 */             if ((prev.getBlockX() == x2) && (prev.getBlockZ() == z2) && (loc.getWorld() == prev.getWorld()))
/*      */             {
/*  326 */               DisguiseManager.this.chunkMove(player, loc, null);
/*      */             }
/*      */             
/*  329 */             DisguiseManager.this.refreshBedTrackers(player);
/*      */           }
/*      */         });
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void ChunkUnload(ChunkUnloadEvent event) {
/*      */     org.bukkit.entity.Entity[] arrayOfEntity;
/*  339 */     int j = (arrayOfEntity = event.getChunk().getEntities()).length; for (int i = 0; i < j; i++) { org.bukkit.entity.Entity entity = arrayOfEntity[i];
/*      */       
/*  341 */       if (this._spawnPacketMap.containsKey(Integer.valueOf(entity.getEntityId())))
/*      */       {
/*  343 */         this._entityDisguiseMap.put(entity.getUniqueId().toString(), (DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entity.getEntityId())));
/*  344 */         this._spawnPacketMap.remove(Integer.valueOf(entity.getEntityId()));
/*  345 */         this._lastRabbitHop.remove(Integer.valueOf(entity.getEntityId()));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void clearDisguises()
/*      */   {
/*  352 */     this._spawnPacketMap.clear();
/*  353 */     this._movePacketMap.clear();
/*  354 */     this._moveTempMap.clear();
/*  355 */     this._goingUp.clear();
/*  356 */     this._entityDisguiseMap.clear();
/*  357 */     this._disguisePlayerMap.clear();
/*      */     
/*  359 */     if (this._bedPackets)
/*      */     {
/*  361 */       unregisterBedChunk();
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean containsSpawnDisguise(Player owner, int entityId)
/*      */   {
/*  367 */     return (this._spawnPacketMap.containsKey(Integer.valueOf(entityId))) && (
/*  368 */       (((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId))).Global) || ((this._disguisePlayerMap.containsKey((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId)))) && 
/*  369 */       (((HashSet)this._disguisePlayerMap.get((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId)))).contains(owner))));
/*      */   }
/*      */   
/*      */   public void disguise(DisguiseBase disguise, boolean refreshTrackers, Player... players)
/*      */   {
/*  374 */     if (!disguise.GetEntity().isAlive()) {
/*  375 */       return;
/*      */     }
/*  377 */     if ((!this._bedPackets) && ((disguise instanceof DisguisePlayer)) && (((DisguisePlayer)disguise).getSleepingDirection() != null))
/*      */     {
/*  379 */       this._bedPackets = true;
/*      */       
/*  381 */       for (Player player : Bukkit.getOnlinePlayers())
/*      */       {
/*  383 */         UtilPlayer.sendPacket(player, getBedChunkLoadPackets(player, player.getLocation()));
/*      */       }
/*      */     }
/*      */     
/*  387 */     if (players.length != 0)
/*      */     {
/*  389 */       disguise.Global = false;
/*      */     }
/*      */     
/*  392 */     this._spawnPacketMap.put(Integer.valueOf(disguise.GetEntityId()), disguise);
/*  393 */     this._disguisePlayerMap.put(disguise, new HashSet());
/*      */     
/*  395 */     if ((disguise instanceof DisguiseRabbit))
/*      */     {
/*  397 */       this._lastRabbitHop.put(Integer.valueOf(disguise.GetEntityId()), new NautHashMap());
/*      */     }
/*      */     Player[] arrayOfPlayer;
/*  400 */     int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*  401 */       addViewerToDisguise(disguise, player, false);
/*      */     }
/*  403 */     if (((disguise.GetEntity() instanceof Player)) && ((disguise instanceof DisguisePlayer)))
/*      */     {
/*  405 */       if (!((Player)disguise.GetEntity()).getName().equalsIgnoreCase(((DisguisePlayer)disguise).getName()))
/*      */       {
/*  407 */         this._blockedNames.add(((Player)disguise.GetEntity()).getName());
/*      */       }
/*      */     }
/*      */     
/*  411 */     if (refreshTrackers)
/*      */     {
/*  413 */       refreshTrackers(disguise.GetEntity().getBukkitEntity(), 
/*  414 */         disguise.Global ? (Player[])Bukkit.getOnlinePlayers().toArray(new Player[0]) : players);
/*      */     }
/*      */   }
/*      */   
/*      */   public void disguise(DisguiseBase disguise, Player... players)
/*      */   {
/*  420 */     disguise(disguise, true, players);
/*      */   }
/*      */   
/*      */   public Packet[] getBedChunkLoadPackets(Player player, Location newLoc)
/*      */   {
/*  425 */     prepareChunk(newLoc);
/*      */     
/*  427 */     Packet[] packets = new Packet[2];
/*      */     
/*      */ 
/*  430 */     packets[0] = new PacketPlayOutMapChunk(this._bedChunk, true, 0, UtilPlayer.is1_8(player) ? 48 : 0);
/*      */     
/*      */ 
/*  433 */     packets[1] = new net.minecraft.server.v1_7_R4.PacketPlayOutMapChunkBulk(Arrays.asList(new net.minecraft.server.v1_7_R4.Chunk[] { this._bedChunk }), UtilPlayer.is1_8(player) ? 48 : 0);
/*      */     
/*  435 */     return packets;
/*      */   }
/*      */   
/*      */   public Packet getBedChunkUnloadPacket(Player player, Location oldLoc)
/*      */   {
/*  440 */     prepareChunk(oldLoc);
/*      */     
/*  442 */     return new PacketPlayOutMapChunk(this._bedChunk, true, 0, UtilPlayer.is1_8(player) ? 48 : 0);
/*      */   }
/*      */   
/*      */   private Packet[] getBedPackets(Location recieving, DisguisePlayer playerDisguise)
/*      */   {
/*      */     try
/*      */     {
/*  449 */       PacketPlayOutBed bedPacket = new PacketPlayOutBed();
/*      */       
/*  451 */       this._bedA.set(bedPacket, Integer.valueOf(playerDisguise.GetEntityId()));
/*      */       
/*  453 */       int chunkX = getChunk(recieving.getX());
/*  454 */       int chunkZ = getChunk(recieving.getZ());
/*      */       
/*  456 */       this._bedB.set(bedPacket, Integer.valueOf(chunkX * 16 + 1 + playerDisguise.getSleepingDirection().getModX()));
/*  457 */       this._bedD.set(bedPacket, Integer.valueOf(chunkZ * 16 + 1 + playerDisguise.getSleepingDirection().getModZ()));
/*      */       
/*  459 */       PacketPlayOutEntityTeleport teleportPacket = new PacketPlayOutEntityTeleport(playerDisguise.GetEntity());
/*      */       
/*  461 */       teleportPacket.c += 11;
/*      */       
/*  463 */       return 
/*  464 */         new Packet[] {
/*  465 */         bedPacket, teleportPacket };
/*      */ 
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  470 */       ex.printStackTrace();
/*      */     }
/*      */     
/*  473 */     return null;
/*      */   }
/*      */   
/*      */   private int getChunk(double block)
/*      */   {
/*  478 */     int chunk = (int)Math.floor(block / 16.0D) - 17;
/*  479 */     chunk -= chunk % 8;
/*  480 */     return chunk;
/*      */   }
/*      */   
/*      */   private ArrayList<Packet> getChunkMovePackets(Player player, Location newLoc, Location oldLoc)
/*      */   {
/*  485 */     ArrayList<Packet> packets = new ArrayList();
/*      */     
/*  487 */     if (newLoc != null)
/*      */     {
/*  489 */       packets.addAll(Arrays.asList(getBedChunkLoadPackets(player, newLoc)));
/*      */       
/*  491 */       EntityPlayer nmsPlayer = ((CraftPlayer)player).getHandle();
/*      */       
/*  493 */       for (Map.Entry<DisguiseBase, HashSet<Player>> entry : this._disguisePlayerMap.entrySet())
/*      */       {
/*  495 */         if ((((DisguiseBase)entry.getKey()).Global) || (((HashSet)entry.getValue()).contains(player)))
/*      */         {
/*  497 */           EntityTrackerEntry tracker = getEntityTracker(((DisguiseBase)entry.getKey()).GetEntity());
/*      */           
/*  499 */           if ((tracker != null) && (tracker.trackedPlayers.contains(nmsPlayer)))
/*      */           {
/*  501 */             if (((entry.getKey() instanceof DisguisePlayer)) && 
/*  502 */               (((DisguisePlayer)entry.getKey()).getSleepingDirection() != null))
/*      */             {
/*      */ 
/*  505 */               packets.addAll(Arrays.asList(getBedPackets(newLoc, (DisguisePlayer)entry.getKey())));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  512 */     if (oldLoc != null)
/*      */     {
/*  514 */       packets.add(getBedChunkUnloadPacket(player, oldLoc));
/*      */     }
/*      */     
/*  517 */     return packets;
/*      */   }
/*      */   
/*      */   public DisguiseBase getDisguise(LivingEntity entity)
/*      */   {
/*  522 */     return (DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entity.getEntityId()));
/*      */   }
/*      */   
/*      */   private EntityTrackerEntry getEntityTracker(net.minecraft.server.v1_7_R4.Entity entity)
/*      */   {
/*  527 */     return (EntityTrackerEntry)((WorldServer)entity.world).tracker.trackedEntities.get(entity.getId());
/*      */   }
/*      */   
/*      */   public void handle(PacketInfo packetInfo)
/*      */   {
/*  532 */     if (this._handlingPacket) {
/*  533 */       return;
/*      */     }
/*  535 */     Packet packet = packetInfo.getPacket();
/*  536 */     Player owner = packetInfo.getPlayer();
/*  537 */     final PacketVerifier packetVerifier = packetInfo.getVerifier();
/*      */     
/*  539 */     if ((UtilPlayer.is1_8(owner)) && (
/*  540 */       ((packet instanceof PacketPlayOutRelEntityMoveLook)) || ((packet instanceof PacketPlayOutRelEntityMove))))
/*      */     {
/*  542 */       int entityId = -1;
/*      */       
/*  544 */       if ((packet instanceof PacketPlayOutRelEntityMoveLook))
/*      */       {
/*  546 */         entityId = ((PacketPlayOutRelEntityMoveLook)packet).a;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       }
/*  552 */       else if ((packet instanceof PacketPlayOutRelEntityMove))
/*      */       {
/*  554 */         PacketPlayOutRelEntityMove rPacket = (PacketPlayOutRelEntityMove)packet;
/*      */         
/*  556 */         if ((rPacket.b != 0) || (rPacket.c != 0) || (rPacket.d != 0))
/*      */         {
/*  558 */           entityId = rPacket.a;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  566 */       if (this._lastRabbitHop.containsKey(Integer.valueOf(entityId)))
/*      */       {
/*  568 */         NautHashMap<Integer, Long> rabbitHops = (NautHashMap)this._lastRabbitHop.get(Integer.valueOf(entityId));
/*      */         
/*  570 */         if (rabbitHops != null)
/*      */         {
/*  572 */           long last = rabbitHops.containsKey(Integer.valueOf(owner.getEntityId())) ? System.currentTimeMillis() - 
/*  573 */             ((Long)rabbitHops.get(Integer.valueOf(owner.getEntityId()))).longValue() : 1000L;
/*      */           
/*  575 */           if ((last > 500L) || (last < 100L))
/*      */           {
/*  577 */             rabbitHops.put(Integer.valueOf(owner.getEntityId()), Long.valueOf(System.currentTimeMillis()));
/*      */             
/*  579 */             PacketPlayOutEntityStatus entityStatus = new PacketPlayOutEntityStatus();
/*      */             try
/*      */             {
/*  582 */               this._eStatusId.set(entityStatus, Integer.valueOf(entityId));
/*  583 */               this._eStatusState.set(entityStatus, Byte.valueOf((byte)1));
/*      */               
/*  585 */               handlePacket(entityStatus, packetVerifier);
/*      */             }
/*      */             catch (Exception ex)
/*      */             {
/*  589 */               ex.printStackTrace();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  596 */     if ((packet instanceof PacketPlayOutPlayerInfo))
/*      */     {
/*  598 */       if (this._blockedNames.contains(((PacketPlayOutPlayerInfo)packet).username))
/*      */       {
/*  600 */         packetInfo.setCancelled(true);
/*      */       }
/*      */     }
/*  603 */     else if (((packet instanceof PacketPlayOutSpawnEntity)) || ((packet instanceof PacketPlayOutSpawnEntityLiving)) || 
/*  604 */       ((packet instanceof PacketPlayOutNamedEntitySpawn)))
/*      */     {
/*  606 */       int entityId = -1;
/*      */       
/*  608 */       if ((packet instanceof PacketPlayOutSpawnEntity))
/*      */       {
/*  610 */         entityId = ((PacketPlayOutSpawnEntity)packet).a;
/*      */       }
/*  612 */       else if ((packet instanceof PacketPlayOutSpawnEntityLiving))
/*      */       {
/*  614 */         entityId = ((PacketPlayOutSpawnEntityLiving)packet).a;
/*      */       }
/*  616 */       else if ((packet instanceof PacketPlayOutNamedEntitySpawn))
/*      */       {
/*  618 */         entityId = ((PacketPlayOutNamedEntitySpawn)packet).a;
/*      */       }
/*      */       
/*  621 */       if (this._futureDisguises.containsKey(Integer.valueOf(entityId)))
/*      */       {
/*  623 */         Map.Entry<DisguiseBase, Player[]> entry = (Map.Entry)this._futureDisguises.remove(Integer.valueOf(entityId));
/*      */         
/*  625 */         org.bukkit.entity.Entity entity = UtilEnt.getEntityById(entityId);
/*      */         
/*  627 */         if (entity != null)
/*      */         {
/*  629 */           ((DisguiseBase)entry.getKey()).setEntity(entity);
/*      */           
/*  631 */           disguise((DisguiseBase)entry.getKey(), false, (Player[])entry.getValue());
/*      */         }
/*      */       }
/*      */       
/*  635 */       if ((this._spawnPacketMap.containsKey(Integer.valueOf(entityId))) && (
/*  636 */         (((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId))).Global) || 
/*  637 */         (((HashSet)this._disguisePlayerMap.get((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId)))).contains(owner))))
/*      */       {
/*  639 */         packetInfo.setCancelled(true);
/*      */         
/*  641 */         handleSpawnPackets(packetInfo, (DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId)));
/*      */       }
/*      */     }
/*  644 */     else if ((packet instanceof PacketPlayOutUpdateAttributes))
/*      */     {
/*  646 */       int entityId = -1;
/*      */       
/*      */       try
/*      */       {
/*  650 */         entityId = ((Integer)this._attributesA.get((PacketPlayOutUpdateAttributes)packet)).intValue();
/*      */       }
/*      */       catch (IllegalArgumentException e)
/*      */       {
/*  654 */         e.printStackTrace();
/*      */       }
/*      */       catch (IllegalAccessException e)
/*      */       {
/*  658 */         e.printStackTrace();
/*      */       }
/*      */       
/*  661 */       if ((this._spawnPacketMap.containsKey(Integer.valueOf(entityId))) && 
/*  662 */         (owner.getEntityId() != entityId) && (
/*  663 */         (((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId))).Global) || 
/*  664 */         (((HashSet)this._disguisePlayerMap.get((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId)))).contains(owner))))
/*      */       {
/*      */ 
/*  667 */         if ((this._spawnPacketMap.get(Integer.valueOf(entityId)) instanceof DisguiseBlock)) {
/*  668 */           packetInfo.setCancelled(true);
/*      */         }
/*      */       }
/*  671 */     } else if ((packet instanceof PacketPlayOutAnimation))
/*      */     {
/*  673 */       int entityId = ((PacketPlayOutAnimation)packet).a;
/*      */       
/*  675 */       if ((containsSpawnDisguise(owner, entityId)) && (owner.getEntityId() != entityId))
/*      */       {
/*  677 */         packetInfo.setCancelled(true);
/*      */       }
/*      */     }
/*  680 */     else if ((packet instanceof PacketPlayOutEntityMetadata))
/*      */     {
/*  682 */       int entityId = ((PacketPlayOutEntityMetadata)packet).a;
/*      */       
/*  684 */       if ((containsSpawnDisguise(owner, entityId)) && (owner.getEntityId() != entityId))
/*      */       {
/*  686 */         handlePacket(((DisguiseBase)this._spawnPacketMap.get(Integer.valueOf(entityId))).GetMetaDataPacket(), packetVerifier);
/*  687 */         packetInfo.setCancelled(true);
/*      */       }
/*      */     }
/*  690 */     else if ((packet instanceof PacketPlayOutEntityEquipment))
/*      */     {
/*  692 */       int entityId = ((PacketPlayOutEntityEquipment)packet).a;
/*      */       
/*  694 */       if ((containsSpawnDisguise(owner, entityId)) && ((this._spawnPacketMap.get(Integer.valueOf(entityId)) instanceof DisguiseInsentient)))
/*      */       {
/*  696 */         if ((!((DisguiseInsentient)this._spawnPacketMap.get(Integer.valueOf(entityId))).armorVisible()) && 
/*  697 */           (((PacketPlayOutEntityEquipment)packet).b != 0))
/*      */         {
/*  699 */           packetInfo.setCancelled(true);
/*      */         }
/*      */       }
/*      */     }
/*  703 */     else if ((packet instanceof PacketPlayOutEntityVelocity))
/*      */     {
/*  705 */       PacketPlayOutEntityVelocity velocityPacket = (PacketPlayOutEntityVelocity)packet;
/*      */       
/*      */ 
/*  708 */       if (velocityPacket.a == owner.getEntityId())
/*      */       {
/*  710 */         if (velocityPacket.c > 0)
/*  711 */           this._goingUp.add(Integer.valueOf(velocityPacket.a));
/*      */       } else {
/*  713 */         if ((velocityPacket.b == 0) && (velocityPacket.c == 0) && (velocityPacket.d == 0))
/*      */         {
/*  715 */           return;
/*      */         }
/*  717 */         if (this._spawnPacketMap.containsKey(Integer.valueOf(velocityPacket.a)))
/*      */         {
/*  719 */           packetInfo.setCancelled(true);
/*      */         }
/*      */       }
/*  722 */     } else if ((packet instanceof PacketPlayOutRelEntityMove))
/*      */     {
/*  724 */       PacketPlayOutRelEntityMove movePacket = (PacketPlayOutRelEntityMove)packet;
/*      */       
/*      */ 
/*  727 */       if (movePacket.a == owner.getEntityId()) {
/*  728 */         return;
/*      */       }
/*  730 */       if ((this._goingUp.contains(Integer.valueOf(movePacket.a))) && (movePacket.c != 0) && (movePacket.c < 20))
/*      */       {
/*  732 */         this._goingUp.remove(Integer.valueOf(movePacket.a));
/*  733 */         this._movePacketMap.remove(Integer.valueOf(movePacket.a));
/*      */       }
/*      */       
/*  736 */       if (!containsSpawnDisguise(owner, movePacket.a)) {
/*  737 */         return;
/*      */       }
/*  739 */       final PacketPlayOutEntityVelocity velocityPacket = new PacketPlayOutEntityVelocity();
/*  740 */       velocityPacket.a = movePacket.a;
/*  741 */       velocityPacket.b = (movePacket.b * 100);
/*  742 */       velocityPacket.c = (movePacket.c * 100);
/*  743 */       velocityPacket.d = (movePacket.d * 100);
/*      */       
/*  745 */       if (this._movePacketMap.containsKey(Integer.valueOf(movePacket.a)))
/*      */       {
/*  747 */         PacketPlayOutEntityVelocity lastVelocityPacket = (PacketPlayOutEntityVelocity)this._movePacketMap.get(Integer.valueOf(movePacket.a));
/*      */         
/*  749 */         velocityPacket.b = ((int)(0.8D * lastVelocityPacket.b));
/*  750 */         velocityPacket.c = ((int)(0.8D * lastVelocityPacket.c));
/*  751 */         velocityPacket.d = ((int)(0.8D * lastVelocityPacket.d));
/*      */       }
/*      */       
/*  754 */       this._movePacketMap.put(Integer.valueOf(movePacket.a), velocityPacket);
/*      */       
/*  756 */       packetVerifier.bypassProcess(velocityPacket);
/*      */       
/*  758 */       if ((this._goingUp.contains(Integer.valueOf(movePacket.a))) && (movePacket.c != 0) && (movePacket.c > 20))
/*      */       {
/*  760 */         Bukkit.getServer().getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*  764 */             packetVerifier.bypassProcess(velocityPacket);
/*      */           }
/*      */         });
/*      */       }
/*      */       
/*  769 */       (this._spawnPacketMap.get(Integer.valueOf(movePacket.a)) instanceof DisguiseBlock);
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*  774 */     else if ((packet instanceof PacketPlayOutRelEntityMoveLook))
/*      */     {
/*  776 */       PacketPlayOutRelEntityMoveLook movePacket = (PacketPlayOutRelEntityMoveLook)packet;
/*      */       
/*      */ 
/*  779 */       if (movePacket.a == owner.getEntityId()) {
/*  780 */         return;
/*      */       }
/*  782 */       if ((this._goingUp.contains(Integer.valueOf(movePacket.a))) && (movePacket.c != 0) && (movePacket.c <= 20))
/*      */       {
/*  784 */         this._goingUp.remove(Integer.valueOf(movePacket.a));
/*  785 */         this._movePacketMap.remove(Integer.valueOf(movePacket.a));
/*      */       }
/*      */       
/*  788 */       if (!containsSpawnDisguise(owner, movePacket.a)) {
/*  789 */         return;
/*      */       }
/*  791 */       final PacketPlayOutEntityVelocity velocityPacket = new PacketPlayOutEntityVelocity();
/*  792 */       velocityPacket.a = movePacket.a;
/*  793 */       velocityPacket.b = (movePacket.b * 100);
/*  794 */       velocityPacket.c = (movePacket.c * 100);
/*  795 */       velocityPacket.d = (movePacket.d * 100);
/*      */       
/*  797 */       if (this._movePacketMap.containsKey(Integer.valueOf(movePacket.a)))
/*      */       {
/*  799 */         PacketPlayOutEntityVelocity lastVelocityPacket = (PacketPlayOutEntityVelocity)this._movePacketMap.get(Integer.valueOf(movePacket.a));
/*      */         
/*  801 */         velocityPacket.b = ((int)(0.8D * lastVelocityPacket.b));
/*  802 */         velocityPacket.c = ((int)(0.8D * lastVelocityPacket.c));
/*  803 */         velocityPacket.d = ((int)(0.8D * lastVelocityPacket.d));
/*      */       }
/*      */       
/*  806 */       this._movePacketMap.put(Integer.valueOf(movePacket.a), velocityPacket);
/*      */       
/*  808 */       packetVerifier.bypassProcess(velocityPacket);
/*      */       
/*  810 */       if ((this._goingUp.contains(Integer.valueOf(movePacket.a))) && (movePacket.c != 0) && (movePacket.c > 20))
/*      */       {
/*  812 */         Bukkit.getServer().getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*  816 */             packetVerifier.bypassProcess(velocityPacket);
/*      */           }
/*      */         });
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void handlePacket(Packet packet, PacketVerifier verifier)
/*      */   {
/*  825 */     this._handlingPacket = true;
/*  826 */     verifier.process(packet);
/*  827 */     this._handlingPacket = false;
/*      */   }
/*      */   
/*      */   private void handleSpawnPackets(PacketInfo packetInfo, DisguiseBase disguise)
/*      */   {
/*  832 */     Player player = packetInfo.getPlayer();
/*      */     
/*  834 */     if ((!UtilPlayer.is1_8(player)) && ((disguise instanceof DisguiseRabbit)))
/*      */     {
/*  836 */       return;
/*      */     }
/*      */     
/*  839 */     final PacketVerifier packetVerifier = packetInfo.getVerifier();
/*      */     Packet packet;
/*  841 */     if ((disguise instanceof DisguisePlayer))
/*      */     {
/*      */ 
/*  844 */       final DisguisePlayer pDisguise = (DisguisePlayer)disguise;
/*      */       
/*  846 */       handlePacket(pDisguise.getNewInfoPacket(true), packetVerifier);
/*      */       
/*  848 */       PacketPlayOutNamedEntitySpawn namePacket = pDisguise.spawnBeforePlayer(player.getLocation());
/*      */       
/*  850 */       namePacket.i.watch(0, Byte.valueOf((byte)32));
/*      */       
/*  852 */       handlePacket(namePacket, packetVerifier);
/*      */       
/*  854 */       if (pDisguise.getSleepingDirection() != null) {
/*      */         Packet[] arrayOfPacket;
/*  856 */         int j = (arrayOfPacket = getBedPackets(player.getLocation(), pDisguise)).length; for (int i = 0; i < j; i++) { Packet packet = arrayOfPacket[i];
/*      */           
/*  858 */           handlePacket(packet, packetVerifier);
/*      */         }
/*      */         
/*      */       }
/*      */       else
/*      */       {
/*  864 */         handlePacket(new PacketPlayOutEntityTeleport(pDisguise.GetEntity()), packetVerifier);
/*      */       }
/*      */       
/*  867 */       for (Iterator localIterator = pDisguise.getEquipmentPackets().iterator(); localIterator.hasNext();) { packet = (Packet)localIterator.next();
/*      */         
/*  869 */         handlePacket(packet, packetVerifier);
/*      */       }
/*      */       
/*  872 */       handlePacket(pDisguise.GetMetaDataPacket(), packetVerifier);
/*      */       
/*  874 */       Bukkit.getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*  878 */           DisguiseManager.this.handlePacket(pDisguise.getNewInfoPacket(false), packetVerifier);
/*      */         }
/*  880 */       }, 6L);
/*      */     }
/*      */     else
/*      */     {
/*  884 */       handlePacket(disguise.GetSpawnPacket(), packetVerifier);
/*      */       
/*  886 */       if ((disguise instanceof DisguiseLiving))
/*      */       {
/*  888 */         ArrayList<Packet> packets = ((DisguiseLiving)disguise).getEquipmentPackets();
/*      */         
/*  890 */         for (Packet packet : packets)
/*      */         {
/*  892 */           handlePacket(packet, packetVerifier);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isDisguised(LivingEntity entity)
/*      */   {
/*  900 */     return this._spawnPacketMap.containsKey(Integer.valueOf(entity.getEntityId()));
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void PlayerQuit(PlayerQuitEvent event)
/*      */   {
/*  906 */     undisguise(event.getPlayer());
/*      */     
/*  908 */     for (DisguiseBase disguise : this._disguisePlayerMap.keySet())
/*      */     {
/*  910 */       ((HashSet)this._disguisePlayerMap.get(disguise)).remove(event.getPlayer());
/*      */     }
/*      */     
/*  913 */     for (Integer disguise : this._lastRabbitHop.keySet())
/*      */     {
/*  915 */       ((NautHashMap)this._lastRabbitHop.get(disguise)).remove(Integer.valueOf(event.getPlayer().getEntityId()));
/*      */     }
/*      */   }
/*      */   
/*      */   private void prepareChunk(Location loc)
/*      */   {
/*  921 */     int chunkX = getChunk(loc.getX());
/*  922 */     int chunkZ = getChunk(loc.getZ());
/*      */     
/*      */     try
/*      */     {
/*  926 */       this._xChunk.set(this._bedChunk, Integer.valueOf(chunkX));
/*  927 */       this._zChunk.set(this._bedChunk, Integer.valueOf(chunkZ));
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  931 */       ex.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   private void refreshBedTrackers(final Player player)
/*      */   {
/*  937 */     for (final DisguiseBase disguise : this._disguisePlayerMap.keySet())
/*      */     {
/*  939 */       if (((disguise instanceof DisguisePlayer)) && (((DisguisePlayer)disguise).getSleepingDirection() != null))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  944 */         final EntityTrackerEntry entityTracker = getEntityTracker(disguise.GetEntity());
/*      */         
/*  946 */         if (entityTracker != null)
/*      */         {
/*  948 */           if (entityTracker.trackedPlayers.contains(((CraftPlayer)player).getHandle()))
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*  953 */             Packet destroyPacket = new PacketPlayOutEntityDestroy(
/*  954 */               new int[] {
/*  955 */               disguise.GetEntityId() });
/*      */             
/*      */ 
/*  958 */             entityTracker.clear(((CraftPlayer)player).getHandle());
/*      */             
/*  960 */             UtilPlayer.sendPacket(player, new Packet[] { destroyPacket });
/*      */             
/*  962 */             final World world = disguise.GetEntity().getBukkitEntity().getWorld();
/*      */             
/*  964 */             Bukkit.getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */             {
/*      */               public void run()
/*      */               {
/*      */                 try
/*      */                 {
/*  970 */                   org.bukkit.entity.Entity entity = disguise.GetEntity().getBukkitEntity();
/*      */                   
/*  972 */                   if ((entity.getWorld() == world) && (entity.isValid()))
/*      */                   {
/*  974 */                     if ((player.isOnline()) && (player.getWorld() == entity.getWorld()))
/*      */                     {
/*  976 */                       entityTracker.updatePlayer(((CraftPlayer)player).getHandle());
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 catch (Exception ex)
/*      */                 {
/*  982 */                   ex.printStackTrace();
/*      */                 }
/*      */               }
/*  985 */             }, 5L);
/*      */           } }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void refreshTrackers(final org.bukkit.entity.Entity entity, final Player[] players) {
/*  992 */     final EntityTrackerEntry entityTracker = getEntityTracker(((CraftEntity)entity).getHandle());
/*      */     
/*  994 */     if (entityTracker != null)
/*      */     {
/*  996 */       Packet destroyPacket = new PacketPlayOutEntityDestroy(
/*  997 */         new int[] {
/*  998 */         entity.getEntityId() });
/*      */       
/*      */       Player[] arrayOfPlayer;
/* 1001 */       int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*      */         
/* 1003 */         entityTracker.clear(((CraftPlayer)player).getHandle());
/*      */         
/* 1005 */         UtilPlayer.sendPacket(player, new Packet[] { destroyPacket });
/*      */       }
/*      */       
/* 1008 */       final World world = entity.getWorld();
/*      */       
/* 1010 */       Bukkit.getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*      */       {
/*      */         public void run()
/*      */         {
/*      */           try
/*      */           {
/* 1016 */             if ((entity.getWorld() == world) && (entity.isValid())) {
/*      */               Player[] arrayOfPlayer;
/* 1018 */               int j = (arrayOfPlayer = players).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*      */                 
/* 1020 */                 if ((player.isOnline()) && (player.getWorld() == entity.getWorld()))
/*      */                 {
/* 1022 */                   entityTracker.updatePlayer(((CraftPlayer)player).getHandle());
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (Exception ex)
/*      */           {
/* 1029 */             ex.printStackTrace();
/*      */           }
/*      */         }
/* 1032 */       }, 5L);
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeViewerToDisguise(DisguiseBase disguise, Player player)
/*      */   {
/* 1038 */     ((HashSet)this._disguisePlayerMap.get(disguise)).remove(player);
/*      */     
/* 1040 */     refreshTrackers(disguise.GetEntity().getBukkitEntity(), 
/* 1041 */       new Player[] {
/* 1042 */       player });
/*      */   }
/*      */   
/*      */ 
/*      */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*      */   public void switchedWorld(PlayerChangedWorldEvent event)
/*      */   {
/* 1049 */     if (!this._bedPackets) {
/* 1050 */       return;
/*      */     }
/* 1052 */     chunkMove(event.getPlayer(), event.getPlayer().getLocation(), null);
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void TeleportDisguises(UpdateEvent event)
/*      */   {
/* 1058 */     if (event.getType() != UpdateType.SEC) {
/* 1059 */       return;
/*      */     }
/* 1061 */     TimingManager.startTotal("Teleport Disguises");
/* 1062 */     Iterator localIterator2; for (Iterator localIterator1 = Bukkit.getOnlinePlayers().iterator(); localIterator1.hasNext(); 
/*      */         
/* 1064 */         localIterator2.hasNext())
/*      */     {
/* 1062 */       Player player = (Player)localIterator1.next();
/*      */       
/* 1064 */       localIterator2 = Bukkit.getOnlinePlayers().iterator(); continue;Player otherPlayer = (Player)localIterator2.next();
/*      */       
/* 1066 */       if (player != otherPlayer)
/*      */       {
/*      */ 
/* 1069 */         if (otherPlayer.getLocation().subtract(0.0D, 0.5D, 0.0D).getBlock().getTypeId() != 0)
/* 1070 */           ((CraftPlayer)player).getHandle().playerConnection.sendPacket(new PacketPlayOutEntityTeleport(
/* 1071 */             ((CraftPlayer)otherPlayer).getHandle()));
/*      */       }
/*      */     }
/* 1074 */     TimingManager.stopTotal("Teleport Disguises");
/*      */   }
/*      */   
/*      */   public void undisguise(LivingEntity entity)
/*      */   {
/* 1079 */     if (!this._spawnPacketMap.containsKey(Integer.valueOf(entity.getEntityId()))) {
/* 1080 */       return;
/*      */     }
/* 1082 */     this._lastRabbitHop.remove(Integer.valueOf(entity.getEntityId()));
/* 1083 */     DisguiseBase disguise = (DisguiseBase)this._spawnPacketMap.remove(Integer.valueOf(entity.getEntityId()));
/* 1084 */     Collection<? extends Player> players = disguise.Global ? Bukkit.getOnlinePlayers() : (Collection)this._disguisePlayerMap.remove(disguise);
/*      */     
/* 1086 */     this._movePacketMap.remove(Integer.valueOf(entity.getEntityId()));
/* 1087 */     this._moveTempMap.remove(Integer.valueOf(entity.getEntityId()));
/* 1088 */     this._blockedNames.remove(((Player)entity).getName());
/*      */     
/* 1090 */     refreshTrackers(entity, (Player[])players.toArray(new Player[0]));
/*      */     
/* 1092 */     if ((this._bedPackets) && ((disguise instanceof DisguisePlayer)) && (((DisguisePlayer)disguise).getSleepingDirection() != null))
/*      */     {
/* 1094 */       for (DisguiseBase dis : this._disguisePlayerMap.keySet())
/*      */       {
/* 1096 */         if (((dis instanceof DisguisePlayer)) && (((DisguisePlayer)dis).getSleepingDirection() != null))
/*      */         {
/* 1098 */           return;
/*      */         }
/*      */       }
/*      */       
/* 1102 */       unregisterBedChunk();
/*      */     }
/*      */   }
/*      */   
/*      */   private void unregisterBedChunk()
/*      */   {
/* 1108 */     this._bedPackets = false;
/*      */     
/* 1110 */     for (Player player : Bukkit.getOnlinePlayers())
/*      */     {
/* 1112 */       chunkMove(player, null, player.getLocation());
/*      */     }
/*      */   }
/*      */   
/*      */   public void updateDisguise(DisguiseBase disguise)
/*      */   {
/* 1118 */     Collection<? extends Player> players = disguise.Global ? Bukkit.getOnlinePlayers() : (Collection)this._disguisePlayerMap.get(disguise);
/*      */     
/* 1120 */     for (Player player : players)
/*      */     {
/* 1122 */       if (disguise.GetEntity() != ((CraftPlayer)player).getHandle())
/*      */       {
/*      */ 
/* 1125 */         EntityPlayer entityPlayer = ((CraftPlayer)player).getHandle();
/*      */         
/* 1127 */         entityPlayer.playerConnection.sendPacket(disguise.GetMetaDataPacket());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   @EventHandler
/*      */   public void cleanDisguises(UpdateEvent event) {
/* 1134 */     if ((event.getType() != UpdateType.SLOWER) || (this._disguisePlayerMap.isEmpty())) {
/* 1135 */       return;
/*      */     }
/* 1137 */     for (Iterator<DisguiseBase> disguiseIterator = this._disguisePlayerMap.keySet().iterator(); disguiseIterator.hasNext();)
/*      */     {
/* 1139 */       DisguiseBase disguise = (DisguiseBase)disguiseIterator.next();
/*      */       
/* 1141 */       if ((disguise.GetEntity() instanceof EntityPlayer))
/*      */       {
/*      */ 
/* 1144 */         EntityPlayer disguisedPlayer = (EntityPlayer)disguise.GetEntity();
/*      */         
/* 1146 */         if ((Bukkit.getPlayerExact(disguisedPlayer.getName()) == null) || (!disguisedPlayer.isAlive()) || (!disguisedPlayer.valid)) {
/* 1147 */           disguiseIterator.remove();
/*      */         }
/*      */         else {
/* 1150 */           for (Iterator<Player> playerIterator = ((HashSet)this._disguisePlayerMap.get(disguise)).iterator(); playerIterator.hasNext();)
/*      */           {
/* 1152 */             Player player = (Player)playerIterator.next();
/*      */             
/* 1154 */             if ((!player.isOnline()) || (!player.isValid())) {
/* 1155 */               playerIterator.remove();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\DisguiseManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */