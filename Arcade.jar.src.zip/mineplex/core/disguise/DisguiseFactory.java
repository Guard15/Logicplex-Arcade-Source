/*    */ package mineplex.core.disguise;
/*    */ 
/*    */ import mineplex.core.disguise.disguises.DisguiseWitch;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ 
/*    */ public class DisguiseFactory
/*    */ {
/*    */   public static mineplex.core.disguise.disguises.DisguiseBase createDisguise(Entity disguised, EntityType disguiseType)
/*    */   {
/* 11 */     switch (disguiseType)
/*    */     {
/*    */     case PIG: 
/* 14 */       return new mineplex.core.disguise.disguises.DisguiseBat(disguised);
/*    */     case MINECART_TNT: 
/* 16 */       return new mineplex.core.disguise.disguises.DisguiseBlaze(disguised);
/*    */     case SNOWMAN: 
/* 18 */       return new mineplex.core.disguise.disguises.DisguiseCat(disguised);
/*    */     case SILVERFISH: 
/* 20 */       return new mineplex.core.disguise.disguises.DisguiseChicken(disguised);
/*    */     case SHEEP: 
/* 22 */       return new mineplex.core.disguise.disguises.DisguiseCow(disguised);
/*    */     case IRON_GOLEM: 
/* 24 */       return new mineplex.core.disguise.disguises.DisguiseCreeper(disguised);
/*    */     case MINECART_FURNACE: 
/* 26 */       return new mineplex.core.disguise.disguises.DisguiseEnderman(disguised);
/*    */     case SPLASH_POTION: 
/* 28 */       return new mineplex.core.disguise.disguises.DisguiseHorse(disguised);
/*    */     case SPIDER: 
/* 30 */       return new mineplex.core.disguise.disguises.DisguiseIronGolem(disguised);
/*    */     case MUSHROOM_COW: 
/* 32 */       return new mineplex.core.disguise.disguises.DisguiseMagmaCube(disguised);
/*    */     case PLAYER: 
/* 34 */       return new mineplex.core.disguise.disguises.DisguisePig(disguised);
/*    */     case MINECART_COMMAND: 
/* 36 */       return new mineplex.core.disguise.disguises.DisguisePigZombie(disguised);
/*    */     case WITHER_SKULL: 
/* 38 */       return new mineplex.core.disguise.disguises.DisguisePlayer(disguised);
/*    */     case PRIMED_TNT: 
/* 40 */       return new mineplex.core.disguise.disguises.DisguiseSheep(disguised);
/*    */     case ITEM_FRAME: 
/* 42 */       return new mineplex.core.disguise.disguises.DisguiseSkeleton(disguised);
/*    */     case MINECART: 
/* 44 */       return new mineplex.core.disguise.disguises.DisguiseSlime(disguised);
/*    */     case SNOWBALL: 
/* 46 */       return new mineplex.core.disguise.disguises.DisguiseSnowman(disguised);
/*    */     case LEASH_HITCH: 
/* 48 */       return new mineplex.core.disguise.disguises.DisguiseSpider(disguised);
/*    */     case SKELETON: 
/* 50 */       return new mineplex.core.disguise.disguises.DisguiseSquid(disguised);
/*    */     case SQUID: 
/* 52 */       return new mineplex.core.disguise.disguises.DisguiseVillager(disguised);
/*    */     case PIG_ZOMBIE: 
/* 54 */       return new DisguiseWitch(disguised);
/*    */     case SLIME: 
/* 56 */       return new mineplex.core.disguise.disguises.DisguiseWolf(disguised);
/*    */     case MAGMA_CUBE: 
/* 58 */       return new mineplex.core.disguise.disguises.DisguiseZombie(disguised);
/*    */     }
/* 60 */     return null;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\DisguiseFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */