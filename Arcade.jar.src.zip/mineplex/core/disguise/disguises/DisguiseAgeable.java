/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.spigotmc.ProtocolData.IntByte;
/*    */ 
/*    */ public abstract class DisguiseAgeable extends DisguiseCreature
/*    */ {
/*    */   public DisguiseAgeable(org.bukkit.entity.EntityType disguiseType, org.bukkit.entity.Entity entity)
/*    */   {
/* 10 */     super(disguiseType, entity);
/*    */     
/* 12 */     this.DataWatcher.a(12, new ProtocolData.IntByte(0, (byte)0));
/*    */   }
/*    */   
/*    */   public void UpdateDataWatcher()
/*    */   {
/* 17 */     super.UpdateDataWatcher();
/*    */     
/* 19 */     this.DataWatcher.watch(12, this.DataWatcher.getIntByte(12));
/*    */   }
/*    */   
/*    */   public boolean isBaby()
/*    */   {
/* 24 */     return this.DataWatcher.getIntByte(12).value < 0;
/*    */   }
/*    */   
/*    */   public void setBaby()
/*    */   {
/* 29 */     this.DataWatcher.watch(12, new ProtocolData.IntByte(41536, (byte)-1));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseAgeable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */