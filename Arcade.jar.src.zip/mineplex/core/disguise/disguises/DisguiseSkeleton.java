/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.bukkit.entity.Skeleton.SkeletonType;
/*    */ 
/*    */ public class DisguiseSkeleton extends DisguiseMonster
/*    */ {
/*    */   public DisguiseSkeleton(org.bukkit.entity.Entity entity)
/*    */   {
/* 10 */     super(org.bukkit.entity.EntityType.SKELETON, entity);
/*    */     
/* 12 */     this.DataWatcher.a(13, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public void SetSkeletonType(Skeleton.SkeletonType skeletonType)
/*    */   {
/* 17 */     this.DataWatcher.watch(13, Byte.valueOf((byte)skeletonType.getId()));
/*    */   }
/*    */   
/*    */   public int GetSkeletonType()
/*    */   {
/* 22 */     return this.DataWatcher.getByte(13);
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 27 */     return "mob.skeleton.hurt";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseSkeleton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */