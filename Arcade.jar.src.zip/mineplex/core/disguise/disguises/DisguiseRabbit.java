/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import net.minecraft.server.v1_7_R4.EnumEntitySize;
/*    */ import net.minecraft.server.v1_7_R4.MathHelper;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*    */ 
/*    */ public class DisguiseRabbit extends DisguiseInsentient
/*    */ {
/*    */   public DisguiseRabbit(org.bukkit.entity.Entity entity)
/*    */   {
/* 13 */     super(entity);
/*    */     
/* 15 */     this.DataWatcher.a(4, Byte.valueOf((byte)0));
/*    */     
/* 17 */     this.DataWatcher.a(12, Byte.valueOf((byte)0));
/* 18 */     this.DataWatcher.a(15, Byte.valueOf((byte)0));
/* 19 */     this.DataWatcher.a(18, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */ 
/*    */   public Packet GetSpawnPacket()
/*    */   {
/* 25 */     PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
/* 26 */     packet.a = this.Entity.getId();
/* 27 */     packet.b = 101;
/* 28 */     packet.c = EnumEntitySize.SIZE_2.a(this.Entity.locX);
/* 29 */     packet.d = MathHelper.floor(this.Entity.locY * 32.0D);
/* 30 */     packet.e = EnumEntitySize.SIZE_2.a(this.Entity.locZ);
/* 31 */     packet.i = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/* 32 */     packet.j = ((byte)(int)(this.Entity.pitch * 256.0F / 360.0F));
/* 33 */     packet.k = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/*    */     
/* 35 */     double var2 = 3.9D;
/* 36 */     double var4 = 0.0D;
/* 37 */     double var6 = 0.0D;
/* 38 */     double var8 = 0.0D;
/*    */     
/* 40 */     if (var4 < -var2)
/*    */     {
/* 42 */       var4 = -var2;
/*    */     }
/*    */     
/* 45 */     if (var6 < -var2)
/*    */     {
/* 47 */       var6 = -var2;
/*    */     }
/*    */     
/* 50 */     if (var8 < -var2)
/*    */     {
/* 52 */       var8 = -var2;
/*    */     }
/*    */     
/* 55 */     if (var4 > var2)
/*    */     {
/* 57 */       var4 = var2;
/*    */     }
/*    */     
/* 60 */     if (var6 > var2)
/*    */     {
/* 62 */       var6 = var2;
/*    */     }
/*    */     
/* 65 */     if (var8 > var2)
/*    */     {
/* 67 */       var8 = var2;
/*    */     }
/*    */     
/* 70 */     packet.f = ((int)(var4 * 8000.0D));
/* 71 */     packet.g = ((int)(var6 * 8000.0D));
/* 72 */     packet.h = ((int)(var8 * 8000.0D));
/*    */     
/* 74 */     packet.l = this.DataWatcher;
/* 75 */     packet.m = this.DataWatcher.b();
/*    */     
/* 77 */     return packet;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseRabbit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */