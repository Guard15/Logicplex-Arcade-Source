/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ public class DisguiseWolf extends DisguiseTameableAnimal
/*    */ {
/*    */   public DisguiseWolf(Entity entity)
/*    */   {
/* 10 */     super(org.bukkit.entity.EntityType.WOLF, entity);
/*    */     
/* 12 */     this.DataWatcher.a(18, new Float(20.0F));
/* 13 */     this.DataWatcher.a(19, new Byte((byte)0));
/* 14 */     this.DataWatcher.a(20, new Byte((byte)net.minecraft.server.v1_7_R4.BlockCloth.b(1)));
/*    */   }
/*    */   
/*    */   public boolean isAngry()
/*    */   {
/* 19 */     return (this.DataWatcher.getByte(16) & 0x2) != 0;
/*    */   }
/*    */   
/*    */   public void setAngry(boolean angry)
/*    */   {
/* 24 */     byte b0 = this.DataWatcher.getByte(16);
/*    */     
/* 26 */     if (angry) {
/* 27 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 | 0x2)));
/*    */     } else {
/* 29 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFD)));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getCollarColor() {
/* 34 */     return this.DataWatcher.getByte(20) & 0xF;
/*    */   }
/*    */   
/*    */   public void setCollarColor(int i)
/*    */   {
/* 39 */     this.DataWatcher.watch(20, Byte.valueOf((byte)(i & 0xF)));
/*    */   }
/*    */   
/*    */   public void m(boolean flag)
/*    */   {
/* 44 */     if (flag) {
/* 45 */       this.DataWatcher.watch(19, Byte.valueOf((byte)1));
/*    */     } else {
/* 47 */       this.DataWatcher.watch(19, Byte.valueOf((byte)0));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean ce() {
/* 52 */     return this.DataWatcher.getByte(19) == 1;
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 57 */     return "mob.wolf.hurt";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseWolf.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */