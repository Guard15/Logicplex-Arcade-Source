/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseWitch extends DisguiseMonster
/*    */ {
/*    */   public DisguiseWitch(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.WITCH, entity);
/*    */     
/* 11 */     this.DataWatcher.a(21, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public String getHurtSound()
/*    */   {
/* 16 */     return "mob.witch.hurt";
/*    */   }
/*    */   
/*    */   public void a(boolean flag)
/*    */   {
/* 21 */     this.DataWatcher.watch(21, Byte.valueOf((byte)(flag ? 1 : 0)));
/*    */   }
/*    */   
/*    */   public boolean bT()
/*    */   {
/* 26 */     return this.DataWatcher.getByte(21) == 1;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseWitch.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */