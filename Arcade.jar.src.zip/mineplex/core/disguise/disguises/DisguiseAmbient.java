/*   */ package mineplex.core.disguise.disguises;
/*   */ 
/*   */ import org.bukkit.entity.Entity;
/*   */ 
/*   */ public abstract class DisguiseAmbient extends DisguiseInsentient {
/*   */   public DisguiseAmbient(Entity entity) {
/* 7 */     super(entity);
/*   */   }
/*   */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseAmbient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */