/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseIronGolem extends DisguiseGolem
/*    */ {
/*    */   public DisguiseIronGolem(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.IRON_GOLEM, entity);
/*    */     
/* 11 */     this.DataWatcher.a(16, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public boolean bW()
/*    */   {
/* 16 */     return (this.DataWatcher.getByte(16) & 0x1) != 0;
/*    */   }
/*    */   
/*    */   public void setPlayerCreated(boolean flag)
/*    */   {
/* 21 */     byte b0 = this.DataWatcher.getByte(16);
/*    */     
/* 23 */     if (flag) {
/* 24 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 | 0x1)));
/*    */     } else {
/* 26 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 & 0xFFFFFFFE)));
/*    */     }
/*    */   }
/*    */   
/*    */   protected String getHurtSound() {
/* 31 */     return "mob.irongolem.hit";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseIronGolem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */