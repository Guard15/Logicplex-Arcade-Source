/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public abstract class DisguiseTameableAnimal extends DisguiseAnimal
/*    */ {
/*    */   public DisguiseTameableAnimal(org.bukkit.entity.EntityType disguiseType, org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(disguiseType, entity);
/*    */     
/* 11 */     this.DataWatcher.a(16, Byte.valueOf((byte)0));
/* 12 */     this.DataWatcher.a(17, "");
/*    */   }
/*    */   
/*    */   public boolean isTamed()
/*    */   {
/* 17 */     return (this.DataWatcher.getByte(16) & 0x4) != 0;
/*    */   }
/*    */   
/*    */   public void setTamed(boolean tamed)
/*    */   {
/* 22 */     int i = this.DataWatcher.getByte(16);
/*    */     
/* 24 */     if (tamed) {
/* 25 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(i | 0x4)));
/*    */     } else {
/* 27 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(i | 0xFFFFFFFB)));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isSitting() {
/* 32 */     return (this.DataWatcher.getByte(16) & 0x1) != 0;
/*    */   }
/*    */   
/*    */   public void setSitting(boolean sitting)
/*    */   {
/* 37 */     int i = this.DataWatcher.getByte(16);
/*    */     
/* 39 */     if (sitting) {
/* 40 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(i | 0x1)));
/*    */     } else {
/* 42 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(i | 0xFFFFFFFE)));
/*    */     }
/*    */   }
/*    */   
/*    */   public void setOwnerName(String name) {
/* 47 */     this.DataWatcher.watch(17, name);
/*    */   }
/*    */   
/*    */   public String getOwnerName()
/*    */   {
/* 52 */     return this.DataWatcher.getString(17);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseTameableAnimal.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */