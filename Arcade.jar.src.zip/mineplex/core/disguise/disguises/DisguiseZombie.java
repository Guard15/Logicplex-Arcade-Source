/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseZombie extends DisguiseMonster
/*    */ {
/*    */   public DisguiseZombie(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     this(org.bukkit.entity.EntityType.ZOMBIE, entity);
/*    */   }
/*    */   
/*    */   public DisguiseZombie(org.bukkit.entity.EntityType disguiseType, org.bukkit.entity.Entity entity)
/*    */   {
/* 14 */     super(disguiseType, entity);
/*    */     
/* 16 */     this.DataWatcher.a(12, Byte.valueOf((byte)0));
/* 17 */     this.DataWatcher.a(13, Byte.valueOf((byte)0));
/* 18 */     this.DataWatcher.a(14, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public boolean IsBaby()
/*    */   {
/* 23 */     return this.DataWatcher.getByte(12) == 1;
/*    */   }
/*    */   
/*    */   public void SetBaby(boolean baby)
/*    */   {
/* 28 */     this.DataWatcher.watch(12, Byte.valueOf((byte)(baby ? 1 : 0)));
/*    */   }
/*    */   
/*    */   public boolean IsVillager()
/*    */   {
/* 33 */     return this.DataWatcher.getByte(13) == 1;
/*    */   }
/*    */   
/*    */   public void SetVillager(boolean villager)
/*    */   {
/* 38 */     this.DataWatcher.watch(13, Byte.valueOf((byte)(villager ? 1 : 0)));
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 43 */     return "mob.zombie.hurt";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseZombie.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */