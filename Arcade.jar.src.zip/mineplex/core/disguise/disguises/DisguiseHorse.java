/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.bukkit.entity.Horse.Variant;
/*    */ 
/*    */ public class DisguiseHorse extends DisguiseAnimal
/*    */ {
/*    */   public DisguiseHorse(org.bukkit.entity.Entity entity)
/*    */   {
/* 10 */     super(org.bukkit.entity.EntityType.HORSE, entity);
/*    */     
/* 12 */     this.DataWatcher.a(16, Integer.valueOf(0));
/* 13 */     this.DataWatcher.a(19, Byte.valueOf((byte)0));
/* 14 */     this.DataWatcher.a(20, Integer.valueOf(0));
/* 15 */     this.DataWatcher.a(21, String.valueOf(""));
/* 16 */     this.DataWatcher.a(22, Integer.valueOf(0));
/*    */   }
/*    */   
/*    */   public void setType(Horse.Variant horseType)
/*    */   {
/* 21 */     this.DataWatcher.watch(19, Byte.valueOf((byte)horseType.ordinal()));
/*    */   }
/*    */   
/*    */   public Horse.Variant getType()
/*    */   {
/* 26 */     return Horse.Variant.values()[this.DataWatcher.getByte(19)];
/*    */   }
/*    */   
/*    */   public void setVariant(org.bukkit.entity.Horse.Color color)
/*    */   {
/* 31 */     this.DataWatcher.watch(20, Integer.valueOf(color.ordinal()));
/*    */   }
/*    */   
/*    */   public org.bukkit.entity.Horse.Color getVariant()
/*    */   {
/* 36 */     return org.bukkit.entity.Horse.Color.values()[this.DataWatcher.getInt(20)];
/*    */   }
/*    */   
/*    */   private boolean w(int i)
/*    */   {
/* 41 */     return (this.DataWatcher.getInt(16) & i) != 0;
/*    */   }
/*    */   
/*    */   public void kick()
/*    */   {
/* 46 */     b(32, false);
/* 47 */     b(64, true);
/*    */   }
/*    */   
/*    */   public void stopKick()
/*    */   {
/* 52 */     b(64, false);
/*    */   }
/*    */   
/*    */   private void b(int i, boolean flag)
/*    */   {
/* 57 */     int j = this.DataWatcher.getInt(16);
/*    */     
/* 59 */     if (flag) {
/* 60 */       this.DataWatcher.watch(16, Integer.valueOf(j | i));
/*    */     } else {
/* 62 */       this.DataWatcher.watch(16, Integer.valueOf(j & (i ^ 0xFFFFFFFF)));
/*    */     }
/*    */   }
/*    */   
/*    */   public String getOwnerName() {
/* 67 */     return this.DataWatcher.getString(21);
/*    */   }
/*    */   
/*    */   public void setOwnerName(String s)
/*    */   {
/* 72 */     this.DataWatcher.watch(21, s);
/*    */   }
/*    */   
/*    */   public int cf()
/*    */   {
/* 77 */     return this.DataWatcher.getInt(22);
/*    */   }
/*    */   
/*    */   public void r(int i)
/*    */   {
/* 82 */     this.DataWatcher.watch(22, Integer.valueOf(i));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseHorse.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */