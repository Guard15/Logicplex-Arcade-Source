/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ public class DisguiseWither extends DisguiseMonster
/*    */ {
/*    */   public DisguiseWither(Entity entity)
/*    */   {
/* 10 */     super(org.bukkit.entity.EntityType.WITHER, entity);
/*    */     
/* 12 */     this.DataWatcher.a(17, new Integer(0));
/* 13 */     this.DataWatcher.a(18, new Integer(0));
/* 14 */     this.DataWatcher.a(19, new Integer(0));
/* 15 */     this.DataWatcher.a(20, new Integer(0));
/*    */   }
/*    */   
/*    */   public int ca()
/*    */   {
/* 20 */     return this.DataWatcher.getInt(20);
/*    */   }
/*    */   
/*    */   public void s(int i)
/*    */   {
/* 25 */     this.DataWatcher.watch(20, Integer.valueOf(i));
/*    */   }
/*    */   
/*    */   public int t(int i)
/*    */   {
/* 30 */     return this.DataWatcher.getInt(17 + i);
/*    */   }
/*    */   
/*    */   public void b(int i, int j)
/*    */   {
/* 35 */     this.DataWatcher.watch(17 + i, Integer.valueOf(j));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseWither.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */