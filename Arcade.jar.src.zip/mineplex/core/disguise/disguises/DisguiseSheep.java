/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import org.bukkit.DyeColor;
/*    */ 
/*    */ public class DisguiseSheep extends DisguiseAnimal
/*    */ {
/*    */   public DisguiseSheep(org.bukkit.entity.Entity entity)
/*    */   {
/* 10 */     super(org.bukkit.entity.EntityType.SHEEP, entity);
/*    */     
/* 12 */     this.DataWatcher.a(16, new Byte((byte)0));
/*    */   }
/*    */   
/*    */   public boolean isSheared()
/*    */   {
/* 17 */     return (this.DataWatcher.getByte(16) & 0x10) != 0;
/*    */   }
/*    */   
/*    */   public void setSheared(boolean sheared)
/*    */   {
/* 22 */     byte b0 = this.DataWatcher.getByte(16);
/*    */     
/* 24 */     if (sheared) {
/* 25 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 | 0x10)));
/*    */     } else {
/* 27 */       this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 & 0xFFFFFFEF)));
/*    */     }
/*    */   }
/*    */   
/*    */   public int getColor() {
/* 32 */     return this.DataWatcher.getByte(16) & 0xF;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setColor(DyeColor color)
/*    */   {
/* 38 */     byte b0 = this.DataWatcher.getByte(16);
/*    */     
/* 40 */     this.DataWatcher.watch(16, Byte.valueOf((byte)(b0 & 0xF0 | color.getWoolData() & 0xF)));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseSheep.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */