/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import mineplex.core.common.DummyEntity;
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityMetadata;
/*    */ import net.minecraft.server.v1_7_R4.World;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class DisguiseBase
/*    */ {
/*    */   protected net.minecraft.server.v1_7_R4.Entity Entity;
/*    */   protected DataWatcher DataWatcher;
/*    */   private DisguiseBase _soundDisguise;
/* 20 */   public boolean Global = true;
/*    */   
/*    */   public DisguiseBase(org.bukkit.entity.Entity entity)
/*    */   {
/* 24 */     if (entity != null)
/*    */     {
/* 26 */       setEntity(entity);
/*    */     }
/*    */     
/* 29 */     this.DataWatcher = new DataWatcher(new DummyEntity(null));
/*    */     
/* 31 */     this.DataWatcher.a(0, Byte.valueOf((byte)0));
/* 32 */     this.DataWatcher.a(1, Short.valueOf((short)300));
/*    */     
/* 34 */     this._soundDisguise = this;
/*    */   }
/*    */   
/*    */   public void setEntity(org.bukkit.entity.Entity entity)
/*    */   {
/* 39 */     this.Entity = ((CraftEntity)entity).getHandle();
/*    */   }
/*    */   
/*    */   public void UpdateDataWatcher()
/*    */   {
/* 44 */     this.DataWatcher.watch(0, Byte.valueOf(this.Entity.getDataWatcher().getByte(0)));
/* 45 */     this.DataWatcher.watch(1, Short.valueOf(this.Entity.getDataWatcher().getShort(1)));
/*    */   }
/*    */   
/*    */   public abstract Packet GetSpawnPacket();
/*    */   
/*    */   public Packet GetMetaDataPacket()
/*    */   {
/* 52 */     UpdateDataWatcher();
/* 53 */     return new PacketPlayOutEntityMetadata(this.Entity.getId(), this.DataWatcher, true);
/*    */   }
/*    */   
/*    */   public void setSoundDisguise(DisguiseBase soundDisguise)
/*    */   {
/* 58 */     this._soundDisguise = soundDisguise;
/*    */     
/* 60 */     if (this._soundDisguise == null) {
/* 61 */       this._soundDisguise = this;
/*    */     }
/*    */   }
/*    */   
/*    */   public void playHurtSound() {
/* 66 */     this.Entity.world.makeSound(this.Entity, this._soundDisguise.getHurtSound(), this._soundDisguise.getVolume(), this._soundDisguise.getPitch());
/*    */   }
/*    */   
/*    */   public void playHurtSound(Location location)
/*    */   {
/* 71 */     this.Entity.world.makeSound(location.getX(), location.getY(), location.getZ(), this._soundDisguise.getHurtSound(), this._soundDisguise.getVolume(), this._soundDisguise.getPitch());
/*    */   }
/*    */   
/*    */   public net.minecraft.server.v1_7_R4.Entity GetEntity()
/*    */   {
/* 76 */     return this.Entity;
/*    */   }
/*    */   
/*    */   public int GetEntityId()
/*    */   {
/* 81 */     return this.Entity.getId();
/*    */   }
/*    */   
/*    */   protected abstract String getHurtSound();
/*    */   
/*    */   protected abstract float getVolume();
/*    */   
/*    */   protected abstract float getPitch();
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseBase.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */