/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import net.minecraft.server.v1_7_R4.MobEffect;
/*    */ import net.minecraft.server.v1_7_R4.MobEffectList;
/*    */ import net.minecraft.server.v1_7_R4.PotionBrewer;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.spigotmc.ProtocolData.ByteShort;
/*    */ 
/*    */ public class DisguiseEnderman extends DisguiseMonster
/*    */ {
/*    */   public DisguiseEnderman(Entity entity)
/*    */   {
/* 16 */     super(EntityType.ENDERMAN, entity);
/*    */     
/* 18 */     this.DataWatcher.a(16, new ProtocolData.ByteShort((short)0));
/* 19 */     this.DataWatcher.a(17, new Byte((byte)0));
/* 20 */     this.DataWatcher.a(18, new Byte((byte)0));
/*    */     
/* 22 */     int i = PotionBrewer.a(Arrays.asList(new MobEffect[] { new MobEffect(MobEffectList.FIRE_RESISTANCE.id, 777) }));
/* 23 */     this.DataWatcher.watch(8, Byte.valueOf((byte)(PotionBrewer.b(Arrays.asList(tmp99_96)) ? 1 : 0)));
/* 24 */     this.DataWatcher.watch(7, Integer.valueOf(i));
/*    */   }
/*    */   
/*    */   public void UpdateDataWatcher()
/*    */   {
/* 29 */     super.UpdateDataWatcher();
/*    */     
/* 31 */     this.DataWatcher.watch(0, Byte.valueOf((byte)(this.DataWatcher.getByte(0) & 0xFFFFFFFE)));
/* 32 */     this.DataWatcher.watch(16, new ProtocolData.ByteShort(this.DataWatcher.getShort(16)));
/*    */   }
/*    */   
/*    */   public void SetCarriedId(int i)
/*    */   {
/* 37 */     this.DataWatcher.watch(16, new ProtocolData.ByteShort((short)(i & 0xFF)));
/*    */   }
/*    */   
/*    */   public int GetCarriedId()
/*    */   {
/* 42 */     return this.DataWatcher.getByte(16);
/*    */   }
/*    */   
/*    */   public void SetCarriedData(int i)
/*    */   {
/* 47 */     this.DataWatcher.watch(17, Byte.valueOf((byte)(i & 0xFF)));
/*    */   }
/*    */   
/*    */   public int GetCarriedData()
/*    */   {
/* 52 */     return this.DataWatcher.getByte(17);
/*    */   }
/*    */   
/*    */   public boolean bX()
/*    */   {
/* 57 */     return this.DataWatcher.getByte(18) > 0;
/*    */   }
/*    */   
/*    */   public void a(boolean flag)
/*    */   {
/* 62 */     this.DataWatcher.watch(18, Byte.valueOf((byte)(flag ? 1 : 0)));
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 67 */     return "mob.endermen.hit";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseEnderman.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */