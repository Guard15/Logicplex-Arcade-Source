/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import mineplex.core.common.Rank;
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public abstract class DisguiseInsentient extends DisguiseLiving
/*    */ {
/*    */   private boolean _showArmor;
/*    */   
/*    */   public DisguiseInsentient(org.bukkit.entity.Entity entity)
/*    */   {
/* 12 */     super(entity);
/*    */     
/* 14 */     this.DataWatcher.a(3, Byte.valueOf((byte)0));
/* 15 */     this.DataWatcher.a(2, "");
/*    */     
/* 17 */     if (!(this instanceof DisguiseArmorStand))
/*    */     {
/* 19 */       this.DataWatcher.a(11, Byte.valueOf((byte)0));
/* 20 */       this.DataWatcher.a(10, "");
/*    */     }
/*    */   }
/*    */   
/*    */   public void setName(String name)
/*    */   {
/* 26 */     setName(name, null);
/*    */   }
/*    */   
/*    */   public void setName(String name, Rank rank)
/*    */   {
/* 31 */     if (rank != null)
/*    */     {
/* 33 */       if (rank.Has(Rank.ULTRA))
/*    */       {
/* 35 */         name = rank.GetTag(true, true) + " " + org.bukkit.ChatColor.RESET + name;
/*    */       }
/*    */     }
/*    */     
/* 39 */     this.DataWatcher.watch(10, name);
/* 40 */     this.DataWatcher.watch(2, name);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean hasCustomName()
/*    */   {
/* 46 */     return this.DataWatcher.getString(10).length() > 0;
/*    */   }
/*    */   
/*    */   public void setCustomNameVisible(boolean visible)
/*    */   {
/* 51 */     this.DataWatcher.watch(11, Byte.valueOf((byte)(visible ? 1 : 0)));
/* 52 */     this.DataWatcher.watch(3, Byte.valueOf((byte)(visible ? 1 : 0)));
/*    */   }
/*    */   
/*    */   public boolean getCustomNameVisible()
/*    */   {
/* 57 */     return this.DataWatcher.getByte(11) == 1;
/*    */   }
/*    */   
/*    */   public boolean armorVisible()
/*    */   {
/* 62 */     return this._showArmor;
/*    */   }
/*    */   
/*    */   public void showArmor()
/*    */   {
/* 67 */     this._showArmor = true;
/*    */   }
/*    */   
/*    */   public void hideArmor()
/*    */   {
/* 72 */     this._showArmor = false;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseInsentient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */