/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public abstract class DisguiseHuman extends DisguiseLiving
/*    */ {
/*    */   public DisguiseHuman(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(entity);
/*    */     
/* 11 */     this.DataWatcher.a(10, new org.spigotmc.ProtocolData.HiddenByte((byte)0));
/* 12 */     this.DataWatcher.a(16, new org.spigotmc.ProtocolData.DualByte((byte)0, (byte)0));
/* 13 */     this.DataWatcher.a(17, Float.valueOf(0.0F));
/* 14 */     this.DataWatcher.a(18, Integer.valueOf(0));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseHuman.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */