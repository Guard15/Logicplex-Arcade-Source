/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import net.minecraft.server.v1_7_R4.EnumEntitySize;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*    */ 
/*    */ public class DisguiseSlime extends DisguiseInsentient
/*    */ {
/*    */   public DisguiseSlime(org.bukkit.entity.Entity entity)
/*    */   {
/* 12 */     super(entity);
/*    */     
/* 14 */     this.DataWatcher.a(16, new Byte((byte)1));
/*    */   }
/*    */   
/*    */   public void SetSize(int i)
/*    */   {
/* 19 */     this.DataWatcher.watch(16, new Byte((byte)i));
/*    */   }
/*    */   
/*    */   public int GetSize()
/*    */   {
/* 24 */     return this.DataWatcher.getByte(16);
/*    */   }
/*    */   
/*    */   public Packet GetSpawnPacket()
/*    */   {
/* 29 */     PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
/* 30 */     packet.a = this.Entity.getId();
/* 31 */     packet.b = 55;
/* 32 */     packet.c = EnumEntitySize.SIZE_2.a(this.Entity.locX);
/* 33 */     packet.d = net.minecraft.server.v1_7_R4.MathHelper.floor(this.Entity.locY * 32.0D);
/* 34 */     packet.e = EnumEntitySize.SIZE_2.a(this.Entity.locZ);
/* 35 */     packet.i = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/* 36 */     packet.j = ((byte)(int)(this.Entity.pitch * 256.0F / 360.0F));
/* 37 */     packet.k = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/*    */     
/* 39 */     double var2 = 3.9D;
/* 40 */     double var4 = 0.0D;
/* 41 */     double var6 = 0.0D;
/* 42 */     double var8 = 0.0D;
/*    */     
/* 44 */     if (var4 < -var2)
/*    */     {
/* 46 */       var4 = -var2;
/*    */     }
/*    */     
/* 49 */     if (var6 < -var2)
/*    */     {
/* 51 */       var6 = -var2;
/*    */     }
/*    */     
/* 54 */     if (var8 < -var2)
/*    */     {
/* 56 */       var8 = -var2;
/*    */     }
/*    */     
/* 59 */     if (var4 > var2)
/*    */     {
/* 61 */       var4 = var2;
/*    */     }
/*    */     
/* 64 */     if (var6 > var2)
/*    */     {
/* 66 */       var6 = var2;
/*    */     }
/*    */     
/* 69 */     if (var8 > var2)
/*    */     {
/* 71 */       var8 = var2;
/*    */     }
/*    */     
/* 74 */     packet.f = ((int)(var4 * 8000.0D));
/* 75 */     packet.g = ((int)(var6 * 8000.0D));
/* 76 */     packet.h = ((int)(var8 * 8000.0D));
/* 77 */     packet.l = this.DataWatcher;
/* 78 */     packet.m = this.DataWatcher.b();
/*    */     
/* 80 */     return packet;
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 85 */     return "mob.slime." + (GetSize() > 1 ? "big" : "small");
/*    */   }
/*    */   
/*    */   protected float getVolume()
/*    */   {
/* 90 */     return 0.4F * GetSize();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseSlime.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */