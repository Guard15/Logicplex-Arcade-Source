/*     */ package mineplex.core.disguise.disguises;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import net.minecraft.server.v1_7_R4.EntityLiving;
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityEquipment;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.inventory.CraftItemStack;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ 
/*     */ public abstract class DisguiseLiving
/*     */   extends DisguiseBase
/*     */ {
/*  16 */   private static Random _random = new Random();
/*     */   private boolean _invisible;
/*  18 */   private ItemStack[] _equipment = new ItemStack[5];
/*     */   
/*     */   public DisguiseLiving(org.bukkit.entity.Entity entity)
/*     */   {
/*  22 */     super(entity);
/*     */     
/*  24 */     this.DataWatcher.a(6, Float.valueOf(1.0F));
/*  25 */     this.DataWatcher.a(7, Integer.valueOf(0));
/*  26 */     this.DataWatcher.a(8, Byte.valueOf((byte)0));
/*  27 */     this.DataWatcher.a(9, Byte.valueOf((byte)0));
/*     */   }
/*     */   
/*     */   public ItemStack[] getEquipment()
/*     */   {
/*  32 */     return this._equipment;
/*     */   }
/*     */   
/*     */   public void setEquipment(ItemStack[] equipment)
/*     */   {
/*  37 */     this._equipment = equipment;
/*     */   }
/*     */   
/*     */   public void setHelmet(ItemStack item)
/*     */   {
/*  42 */     this._equipment[3] = item;
/*     */   }
/*     */   
/*     */   public void setChestplate(ItemStack item)
/*     */   {
/*  47 */     this._equipment[2] = item;
/*     */   }
/*     */   
/*     */   public void setLeggings(ItemStack item)
/*     */   {
/*  52 */     this._equipment[1] = item;
/*     */   }
/*     */   
/*     */   public void setBoots(ItemStack item)
/*     */   {
/*  57 */     this._equipment[0] = item;
/*     */   }
/*     */   
/*     */   public void setHeldItem(ItemStack item)
/*     */   {
/*  62 */     this._equipment[4] = item;
/*     */   }
/*     */   
/*     */   public ArrayList<Packet> getEquipmentPackets()
/*     */   {
/*  67 */     ArrayList<Packet> packets = new ArrayList();
/*     */     
/*  69 */     for (int nmsSlot = 0; nmsSlot < 5; nmsSlot++)
/*     */     {
/*  71 */       int armorSlot = nmsSlot - 1;
/*     */       
/*  73 */       if (armorSlot < 0) {
/*  74 */         armorSlot = 4;
/*     */       }
/*  76 */       ItemStack itemstack = this._equipment[armorSlot];
/*     */       
/*  78 */       if ((itemstack != null) && (itemstack.getType() != Material.AIR))
/*     */       {
/*  80 */         ItemStack item = null;
/*     */         
/*  82 */         if ((this.Entity instanceof EntityLiving))
/*     */         {
/*  84 */           item = CraftItemStack.asBukkitCopy(((EntityLiving)this.Entity).getEquipment()[nmsSlot]);
/*     */         }
/*     */         
/*  87 */         if ((item == null) || (item.getType() == Material.AIR))
/*     */         {
/*  89 */           PacketPlayOutEntityEquipment packet = new PacketPlayOutEntityEquipment();
/*     */           
/*  91 */           packet.a = GetEntityId();
/*  92 */           packet.b = nmsSlot;
/*  93 */           packet.c = CraftItemStack.asNMSCopy(itemstack);
/*     */           
/*  95 */           packets.add(packet);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 100 */     return packets;
/*     */   }
/*     */   
/*     */   public void UpdateDataWatcher()
/*     */   {
/* 105 */     super.UpdateDataWatcher();
/* 106 */     byte b0 = this.DataWatcher.getByte(0);
/*     */     
/* 108 */     if (this._invisible) {
/* 109 */       this.DataWatcher.watch(0, Byte.valueOf((byte)(b0 | 0x20)));
/*     */     } else {
/* 111 */       this.DataWatcher.watch(0, Byte.valueOf((byte)(b0 & 0xFFFFFFDF)));
/*     */     }
/* 113 */     if ((this.Entity instanceof EntityLiving))
/*     */     {
/* 115 */       this.DataWatcher.watch(6, Float.valueOf(this.Entity.getDataWatcher().getFloat(6)));
/* 116 */       this.DataWatcher.watch(7, Integer.valueOf(this.Entity.getDataWatcher().getInt(7)));
/* 117 */       this.DataWatcher.watch(8, Byte.valueOf(this.Entity.getDataWatcher().getByte(8)));
/* 118 */       this.DataWatcher.watch(9, Byte.valueOf(this.Entity.getDataWatcher().getByte(9)));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isInvisible()
/*     */   {
/* 124 */     return this._invisible;
/*     */   }
/*     */   
/*     */   public void setInvisible(boolean invisible)
/*     */   {
/* 129 */     this._invisible = invisible;
/*     */   }
/*     */   
/*     */   protected String getHurtSound()
/*     */   {
/* 134 */     return "damage.hit";
/*     */   }
/*     */   
/*     */   protected float getVolume()
/*     */   {
/* 139 */     return 1.0F;
/*     */   }
/*     */   
/*     */   protected float getPitch()
/*     */   {
/* 144 */     return (_random.nextFloat() - _random.nextFloat()) * 0.2F + 1.0F;
/*     */   }
/*     */   
/*     */   public void setHealth(float health)
/*     */   {
/* 149 */     this.DataWatcher.watch(6, Float.valueOf(health));
/*     */   }
/*     */   
/*     */   public float getHealth()
/*     */   {
/* 154 */     return this.DataWatcher.getFloat(6);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseLiving.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */