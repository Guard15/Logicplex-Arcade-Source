/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ import net.minecraft.server.v1_7_R4.EnumEntitySize;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*    */ import org.bukkit.entity.EntityType;
/*    */ 
/*    */ public abstract class DisguiseCreature extends DisguiseInsentient
/*    */ {
/*    */   private final EntityType _disguiseType;
/*    */   
/*    */   public DisguiseCreature(EntityType disguiseType, org.bukkit.entity.Entity entity)
/*    */   {
/* 15 */     super(entity);
/*    */     
/* 17 */     this._disguiseType = disguiseType;
/*    */   }
/*    */   
/*    */   public EntityType getDisguiseType()
/*    */   {
/* 22 */     return this._disguiseType;
/*    */   }
/*    */   
/*    */ 
/*    */   public Packet GetSpawnPacket()
/*    */   {
/* 28 */     PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
/* 29 */     packet.a = this.Entity.getId();
/* 30 */     packet.b = ((byte)getDisguiseType().getTypeId());
/* 31 */     packet.c = EnumEntitySize.SIZE_2.a(this.Entity.locX);
/* 32 */     packet.d = net.minecraft.server.v1_7_R4.MathHelper.floor(this.Entity.locY * 32.0D);
/* 33 */     packet.e = EnumEntitySize.SIZE_2.a(this.Entity.locZ);
/* 34 */     packet.i = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/* 35 */     packet.j = ((byte)(int)(this.Entity.pitch * 256.0F / 360.0F));
/* 36 */     packet.k = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/*    */     
/* 38 */     double var2 = 3.9D;
/* 39 */     double var4 = 0.0D;
/* 40 */     double var6 = 0.0D;
/* 41 */     double var8 = 0.0D;
/*    */     
/* 43 */     if (var4 < -var2)
/*    */     {
/* 45 */       var4 = -var2;
/*    */     }
/*    */     
/* 48 */     if (var6 < -var2)
/*    */     {
/* 50 */       var6 = -var2;
/*    */     }
/*    */     
/* 53 */     if (var8 < -var2)
/*    */     {
/* 55 */       var8 = -var2;
/*    */     }
/*    */     
/* 58 */     if (var4 > var2)
/*    */     {
/* 60 */       var4 = var2;
/*    */     }
/*    */     
/* 63 */     if (var6 > var2)
/*    */     {
/* 65 */       var6 = var2;
/*    */     }
/*    */     
/* 68 */     if (var8 > var2)
/*    */     {
/* 70 */       var8 = var2;
/*    */     }
/*    */     
/* 73 */     packet.f = ((int)(var4 * 8000.0D));
/* 74 */     packet.g = ((int)(var6 * 8000.0D));
/* 75 */     packet.h = ((int)(var8 * 8000.0D));
/*    */     
/* 77 */     packet.l = this.DataWatcher;
/* 78 */     packet.m = this.DataWatcher.b();
/*    */     
/* 80 */     return packet;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseCreature.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */