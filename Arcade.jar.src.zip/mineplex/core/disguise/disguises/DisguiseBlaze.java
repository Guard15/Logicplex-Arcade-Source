/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseBlaze extends DisguiseMonster
/*    */ {
/*    */   public DisguiseBlaze(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.BLAZE, entity);
/*    */     
/* 11 */     this.DataWatcher.a(16, new Byte((byte)0));
/*    */   }
/*    */   
/*    */   public boolean bT()
/*    */   {
/* 16 */     return (this.DataWatcher.getByte(16) & 0x1) != 0;
/*    */   }
/*    */   
/*    */   public void a(boolean flag)
/*    */   {
/* 21 */     byte b0 = this.DataWatcher.getByte(16);
/*    */     
/* 23 */     if (flag) {
/* 24 */       b0 = (byte)(b0 | 0x1);
/*    */     } else {
/* 26 */       b0 = (byte)(b0 | 0xFFFFFFFE);
/*    */     }
/* 28 */     this.DataWatcher.watch(16, Byte.valueOf(b0));
/*    */   }
/*    */   
/*    */   public String getHurtSound()
/*    */   {
/* 33 */     return "mob.blaze.hit";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseBlaze.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */