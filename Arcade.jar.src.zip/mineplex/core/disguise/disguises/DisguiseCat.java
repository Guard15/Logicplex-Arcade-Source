/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseCat extends DisguiseTameableAnimal
/*    */ {
/*    */   public DisguiseCat(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.OCELOT, entity);
/*    */     
/* 11 */     this.DataWatcher.a(18, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public int getCatType()
/*    */   {
/* 16 */     return this.DataWatcher.getByte(18);
/*    */   }
/*    */   
/*    */   public void setCatType(int i)
/*    */   {
/* 21 */     this.DataWatcher.watch(18, Byte.valueOf((byte)i));
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 26 */     return "mob.cat.hitt";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseCat.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */