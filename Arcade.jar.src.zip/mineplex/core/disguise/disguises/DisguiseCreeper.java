/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*    */ 
/*    */ public class DisguiseCreeper extends DisguiseMonster
/*    */ {
/*    */   public DisguiseCreeper(org.bukkit.entity.Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.CREEPER, entity);
/*    */     
/* 11 */     this.DataWatcher.a(16, Byte.valueOf((byte)-1));
/* 12 */     this.DataWatcher.a(17, Byte.valueOf((byte)0));
/*    */   }
/*    */   
/*    */   public boolean IsPowered()
/*    */   {
/* 17 */     return this.DataWatcher.getByte(17) == 1;
/*    */   }
/*    */   
/*    */   public void SetPowered(boolean powered)
/*    */   {
/* 22 */     this.DataWatcher.watch(17, Byte.valueOf((byte)(powered ? 1 : 0)));
/*    */   }
/*    */   
/*    */   public int bV()
/*    */   {
/* 27 */     return this.DataWatcher.getByte(16);
/*    */   }
/*    */   
/*    */   public void a(int i)
/*    */   {
/* 32 */     this.DataWatcher.watch(16, Byte.valueOf((byte)i));
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 37 */     return "mob.creeper.say";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseCreeper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */