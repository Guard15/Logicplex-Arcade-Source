/*   */ package mineplex.core.disguise.disguises;
/*   */ 
/*   */ import org.bukkit.entity.Entity;
/*   */ 
/*   */ public class DisguiseSnowman extends DisguiseGolem
/*   */ {
/*   */   public DisguiseSnowman(Entity entity)
/*   */   {
/* 9 */     super(org.bukkit.entity.EntityType.SNOWMAN, entity);
/*   */   }
/*   */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseSnowman.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */