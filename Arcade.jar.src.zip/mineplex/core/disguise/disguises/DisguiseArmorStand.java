/*     */ package mineplex.core.disguise.disguises;
/*     */ 
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import net.minecraft.server.v1_7_R4.EnumEntitySize;
/*     */ import net.minecraft.server.v1_7_R4.MathHelper;
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class DisguiseArmorStand extends DisguiseInsentient
/*     */ {
/*  12 */   private Vector _headPosition = new Vector();
/*     */   
/*     */   public DisguiseArmorStand(org.bukkit.entity.Entity entity)
/*     */   {
/*  16 */     super(entity);
/*     */     
/*  18 */     this.DataWatcher.a(10, Byte.valueOf((byte)0));
/*     */     
/*  20 */     for (int i = 11; i < 17; i++)
/*     */     {
/*  22 */       this.DataWatcher.a(i, new Vector(0, 0, 0));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Vector getHeadPosition()
/*     */   {
/*  30 */     return this._headPosition.clone();
/*     */   }
/*     */   
/*     */   protected String getHurtSound()
/*     */   {
/*  35 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   public Packet GetSpawnPacket()
/*     */   {
/*  41 */     PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
/*  42 */     packet.a = this.Entity.getId();
/*  43 */     packet.b = 30;
/*  44 */     packet.c = EnumEntitySize.SIZE_2.a(this.Entity.locX);
/*  45 */     packet.d = MathHelper.floor(this.Entity.locY * 32.0D);
/*  46 */     packet.e = EnumEntitySize.SIZE_2.a(this.Entity.locZ);
/*  47 */     packet.i = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/*  48 */     packet.j = ((byte)(int)(this.Entity.pitch * 256.0F / 360.0F));
/*  49 */     packet.k = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/*     */     
/*  51 */     double var2 = 3.9D;
/*  52 */     double var4 = 0.0D;
/*  53 */     double var6 = 0.0D;
/*  54 */     double var8 = 0.0D;
/*     */     
/*  56 */     if (var4 < -var2)
/*     */     {
/*  58 */       var4 = -var2;
/*     */     }
/*     */     
/*  61 */     if (var6 < -var2)
/*     */     {
/*  63 */       var6 = -var2;
/*     */     }
/*     */     
/*  66 */     if (var8 < -var2)
/*     */     {
/*  68 */       var8 = -var2;
/*     */     }
/*     */     
/*  71 */     if (var4 > var2)
/*     */     {
/*  73 */       var4 = var2;
/*     */     }
/*     */     
/*  76 */     if (var6 > var2)
/*     */     {
/*  78 */       var6 = var2;
/*     */     }
/*     */     
/*  81 */     if (var8 > var2)
/*     */     {
/*  83 */       var8 = var2;
/*     */     }
/*     */     
/*  86 */     packet.f = ((int)(var4 * 8000.0D));
/*  87 */     packet.g = ((int)(var6 * 8000.0D));
/*  88 */     packet.h = ((int)(var8 * 8000.0D));
/*     */     
/*  90 */     packet.l = this.DataWatcher;
/*  91 */     packet.m = this.DataWatcher.b();
/*     */     
/*  93 */     return packet;
/*     */   }
/*     */   
/*     */   public void setBodyPosition(Vector vector)
/*     */   {
/*  98 */     this.DataWatcher.watch(12, vector);
/*     */   }
/*     */   
/*     */   public void setHasArms()
/*     */   {
/* 103 */     this.DataWatcher.watch(10, Integer.valueOf(this.DataWatcher.getByte(10) | 0x4));
/*     */   }
/*     */   
/*     */   public void setHeadPosition(Vector vector)
/*     */   {
/* 108 */     this._headPosition = vector;
/* 109 */     this.DataWatcher.watch(11, vector);
/*     */   }
/*     */   
/*     */   public void setLeftArmPosition(Vector vector)
/*     */   {
/* 114 */     this.DataWatcher.watch(13, vector);
/*     */   }
/*     */   
/*     */   public void setLeftLegPosition(Vector vector)
/*     */   {
/* 119 */     this.DataWatcher.watch(15, vector);
/*     */   }
/*     */   
/*     */   public void setRemoveBase()
/*     */   {
/* 124 */     this.DataWatcher.watch(10, Integer.valueOf(this.DataWatcher.getByte(10) | 0x8));
/*     */   }
/*     */   
/*     */   public void setRightArmPosition(Vector vector)
/*     */   {
/* 129 */     this.DataWatcher.watch(14, vector);
/*     */   }
/*     */   
/*     */   public void setRightLegPosition(Vector vector)
/*     */   {
/* 134 */     this.DataWatcher.watch(16, vector);
/*     */   }
/*     */   
/*     */   public void setSmall()
/*     */   {
/* 139 */     this.DataWatcher.watch(10, Integer.valueOf(this.DataWatcher.getByte(10) | 0x1));
/*     */   }
/*     */   
/*     */   public void setGravityEffected()
/*     */   {
/* 144 */     this.DataWatcher.watch(10, Integer.valueOf(this.DataWatcher.getByte(10) | 0x2));
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseArmorStand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */