/*     */ package mineplex.core.disguise.disguises;
/*     */ 
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import net.minecraft.server.v1_7_R4.MathHelper;
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutNamedEntitySpawn;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutPlayerInfo;
/*     */ import net.minecraft.util.com.mojang.authlib.GameProfile;
/*     */ import net.minecraft.util.com.mojang.authlib.properties.PropertyMap;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class DisguisePlayer extends DisguiseHuman
/*     */ {
/*     */   private GameProfile _profile;
/*     */   private boolean _sneaking;
/*     */   private BlockFace _sleeping;
/*     */   
/*     */   public DisguisePlayer(org.bukkit.entity.Entity entity)
/*     */   {
/*  24 */     super(entity);
/*     */   }
/*     */   
/*     */   public DisguisePlayer(org.bukkit.entity.Entity entity, GameProfile profile)
/*     */   {
/*  29 */     this(entity);
/*     */     
/*  31 */     setProfile(profile);
/*     */   }
/*     */   
/*     */   public void setProfile(GameProfile profile)
/*     */   {
/*  36 */     GameProfile newProfile = new GameProfile(java.util.UUID.randomUUID(), profile.getName());
/*     */     
/*  38 */     newProfile.getProperties().putAll(profile.getProperties());
/*     */     
/*  40 */     this._profile = newProfile;
/*     */   }
/*     */   
/*     */   public BlockFace getSleepingDirection()
/*     */   {
/*  45 */     return this._sleeping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSleeping(BlockFace sleeping)
/*     */   {
/*  54 */     this._sleeping = sleeping;
/*     */   }
/*     */   
/*     */   public void setSneaking(boolean sneaking)
/*     */   {
/*  59 */     this._sneaking = sneaking;
/*     */   }
/*     */   
/*     */   public Packet getOldInfoPacket(boolean add)
/*     */   {
/*  64 */     PacketPlayOutPlayerInfo playerInfo = new PacketPlayOutPlayerInfo();
/*     */     
/*  66 */     if ((this.Entity instanceof Player))
/*     */     {
/*  68 */       playerInfo.username = this.Entity.getName();
/*  69 */       playerInfo.action = (add ? 0 : 4);
/*  70 */       playerInfo.ping = 90;
/*  71 */       playerInfo.player = ((CraftPlayer)this.Entity).getProfile();
/*  72 */       playerInfo.gamemode = 0;
/*     */     }
/*     */     
/*  75 */     return playerInfo;
/*     */   }
/*     */   
/*     */   public Packet getNewInfoPacket(boolean add)
/*     */   {
/*  80 */     PacketPlayOutPlayerInfo newDisguiseInfo = new PacketPlayOutPlayerInfo();
/*  81 */     newDisguiseInfo.username = this._profile.getName();
/*  82 */     newDisguiseInfo.action = (add ? 0 : 4);
/*  83 */     newDisguiseInfo.ping = 90;
/*  84 */     newDisguiseInfo.player = this._profile;
/*  85 */     newDisguiseInfo.gamemode = 0;
/*     */     
/*  87 */     return newDisguiseInfo;
/*     */   }
/*     */   
/*     */ 
/*     */   public void UpdateDataWatcher()
/*     */   {
/*  93 */     super.UpdateDataWatcher();
/*     */     
/*  95 */     byte b0 = this.DataWatcher.getByte(0);
/*     */     
/*  97 */     if (this._sneaking) {
/*  98 */       this.DataWatcher.watch(0, Byte.valueOf((byte)(b0 | 0x2)));
/*     */     } else {
/* 100 */       this.DataWatcher.watch(0, Byte.valueOf((byte)(b0 & 0xFFFFFFFD)));
/*     */     }
/*     */   }
/*     */   
/*     */   public PacketPlayOutNamedEntitySpawn spawnBeforePlayer(Location spawnLocation) {
/* 105 */     Location loc = spawnLocation.add(spawnLocation.getDirection().normalize().multiply(30));
/* 106 */     loc.setY(Math.max(loc.getY(), 0.0D));
/*     */     
/* 108 */     PacketPlayOutNamedEntitySpawn packet = new PacketPlayOutNamedEntitySpawn();
/* 109 */     packet.a = this.Entity.getId();
/* 110 */     packet.b = this._profile;
/* 111 */     packet.c = MathHelper.floor(loc.getX() * 32.0D);
/* 112 */     packet.d = MathHelper.floor(loc.getY() * 32.0D);
/* 113 */     packet.e = MathHelper.floor(loc.getZ() * 32.0D);
/* 114 */     packet.f = ((byte)(int)(loc.getYaw() * 256.0F / 360.0F));
/* 115 */     packet.g = ((byte)(int)(loc.getPitch() * 256.0F / 360.0F));
/* 116 */     packet.i = this.DataWatcher;
/*     */     
/* 118 */     return packet;
/*     */   }
/*     */   
/*     */ 
/*     */   public PacketPlayOutNamedEntitySpawn GetSpawnPacket()
/*     */   {
/* 124 */     PacketPlayOutNamedEntitySpawn packet = new PacketPlayOutNamedEntitySpawn();
/* 125 */     packet.a = this.Entity.getId();
/* 126 */     packet.b = this._profile;
/* 127 */     packet.c = MathHelper.floor(this.Entity.locX * 32.0D);
/* 128 */     packet.d = MathHelper.floor(this.Entity.locY * 32.0D);
/* 129 */     packet.e = MathHelper.floor(this.Entity.locZ * 32.0D);
/* 130 */     packet.f = ((byte)(int)(this.Entity.yaw * 256.0F / 360.0F));
/* 131 */     packet.g = ((byte)(int)(this.Entity.pitch * 256.0F / 360.0F));
/* 132 */     packet.i = this.DataWatcher;
/*     */     
/* 134 */     return packet;
/*     */   }
/*     */   
/*     */   public String getName()
/*     */   {
/* 139 */     return this._profile.getName();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguisePlayer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */