/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import java.util.Random;
/*    */ import net.minecraft.server.v1_7_R4.MathHelper;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntity;
/*    */ 
/*    */ public class DisguiseBlock
/*    */   extends DisguiseBase
/*    */ {
/* 11 */   private static Random _random = new Random();
/*    */   
/*    */   private int _blockId;
/*    */   private int _blockData;
/*    */   
/*    */   public DisguiseBlock(org.bukkit.entity.Entity entity, int blockId, int blockData)
/*    */   {
/* 18 */     super(entity);
/*    */     
/* 20 */     this._blockId = blockId;
/* 21 */     this._blockData = blockData;
/*    */   }
/*    */   
/*    */   public int GetBlockId()
/*    */   {
/* 26 */     return this._blockId;
/*    */   }
/*    */   
/*    */   public byte GetBlockData()
/*    */   {
/* 31 */     return (byte)this._blockData;
/*    */   }
/*    */   
/*    */ 
/*    */   public Packet GetSpawnPacket()
/*    */   {
/* 37 */     PacketPlayOutSpawnEntity packet = new PacketPlayOutSpawnEntity();
/* 38 */     packet.a = this.Entity.getId();
/* 39 */     packet.b = MathHelper.floor(this.Entity.locX * 32.0D);
/* 40 */     packet.c = MathHelper.floor(this.Entity.locY * 32.0D);
/* 41 */     packet.d = MathHelper.floor(this.Entity.locZ * 32.0D);
/* 42 */     packet.h = MathHelper.d(this.Entity.pitch * 256.0F / 360.0F);
/* 43 */     packet.i = MathHelper.d(this.Entity.yaw * 256.0F / 360.0F);
/* 44 */     packet.j = 70;
/* 45 */     packet.k = (this._blockId | this._blockData << 12);
/*    */     
/* 47 */     double d1 = this.Entity.motX;
/* 48 */     double d2 = this.Entity.motY;
/* 49 */     double d3 = this.Entity.motZ;
/* 50 */     double d4 = 3.9D;
/*    */     
/* 52 */     if (d1 < -d4) d1 = -d4;
/* 53 */     if (d2 < -d4) d2 = -d4;
/* 54 */     if (d3 < -d4) d3 = -d4;
/* 55 */     if (d1 > d4) d1 = d4;
/* 56 */     if (d2 > d4) d2 = d4;
/* 57 */     if (d3 > d4) { d3 = d4;
/*    */     }
/* 59 */     packet.e = ((int)(d1 * 8000.0D));
/* 60 */     packet.f = ((int)(d2 * 8000.0D));
/* 61 */     packet.g = ((int)(d3 * 8000.0D));
/*    */     
/* 63 */     return packet;
/*    */   }
/*    */   
/*    */   protected String getHurtSound()
/*    */   {
/* 68 */     return "damage.hit";
/*    */   }
/*    */   
/*    */   protected float getVolume()
/*    */   {
/* 73 */     return 1.0F;
/*    */   }
/*    */   
/*    */   protected float getPitch()
/*    */   {
/* 78 */     return (_random.nextFloat() - _random.nextFloat()) * 0.2F + 1.0F;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseBlock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */