/*    */ package mineplex.core.disguise.disguises;
/*    */ 
/*    */ import org.bukkit.entity.Entity;
/*    */ 
/*    */ public class DisguiseChicken extends DisguiseAnimal
/*    */ {
/*    */   public DisguiseChicken(Entity entity)
/*    */   {
/*  9 */     super(org.bukkit.entity.EntityType.CHICKEN, entity);
/*    */   }
/*    */   
/*    */   public String getHurtSound()
/*    */   {
/* 14 */     return "mob.chicken.hurt";
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\disguise\disguises\DisguiseChicken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */