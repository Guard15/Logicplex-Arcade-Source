/*     */ package mineplex.core.mount.types;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.mount.Mount;
/*     */ import mineplex.core.mount.MountManager;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Minecart;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityTargetEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.vehicle.VehicleDamageEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MountCart
/*     */   extends Mount<Minecart>
/*     */ {
/*     */   public MountCart(MountManager manager)
/*     */   {
/*  36 */     super(manager, "Minecart", Material.MINECART, (byte)0, new String[] {ChatColor.RESET + "Cruise around town in your", ChatColor.RESET + "new Minecart VX Turbo!" }, 15000);
/*     */     
/*  38 */     this.KnownPackage = false;
/*     */   }
/*     */   
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  43 */     player.leaveVehicle();
/*  44 */     player.eject();
/*     */     
/*     */ 
/*  47 */     this.Manager.DeregisterAll(player);
/*     */     
/*  49 */     Minecart mount = (Minecart)player.getWorld().spawn(player.getLocation().add(0.0D, 2.0D, 0.0D), Minecart.class);
/*     */     
/*     */ 
/*  52 */     UtilPlayer.message(player, F.main("Mount", "You spawned " + F.elem(GetName()) + "."));
/*     */     
/*     */ 
/*  55 */     this._active.put(player, mount);
/*     */   }
/*     */   
/*     */   public void Disable(Player player)
/*     */   {
/*  60 */     Minecart mount = (Minecart)this._active.remove(player);
/*  61 */     if (mount != null)
/*     */     {
/*  63 */       mount.remove();
/*     */       
/*     */ 
/*  66 */       UtilPlayer.message(player, F.main("Mount", "You despawned " + F.elem(GetName()) + "."));
/*     */       
/*  68 */       this.Manager.removeActive(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void interactMount(PlayerInteractEntityEvent event)
/*     */   {
/*  75 */     if (event.getRightClicked() == null) {
/*  76 */       return;
/*     */     }
/*  78 */     if (!GetActive().containsKey(event.getPlayer())) {
/*  79 */       return;
/*     */     }
/*  81 */     if (!((Minecart)GetActive().get(event.getPlayer())).equals(event.getRightClicked()))
/*     */     {
/*  83 */       UtilPlayer.message(event.getPlayer(), F.main("Mount", "This is not your Mount!"));
/*  84 */       return;
/*     */     }
/*     */     
/*  87 */     event.getPlayer().leaveVehicle();
/*  88 */     event.getPlayer().eject();
/*     */     
/*  90 */     event.getRightClicked().setPassenger(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void target(EntityTargetEvent event)
/*     */   {
/*  96 */     if (!GetActive().containsKey(event.getTarget())) {
/*  97 */       return;
/*     */     }
/*  99 */     if (!((Minecart)GetActive().get(event.getTarget())).equals(event.getEntity())) {
/* 100 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateBounce(UpdateEvent event) {
/* 106 */     if (event.getType() != UpdateType.TICK) {
/* 107 */       return;
/*     */     }
/*     */     
/* 110 */     for (Minecart cart : GetActive().values())
/*     */     {
/* 112 */       if (cart.getPassenger() != null)
/*     */       {
/*     */ 
/* 115 */         if (UtilEnt.isGrounded(cart))
/*     */         {
/*     */ 
/* 118 */           if ((cart.getPassenger() instanceof Player))
/*     */           {
/*     */ 
/* 121 */             UtilAction.velocity(cart, cart.getPassenger().getLocation().getDirection(), 1.4D, true, 0.0D, 0.0D, 1.0D, false);
/*     */             
/* 123 */             if (Math.random() > 0.8D)
/* 124 */               cart.getWorld().playSound(cart.getLocation(), Sound.MINECART_BASE, 0.05F, 2.0F);
/*     */           } }
/*     */       }
/*     */     }
/* 128 */     for (Minecart cart : GetActive().values())
/*     */     {
/* 130 */       if (cart.getPassenger() != null)
/*     */       {
/*     */ 
/* 133 */         if ((cart.getPassenger() instanceof Player))
/*     */         {
/*     */ 
/* 136 */           Player player = (Player)cart.getPassenger();
/*     */           
/* 138 */           if (Recharge.Instance.usable(player, GetName() + " Collide"))
/*     */           {
/*     */ 
/* 141 */             for (Minecart other : GetActive().values())
/*     */             {
/* 143 */               if (!other.equals(cart))
/*     */               {
/*     */ 
/* 146 */                 if (other.getPassenger() != null)
/*     */                 {
/*     */ 
/* 149 */                   if ((other.getPassenger() instanceof Player))
/*     */                   {
/*     */ 
/* 152 */                     Player otherPlayer = (Player)other.getPassenger();
/*     */                     
/* 154 */                     if (Recharge.Instance.usable(otherPlayer, GetName() + " Collide"))
/*     */                     {
/*     */ 
/*     */ 
/* 158 */                       if (UtilMath.offset(cart, other) <= 2.0D)
/*     */                       {
/*     */ 
/* 161 */                         Recharge.Instance.useForce(player, GetName() + " Collide", 500L);
/* 162 */                         Recharge.Instance.useForce(otherPlayer, GetName() + " Collide", 500L);
/*     */                         
/* 164 */                         UtilAction.velocity(cart, UtilAlg.getTrajectory(other, cart), 1.2D, false, 0.0D, 0.8D, 10.0D, true);
/* 165 */                         UtilAction.velocity(other, UtilAlg.getTrajectory(cart, other), 1.2D, false, 0.0D, 0.8D, 10.0D, true);
/*     */                         
/* 167 */                         cart.getWorld().playSound(cart.getLocation(), Sound.IRONGOLEM_HIT, 1.0F, 0.5F);
/* 168 */                         other.getWorld().playSound(other.getLocation(), Sound.IRONGOLEM_HIT, 1.0F, 0.5F);
/*     */                       } }
/*     */                   } } } }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void cancelBreak(VehicleDamageEvent event) {
/* 179 */     if (GetActive().values().contains(event.getVehicle())) {
/* 180 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\types\MountCart.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */