/*     */ package mineplex.core.mount.types;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.mount.Mount;
/*     */ import mineplex.core.mount.MountManager;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.EntityEffect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Slime;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityTargetEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ 
/*     */ 
/*     */ public class MountSlime
/*     */   extends Mount<Slime>
/*     */ {
/*     */   public MountSlime(MountManager manager)
/*     */   {
/*  34 */     super(manager, "Slime Mount", Material.SLIME_BALL, (byte)0, new String[] {ChatColor.RESET + "Bounce around on your very", ChatColor.RESET + "own personal slime friend!" }, 15000);
/*     */     
/*  36 */     this.KnownPackage = false;
/*     */   }
/*     */   
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  41 */     player.leaveVehicle();
/*  42 */     player.eject();
/*     */     
/*     */ 
/*  45 */     this.Manager.DeregisterAll(player);
/*     */     
/*  47 */     Slime mount = (Slime)player.getWorld().spawn(player.getLocation(), Slime.class);
/*  48 */     mount.setSize(2);
/*     */     
/*  50 */     mount.setCustomName(player.getName() + "'s " + GetName());
/*     */     
/*     */ 
/*  53 */     UtilPlayer.message(player, F.main("Mount", "You spawned " + F.elem(GetName()) + "."));
/*     */     
/*     */ 
/*  56 */     this._active.put(player, mount);
/*     */   }
/*     */   
/*     */   public void Disable(Player player)
/*     */   {
/*  61 */     Slime mount = (Slime)this._active.remove(player);
/*  62 */     if (mount != null)
/*     */     {
/*  64 */       mount.remove();
/*     */       
/*     */ 
/*  67 */       UtilPlayer.message(player, F.main("Mount", "You despawned " + F.elem(GetName()) + "."));
/*     */       
/*  69 */       this.Manager.removeActive(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void interactMount(PlayerInteractEntityEvent event)
/*     */   {
/*  76 */     if (event.getRightClicked() == null) {
/*  77 */       return;
/*     */     }
/*  79 */     if (!GetActive().containsKey(event.getPlayer())) {
/*  80 */       return;
/*     */     }
/*  82 */     if (!((Slime)GetActive().get(event.getPlayer())).equals(event.getRightClicked()))
/*     */     {
/*  84 */       UtilPlayer.message(event.getPlayer(), F.main("Mount", "This is not your Mount!"));
/*  85 */       return;
/*     */     }
/*     */     
/*  88 */     event.getPlayer().leaveVehicle();
/*  89 */     event.getPlayer().eject();
/*     */     
/*  91 */     event.getRightClicked().setPassenger(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void target(EntityTargetEvent event)
/*     */   {
/*  97 */     if (!GetActive().containsKey(event.getTarget())) {
/*  98 */       return;
/*     */     }
/* 100 */     if (!((Slime)GetActive().get(event.getTarget())).equals(event.getEntity())) {
/* 101 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateBounce(UpdateEvent event) {
/* 107 */     if (event.getType() != UpdateType.TICK) {
/* 108 */       return;
/*     */     }
/*     */     
/* 111 */     for (Slime slime : GetActive().values())
/*     */     {
/* 113 */       if (slime.getPassenger() != null)
/*     */       {
/*     */ 
/* 116 */         if (UtilEnt.isGrounded(slime))
/*     */         {
/*     */ 
/* 119 */           if ((slime.getPassenger() instanceof Player))
/*     */           {
/*     */ 
/* 122 */             Player player = (Player)slime.getPassenger();
/*     */             
/* 124 */             if (Recharge.Instance.use(player, GetName(), 200L, false, false))
/*     */             {
/*     */ 
/* 127 */               UtilAction.velocity(slime, slime.getPassenger().getLocation().getDirection(), 1.0D, true, 0.0D, 0.4D, 1.0D, true);
/*     */               
/* 129 */               slime.getWorld().playSound(slime.getLocation(), Sound.SLIME_WALK, 1.0F, 0.75F);
/*     */             }
/*     */           } } }
/*     */     }
/* 133 */     for (Slime slime : GetActive().values())
/*     */     {
/* 135 */       if (slime.getPassenger() != null)
/*     */       {
/*     */ 
/* 138 */         if ((slime.getPassenger() instanceof Player))
/*     */         {
/*     */ 
/* 141 */           Player player = (Player)slime.getPassenger();
/*     */           
/* 143 */           if (Recharge.Instance.usable(player, GetName() + " Collide"))
/*     */           {
/*     */ 
/* 146 */             for (Slime other : GetActive().values())
/*     */             {
/* 148 */               if (!other.equals(slime))
/*     */               {
/*     */ 
/* 151 */                 if (other.getPassenger() != null)
/*     */                 {
/*     */ 
/* 154 */                   if ((other.getPassenger() instanceof Player))
/*     */                   {
/*     */ 
/* 157 */                     Player otherPlayer = (Player)other.getPassenger();
/*     */                     
/* 159 */                     if (Recharge.Instance.usable(otherPlayer, GetName() + " Collide"))
/*     */                     {
/*     */ 
/*     */ 
/* 163 */                       if (UtilMath.offset(slime, other) <= 2.0D)
/*     */                       {
/*     */ 
/* 166 */                         Recharge.Instance.useForce(player, GetName() + " Collide", 500L);
/* 167 */                         Recharge.Instance.useForce(otherPlayer, GetName() + " Collide", 500L);
/*     */                         
/* 169 */                         UtilAction.velocity(slime, UtilAlg.getTrajectory(other, slime), 1.2D, false, 0.0D, 0.8D, 10.0D, true);
/* 170 */                         UtilAction.velocity(other, UtilAlg.getTrajectory(slime, other), 1.2D, false, 0.0D, 0.8D, 10.0D, true);
/*     */                         
/* 172 */                         slime.getWorld().playSound(slime.getLocation(), Sound.SLIME_ATTACK, 1.0F, 0.5F);
/* 173 */                         slime.getWorld().playSound(slime.getLocation(), Sound.SLIME_WALK, 1.0F, 0.5F);
/* 174 */                         other.getWorld().playSound(other.getLocation(), Sound.SLIME_WALK, 1.0F, 0.5F);
/*     */                         
/* 176 */                         slime.playEffect(EntityEffect.HURT);
/* 177 */                         other.playEffect(EntityEffect.HURT);
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\types\MountSlime.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */