/*     */ package mineplex.core.mount.types;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.mount.DragonData;
/*     */ import mineplex.core.mount.DragonMount;
/*     */ import mineplex.core.mount.MountManager;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.EnderDragon;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityTargetEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MountDragon
/*     */   extends DragonMount
/*     */ {
/*     */   public MountDragon(MountManager manager)
/*     */   {
/*  37 */     super(manager, "Ethereal Dragon", new String[] {C.cWhite + "From the distant ether realm,", C.cWhite + "this prized dragon is said to", C.cWhite + "obey only true Heroes!", " ", C.cPurple + "Unlocked with Hero Rank" }, Material.DRAGON_EGG, (byte)0, -1);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Trail(UpdateEvent event)
/*     */   {
/*  43 */     if (event.getType() == UpdateType.TICK)
/*     */     {
/*  45 */       for (DragonData data : GetActive().values())
/*     */       {
/*  47 */         UtilParticle.PlayParticle(UtilParticle.ParticleType.WITCH_MAGIC, data.Dragon.getLocation().add(0.0D, 1.0D, 0.0D), 
/*  48 */           1.0F, 1.0F, 1.0F, 0.0F, 20, 
/*  49 */           UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void DragonLocation(UpdateEvent event)
/*     */   {
/*  57 */     if (event.getType() != UpdateType.TICK) {
/*  58 */       return;
/*     */     }
/*  60 */     for (DragonData data : GetActive().values()) {
/*  61 */       data.Move();
/*     */     }
/*  63 */     HashSet<Player> toRemove = new HashSet();
/*     */     
/*  65 */     for (Player player : GetActive().keySet())
/*     */     {
/*  67 */       DragonData data = (DragonData)GetActive().get(player);
/*  68 */       if (data == null)
/*     */       {
/*  70 */         toRemove.add(player);
/*     */ 
/*     */ 
/*     */       }
/*  74 */       else if ((!data.Dragon.isValid()) || (data.Dragon.getPassenger() == null) || (data.Dragon.getPassenger().getPassenger() == null))
/*     */       {
/*  76 */         data.Dragon.remove();
/*  77 */         toRemove.add(player);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  82 */     for (Player player : toRemove) {
/*  83 */       Disable(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void DragonTargetCancel(EntityTargetEvent event) {
/*  89 */     if (GetActive().containsValue(event.getEntity())) {
/*  90 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void SetName(String news) {
/*  95 */     for (DragonData dragon : GetActive().values()) {
/*  96 */       dragon.Dragon.setCustomName(news);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setHealthPercent(double healthPercent) {
/* 101 */     for (DragonData dragon : GetActive().values())
/*     */     {
/* 103 */       double health = healthPercent * dragon.Dragon.getMaxHealth();
/* 104 */       if (health <= 0.0D)
/* 105 */         health = 0.001D;
/* 106 */       dragon.Dragon.setHealth(health);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void HeroOwner(PlayerJoinEvent event)
/*     */   {
/* 113 */     if (this.Manager.getClientManager().Get(event.getPlayer()).GetRank().Has(Rank.HERO))
/*     */     {
/* 115 */       ((Donor)this.Manager.getDonationManager().Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(GetName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\types\MountDragon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */