/*    */ package mineplex.core.mount.types;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.UtilParticle;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.mount.HorseMount;
/*    */ import mineplex.core.mount.MountManager;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Horse;
/*    */ import org.bukkit.entity.Horse.Color;
/*    */ import org.bukkit.entity.Horse.Style;
/*    */ import org.bukkit.entity.Horse.Variant;
/*    */ import org.bukkit.event.EventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MountFrost
/*    */   extends HorseMount
/*    */ {
/*    */   public MountFrost(MountManager manager)
/*    */   {
/* 33 */     super(manager, "Glacial Steed", new String[] {C.cWhite + "Born in the North Pole,", C.cWhite + "it leaves a trail of frost", C.cWhite + "as it moves!" }, Material.SNOW_BALL, (byte)0, 15000, Horse.Color.WHITE, Horse.Style.WHITE, Horse.Variant.HORSE, 1.0D, null);
/*    */   }
/*    */   
/*    */ 
/*    */   @EventHandler
/*    */   public void Trail(UpdateEvent event)
/*    */   {
/* 40 */     if (event.getType() == UpdateType.TICK) {
/* 41 */       for (Horse horse : GetActive().values()) {
/* 42 */         UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, horse.getLocation().add(0.0D, 1.0D, 0.0D), 
/* 43 */           0.25F, 0.25F, 0.25F, 0.1F, 4, 
/* 44 */           UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\types\MountFrost.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */