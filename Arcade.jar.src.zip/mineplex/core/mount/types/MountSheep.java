/*    */ package mineplex.core.mount.types;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.disguise.DisguiseManager;
/*    */ import mineplex.core.disguise.disguises.DisguiseBase;
/*    */ import mineplex.core.disguise.disguises.DisguiseSheep;
/*    */ import mineplex.core.mount.HorseMount;
/*    */ import mineplex.core.mount.MountManager;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.ChatColor;
/*    */ import org.bukkit.DyeColor;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Horse;
/*    */ import org.bukkit.entity.Horse.Color;
/*    */ import org.bukkit.entity.Horse.Style;
/*    */ import org.bukkit.entity.Horse.Variant;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.inventory.HorseInventory;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MountSheep
/*    */   extends HorseMount
/*    */ {
/*    */   public MountSheep(MountManager manager)
/*    */   {
/* 35 */     super(manager, "Techno Sheep", new String[] {ChatColor.RESET + "Muley muley!" }, Material.WOOL, (byte)14, 3000, Horse.Color.BLACK, Horse.Style.BLACK_DOTS, Horse.Variant.MULE, 1.0D, null);
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 41 */     player.leaveVehicle();
/* 42 */     player.eject();
/*    */     
/*    */ 
/* 45 */     this.Manager.DeregisterAll(player);
/*    */     
/* 47 */     Horse horse = (Horse)player.getWorld().spawn(player.getLocation(), Horse.class);
/*    */     
/* 49 */     horse.setOwner(player);
/* 50 */     horse.setMaxDomestication(1);
/* 51 */     horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
/*    */     
/* 53 */     DisguiseSheep disguise = new DisguiseSheep(horse);
/* 54 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*    */     
/* 56 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*    */     
/*    */ 
/* 59 */     UtilPlayer.message(player, F.main("Mount", "You spawned " + F.elem(GetName()) + "."));
/*    */     
/*    */ 
/* 62 */     this._active.put(player, horse);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void updateColor(UpdateEvent event)
/*    */   {
/* 68 */     if (event.getType() != UpdateType.TICK) {
/* 69 */       return;
/*    */     }
/* 71 */     for (Horse horse : GetActive().values())
/*    */     {
/* 73 */       DisguiseBase base = this.Manager.getDisguiseManager().getDisguise(horse);
/* 74 */       if ((base != null) && ((base instanceof DisguiseSheep)))
/*    */       {
/*    */ 
/* 77 */         DisguiseSheep sheep = (DisguiseSheep)base;
/*    */         
/* 79 */         if (horse.getTicksLived() % 4 == 0) { sheep.setColor(DyeColor.RED);
/* 80 */         } else if (horse.getTicksLived() % 4 == 1) { sheep.setColor(DyeColor.YELLOW);
/* 81 */         } else if (horse.getTicksLived() % 4 == 2) { sheep.setColor(DyeColor.GREEN);
/* 82 */         } else if (horse.getTicksLived() % 4 == 3) sheep.setColor(DyeColor.BLUE);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\types\MountSheep.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */