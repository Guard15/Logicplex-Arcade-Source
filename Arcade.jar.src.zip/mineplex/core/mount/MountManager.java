/*     */ package mineplex.core.mount;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.blockrestore.BlockRestore;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.mount.types.MountDragon;
/*     */ import mineplex.core.mount.types.MountUndead;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Horse;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.ItemSpawnEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEntityEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class MountManager extends MiniPlugin
/*     */ {
/*     */   private CoreClientManager _clientManager;
/*     */   private DonationManager _donationManager;
/*     */   private BlockRestore _blockRestore;
/*     */   private DisguiseManager _disguiseManager;
/*     */   private List<Mount<?>> _types;
/*  36 */   private NautHashMap<Player, Mount<?>> _playerActiveMountMap = new NautHashMap();
/*     */   
/*     */   public MountManager(JavaPlugin plugin, CoreClientManager clientManager, DonationManager donationManager, BlockRestore blockRestore, DisguiseManager disguiseManager)
/*     */   {
/*  40 */     super("Mount Manager", plugin);
/*     */     
/*  42 */     this._clientManager = clientManager;
/*  43 */     this._donationManager = donationManager;
/*  44 */     this._blockRestore = blockRestore;
/*  45 */     this._disguiseManager = disguiseManager;
/*     */     
/*  47 */     CreateGadgets();
/*     */   }
/*     */   
/*     */   private void CreateGadgets()
/*     */   {
/*  52 */     this._types = new ArrayList();
/*     */     
/*  54 */     this._types.add(new MountUndead(this));
/*  55 */     this._types.add(new mineplex.core.mount.types.MountFrost(this));
/*  56 */     this._types.add(new mineplex.core.mount.types.MountMule(this));
/*  57 */     this._types.add(new MountDragon(this));
/*  58 */     this._types.add(new mineplex.core.mount.types.MountSlime(this));
/*  59 */     this._types.add(new mineplex.core.mount.types.MountCart(this));
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Mount<?>> getMounts()
/*     */   {
/*  65 */     return this._types;
/*     */   }
/*     */   
/*     */ 
/*     */   public void DeregisterAll(Player player)
/*     */   {
/*  71 */     for (Mount<?> mount : this._types) {
/*  72 */       mount.Disable(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void HorseInteract(PlayerInteractEntityEvent event) {
/*  78 */     if (!(event.getRightClicked() instanceof Horse)) {
/*  79 */       return;
/*     */     }
/*  81 */     boolean found = false;
/*  82 */     for (Mount mount : this._playerActiveMountMap.values())
/*     */     {
/*  84 */       if (mount.GetActive().containsValue(event.getRightClicked()))
/*     */       {
/*  86 */         found = true;
/*  87 */         break;
/*     */       }
/*     */     }
/*     */     
/*  91 */     if (!found) {
/*  92 */       return;
/*     */     }
/*  94 */     Player player = event.getPlayer();
/*  95 */     Horse horse = (Horse)event.getRightClicked();
/*     */     
/*  97 */     if ((horse.getOwner() == null) || (!horse.getOwner().equals(player)))
/*     */     {
/*  99 */       UtilPlayer.message(player, F.main("Mount", "This is not your Mount!"));
/* 100 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void LeashDropCancel(ItemSpawnEvent event)
/*     */   {
/* 107 */     if (event.getEntity().getItemStack().getType() == Material.LEASH)
/* 108 */       event.setCancelled(true);
/*     */   }
/*     */   
/*     */   public void DisableAll() { int j;
/*     */     int i;
/* 113 */     for (Iterator localIterator = this._types.iterator(); localIterator.hasNext(); 
/* 114 */         i < j)
/*     */     {
/* 113 */       Mount<?> mount = (Mount)localIterator.next();
/* 114 */       Player[] arrayOfPlayer; j = (arrayOfPlayer = UtilServer.getPlayers()).length;i = 0; continue;Player player = arrayOfPlayer[i];
/* 115 */       mount.Disable(player);i++;
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void quit(PlayerQuitEvent event)
/*     */   {
/* 121 */     this._playerActiveMountMap.remove(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void death(PlayerDeathEvent event)
/*     */   {
/* 127 */     this._playerActiveMountMap.remove(event.getEntity());
/*     */   }
/*     */   
/*     */   public void setActive(Player player, Mount<?> mount)
/*     */   {
/* 132 */     this._playerActiveMountMap.put(player, mount);
/*     */   }
/*     */   
/*     */   public Mount<?> getActive(Player player)
/*     */   {
/* 137 */     return (Mount)this._playerActiveMountMap.get(player);
/*     */   }
/*     */   
/*     */   public void removeActive(Player player)
/*     */   {
/* 142 */     this._playerActiveMountMap.remove(player);
/*     */   }
/*     */   
/*     */   public CoreClientManager getClientManager()
/*     */   {
/* 147 */     return this._clientManager;
/*     */   }
/*     */   
/*     */   public DonationManager getDonationManager()
/*     */   {
/* 152 */     return this._donationManager;
/*     */   }
/*     */   
/*     */   public BlockRestore getBlockRestore()
/*     */   {
/* 157 */     return this._blockRestore;
/*     */   }
/*     */   
/*     */   public DisguiseManager getDisguiseManager()
/*     */   {
/* 162 */     return this._disguiseManager;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\MountManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */