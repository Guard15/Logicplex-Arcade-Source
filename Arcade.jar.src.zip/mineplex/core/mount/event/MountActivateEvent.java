/*    */ package mineplex.core.mount.event;
/*    */ 
/*    */ import mineplex.core.mount.Mount;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class MountActivateEvent
/*    */   extends Event
/*    */ {
/* 12 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Player _player;
/*    */   
/*    */   private Mount<?> _mount;
/* 17 */   private boolean _cancelled = false;
/*    */   
/*    */   public MountActivateEvent(Player player, Mount<?> mount)
/*    */   {
/* 21 */     this._player = player;
/* 22 */     this._mount = mount;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 27 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 32 */     return handlers;
/*    */   }
/*    */   
/*    */   public Mount getMount()
/*    */   {
/* 37 */     return this._mount;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 42 */     return this._player;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 47 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 52 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\event\MountActivateEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */