/*    */ package mineplex.core.mount;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.EnderDragon;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class DragonMount extends Mount<DragonData>
/*    */ {
/*    */   public DragonMount(MountManager manager, String name, String[] desc, Material displayMaterial, byte displayData, int cost)
/*    */   {
/* 14 */     super(manager, name, displayMaterial, displayData, desc, cost);
/*    */     
/* 16 */     this.KnownPackage = false;
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 22 */     player.leaveVehicle();
/* 23 */     player.eject();
/*    */     
/*    */ 
/* 26 */     this.Manager.DeregisterAll(player);
/*    */     
/*    */ 
/* 29 */     UtilPlayer.message(player, F.main("Mount", "You spawned " + F.elem(GetName()) + "."));
/*    */     
/*    */ 
/* 32 */     DragonData dragonData = new DragonData(this, player);
/*    */     
/* 34 */     dragonData.Dragon.setMaxHealth(1.0D);
/* 35 */     dragonData.Dragon.setHealth(1.0D);
/* 36 */     this._active.put(player, dragonData);
/*    */   }
/*    */   
/*    */ 
/*    */   public void Disable(Player player)
/*    */   {
/* 42 */     DragonData data = (DragonData)this._active.remove(player);
/* 43 */     if (data != null)
/*    */     {
/* 45 */       data.Dragon.remove();
/* 46 */       data.Chicken.remove();
/*    */       
/*    */ 
/* 49 */       UtilPlayer.message(player, F.main("Mount", "You despawned " + F.elem(GetName()) + "."));
/*    */       
/* 51 */       this.Manager.removeActive(player);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\DragonMount.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */