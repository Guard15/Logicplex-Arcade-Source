/*     */ package mineplex.core.mount;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import net.minecraft.server.v1_7_R4.EntityCreature;
/*     */ import net.minecraft.server.v1_7_R4.Navigation;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftCreature;
/*     */ import org.bukkit.entity.Horse;
/*     */ import org.bukkit.entity.Horse.Color;
/*     */ import org.bukkit.entity.Horse.Style;
/*     */ import org.bukkit.entity.Horse.Variant;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.inventory.HorseInventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class HorseMount extends Mount<Horse>
/*     */ {
/*     */   protected Horse.Color _color;
/*     */   protected Horse.Style _style;
/*     */   protected Horse.Variant _variant;
/*     */   protected double _jump;
/*     */   protected Material _armor;
/*     */   
/*     */   public HorseMount(MountManager manager, String name, String[] desc, Material displayMaterial, byte displayData, int cost, Horse.Color color, Horse.Style style, Horse.Variant variant, double jump, Material armor)
/*     */   {
/*  35 */     super(manager, name, displayMaterial, displayData, desc, cost);
/*  36 */     this.KnownPackage = false;
/*     */     
/*  38 */     this._color = color;
/*  39 */     this._style = style;
/*  40 */     this._variant = variant;
/*  41 */     this._jump = jump;
/*  42 */     this._armor = armor;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void UpdateHorse(UpdateEvent event)
/*     */   {
/*  48 */     if (event.getType() != mineplex.core.updater.UpdateType.SEC) {
/*  49 */       return;
/*     */     }
/*  51 */     Iterator<Player> activeIterator = this._active.keySet().iterator();
/*     */     
/*  53 */     while (activeIterator.hasNext())
/*     */     {
/*  55 */       Player player = (Player)activeIterator.next();
/*  56 */       Horse horse = (Horse)this._active.get(player);
/*     */       
/*     */ 
/*  59 */       if (!horse.isValid())
/*     */       {
/*  61 */         horse.remove();
/*  62 */         activeIterator.remove();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  67 */         EntityCreature ec = ((CraftCreature)horse).getHandle();
/*  68 */         Navigation nav = ec.getNavigation();
/*     */         
/*  70 */         Location target = player.getLocation().add(UtilAlg.getTrajectory(player, horse).multiply(2));
/*     */         
/*  72 */         if (UtilMath.offset(horse.getLocation(), target) > 12.0D)
/*     */         {
/*  74 */           target = horse.getLocation();
/*  75 */           target.add(UtilAlg.getTrajectory(horse, player).multiply(12));
/*  76 */           nav.a(target.getX(), target.getY(), target.getZ(), 1.399999976158142D);
/*     */         }
/*  78 */         else if (UtilMath.offset(horse, player) > 4.0D)
/*     */         {
/*  80 */           nav.a(target.getX(), target.getY(), target.getZ(), 1.399999976158142D);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void EnableCustom(Player player) {
/*  87 */     player.leaveVehicle();
/*  88 */     player.eject();
/*     */     
/*     */ 
/*  91 */     this.Manager.DeregisterAll(player);
/*     */     
/*  93 */     Horse horse = (Horse)player.getWorld().spawn(player.getLocation(), Horse.class);
/*  94 */     horse.setAdult();
/*  95 */     horse.setAgeLock(true);
/*  96 */     horse.setColor(this._color);
/*  97 */     horse.setStyle(this._style);
/*  98 */     horse.setVariant(this._variant);
/*  99 */     horse.setOwner(player);
/* 100 */     horse.setMaxDomestication(1);
/* 101 */     horse.setJumpStrength(this._jump);
/* 102 */     horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
/*     */     
/* 104 */     if (horse.getVariant() == Horse.Variant.MULE) {
/* 105 */       horse.setCarryingChest(true);
/*     */     }
/* 107 */     if (this._armor != null) {
/* 108 */       horse.getInventory().setArmor(new ItemStack(this._armor));
/*     */     }
/* 110 */     horse.setCustomName(player.getName() + "'s " + GetName());
/*     */     
/*     */ 
/* 113 */     UtilPlayer.message(player, F.main("Mount", "You spawned " + F.elem(GetName()) + "."));
/*     */     
/*     */ 
/* 116 */     this._active.put(player, horse);
/*     */   }
/*     */   
/*     */   public void Disable(Player player)
/*     */   {
/* 121 */     Horse horse = (Horse)this._active.remove(player);
/* 122 */     if (horse != null)
/*     */     {
/* 124 */       horse.remove();
/*     */       
/*     */ 
/* 127 */       UtilPlayer.message(player, F.main("Mount", "You despawned " + F.elem(GetName()) + "."));
/*     */       
/* 129 */       this.Manager.removeActive(player);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\HorseMount.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */