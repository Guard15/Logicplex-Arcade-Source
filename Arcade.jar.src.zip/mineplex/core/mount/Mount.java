/*    */ package mineplex.core.mount;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.mount.event.MountActivateEvent;
/*    */ import mineplex.core.shop.item.SalesPackageBase;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public abstract class Mount<T> extends SalesPackageBase implements Listener
/*    */ {
/* 23 */   protected HashSet<Player> _owners = new HashSet();
/* 24 */   protected HashMap<Player, T> _active = new HashMap();
/*    */   
/*    */   public MountManager Manager;
/*    */   
/*    */   public Mount(MountManager manager, String name, Material material, byte displayData, String[] description, int coins)
/*    */   {
/* 30 */     super(name, material, displayData, description, coins);
/*    */     
/* 32 */     this.Manager = manager;
/*    */     
/* 34 */     this.Manager.getPlugin().getServer().getPluginManager().registerEvents(this, this.Manager.getPlugin());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void Sold(Player player, CurrencyType currencyType) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public final void Enable(Player player)
/*    */   {
/* 45 */     MountActivateEvent gadgetEvent = new MountActivateEvent(player, this);
/* 46 */     Bukkit.getServer().getPluginManager().callEvent(gadgetEvent);
/*    */     
/* 48 */     if (gadgetEvent.isCancelled())
/*    */     {
/* 50 */       UtilPlayer.message(player, F.main("Inventory", GetName() + " is not enabled."));
/* 51 */       return;
/*    */     }
/*    */     
/* 54 */     this.Manager.setActive(player, this);
/* 55 */     EnableCustom(player); }
/*    */   
/*    */   public abstract void EnableCustom(Player paramPlayer);
/*    */   
/*    */   public abstract void Disable(Player paramPlayer);
/*    */   
/*    */   public void DisableForAll() { Player[] arrayOfPlayer;
/* 62 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 63 */       Disable(player);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void PlayerJoin(PlayerJoinEvent event) {
/* 69 */     if (event.getPlayer().isOp()) {
/* 70 */       this._owners.add(event.getPlayer());
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void PlayerQuit(PlayerQuitEvent event) {
/* 76 */     this._owners.remove(event.getPlayer());
/* 77 */     Disable(event.getPlayer());
/*    */   }
/*    */   
/*    */   public HashSet<Player> GetOwners()
/*    */   {
/* 82 */     return this._owners;
/*    */   }
/*    */   
/*    */   public HashMap<Player, T> GetActive()
/*    */   {
/* 87 */     return this._active;
/*    */   }
/*    */   
/*    */   public boolean IsActive(Player player)
/*    */   {
/* 92 */     return this._active.containsKey(player);
/*    */   }
/*    */   
/*    */   public boolean HasMount(Player player)
/*    */   {
/* 97 */     return this._owners.contains(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\Mount.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */