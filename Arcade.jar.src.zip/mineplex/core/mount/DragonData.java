/*    */ package mineplex.core.mount;
/*    */ 
/*    */ import mineplex.core.common.util.UtilEnt;
/*    */ import net.minecraft.server.v1_7_R4.EntityEnderDragon;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEnderDragon;
/*    */ import org.bukkit.entity.Chicken;
/*    */ import org.bukkit.entity.EnderDragon;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.scheduler.BukkitScheduler;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class DragonData
/*    */ {
/*    */   DragonMount Host;
/*    */   public EnderDragon Dragon;
/*    */   public Player Rider;
/* 23 */   public Entity TargetEntity = null;
/*    */   
/* 25 */   public Location Location = null;
/*    */   
/* 27 */   public float Pitch = 0.0F;
/* 28 */   public Vector Velocity = new Vector(0, 0, 0);
/*    */   
/*    */   public Entity Chicken;
/*    */   
/*    */   public DragonData(DragonMount dragonMount, Player rider)
/*    */   {
/* 34 */     this.Host = dragonMount;
/*    */     
/* 36 */     this.Rider = rider;
/*    */     
/* 38 */     this.Velocity = rider.getLocation().getDirection().setY(0).normalize();
/* 39 */     this.Pitch = mineplex.core.common.util.UtilAlg.GetPitch(rider.getLocation().getDirection());
/*    */     
/* 41 */     this.Location = rider.getLocation();
/*    */     
/*    */ 
/*    */ 
/* 45 */     this.Dragon = ((EnderDragon)rider.getWorld().spawn(rider.getLocation(), EnderDragon.class));
/* 46 */     UtilEnt.Vegetate(this.Dragon);
/* 47 */     UtilEnt.ghost(this.Dragon, true, false);
/*    */     
/* 49 */     rider.getWorld().playSound(rider.getLocation(), Sound.ENDERDRAGON_GROWL, 20.0F, 1.0F);
/*    */     
/* 51 */     this.Chicken = rider.getWorld().spawn(rider.getLocation(), Chicken.class);
/* 52 */     this.Dragon.setPassenger(this.Chicken);
/*    */     
/* 54 */     this.Chicken.setPassenger(this.Rider);
/*    */     
/* 56 */     Bukkit.getServer().getScheduler().runTaskLater(this.Host.Manager.getPlugin(), new Runnable()
/*    */     {
/*    */       public void run()
/*    */       {
/* 60 */         DragonData.this.Chicken.setPassenger(DragonData.this.Rider);
/*    */       }
/* 62 */     }, 10L);
/*    */   }
/*    */   
/*    */   public void Move()
/*    */   {
/* 67 */     this.Rider.eject();
/* 68 */     ((CraftEnderDragon)this.Dragon).getHandle().setTargetBlock(GetTarget().getBlockX(), GetTarget().getBlockY(), GetTarget().getBlockZ());
/*    */   }
/*    */   
/*    */   public Location GetTarget()
/*    */   {
/* 73 */     return this.Rider.getLocation().add(this.Rider.getLocation().getDirection().multiply(40));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\mount\DragonData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */