/*     */ package mineplex.core.cosmetic;
/*     */ 
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilGear;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.mount.MountManager;
/*     */ import mineplex.core.pet.PetManager;
/*     */ import mineplex.core.treasure.TreasureManager;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.InventoryView;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class CosmeticManager
/*     */   extends MiniPlugin
/*     */ {
/*     */   private InventoryManager _inventoryManager;
/*     */   private GadgetManager _gadgetManager;
/*     */   private MountManager _mountManager;
/*     */   private PetManager _petManager;
/*     */   private TreasureManager _treasureManager;
/*     */   private CosmeticShop _shop;
/*  42 */   private boolean _showInterface = true;
/*  43 */   private int _interfaceSlot = 4;
/*     */   
/*     */   public CosmeticManager(JavaPlugin plugin, CoreClientManager clientManager, DonationManager donationManager, InventoryManager inventoryManager, GadgetManager gadgetManager, MountManager mountManager, PetManager petManager, TreasureManager treasureManager)
/*     */   {
/*  47 */     super("Cosmetic Manager", plugin);
/*     */     
/*  49 */     this._inventoryManager = inventoryManager;
/*  50 */     this._gadgetManager = gadgetManager;
/*  51 */     this._mountManager = mountManager;
/*  52 */     this._petManager = petManager;
/*  53 */     this._treasureManager = treasureManager;
/*     */     
/*  55 */     this._shop = new CosmeticShop(this, clientManager, donationManager, this._moduleName);
/*     */   }
/*     */   
/*     */   public void showInterface(boolean showInterface)
/*     */   {
/*  60 */     boolean changed = this._showInterface == showInterface;
/*     */     
/*  62 */     this._showInterface = showInterface;
/*  63 */     if (changed) {
/*  64 */       for (Player player : Bukkit.getOnlinePlayers()) {
/*  65 */         if (this._showInterface) {
/*  66 */           player.getInventory().setItem(this._interfaceSlot, ItemStackFactory.Instance.CreateStack(Material.CHEST, (byte)0, 1, ChatColor.RESET + C.cGreen + "Cosmetic Menu"));
/*     */         } else {
/*  68 */           player.getInventory().setItem(this._interfaceSlot, null);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event)
/*     */   {
/*  77 */     if (!this._showInterface) {
/*  78 */       return;
/*     */     }
/*  80 */     giveInterfaceItem(event.getPlayer());
/*     */   }
/*     */   
/*     */   public void giveInterfaceItem(Player player)
/*     */   {
/*  85 */     if (!UtilGear.isMat(player.getInventory().getItem(this._interfaceSlot), Material.CHEST))
/*     */     {
/*  87 */       player.getInventory().setItem(this._interfaceSlot, ItemStackFactory.Instance.CreateStack(Material.CHEST, (byte)0, 1, ChatColor.RESET + C.cGreen + "Cosmetic Menu"));
/*     */       
/*  89 */       this._gadgetManager.redisplayActiveItem(player);
/*     */       
/*  91 */       UtilInv.Update(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void orderThatChest(final PlayerDropItemEvent event)
/*     */   {
/*  98 */     if (!this._showInterface) {
/*  99 */       return;
/*     */     }
/* 101 */     if (event.getItemDrop().getItemStack().getType() == Material.CHEST) {
/* 102 */       Bukkit.getScheduler().scheduleSyncDelayedTask(getPlugin(), new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 106 */           if (event.getPlayer().isOnline())
/*     */           {
/* 108 */             event.getPlayer().getInventory().remove(Material.CHEST);
/* 109 */             event.getPlayer().getInventory().setItem(CosmeticManager.this._interfaceSlot, ItemStackFactory.Instance.CreateStack(Material.CHEST, (byte)0, 1, ChatColor.RESET + C.cGreen + "Inventory Menu"));
/* 110 */             event.getPlayer().updateInventory();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void openShop(PlayerInteractEvent event)
/*     */   {
/* 120 */     if (!this._showInterface) {
/* 121 */       return;
/*     */     }
/* 123 */     if ((event.hasItem()) && (event.getItem().getType() == Material.CHEST))
/*     */     {
/* 125 */       event.setCancelled(true);
/*     */       
/* 127 */       this._shop.attemptShopOpen(event.getPlayer());
/*     */     }
/*     */   }
/*     */   
/*     */   public GadgetManager getGadgetManager()
/*     */   {
/* 133 */     return this._gadgetManager;
/*     */   }
/*     */   
/*     */   public MountManager getMountManager()
/*     */   {
/* 138 */     return this._mountManager;
/*     */   }
/*     */   
/*     */   public PetManager getPetManager()
/*     */   {
/* 143 */     return this._petManager;
/*     */   }
/*     */   
/*     */   public InventoryManager getInventoryManager()
/*     */   {
/* 148 */     return this._inventoryManager;
/*     */   }
/*     */   
/*     */   public void setInterfaceSlot(int i)
/*     */   {
/* 153 */     this._interfaceSlot = i;
/*     */     
/* 155 */     this._gadgetManager.setActiveItemSlot(i - 1);
/*     */   }
/*     */   
/*     */   public void setActive(boolean showInterface)
/*     */   {
/* 160 */     this._showInterface = showInterface;
/* 161 */     if (!showInterface) { Player[] arrayOfPlayer;
/* 162 */       int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 163 */         if (player.getOpenInventory().getTopInventory().getHolder() != player) {
/* 164 */           player.closeInventory();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableItemsForGame()
/*     */   {
/* 172 */     this._gadgetManager.DisableAll();
/* 173 */     this._mountManager.DisableAll();
/* 174 */     this._petManager.DisableAll();
/*     */   }
/*     */   
/*     */   public void setHideParticles(boolean b)
/*     */   {
/* 179 */     this._gadgetManager.setHideParticles(b);
/*     */   }
/*     */   
/*     */   public boolean isShowingInterface()
/*     */   {
/* 184 */     return this._showInterface;
/*     */   }
/*     */   
/*     */   public TreasureManager getTreasureManager()
/*     */   {
/* 189 */     return this._treasureManager;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\CosmeticManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */