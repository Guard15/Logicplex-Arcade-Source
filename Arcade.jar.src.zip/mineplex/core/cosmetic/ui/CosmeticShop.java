/*    */ package mineplex.core.cosmetic.ui;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.page.GadgetPage;
/*    */ import mineplex.core.cosmetic.ui.page.Menu;
/*    */ import mineplex.core.cosmetic.ui.page.PetTagPage;
/*    */ import mineplex.core.cosmetic.ui.page.TreasurePage;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.gadget.event.ItemGadgetOutOfAmmoEvent;
/*    */ import mineplex.core.shop.ShopBase;
/*    */ import mineplex.core.shop.page.ShopPageBase;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.plugin.messaging.Messenger;
/*    */ import org.bukkit.plugin.messaging.PluginMessageListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CosmeticShop
/*    */   extends ShopBase<CosmeticManager>
/*    */   implements PluginMessageListener
/*    */ {
/*    */   public CosmeticShop(CosmeticManager plugin, CoreClientManager clientManager, DonationManager donationManager, String name)
/*    */   {
/* 46 */     super(plugin, clientManager, donationManager, name, new CurrencyType[] { CurrencyType.Gems, CurrencyType.Coins });
/* 47 */     plugin.getPlugin().getServer().getMessenger().registerIncomingPluginChannel(plugin.getPlugin(), "MC|ItemName", this);
/*    */   }
/*    */   
/*    */   protected ShopPageBase<CosmeticManager, ? extends ShopBase<CosmeticManager>> buildPagesFor(Player player)
/*    */   {
/* 52 */     return new Menu((CosmeticManager)getPlugin(), this, getClientManager(), getDonationManager(), player);
/*    */   }
/*    */   
/*    */   public void onPluginMessageReceived(String channel, Player player, byte[] message) {
/* 56 */     if (!channel.equalsIgnoreCase("MC|ItemName")) {
/* 57 */       return;
/*    */     }
/* 59 */     if ((getPlayerPageMap().containsKey(player.getName())) && ((getPlayerPageMap().get(player.getName()) instanceof PetTagPage)) && (message != null) && (message.length >= 1)) {
/* 60 */       String tagName = new String(message);
/* 61 */       ((PetTagPage)getPlayerPageMap().get(player.getName())).SetTagName(tagName);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void itemGadgetEmptyAmmo(ItemGadgetOutOfAmmoEvent event) {
/* 67 */     new GadgetPage((CosmeticManager)getPlugin(), this, getClientManager(), getDonationManager(), "Gadgets", event.getPlayer()).purchaseGadget(event.getPlayer(), event.getGadget());
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void updateTreasure(UpdateEvent event) {
/* 72 */     if (event.getType() != UpdateType.TICK) {
/* 73 */       return;
/*    */     }
/* 75 */     for (ShopPageBase shop : getPlayerPageMap().values()) {
/* 76 */       if ((shop instanceof TreasurePage)) {
/* 77 */         ((TreasurePage)shop).update();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\CosmeticShop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */