/*    */ package mineplex.core.cosmetic.ui;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ import mineplex.core.pet.Pet;
/*    */ import org.bukkit.entity.EntityType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PetSorter
/*    */   implements Comparator<Pet>
/*    */ {
/*    */   public int compare(Pet a, Pet b)
/*    */   {
/* 17 */     if (a.GetPetType().getTypeId() < b.GetPetType().getTypeId()) {
/* 18 */       return -1;
/*    */     }
/* 20 */     return 1;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\PetSorter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */