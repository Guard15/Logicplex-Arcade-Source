/*     */ package mineplex.core.cosmetic.ui.page;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.cosmetic.CosmeticManager;
/*     */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import mineplex.core.shop.page.ShopPageBase;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public class TreasurePage
/*     */   extends ShopPageBase<CosmeticManager, CosmeticShop>
/*     */ {
/*  28 */   private static final int[] ROTATION_SLOTS = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 17, 26, 35, 34, 33, 32, 31, 30, 29, 28, 27, 18, 9 };
/*  29 */   private static final List<Integer> CHEST_SLOTS = Arrays.asList(new Integer[] { Integer.valueOf(21), Integer.valueOf(24), Integer.valueOf(20), Integer.valueOf(22), Integer.valueOf(23) });
/*  30 */   private static final List<ChatColor> CHEST_COLORS = Arrays.asList(new ChatColor[] { ChatColor.RED, ChatColor.GREEN, ChatColor.YELLOW, ChatColor.BLUE, ChatColor.AQUA, ChatColor.GOLD });
/*     */   private int _ticks;
/*     */   private Random _random;
/*  33 */   private short _rotationColorOne = 0;
/*  34 */   private short _rotationColorTwo = 0;
/*  35 */   private boolean _rotationForwardOne = true;
/*  36 */   private boolean _rotationForwardTwo = false;
/*  37 */   private int _currentIndexOne = 4;
/*  38 */   private int _currentIndexTwo = 4;
/*  39 */   public boolean _canSelectChest = false;
/*     */   private LinkedList<ChatColor> _colors;
/*     */   private LinkedList<Integer> _chestSlots;
/*     */   
/*     */   public TreasurePage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*     */   {
/*  45 */     super(plugin, shop, clientManager, donationManager, name, player, 36);
/*  46 */     this._random = new Random();
/*     */     
/*  48 */     this._colors = new LinkedList(CHEST_COLORS);
/*  49 */     this._chestSlots = new LinkedList(CHEST_SLOTS);
/*  50 */     Collections.shuffle(this._colors, this._random);
/*  51 */     Collections.shuffle(this._chestSlots, this._random);
/*     */   }
/*     */   
/*     */   protected void buildPage()
/*     */   {
/*  56 */     int treasureCount = ((ClientInventory)((CosmeticManager)getPlugin()).getInventoryManager().Get(getPlayer())).getItemCount("Treasure Chest");
/*     */     
/*  58 */     this._rotationColorOne = (this._ticks % 2 == 0 ? (short)this._random.nextInt(15) : this._rotationColorOne);
/*  59 */     this._rotationColorTwo = (this._ticks % 20 == 0 ? (short)this._random.nextInt(15) : this._rotationColorTwo);
/*  60 */     ItemStack borderPane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)(this._canSelectChest ? 7 : 15));
/*  61 */     for (int row = 0; row < 4; row++) {
/*  62 */       if ((row == 0) || (row == 3))
/*     */       {
/*  64 */         for (int column = 0; column < 9; column++) {
/*  65 */           setItem(column, row, borderPane);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  70 */         setItem(0, row, borderPane);
/*  71 */         setItem(8, row, borderPane);
/*     */       }
/*     */     }
/*  74 */     if (this._ticks <= 21) {
/*  75 */       rotateBorderPanes();
/*     */     }
/*  77 */     if (this._ticks == 0)
/*     */     {
/*  79 */       getPlayer().playSound(getPlayer().getEyeLocation(), Sound.ANVIL_USE, 4.0F, 1.0F);
/*     */     }
/*  81 */     else if (this._ticks == 20)
/*     */     {
/*  83 */       getPlayer().playSound(getPlayer().getEyeLocation(), Sound.CHEST_OPEN, 4.0F, 1.0F);
/*     */     }
/*  85 */     else if ((this._ticks >= 30) && (this._ticks <= 120) && (this._ticks % 20 == 0))
/*     */     {
/*  87 */       ChatColor color = (ChatColor)this._colors.poll();
/*  88 */       String colorName = color.name().toLowerCase();
/*  89 */       colorName = colorName.substring(0, 1).toUpperCase() + colorName.substring(1);
/*  90 */       String chestName = color + colorName + " Chest";
/*  91 */       String[] lore = { ChatColor.RESET.toString() + ChatColor.WHITE + "Click to Open" };
/*     */       
/*  93 */       getPlayer().playSound(getPlayer().getEyeLocation(), Sound.NOTE_PLING, 4.0F, 1.0F);
/*  94 */       int slot = ((Integer)this._chestSlots.poll()).intValue();
/*  95 */       addButton(slot, new ShopItem(Material.CHEST, chestName, lore, 1, false), new IButton()
/*     */       {
/*     */         public void onClick(Player player, ClickType clickType)
/*     */         {
/*  99 */           if (TreasurePage.this._canSelectChest) {
/* 100 */             player.playSound(player.getLocation(), Sound.CHEST_OPEN, 1.0F, 1.0F);
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/* 105 */     else if (this._ticks == 140)
/*     */     {
/* 107 */       getPlayer().playSound(getPlayer().getEyeLocation(), Sound.LEVEL_UP, 4.0F, 1.0F);
/* 108 */       ItemStack is = new ItemStack(Material.BOOK);
/* 109 */       ItemMeta meta = is.getItemMeta();
/* 110 */       meta.setDisplayName(ChatColor.RESET.toString() + "Select a Chest");
/* 111 */       is.setItemMeta(meta);
/*     */       
/* 113 */       setItem(13, is);
/* 114 */       addGlow(13);
/*     */       
/* 116 */       this._canSelectChest = true;
/*     */     }
/* 118 */     this._ticks += 1;
/*     */   }
/*     */   
/*     */   public void rotateBorderPanes()
/*     */   {
/* 123 */     ItemStack whitePane = new ItemStack(Material.STAINED_GLASS_PANE, 1, (short)0);
/* 124 */     ItemStack paneOne = new ItemStack(Material.STAINED_GLASS_PANE, 1, this._rotationColorOne);
/* 125 */     ItemStack paneTwo = new ItemStack(Material.STAINED_GLASS_PANE, 1, this._rotationColorTwo);
/*     */     
/* 127 */     this._currentIndexOne = ((this._currentIndexOne + (this._rotationForwardOne ? 1 : -1)) % ROTATION_SLOTS.length);
/* 128 */     if (this._currentIndexOne < 0) {
/* 129 */       this._currentIndexOne += ROTATION_SLOTS.length;
/*     */     }
/* 131 */     this._currentIndexTwo = ((this._currentIndexTwo + (this._rotationForwardTwo ? 1 : -1)) % ROTATION_SLOTS.length);
/* 132 */     if (this._currentIndexTwo < 0) {
/* 133 */       this._currentIndexTwo += ROTATION_SLOTS.length;
/*     */     }
/* 135 */     if (this._currentIndexOne == this._currentIndexTwo)
/*     */     {
/* 137 */       setItem(ROTATION_SLOTS[this._currentIndexOne], whitePane);
/*     */     }
/*     */     else
/*     */     {
/* 141 */       setItem(ROTATION_SLOTS[this._currentIndexOne], paneOne);
/* 142 */       setItem(ROTATION_SLOTS[this._currentIndexTwo], paneTwo);
/*     */     }
/*     */   }
/*     */   
/*     */   public void update()
/*     */   {
/* 148 */     buildPage();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\TreasurePage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */