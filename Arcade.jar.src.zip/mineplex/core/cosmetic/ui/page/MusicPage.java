/*    */ package mineplex.core.cosmetic.ui.page;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.Gadget;
/*    */ import mineplex.core.gadget.types.GadgetType;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import mineplex.core.shop.item.ShopItem;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MusicPage
/*    */   extends GadgetPage
/*    */ {
/*    */   public MusicPage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*    */   {
/* 35 */     super(plugin, shop, clientManager, donationManager, name, player);
/*    */   }
/*    */   
/*    */   protected void buildPage()
/*    */   {
/* 40 */     int slot = 19;
/* 41 */     for (Gadget gadget : ((CosmeticManager)getPlugin()).getGadgetManager().getGadgets(GadgetType.MusicDisc)) {
/* 42 */       addGadget(gadget, slot);
/* 43 */       slot++; if (slot == 26)
/* 44 */         slot = 28;
/*    */     }
/* 46 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ⇽ Go Back", new String[0], 1, false), new IButton()
/*    */     {
/*    */       public void onClick(Player player, ClickType clickType)
/*    */       {
/* 50 */         ((CosmeticShop)MusicPage.this.getShop()).openPageForPlayer(MusicPage.this.getPlayer(), new Menu((CosmeticManager)MusicPage.this.getPlugin(), (CosmeticShop)MusicPage.this.getShop(), MusicPage.this.getClientManager(), MusicPage.this.getDonationManager(), player));
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public void activateGadget(Player player, Gadget gadget)
/*    */   {
/* 57 */     super.activateGadget(player, gadget);
/* 58 */     player.closeInventory();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\MusicPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */