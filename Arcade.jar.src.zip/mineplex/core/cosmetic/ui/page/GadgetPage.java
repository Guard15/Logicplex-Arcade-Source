/*     */ package mineplex.core.cosmetic.ui.page;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.cosmetic.CosmeticManager;
/*     */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*     */ import mineplex.core.cosmetic.ui.button.ActivateGadgetButton;
/*     */ import mineplex.core.cosmetic.ui.button.DeactivateGadgetButton;
/*     */ import mineplex.core.cosmetic.ui.button.GadgetButton;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.gadgets.Ammo;
/*     */ import mineplex.core.gadget.gadgets.MorphBlock;
/*     */ import mineplex.core.gadget.gadgets.MorphNotch;
/*     */ import mineplex.core.gadget.types.Gadget;
/*     */ import mineplex.core.gadget.types.GadgetType;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import mineplex.core.shop.page.ConfirmationPage;
/*     */ import mineplex.core.shop.page.ShopPageBase;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ 
/*     */ public class GadgetPage
/*     */   extends ShopPageBase<CosmeticManager, CosmeticShop>
/*     */ {
/*     */   public GadgetPage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*     */   {
/*  39 */     super(plugin, shop, clientManager, donationManager, name, player, 54);
/*     */     
/*  41 */     buildPage();
/*     */   }
/*     */   
/*     */   protected void buildPage()
/*     */   {
/*  46 */     int slot = 19;
/*  47 */     for (Gadget gadget : ((CosmeticManager)getPlugin()).getGadgetManager().getGadgets(GadgetType.Item))
/*     */     {
/*  49 */       addGadget(gadget, slot);
/*  50 */       if (((ClientInventory)((CosmeticManager)getPlugin()).getInventoryManager().Get(getPlayer())).getItemCount(gadget.GetDisplayName()) > 0) {
/*  51 */         addGlow(slot);
/*     */       }
/*  53 */       slot++;
/*  54 */       if (slot == 26) {
/*  55 */         slot = 28;
/*     */       }
/*     */     }
/*  58 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ? Go Back", new String[0], 1, false), new IButton()
/*     */     {
/*     */       public void onClick(Player player, ClickType clickType)
/*     */       {
/*  62 */         ((CosmeticShop)GadgetPage.this.getShop()).openPageForPlayer(GadgetPage.this.getPlayer(), new Menu((CosmeticManager)GadgetPage.this.getPlugin(), (CosmeticShop)GadgetPage.this.getShop(), GadgetPage.this.getClientManager(), GadgetPage.this.getDonationManager(), player));
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected void addGadget(Gadget gadget, int slot)
/*     */   {
/*  69 */     if ((!(gadget instanceof MorphNotch)) && 
/*  70 */       ((gadget instanceof MorphBlock)) && 
/*  71 */       (getPlayer().getPassenger() != null)) {
/*  72 */       return;
/*     */     }
/*     */     
/*     */ 
/*  76 */     List<String> itemLore = new ArrayList();
/*  77 */     if (gadget.GetCost(CurrencyType.Coins) >= 0) {
/*  78 */       itemLore.add(C.cAqua + gadget.GetCost(CurrencyType.Coins) + " Shards");
/*  79 */     } else if (gadget.GetCost(CurrencyType.Coins) == -2) {
/*  80 */       itemLore.add(C.cGold + "Found in Treasure Chests.");
/*     */     }
/*  82 */     itemLore.add(C.cBlack);
/*  83 */     itemLore.addAll(Arrays.asList(gadget.GetDescription()));
/*  84 */     if ((gadget instanceof ItemGadget))
/*     */     {
/*  86 */       itemLore.add(C.cBlack);
/*  87 */       itemLore.add(C.cGreen + "Right-Click To Purchase:");
/*  88 */       itemLore.add(C.cWhite + ((ItemGadget)gadget).getAmmo().GetDisplayName() + " for " + C.cAqua + ((ItemGadget)gadget).getAmmo().GetCost(CurrencyType.Coins) + " Shards");
/*  89 */       itemLore.add(C.cBlack);
/*  90 */       itemLore.add(C.cWhite + "Your Ammo : " + C.cGreen + ((ClientInventory)((CosmeticManager)getPlugin()).getInventoryManager().Get(getPlayer())).getItemCount(gadget.GetName()));
/*     */     }
/*  92 */     if ((gadget.IsFree()) || (((Donor)getDonationManager().Get(getPlayer().getName())).OwnsUnknownPackage(gadget.GetName())))
/*     */     {
/*  94 */       if (gadget.GetActive().contains(getPlayer())) {
/*  95 */         addButton(slot, new ShopItem(gadget.GetDisplayMaterial(), gadget.GetDisplayData(), "Deactivate " + gadget.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new DeactivateGadgetButton(gadget, this));
/*     */       } else {
/*  97 */         addButton(slot, new ShopItem(gadget.GetDisplayMaterial(), gadget.GetDisplayData(), "Activate " + gadget.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new ActivateGadgetButton(gadget, this));
/*     */       }
/*     */     }
/* 100 */     else if ((gadget.GetCost(CurrencyType.Coins) > 0) && (((Donor)getDonationManager().Get(getPlayer().getName())).GetBalance(CurrencyType.Coins) >= gadget.GetCost(CurrencyType.Coins))) {
/* 101 */       addButton(slot, new ShopItem(Material.INK_SACK, (byte)8, (gadget.GetCost(CurrencyType.Coins) < 0 ? "" : "Purchase ") + gadget.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new GadgetButton(gadget, this));
/*     */     } else {
/* 103 */       setItem(slot, new ShopItem(Material.INK_SACK, (byte)8, (gadget.GetCost(CurrencyType.Coins) < 0 ? "" : "Purchase ") + gadget.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, true, false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void purchaseGadget(Player player, final Gadget gadget)
/*     */   {
/* 109 */     ((CosmeticShop)getShop()).openPageForPlayer(getPlayer(), new ConfirmationPage(getPlugin(), getShop(), getClientManager(), getDonationManager(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 113 */         ((CosmeticManager)GadgetPage.this.getPlugin()).getInventoryManager().addItemToInventory(GadgetPage.this.getPlayer(), gadget.getGadgetType().name(), gadget.GetName(), (gadget instanceof ItemGadget) ? ((ItemGadget)gadget).getAmmo().getQuantity() : gadget.getQuantity());
/* 114 */         GadgetPage.this.refresh();
/*     */       }
/* 116 */     }, this, (gadget instanceof ItemGadget) ? ((ItemGadget)gadget)
/*     */     
/* 118 */       .getAmmo() : gadget, CurrencyType.Coins, getPlayer()));
/*     */   }
/*     */   
/*     */   public void activateGadget(Player player, Gadget gadget)
/*     */   {
/* 123 */     if (((gadget instanceof ItemGadget)) && 
/* 124 */       (((ClientInventory)((CosmeticManager)getPlugin()).getInventoryManager().Get(player)).getItemCount(gadget.GetName()) <= 0))
/*     */     {
/* 126 */       purchaseGadget(player, gadget);
/* 127 */       return;
/*     */     }
/*     */     
/* 130 */     playAcceptSound(player);
/* 131 */     gadget.Enable(player);
/*     */     
/* 133 */     ((CosmeticShop)getShop()).openPageForPlayer(getPlayer(), new Menu((CosmeticManager)getPlugin(), (CosmeticShop)getShop(), getClientManager(), getDonationManager(), player));
/*     */   }
/*     */   
/*     */   public void handleRightClick(Player player, Gadget gadget)
/*     */   {
/* 138 */     if ((gadget instanceof ItemGadget)) {
/* 139 */       purchaseGadget(player, gadget);
/*     */     }
/*     */   }
/*     */   
/*     */   public void deactivateGadget(Player player, Gadget gadget)
/*     */   {
/* 145 */     playAcceptSound(player);
/* 146 */     gadget.Disable(player);
/* 147 */     refresh();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\GadgetPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */