/*    */ package mineplex.core.cosmetic.ui.page;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.HashMap;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*    */ import mineplex.core.cosmetic.ui.button.ActivateMountButton;
/*    */ import mineplex.core.cosmetic.ui.button.DeactivateMountButton;
/*    */ import mineplex.core.cosmetic.ui.button.MountButton;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.donation.Donor;
/*    */ import mineplex.core.mount.Mount;
/*    */ import mineplex.core.mount.MountManager;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import mineplex.core.shop.item.ShopItem;
/*    */ import mineplex.core.shop.page.ShopPageBase;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MountPage
/*    */   extends ShopPageBase<CosmeticManager, CosmeticShop>
/*    */ {
/*    */   public MountPage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*    */   {
/* 42 */     super(plugin, shop, clientManager, donationManager, name, player, 54);
/* 43 */     buildPage();
/*    */   }
/*    */   
/*    */   protected void buildPage()
/*    */   {
/* 48 */     int slot = 19;
/* 49 */     for (Mount mount : ((CosmeticManager)getPlugin()).getMountManager().getMounts()) {
/* 50 */       addMount(mount, slot);
/* 51 */       slot++; if (slot == 26)
/* 52 */         slot = 28;
/*    */     }
/*    */   }
/*    */   
/*    */   protected void addMount(Mount<?> mount, int slot) {
/* 57 */     ArrayList<String> itemLore = new ArrayList();
/* 58 */     if (mount.GetCost(CurrencyType.Coins) != -1) {
/* 59 */       itemLore.add(C.cAqua + mount.GetCost(CurrencyType.Coins) + " Shards");
/*    */     }
/* 61 */     itemLore.add(C.cBlack);
/* 62 */     itemLore.addAll(Arrays.asList(mount.GetDescription()));
/* 63 */     if (((Donor)getDonationManager().Get(getPlayer().getName())).OwnsUnknownPackage(mount.GetName())) {
/* 64 */       if (mount.GetActive().containsKey(getPlayer())) {
/* 65 */         addButton(slot, new ShopItem(mount.GetDisplayMaterial(), mount.GetDisplayData(), "Deactivate " + mount.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new DeactivateMountButton(mount, this));
/*    */       } else {
/* 67 */         addButton(slot, new ShopItem(mount.GetDisplayMaterial(), mount.GetDisplayData(), "Activate " + mount.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new ActivateMountButton(mount, this));
/*    */       }
/* 69 */     } else if ((mount.GetCost(CurrencyType.Coins) != -1) && (((Donor)getDonationManager().Get(getPlayer().getName())).GetBalance(CurrencyType.Coins) >= mount.GetCost(CurrencyType.Coins))) {
/* 70 */       addButton(slot, new ShopItem(mount.GetDisplayMaterial(), mount.GetDisplayData(), (mount.GetCost(CurrencyType.Coins) < 0 ? "" : "Purchase ") + mount.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new MountButton(mount, this));
/*    */     } else {
/* 72 */       setItem(slot, new ShopItem(mount.GetDisplayMaterial(), mount.GetDisplayData(), (mount.GetCost(CurrencyType.Coins) < 0 ? "" : "Purchase ") + mount.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, true, false));
/*    */     }
/* 74 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ⇽ Go Back", new String[0], 1, false), new IButton()
/*    */     {
/*    */       public void onClick(Player player, ClickType clickType)
/*    */       {
/* 78 */         ((CosmeticShop)MountPage.this.getShop()).openPageForPlayer(MountPage.this.getPlayer(), new Menu((CosmeticManager)MountPage.this.getPlugin(), (CosmeticShop)MountPage.this.getShop(), MountPage.this.getClientManager(), MountPage.this.getDonationManager(), player));
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\MountPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */