/*     */ package mineplex.core.cosmetic.ui.page;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.cosmetic.CosmeticManager;
/*     */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.Gadget;
/*     */ import mineplex.core.gadget.types.GadgetType;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.gadget.types.OutfitGadget;
/*     */ import mineplex.core.gadget.types.OutfitGadget.ArmorSlot;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CostumePage
/*     */   extends GadgetPage
/*     */ {
/*     */   public CostumePage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*     */   {
/*  44 */     super(plugin, shop, clientManager, donationManager, name, player);
/*  45 */     buildPage();
/*     */   }
/*     */   
/*     */   protected void buildPage()
/*     */   {
/*  50 */     ArrayList costumeClasses = new ArrayList();
/*  51 */     for (Gadget gadget : ((CosmeticManager)getPlugin()).getGadgetManager().getGadgets(GadgetType.Costume)) {
/*  52 */       OutfitGadget outfitGadget = (OutfitGadget)gadget;
/*  53 */       Class clazz = gadget.getClass();
/*  54 */       if (!costumeClasses.contains(clazz)) {
/*  55 */         costumeClasses.add(clazz);
/*     */       }
/*  57 */       int slot = costumeClasses.indexOf(clazz) * 2 + 3 + 18;
/*  58 */       if (outfitGadget.GetSlot() == OutfitGadget.ArmorSlot.Chest) {
/*  59 */         slot += 9;
/*  60 */       } else if (outfitGadget.GetSlot() == OutfitGadget.ArmorSlot.Legs) {
/*  61 */         slot += 18;
/*  62 */       } else if (outfitGadget.GetSlot() == OutfitGadget.ArmorSlot.Boots) {
/*  63 */         slot += 27;
/*     */       }
/*  65 */       addGadget(gadget, slot);
/*  66 */       if (gadget.IsActive(getPlayer()))
/*  67 */         addGlow(slot);
/*     */     }
/*  69 */     addButton(8, new ShopItem(Material.TNT, C.cRed + C.Bold + "Remove all Clothing", new String[0], 1, false), new IButton()
/*     */     {
/*     */       public void onClick(Player player, ClickType clickType)
/*     */       {
/*  73 */         boolean gadgetDisabled = false;
/*  74 */         for (Gadget gadget : ((CosmeticManager)CostumePage.this.getPlugin()).getGadgetManager().getGadgets(GadgetType.Costume))
/*  75 */           if (gadget.IsActive(player)) {
/*  76 */             gadgetDisabled = true;
/*  77 */             gadget.Disable(player);
/*     */           }
/*  79 */         if (gadgetDisabled) {
/*  80 */           CostumePage.this.buildPage();
/*  81 */           player.playSound(player.getEyeLocation(), Sound.SPLASH, 1.0F, 1.0F);
/*     */         }
/*     */       }
/*  84 */     });
/*  85 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ⇽ Go Back", new String[0], 1, false), new IButton()
/*     */     {
/*     */       public void onClick(Player player, ClickType clickType)
/*     */       {
/*  89 */         ((CosmeticShop)CostumePage.this.getShop()).openPageForPlayer(CostumePage.this.getPlayer(), new Menu((CosmeticManager)CostumePage.this.getPlugin(), (CosmeticShop)CostumePage.this.getShop(), CostumePage.this.getClientManager(), CostumePage.this.getDonationManager(), player));
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void activateGadget(Player player, Gadget gadget)
/*     */   {
/*  96 */     if (((gadget instanceof ItemGadget)) && (((ClientInventory)((CosmeticManager)getPlugin()).getInventoryManager().Get(player)).getItemCount(gadget.GetName()) <= 0)) {
/*  97 */       purchaseGadget(player, gadget);
/*  98 */       return;
/*     */     }
/* 100 */     playAcceptSound(player);
/* 101 */     gadget.Enable(player);
/* 102 */     buildPage();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\CostumePage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */