/*     */ package mineplex.core.cosmetic.ui.page;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.cosmetic.CosmeticManager;
/*     */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*     */ import mineplex.core.cosmetic.ui.PetSorter;
/*     */ import mineplex.core.cosmetic.ui.button.ActivatePetButton;
/*     */ import mineplex.core.cosmetic.ui.button.DeactivatePetButton;
/*     */ import mineplex.core.cosmetic.ui.button.PetButton;
/*     */ import mineplex.core.cosmetic.ui.button.RenamePetButton;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.pet.Pet;
/*     */ import mineplex.core.pet.PetClient;
/*     */ import mineplex.core.pet.PetExtra;
/*     */ import mineplex.core.pet.PetFactory;
/*     */ import mineplex.core.pet.PetManager;
/*     */ import mineplex.core.pet.types.Elf;
/*     */ import mineplex.core.pet.types.Pumpkin;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import mineplex.core.shop.page.AnvilContainer;
/*     */ import mineplex.core.shop.page.ShopPageBase;
/*     */ import net.minecraft.server.v1_7_R4.Container;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.IInventory;
/*     */ import net.minecraft.server.v1_7_R4.ItemStack;
/*     */ import net.minecraft.server.v1_7_R4.Items;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutOpenWindow;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutSetSlot;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Creature;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ 
/*     */ public class PetPage
/*     */   extends ShopPageBase<CosmeticManager, CosmeticShop>
/*     */ {
/*     */   public PetPage(CosmeticManager plugin, CosmeticShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player)
/*     */   {
/*  51 */     super(plugin, shop, clientManager, donationManager, name, player, 54);
/*     */     
/*  53 */     buildPage();
/*     */   }
/*     */   
/*     */   protected void buildPage()
/*     */   {
/*  58 */     int slot = 19;
/*     */     
/*  60 */     List<Pet> pets = new ArrayList(((CosmeticManager)getPlugin()).getPetManager().GetFactory().GetPets());
/*     */     
/*  62 */     Collections.sort(pets, new PetSorter());
/*  63 */     for (Pet pet : pets)
/*     */     {
/*  65 */       List<String> itemLore = new ArrayList();
/*  66 */       if (pet.GetCost(CurrencyType.Coins) == -1)
/*     */       {
/*  68 */         if ((pet instanceof Pumpkin))
/*     */         {
/*  70 */           itemLore.add(C.cBlack);
/*  71 */           itemLore.add(ChatColor.RESET + C.cYellow + "Earned by defeating the Pumpkin King");
/*  72 */           itemLore.add(ChatColor.RESET + C.cYellow + "in the 2014 Halloween Horror Event.");
/*     */         }
/*  74 */         if ((pet instanceof Elf))
/*     */         {
/*  76 */           itemLore.add(C.cBlack);
/*  77 */           itemLore.add(ChatColor.RESET + C.cYellow + "Earned by defeating the Pumpkin King");
/*  78 */           itemLore.add(ChatColor.RESET + C.cYellow + "in the 2014 Christmas Chaos Event.");
/*     */         }
/*  80 */         if (pet.GetPetType() == EntityType.WITHER)
/*     */         {
/*  82 */           itemLore.add(C.cBlack);
/*  83 */           itemLore.add(ChatColor.RESET + C.cYellow + "Unlocked with Legend Rank");
/*     */         }
/*     */       }
/*  86 */       if (((Donor)getDonationManager().Get(getPlayer().getName())).OwnsUnknownPackage(pet.GetPetName()))
/*     */       {
/*  88 */         String petName = (String)((PetClient)((CosmeticManager)getPlugin()).getPetManager().Get(getPlayer())).GetPets().get(pet.GetPetType());
/*  89 */         if (petName == null) {
/*  90 */           petName = pet.GetName();
/*     */         }
/*  92 */         if ((((CosmeticManager)getPlugin()).getPetManager().hasActivePet(getPlayer().getName())) && (((CosmeticManager)getPlugin()).getPetManager().getActivePet(getPlayer().getName()).getType() == pet.GetPetType()))
/*     */         {
/*  94 */           addButton(slot, new ShopItem(Material.MONSTER_EGG, (byte)pet.GetPetType().getTypeId(), "Deactivate " + pet
/*  95 */             .GetPetName() + " (" + C.cWhite + petName + C.cGreen + ")", 
/*  96 */             (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new DeactivatePetButton(this, ((CosmeticManager)getPlugin()).getPetManager()));
/*     */           
/*  98 */           addGlow(slot);
/*     */         }
/*     */         else
/*     */         {
/* 102 */           addButton(slot, new ShopItem(Material.MONSTER_EGG, (byte)pet.GetPetType().getTypeId(), "Activate " + pet
/* 103 */             .GetPetName() + " (" + C.cWhite + petName + C.cGreen + ")", 
/* 104 */             (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new ActivatePetButton(pet, this));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 109 */         if (pet.GetCost(CurrencyType.Coins) > 0)
/*     */         {
/* 111 */           itemLore.add(C.cAqua + pet.GetCost(CurrencyType.Coins) + " Shards");
/* 112 */           itemLore.add(C.cBlack);
/*     */         }
/* 114 */         if (pet.GetCost(CurrencyType.Coins) == -1) {
/* 115 */           setItem(slot, new ShopItem(Material.INK_SACK, (byte)8, pet.GetPetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, true, false));
/* 116 */         } else if (((Donor)getDonationManager().Get(getPlayer().getName())).GetBalance(CurrencyType.Coins) >= pet.GetCost(CurrencyType.Coins)) {
/* 117 */           addButton(slot, new ShopItem(Material.INK_SACK, (byte)8, "Purchase " + pet.GetPetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new PetButton(pet, this));
/*     */         } else {
/* 119 */           setItem(slot, new ShopItem(Material.INK_SACK, (byte)8, "Purchase " + pet.GetPetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, true, false));
/*     */         }
/*     */       }
/* 122 */       slot++;
/* 123 */       if (slot == 26) {
/* 124 */         slot = 28;
/*     */       }
/*     */     }
/* 127 */     slot = 49;
/* 128 */     for (PetExtra petExtra : ((CosmeticManager)getPlugin()).getPetManager().GetFactory().GetPetExtras())
/*     */     {
/* 130 */       List<String> itemLore = new ArrayList();
/* 131 */       if (!((CosmeticManager)getPlugin()).getPetManager().hasActivePet(getPlayer().getName()))
/*     */       {
/* 133 */         itemLore.add(C.cWhite + "You must have an active pet to use this!");
/* 134 */         getInventory().setItem(slot, new ShopItem(petExtra.GetMaterial(), (byte)0, C.cRed + petExtra.GetName(), (String[])itemLore.toArray(new String[itemLore.size()]), 1, true, false).getHandle());
/*     */       }
/* 136 */       else if (((CosmeticManager)getPlugin()).getPetManager().getActivePet(getPlayer().getName()).getType() != EntityType.WITHER)
/*     */       {
/* 138 */         addButton(slot, new ShopItem(petExtra.GetMaterial(), (byte)0, "Rename " + ((CosmeticManager)getPlugin()).getPetManager().getActivePet(getPlayer().getName()).getCustomName() + " for " + C.cAqua + petExtra.GetCost(CurrencyType.Coins) + C.cGreen + " Shards", (String[])itemLore.toArray(new String[itemLore.size()]), 1, false, false), new RenamePetButton(this));
/*     */       }
/* 140 */       slot++;
/*     */     }
/* 142 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ? Go Back", new String[0], 1, false), new IButton()
/*     */     {
/*     */       public void onClick(Player player, ClickType clickType)
/*     */       {
/* 146 */         ((CosmeticShop)PetPage.this.getShop()).openPageForPlayer(PetPage.this.getPlayer(), new Menu((CosmeticManager)PetPage.this.getPlugin(), (CosmeticShop)PetPage.this.getShop(), PetPage.this.getClientManager(), PetPage.this.getDonationManager(), player));
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void purchasePet(Player player, Pet pet)
/*     */   {
/* 153 */     renamePet(player, pet, true);
/*     */   }
/*     */   
/*     */   public void renamePet(Player player, Pet pet, boolean petPurchase)
/*     */   {
/* 158 */     playAcceptSound(player);
/*     */     
/* 160 */     PetTagPage petTagPage = new PetTagPage((CosmeticManager)getPlugin(), (CosmeticShop)getShop(), getClientManager(), getDonationManager(), "Repairing", getPlayer(), pet, petPurchase);
/* 161 */     EntityPlayer entityPlayer = ((CraftPlayer)getPlayer()).getHandle();
/* 162 */     int containerCounter = entityPlayer.nextContainerCounter();
/* 163 */     entityPlayer.playerConnection.sendPacket(new PacketPlayOutOpenWindow(containerCounter, 8, "Repairing", 0, true));
/* 164 */     entityPlayer.activeContainer = new AnvilContainer(entityPlayer.inventory, petTagPage.getInventory());
/* 165 */     entityPlayer.activeContainer.windowId = containerCounter;
/* 166 */     entityPlayer.activeContainer.addSlotListener(entityPlayer);
/* 167 */     entityPlayer.playerConnection.sendPacket(new PacketPlayOutSetSlot(containerCounter, 0, new ItemStack(Items.NAME_TAG)));
/*     */     
/* 169 */     ((CosmeticShop)getShop()).setCurrentPageForPlayer(getPlayer(), petTagPage);
/*     */   }
/*     */   
/*     */   public void deactivatePet(Player player)
/*     */   {
/* 174 */     playAcceptSound(player);
/* 175 */     ((CosmeticManager)getPlugin()).getPetManager().RemovePet(player, true);
/* 176 */     refresh();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\page\PetPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */