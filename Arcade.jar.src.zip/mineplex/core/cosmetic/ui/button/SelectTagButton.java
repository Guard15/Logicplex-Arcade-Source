/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.ui.page.PetTagPage;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectTagButton
/*    */   implements IButton
/*    */ {
/*    */   private PetTagPage _page;
/*    */   
/*    */   public SelectTagButton(PetTagPage page)
/*    */   {
/* 20 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 25 */     this._page.SelectTag();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\SelectTagButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */