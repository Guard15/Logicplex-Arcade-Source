/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.ui.page.Menu;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenMusic
/*    */   implements IButton
/*    */ {
/*    */   private Menu _menu;
/*    */   
/*    */   public OpenMusic(Menu menu)
/*    */   {
/* 20 */     this._menu = menu;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 25 */     this._menu.openMusic(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\OpenMusic.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */