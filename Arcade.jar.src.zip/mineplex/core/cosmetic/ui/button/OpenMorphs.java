/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*    */ import mineplex.core.cosmetic.ui.page.Menu;
/*    */ import mineplex.core.cosmetic.ui.page.MorphPage;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenMorphs
/*    */   implements IButton
/*    */ {
/*    */   private Menu _page;
/*    */   
/*    */   public OpenMorphs(Menu page)
/*    */   {
/* 27 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 32 */     ((CosmeticShop)this._page.getShop()).openPageForPlayer(player, new MorphPage((CosmeticManager)this._page.getPlugin(), (CosmeticShop)this._page.getShop(), this._page.getClientManager(), this._page.getDonationManager(), "Morphs", player));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\OpenMorphs.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */