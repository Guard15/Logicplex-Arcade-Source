/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.page.PetPage;
/*    */ import mineplex.core.pet.Pet;
/*    */ import mineplex.core.pet.PetManager;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Creature;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenamePetButton
/*    */   implements IButton
/*    */ {
/*    */   private PetPage _page;
/*    */   
/*    */   public RenamePetButton(PetPage page)
/*    */   {
/* 27 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 32 */     this._page.playAcceptSound(player);
/* 33 */     Creature currentPet = ((CosmeticManager)this._page.getPlugin()).getPetManager().getActivePet(player.getName());
/* 34 */     this._page.renamePet(player, new Pet(currentPet.getCustomName(), currentPet.getType(), 1), false);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\RenamePetButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */