/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.pet.PetManager;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import mineplex.core.shop.page.ShopPageBase;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeactivatePetButton
/*    */   implements IButton
/*    */ {
/*    */   private ShopPageBase<?, ?> _page;
/*    */   private PetManager _petManager;
/*    */   
/*    */   public DeactivatePetButton(ShopPageBase<?, ?> page, PetManager petManager)
/*    */   {
/* 22 */     this._page = page;
/* 23 */     this._petManager = petManager;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 28 */     this._page.playAcceptSound(player);
/* 29 */     this._petManager.RemovePet(player, true);
/* 30 */     this._page.refresh();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\DeactivatePetButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */