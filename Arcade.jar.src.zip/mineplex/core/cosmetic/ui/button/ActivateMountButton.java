/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*    */ import mineplex.core.cosmetic.ui.page.Menu;
/*    */ import mineplex.core.cosmetic.ui.page.MountPage;
/*    */ import mineplex.core.mount.Mount;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivateMountButton
/*    */   implements IButton
/*    */ {
/*    */   private Mount<?> _mount;
/*    */   private MountPage _page;
/*    */   
/*    */   public ActivateMountButton(Mount<?> mount, MountPage page)
/*    */   {
/* 29 */     this._mount = mount;
/* 30 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 35 */     this._page.playAcceptSound(player);
/* 36 */     this._mount.Enable(player);
/* 37 */     ((CosmeticShop)this._page.getShop()).openPageForPlayer(player, new Menu((CosmeticManager)this._page.getPlugin(), (CosmeticShop)this._page.getShop(), this._page.getClientManager(), this._page.getDonationManager(), player));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\ActivateMountButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */