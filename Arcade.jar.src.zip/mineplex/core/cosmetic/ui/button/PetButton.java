/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.ui.page.PetPage;
/*    */ import mineplex.core.pet.Pet;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PetButton
/*    */   implements IButton
/*    */ {
/*    */   private Pet _pet;
/*    */   private PetPage _page;
/*    */   
/*    */   public PetButton(Pet pet, PetPage page)
/*    */   {
/* 22 */     this._pet = pet;
/* 23 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 28 */     this._page.purchasePet(player, this._pet);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\PetButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */