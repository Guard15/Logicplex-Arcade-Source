/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.ui.page.GadgetPage;
/*    */ import mineplex.core.gadget.types.Gadget;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GadgetButton
/*    */   implements IButton
/*    */ {
/*    */   private Gadget _gadget;
/*    */   private GadgetPage _page;
/*    */   
/*    */   public GadgetButton(Gadget gadget, GadgetPage page)
/*    */   {
/* 22 */     this._gadget = gadget;
/* 23 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 28 */     this._page.purchaseGadget(player, this._gadget);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\GadgetButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */