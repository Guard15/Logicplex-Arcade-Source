/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.mount.Mount;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import mineplex.core.shop.page.ShopPageBase;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeactivateMountButton
/*    */   implements IButton
/*    */ {
/*    */   private Mount<?> _mount;
/*    */   private ShopPageBase<?, ?> _page;
/*    */   
/*    */   public DeactivateMountButton(Mount<?> mount, ShopPageBase<?, ?> page)
/*    */   {
/* 22 */     this._mount = mount;
/* 23 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 28 */     this._page.playAcceptSound(player);
/* 29 */     this._mount.Disable(player);
/* 30 */     this._page.refresh();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\DeactivateMountButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */