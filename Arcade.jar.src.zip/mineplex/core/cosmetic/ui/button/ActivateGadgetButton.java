/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.ui.page.GadgetPage;
/*    */ import mineplex.core.gadget.types.Gadget;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivateGadgetButton
/*    */   implements IButton
/*    */ {
/*    */   private Gadget _gadget;
/*    */   private GadgetPage _page;
/*    */   
/*    */   public ActivateGadgetButton(Gadget gadget, GadgetPage page)
/*    */   {
/* 22 */     this._gadget = gadget;
/* 23 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 28 */     if (clickType.isLeftClick()) {
/* 29 */       this._page.activateGadget(player, this._gadget);
/* 30 */     } else if (clickType.isRightClick()) {
/* 31 */       this._page.handleRightClick(player, this._gadget);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\ActivateGadgetButton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */