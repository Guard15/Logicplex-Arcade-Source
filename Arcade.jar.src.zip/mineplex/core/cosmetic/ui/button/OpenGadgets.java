/*    */ package mineplex.core.cosmetic.ui.button;
/*    */ 
/*    */ import mineplex.core.cosmetic.CosmeticManager;
/*    */ import mineplex.core.cosmetic.ui.CosmeticShop;
/*    */ import mineplex.core.cosmetic.ui.page.GadgetPage;
/*    */ import mineplex.core.cosmetic.ui.page.Menu;
/*    */ import mineplex.core.shop.item.IButton;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.inventory.ClickType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OpenGadgets
/*    */   implements IButton
/*    */ {
/*    */   private Menu _page;
/*    */   
/*    */   public OpenGadgets(Menu page)
/*    */   {
/* 27 */     this._page = page;
/*    */   }
/*    */   
/*    */   public void onClick(Player player, ClickType clickType)
/*    */   {
/* 32 */     ((CosmeticShop)this._page.getShop()).openPageForPlayer(player, new GadgetPage((CosmeticManager)this._page.getPlugin(), (CosmeticShop)this._page.getShop(), this._page.getClientManager(), this._page.getDonationManager(), "Gadgets", player));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\ui\button\OpenGadgets.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */