/*    */ package mineplex.core.cosmetic.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ActivateGemBoosterEvent
/*    */   extends Event
/*    */ {
/* 17 */   private static final HandlerList handlers = new HandlerList();
/*    */   private Player _player;
/* 19 */   private boolean _cancelled = false;
/*    */   
/*    */   public ActivateGemBoosterEvent(Player player) {
/* 22 */     this._player = player;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 26 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 30 */     return handlers;
/*    */   }
/*    */   
/*    */   public Player getPlayer() {
/* 34 */     return this._player;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel) {
/* 38 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled() {
/* 42 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\cosmetic\event\ActivateGemBoosterEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */