/*    */ package mineplex.core.leaderboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum StatType
/*    */ {
/* 10 */   WIN(1), 
/* 11 */   LOSS(2), 
/* 12 */   KILL(3), 
/* 13 */   DEATH(4);
/*    */   
/*    */   public int getTypeId() {
/* 16 */     return this._typeId;
/*    */   }
/*    */   
/*    */ 
/*    */   private int _typeId;
/*    */   
/*    */   private StatType(int typeId)
/*    */   {
/* 24 */     this._typeId = typeId;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static StatType getType(String stat)
/*    */   {
/*    */     String str;
/*    */     
/*    */ 
/* 34 */     switch ((str = stat.toUpperCase().trim()).hashCode()) {case -2043639023:  if (str.equals("LOSSES")) {} break; case 2664471:  if (str.equals("WINS")) break; break; case 71514293:  if (str.equals("KILLS")) {} break; case 2012524671:  if (!str.equals("DEATHS"))
/*    */       {
/*    */         break label120;
/* 37 */         return WIN;
/*    */         
/* 39 */         return LOSS;
/*    */         
/* 41 */         return KILL;
/*    */       } else {
/* 43 */         return DEATH; }
/*    */       break; }
/* 45 */     label120: return null;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\leaderboard\StatType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */