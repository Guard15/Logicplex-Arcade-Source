/*    */ package mineplex.core.leaderboard;
/*    */ 
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LeaderboardManager
/*    */   extends MiniPlugin
/*    */ {
/*    */   private static LeaderboardManager _instance;
/*    */   private StatEventsRepository _statEvents;
/*    */   private CoreClientManager _clientManager;
/*    */   private String _serverGroup;
/*    */   
/*    */   public LeaderboardManager(JavaPlugin plugin, CoreClientManager clientManager)
/*    */   {
/* 32 */     super("Leaderboard Manager", plugin);
/*    */     
/* 34 */     _instance = this;
/* 35 */     this._clientManager = clientManager;
/* 36 */     this._statEvents = new StatEventsRepository(plugin);
/* 37 */     this._serverGroup = this._plugin.getConfig().getString("serverstatus.group");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean attemptStatEvent(Player player, String stat, int gamemode, int value)
/*    */   {
/* 49 */     StatType type = StatType.getType(stat);
/*    */     
/* 51 */     return type == null ? false : onStatEvent(player, type, gamemode, value);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean onStatEvent(Player player, StatType type, int gamemode, int value)
/*    */   {
/* 75 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public void addCommands()
/*    */   {
/* 81 */     addCommand(new SetTournamentCommand(this));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static LeaderboardManager getInstance()
/*    */   {
/* 89 */     return _instance;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\leaderboard\LeaderboardManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */