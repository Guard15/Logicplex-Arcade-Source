/*    */ package mineplex.core.leaderboard;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class SetTournamentCommand
/*    */   extends CommandBase<LeaderboardManager>
/*    */ {
/*    */   public SetTournamentCommand(LeaderboardManager plugin)
/*    */   {
/* 12 */     super(plugin, Rank.ADMIN, new String[] { "settournament", "set-tournament" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args) {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\leaderboard\SetTournamentCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */