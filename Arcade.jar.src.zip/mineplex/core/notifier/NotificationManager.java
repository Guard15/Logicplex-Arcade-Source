/*    */ package mineplex.core.notifier;
/*    */ 
/*    */ import mineplex.core.MiniPlugin;
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotificationManager
/*    */   extends MiniPlugin
/*    */ {
/* 28 */   private boolean _enabled = true;
/*    */   private CoreClientManager _clientManager;
/* 30 */   private String _summerLine = C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█" + C.cGold + "█" + C.cYellow + "█";
/*    */   private String _website;
/*    */   
/*    */   public NotificationManager(JavaPlugin plugin, CoreClientManager client, String website)
/*    */   {
/* 35 */     super("Notification Manager", plugin);
/* 36 */     this._clientManager = client;
/*    */     
/* 38 */     this._website = website;
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void notify(UpdateEvent event) {
/* 43 */     if (!this._enabled) {}
/*    */   }
/*    */   
/*    */   private void sale()
/*    */   {
/*    */     Player[] arrayOfPlayer;
/* 49 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 50 */       Rank rank = this._clientManager.Get(player).GetRank();
/* 51 */       if (!rank.Has(Rank.LEGEND)) {
/* 52 */         if (rank == Rank.ALL) {
/* 53 */           UtilPlayer.message(player, C.cWhite + "Summer Sale!  Purchase " + C.cAqua + C.Bold + "Ultra RANK" + C.cWhite + " for $15");
/* 54 */         } else if (rank == Rank.ULTRA) {
/* 55 */           UtilPlayer.message(player, C.cWhite + "Summer Sale!  Upgrade to " + C.cPurple + C.Bold + "HERO RANK" + C.cWhite + " for $15!");
/* 56 */         } else if (rank == Rank.HERO) {
/* 57 */           UtilPlayer.message(player, C.cWhite + "Summer Sale! Upgrade to " + C.cGreen + C.Bold + "LEGEND RANK" + C.cWhite + " for $15!");
/*    */         }
/* 59 */         UtilPlayer.message(player, C.cWhite + " Visit " + F.link(this._website) + " for 50% Off Ranks!");
/*    */       }
/*    */     } }
/*    */   
/*    */   private void hugeSale() { Player[] arrayOfPlayer;
/* 64 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 65 */       Rank rank = this._clientManager.Get(player).GetRank();
/* 66 */       if (!rank.Has(Rank.LEGEND)) {
/* 67 */         UtilPlayer.message(player, this._summerLine);
/* 68 */         UtilPlayer.message(player, " ");
/* 69 */         UtilPlayer.message(player, "          " + C.cGreen + C.Bold + "75% OFF" + C.cYellow + C.Bold + "  SUMMER SUPER SALE  " + C.cGreen + C.Bold + "75% OFF");
/* 70 */         UtilPlayer.message(player, " ");
/* 71 */         if (rank == Rank.ALL) {
/* 72 */           UtilPlayer.message(player, C.cWhite + " " + player.getName() + ", you can get 75% Off " + C.cAqua + C.Bold + "All Lifetime Ranks" + C.cWhite + "!");
/* 73 */           UtilPlayer.message(player, C.cWhite + " This is our biggest sale ever, available " + C.cRed + C.Line + "this weekend only" + C.cWhite + "!");
/* 74 */         } else if (rank == Rank.ULTRA) {
/* 75 */           UtilPlayer.message(player, C.cWhite + " Hello " + player.getName() + ", upgrade to " + C.cPurple + C.Bold + "HERO RANK" + C.cWhite + " for only $7.50!");
/* 76 */           UtilPlayer.message(player, C.cWhite + " This is our biggest sale ever, available " + C.cRed + C.Line + "this weekend only" + C.cWhite + "!");
/* 77 */         } else if (rank == Rank.HERO) {
/* 78 */           UtilPlayer.message(player, C.cWhite + " Hello " + player.getName() + ", upgrade to " + C.cGreen + C.Bold + "LEGEND RANK" + C.cWhite + " for only $7.50!");
/* 79 */           UtilPlayer.message(player, C.cWhite + " This is our biggest sale ever, available " + C.cRed + C.Line + "this weekend only" + C.cWhite + "!");
/*    */         }
/* 81 */         UtilPlayer.message(player, " ");
/* 82 */         UtilPlayer.message(player, "                         " + C.cGreen + this._website);
/* 83 */         UtilPlayer.message(player, " ");
/* 84 */         UtilPlayer.message(player, this._summerLine);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\notifier\NotificationManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */