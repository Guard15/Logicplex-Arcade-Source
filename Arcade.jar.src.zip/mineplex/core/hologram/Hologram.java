/*     */ package mineplex.core.hologram;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*     */ import net.minecraft.server.v1_7_R4.Packet;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutAttachEntity;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityDestroy;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityMetadata;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutEntityTeleport;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntity;
/*     */ import net.minecraft.server.v1_7_R4.PacketPlayOutSpawnEntityLiving;
/*     */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class Hologram
/*     */ {
/*     */   private Packet _destroy1_7;
/*     */   private Packet _destroy1_8;
/*     */   
/*     */   public static enum HologramTarget
/*     */   {
/*  34 */     BLACKLIST,  WHITELIST;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   private ArrayList<Map.Entry<Integer, Integer>> _entityIds = new ArrayList();
/*     */   private Entity _followEntity;
/*     */   private HologramManager _hologramManager;
/*  45 */   private String[] _hologramText = new String[0];
/*     */   
/*     */   private Vector _lastMovement;
/*     */   
/*     */   private Location _location;
/*     */   
/*  51 */   private boolean _makeDestroyPackets = true;
/*  52 */   private boolean _makeSpawnPackets = true;
/*     */   private Packet[] _packets1_7;
/*     */   private Packet[] _packets1_8;
/*  55 */   private HashSet<String> _playersInList = new HashSet();
/*  56 */   private ArrayList<Player> _playersTracking = new ArrayList();
/*     */   private boolean _removeEntityDeath;
/*  58 */   private HologramTarget _target = HologramTarget.BLACKLIST;
/*  59 */   private int _viewDistance = 70;
/*     */   protected Vector relativeToEntity;
/*     */   
/*     */   public Hologram(HologramManager hologramManager, Location location, String... text)
/*     */   {
/*  64 */     this._hologramManager = hologramManager;
/*  65 */     this._location = location.clone();
/*  66 */     setText(text);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram addPlayer(Player player)
/*     */   {
/*  74 */     return addPlayer(player.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram addPlayer(String player)
/*     */   {
/*  82 */     this._playersInList.add(player);
/*  83 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsPlayer(Player player)
/*     */   {
/*  91 */     return this._playersInList.contains(player.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean containsPlayer(String player)
/*     */   {
/*  99 */     return this._playersInList.contains(player);
/*     */   }
/*     */   
/*     */   protected Packet getDestroyPacket(Player player)
/*     */   {
/* 104 */     if (this._makeDestroyPackets)
/*     */     {
/* 106 */       makeDestroyPacket();
/* 107 */       this._makeDestroyPackets = false;
/*     */     }
/*     */     
/* 110 */     return UtilPlayer.is1_8(player) ? this._destroy1_8 : this._destroy1_7;
/*     */   }
/*     */   
/*     */   public Entity getEntityFollowing()
/*     */   {
/* 115 */     return this._followEntity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HologramTarget getHologramTarget()
/*     */   {
/* 126 */     return this._target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Location getLocation()
/*     */   {
/* 134 */     return this._location.clone();
/*     */   }
/*     */   
/*     */   protected ArrayList<Player> getNearbyPlayers()
/*     */   {
/* 139 */     ArrayList<Player> nearbyPlayers = new ArrayList();
/*     */     
/* 141 */     for (Player player : getLocation().getWorld().getPlayers())
/*     */     {
/* 143 */       if (isVisible(player))
/*     */       {
/* 145 */         nearbyPlayers.add(player);
/*     */       }
/*     */     }
/* 148 */     return nearbyPlayers;
/*     */   }
/*     */   
/*     */   protected ArrayList<Player> getPlayersTracking()
/*     */   {
/* 153 */     return this._playersTracking;
/*     */   }
/*     */   
/*     */   protected Packet[] getSpawnPackets(Player player)
/*     */   {
/* 158 */     if (this._makeSpawnPackets)
/*     */     {
/* 160 */       makeSpawnPackets();
/* 161 */       this._makeSpawnPackets = false;
/*     */     }
/*     */     
/* 164 */     return UtilPlayer.is1_8(player) ? this._packets1_8 : this._packets1_7;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getText()
/*     */   {
/* 173 */     String[] reversed = new String[this._hologramText.length];
/*     */     
/* 175 */     for (int i = 0; i < reversed.length; i++)
/*     */     {
/* 177 */       reversed[i] = this._hologramText[(reversed.length - (i + 1))];
/*     */     }
/*     */     
/* 180 */     return reversed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getViewDistance()
/*     */   {
/* 188 */     return this._viewDistance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isInUse()
/*     */   {
/* 196 */     return this._lastMovement != null;
/*     */   }
/*     */   
/*     */   public boolean isRemoveOnEntityDeath()
/*     */   {
/* 201 */     return this._removeEntityDeath;
/*     */   }
/*     */   
/*     */   public boolean isVisible(Player player)
/*     */   {
/* 206 */     if (getLocation().getWorld() == player.getWorld())
/*     */     {
/* 208 */       if ((getHologramTarget() == HologramTarget.WHITELIST) == containsPlayer(player))
/*     */       {
/* 210 */         if (getLocation().distance(player.getLocation()) < getViewDistance())
/*     */         {
/* 212 */           return true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 217 */     return false;
/*     */   }
/*     */   
/*     */   private void makeDestroyPacket()
/*     */   {
/* 222 */     int[] entityIds1_7 = new int[this._entityIds.size() * 2];
/* 223 */     int[] entityIds1_8 = new int[this._entityIds.size()];
/*     */     
/* 225 */     for (int i = 0; i < this._entityIds.size(); i++)
/*     */     {
/* 227 */       Map.Entry<Integer, Integer> entry = (Map.Entry)this._entityIds.get(i);
/*     */       
/* 229 */       entityIds1_7[(i * 2)] = ((Integer)entry.getKey()).intValue();
/* 230 */       entityIds1_7[(i * 2 + 1)] = ((Integer)entry.getValue()).intValue();
/*     */       
/* 232 */       entityIds1_8[i] = ((Integer)entry.getKey()).intValue();
/*     */     }
/*     */     
/* 235 */     this._destroy1_7 = new PacketPlayOutEntityDestroy(entityIds1_7);
/* 236 */     this._destroy1_8 = new PacketPlayOutEntityDestroy(entityIds1_8);
/*     */   }
/*     */   
/*     */   private void makeSpawnPackets()
/*     */   {
/* 241 */     this._packets1_7 = new Packet[this._hologramText.length * 3];
/* 242 */     this._packets1_8 = new Packet[this._hologramText.length * 1];
/*     */     
/* 244 */     if (this._entityIds.size() < this._hologramText.length)
/*     */     {
/* 246 */       this._makeDestroyPackets = true;
/*     */       
/* 248 */       for (int i = this._entityIds.size(); i < this._hologramText.length; i++)
/*     */       {
/* 250 */         this._entityIds.add(new AbstractMap.SimpleEntry(Integer.valueOf(UtilEnt.getNewEntityId()), Integer.valueOf(UtilEnt.getNewEntityId())));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 255 */       this._makeDestroyPackets = true;
/*     */       
/* 257 */       while (this._entityIds.size() > this._hologramText.length)
/*     */       {
/* 259 */         this._entityIds.remove(this._hologramText.length);
/*     */       }
/*     */     }
/* 262 */     for (int textRow = 0; textRow < this._hologramText.length; textRow++)
/*     */     {
/* 264 */       Map.Entry<Integer, Integer> entityIds = (Map.Entry)this._entityIds.get(textRow);
/*     */       
/* 266 */       Packet[] packets1_7 = makeSpawnPackets1_7(textRow, ((Integer)entityIds.getKey()).intValue(), ((Integer)entityIds.getValue()).intValue(), this._hologramText[textRow]);
/*     */       
/* 268 */       for (int i = 0; i < packets1_7.length; i++)
/*     */       {
/* 270 */         this._packets1_7[(textRow * 3 + i)] = packets1_7[i];
/*     */       }
/*     */       
/* 273 */       Packet[] packets1_8 = makeSpawnPackets1_8(textRow, ((Integer)entityIds.getKey()).intValue(), this._hologramText[textRow]);
/*     */       
/* 275 */       for (int i = 0; i < packets1_8.length; i++)
/*     */       {
/* 277 */         this._packets1_8[(textRow + i)] = packets1_8[i];
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private Packet[] makeSpawnPackets1_7(int height, int witherId, int horseId, String horseName)
/*     */   {
/* 285 */     PacketPlayOutSpawnEntity spawnWitherSkull = new PacketPlayOutSpawnEntity();
/*     */     
/* 287 */     spawnWitherSkull.a = witherId;
/* 288 */     spawnWitherSkull.b = ((int)(getLocation().getX() * 32.0D));
/* 289 */     spawnWitherSkull.c = ((int)((getLocation().getY() + 54.6D + height * 0.285D) * 32.0D));
/* 290 */     spawnWitherSkull.d = ((int)(getLocation().getZ() * 32.0D));
/* 291 */     spawnWitherSkull.j = 66;
/*     */     
/*     */ 
/* 294 */     PacketPlayOutSpawnEntityLiving spawnHorse = new PacketPlayOutSpawnEntityLiving();
/* 295 */     DataWatcher watcher = new DataWatcher(null);
/*     */     
/* 297 */     spawnHorse.a = horseId;
/* 298 */     spawnHorse.b = 100;
/* 299 */     spawnHorse.c = ((int)(getLocation().getX() * 32.0D));
/* 300 */     spawnHorse.d = ((int)((getLocation().getY() + 54.83D + height * 0.285D + 0.23D) * 32.0D));
/* 301 */     spawnHorse.e = ((int)(getLocation().getZ() * 32.0D));
/* 302 */     spawnHorse.l = watcher;
/*     */     
/*     */ 
/* 305 */     watcher.a(0, Byte.valueOf((byte)0));
/* 306 */     watcher.a(1, Short.valueOf((short)300));
/* 307 */     watcher.a(10, horseName);
/* 308 */     watcher.a(11, Byte.valueOf((byte)1));
/* 309 */     watcher.a(12, Integer.valueOf(-1700000));
/*     */     
/*     */ 
/* 312 */     PacketPlayOutAttachEntity attachEntity = new PacketPlayOutAttachEntity();
/*     */     
/* 314 */     attachEntity.b = horseId;
/* 315 */     attachEntity.c = witherId;
/*     */     
/* 317 */     return 
/* 318 */       new Packet[] {
/* 319 */       spawnWitherSkull, spawnHorse, attachEntity };
/*     */   }
/*     */   
/*     */ 
/*     */   private Packet[] makeSpawnPackets1_8(int textRow, int entityId, String lineOfText)
/*     */   {
/* 325 */     PacketPlayOutSpawnEntityLiving packet = new PacketPlayOutSpawnEntityLiving();
/* 326 */     DataWatcher watcher = new DataWatcher(null);
/*     */     
/* 328 */     packet.a = entityId;
/* 329 */     packet.b = 30;
/* 330 */     packet.c = ((int)(getLocation().getX() * 32.0D));
/* 331 */     packet.d = ((int)((getLocation().getY() + -2.1D + textRow * 0.285D) * 32.0D));
/* 332 */     packet.e = ((int)(getLocation().getZ() * 32.0D));
/* 333 */     packet.l = watcher;
/*     */     
/*     */ 
/* 336 */     watcher.a(0, Byte.valueOf((byte)32));
/* 337 */     watcher.a(2, lineOfText);
/* 338 */     watcher.a(3, Byte.valueOf((byte)1));
/*     */     
/*     */ 
/*     */ 
/* 342 */     return 
/* 343 */       new Packet[] {
/* 344 */       packet };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram removePlayer(Player player)
/*     */   {
/* 353 */     return addPlayer(player.getName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram removePlayer(String player)
/*     */   {
/* 361 */     this._playersInList.remove(player);
/* 362 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram setFollowEntity(Entity entityToFollow)
/*     */   {
/* 372 */     this._followEntity = entityToFollow;
/* 373 */     this.relativeToEntity = (entityToFollow == null ? null : this._location.clone().subtract(entityToFollow.getLocation())
/* 374 */       .toVector());
/*     */     
/* 376 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram setHologramTarget(HologramTarget newTarget)
/*     */   {
/* 387 */     this._target = newTarget;
/* 388 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram setLocation(Location newLocation)
/*     */   {
/* 396 */     this._makeSpawnPackets = true;
/*     */     
/* 398 */     Location oldLocation = getLocation();
/* 399 */     this._location = newLocation.clone();
/*     */     
/* 401 */     if (getEntityFollowing() != null)
/*     */     {
/* 403 */       this.relativeToEntity = this._location.clone().subtract(getEntityFollowing().getLocation()).toVector();
/*     */     }
/* 405 */     if (isInUse())
/*     */     {
/* 407 */       ArrayList<Player> canSee = getNearbyPlayers();
/* 408 */       Iterator<Player> itel = this._playersTracking.iterator();
/*     */       
/* 410 */       while (itel.hasNext())
/*     */       {
/* 412 */         Player player = (Player)itel.next();
/* 413 */         if (!canSee.contains(player))
/*     */         {
/* 415 */           itel.remove();
/*     */           
/* 417 */           if (player.getWorld() == getLocation().getWorld())
/*     */           {
/* 419 */             ((CraftPlayer)player).getHandle().playerConnection.sendPacket(getDestroyPacket(player));
/*     */           }
/*     */         }
/*     */       }
/* 423 */       itel = canSee.iterator();
/* 424 */       while (itel.hasNext())
/*     */       {
/* 426 */         Player player = (Player)itel.next();
/*     */         
/* 428 */         if (!this._playersTracking.contains(player))
/*     */         {
/* 430 */           this._playersTracking.add(player);
/* 431 */           itel.remove();
/*     */           Packet[] arrayOfPacket1;
/* 433 */           int j = (arrayOfPacket1 = getSpawnPackets(player)).length; for (int i = 0; i < j; i++) { Packet packet = arrayOfPacket1[i];
/*     */             
/* 435 */             ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
/*     */           }
/*     */         }
/*     */       }
/* 439 */       if (!canSee.isEmpty())
/*     */       {
/* 441 */         this._lastMovement.add(new Vector(newLocation.getX() - oldLocation.getX(), newLocation.getY() - oldLocation.getY(), 
/* 442 */           newLocation.getZ() - oldLocation.getZ()));
/*     */         
/* 444 */         int x = (int)Math.floor(32.0D * this._lastMovement.getX());
/* 445 */         int y = (int)Math.floor(32.0D * this._lastMovement.getY());
/* 446 */         int z = (int)Math.floor(32.0D * this._lastMovement.getZ());
/*     */         
/* 448 */         Packet[] packets1_7 = new Packet[this._hologramText.length];
/* 449 */         Packet[] packets1_8 = new Packet[this._hologramText.length];
/*     */         
/* 451 */         int i = 0;
/*     */         PacketPlayOutEntityTeleport teleportPacket;
/* 453 */         if ((x >= -128) && (x <= 127) && (y >= -128) && (y <= 127) && (z >= -128) && (z <= 127))
/*     */         {
/* 455 */           this._lastMovement.subtract(new Vector(x / 32.0D, y / 32.0D, z / 32.0D));
/* 456 */           for (Map.Entry<Integer, Integer> entityId : this._entityIds)
/*     */           {
/* 458 */             net.minecraft.server.v1_7_R4.PacketPlayOutRelEntityMove relMove = new net.minecraft.server.v1_7_R4.PacketPlayOutRelEntityMove();
/*     */             
/* 460 */             relMove.a = ((Integer)entityId.getKey()).intValue();
/* 461 */             relMove.b = ((byte)x);
/* 462 */             relMove.c = ((byte)y);
/* 463 */             relMove.d = ((byte)z);
/*     */             
/* 465 */             packets1_7[i] = relMove;
/* 466 */             packets1_8[i] = relMove;
/* 467 */             i++;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 472 */           x = (int)Math.floor(32.0D * newLocation.getX());
/* 473 */           z = (int)Math.floor(32.0D * newLocation.getZ());
/*     */           
/* 475 */           this._lastMovement = new Vector(newLocation.getX() - x / 32.0D, 0.0D, newLocation.getZ() - z / 32.0D);
/*     */           
/* 477 */           for (Map.Entry<Integer, Integer> entityId : this._entityIds)
/*     */           {
/* 479 */             for (int b = 0; b < 2; b++)
/*     */             {
/* 481 */               teleportPacket = new PacketPlayOutEntityTeleport();
/* 482 */               teleportPacket.a = ((Integer)entityId.getKey()).intValue();
/* 483 */               teleportPacket.b = x;
/* 484 */               teleportPacket.c = 
/* 485 */                 ((int)Math.floor((oldLocation.getY() + (b == 0 ? 54.6D : -2.1D) + i * 0.285D) * 32.0D));
/* 486 */               teleportPacket.d = z;
/*     */               
/* 488 */               if (b == 0)
/*     */               {
/* 490 */                 packets1_7[i] = teleportPacket;
/*     */               }
/*     */               else
/*     */               {
/* 494 */                 packets1_8[i] = teleportPacket;
/*     */               }
/*     */             }
/*     */             
/* 498 */             i++;
/*     */           }
/*     */         }
/*     */         PacketPlayOutEntityTeleport localPacketPlayOutEntityTeleport1;
/* 502 */         for (??? = canSee.iterator(); ???.hasNext(); 
/*     */             
/* 504 */             teleportPacket < localPacketPlayOutEntityTeleport1)
/*     */         {
/* 502 */           Player player = (Player)???.next();
/*     */           Packet[] arrayOfPacket2;
/* 504 */           localPacketPlayOutEntityTeleport1 = (arrayOfPacket2 = UtilPlayer.is1_8(player) ? packets1_8 : packets1_7).length;teleportPacket = 0; continue;Packet packet = arrayOfPacket2[teleportPacket];
/*     */           
/* 506 */           ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);teleportPacket++;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 511 */     return this;
/*     */   }
/*     */   
/*     */   public Hologram setRemoveOnEntityDeath()
/*     */   {
/* 516 */     this._removeEntityDeath = true;
/* 517 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram setText(String... newLines)
/*     */   {
/* 525 */     String[] newText = new String[newLines.length];
/*     */     
/* 527 */     for (int i = 0; i < newText.length; i++)
/*     */     {
/* 529 */       newText[i] = newLines[(newText.length - (i + 1))];
/*     */     }
/*     */     
/* 532 */     if (newText.equals(this._hologramText)) {
/* 533 */       return this;
/*     */     }
/* 535 */     this._makeSpawnPackets = true;
/*     */     
/* 537 */     if (isInUse())
/*     */     {
/* 539 */       int[] destroy1_7 = new int[0];
/* 540 */       int[] destroy1_8 = new int[0];
/*     */       
/* 542 */       ArrayList<Packet> packets1_7 = new ArrayList();
/* 543 */       ArrayList<Packet> packets1_8 = new ArrayList();
/*     */       
/* 545 */       if (this._hologramText.length != newText.length)
/*     */       {
/* 547 */         this._makeDestroyPackets = true;
/*     */       }
/*     */       DataWatcher watcher1_7;
/* 550 */       for (int i = 0; i < Math.max(this._hologramText.length, newText.length); i++)
/*     */       {
/*     */ 
/* 553 */         if (i >= this._hologramText.length)
/*     */         {
/*     */ 
/*     */ 
/* 557 */           Map.Entry<Integer, Integer> entry = new AbstractMap.SimpleEntry(Integer.valueOf(UtilEnt.getNewEntityId()), Integer.valueOf(UtilEnt.getNewEntityId()));
/* 558 */           this._entityIds.add(entry);
/*     */           
/* 560 */           packets1_7.addAll(Arrays.asList(makeSpawnPackets1_7(i, ((Integer)entry.getKey()).intValue(), ((Integer)entry.getValue()).intValue(), newText[i])));
/*     */           
/* 562 */           packets1_8.addAll(Arrays.asList(makeSpawnPackets1_8(i, ((Integer)entry.getKey()).intValue(), newText[i])));
/*     */ 
/*     */         }
/* 565 */         else if (i >= newText.length)
/*     */         {
/*     */ 
/* 568 */           Map.Entry<Integer, Integer> entry = (Map.Entry)this._entityIds.remove(newText.length);
/*     */           
/* 570 */           destroy1_7 = Arrays.copyOf(destroy1_7, destroy1_7.length + 2);
/*     */           
/* 572 */           destroy1_7[(destroy1_7.length - 2)] = ((Integer)entry.getKey()).intValue();
/* 573 */           destroy1_7[(destroy1_7.length - 1)] = ((Integer)entry.getValue()).intValue();
/*     */           
/* 575 */           destroy1_8 = Arrays.copyOf(destroy1_8, destroy1_8.length + 1);
/* 576 */           destroy1_8[(destroy1_8.length - 1)] = ((Integer)entry.getKey()).intValue();
/*     */         }
/* 578 */         else if (!newText[i].equals(this._hologramText[i]))
/*     */         {
/*     */ 
/* 581 */           entry = (Map.Entry)this._entityIds.get(i);
/* 582 */           PacketPlayOutEntityMetadata metadata1_7 = new PacketPlayOutEntityMetadata();
/*     */           
/* 584 */           metadata1_7.a = ((Integer)entry.getValue()).intValue();
/*     */           
/* 586 */           watcher1_7 = new DataWatcher(null);
/*     */           
/* 588 */           watcher1_7.a(0, Byte.valueOf((byte)0));
/* 589 */           watcher1_7.a(1, Short.valueOf((short)300));
/* 590 */           watcher1_7.a(10, newText[i]);
/* 591 */           watcher1_7.a(11, Byte.valueOf((byte)1));
/* 592 */           watcher1_7.a(12, Integer.valueOf(-1700000));
/*     */           
/* 594 */           metadata1_7.b = watcher1_7.c();
/*     */           
/* 596 */           packets1_7.add(metadata1_7);
/*     */           
/* 598 */           PacketPlayOutEntityMetadata metadata1_8 = new PacketPlayOutEntityMetadata();
/*     */           
/* 600 */           metadata1_8.a = ((Integer)entry.getKey()).intValue();
/*     */           
/* 602 */           DataWatcher watcher1_8 = new DataWatcher(null);
/*     */           
/* 604 */           watcher1_8.a(0, Byte.valueOf((byte)32));
/* 605 */           watcher1_8.a(2, newText[i]);
/* 606 */           watcher1_8.a(3, Byte.valueOf((byte)1));
/*     */           
/*     */ 
/* 609 */           metadata1_8.b = watcher1_8.c();
/*     */           
/* 611 */           packets1_8.add(metadata1_8);
/*     */         }
/*     */       }
/*     */       
/* 615 */       if (destroy1_7.length > 0)
/*     */       {
/* 617 */         packets1_7.add(new PacketPlayOutEntityDestroy(destroy1_7));
/*     */       }
/*     */       
/* 620 */       if (destroy1_8.length > 0)
/*     */       {
/* 622 */         packets1_8.add(new PacketPlayOutEntityDestroy(destroy1_8));
/*     */       }
/*     */       
/* 625 */       for (Map.Entry<Integer, Integer> entry = this._playersTracking.iterator(); entry.hasNext(); 
/*     */           
/* 627 */           watcher1_7.hasNext())
/*     */       {
/* 625 */         Player player = (Player)entry.next();
/*     */         
/* 627 */         watcher1_7 = (UtilPlayer.is1_8(player) ? packets1_8 : packets1_7).iterator(); continue;Packet packet = (Packet)watcher1_7.next();
/*     */         
/* 629 */         ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 634 */     this._hologramText = newText;
/*     */     
/* 636 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram setViewDistance(int newDistance)
/*     */   {
/* 644 */     this._viewDistance = newDistance;
/* 645 */     return setLocation(getLocation());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram start()
/*     */   {
/* 653 */     if (!isInUse())
/*     */     {
/* 655 */       this._hologramManager.addHologram(this);
/* 656 */       this._playersTracking.addAll(getNearbyPlayers());
/*     */       int j;
/* 658 */       int i; for (Iterator localIterator = this._playersTracking.iterator(); localIterator.hasNext(); 
/*     */           
/* 660 */           i < j)
/*     */       {
/* 658 */         Player player = (Player)localIterator.next();
/*     */         Packet[] arrayOfPacket;
/* 660 */         j = (arrayOfPacket = getSpawnPackets(player)).length;i = 0; continue;Packet packet = arrayOfPacket[i];
/*     */         
/* 662 */         ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);i++;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 666 */       this._lastMovement = new Vector();
/*     */     }
/* 668 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Hologram stop()
/*     */   {
/* 676 */     if (isInUse())
/*     */     {
/* 678 */       this._hologramManager.removeHologram(this);
/*     */       
/* 680 */       for (Player player : this._playersTracking)
/*     */       {
/* 682 */         ((CraftPlayer)player).getHandle().playerConnection.sendPacket(getDestroyPacket(player));
/*     */       }
/*     */       
/* 685 */       this._playersTracking.clear();
/* 686 */       this._lastMovement = null;
/*     */     }
/* 688 */     return this;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\hologram\Hologram.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */