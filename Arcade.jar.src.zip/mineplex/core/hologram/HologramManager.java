/*    */ package mineplex.core.hologram;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*    */ import net.minecraft.server.v1_7_R4.Packet;
/*    */ import net.minecraft.server.v1_7_R4.PlayerConnection;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class HologramManager implements org.bukkit.event.Listener
/*    */ {
/* 24 */   private ArrayList<Hologram> _activeHolograms = new ArrayList();
/*    */   
/*    */   public HologramManager(JavaPlugin arcadeManager)
/*    */   {
/* 28 */     Bukkit.getPluginManager().registerEvents(this, arcadeManager);
/*    */   }
/*    */   
/*    */   void addHologram(Hologram hologram)
/*    */   {
/* 33 */     this._activeHolograms.add(hologram);
/*    */   }
/*    */   
/*    */   void removeHologram(Hologram hologram)
/*    */   {
/* 38 */     this._activeHolograms.remove(hologram);
/*    */   }
/*    */   
/*    */   @EventHandler(priority=EventPriority.LOWEST)
/*    */   public void onTick(UpdateEvent event)
/*    */   {
/* 44 */     if ((event.getType() != UpdateType.TICK) || (this._activeHolograms.isEmpty()))
/* 45 */       return;
/* 46 */     List<org.bukkit.World> worlds = Bukkit.getWorlds();
/* 47 */     Iterator<Hologram> itel = this._activeHolograms.iterator();
/* 48 */     while (itel.hasNext())
/*    */     {
/* 50 */       Hologram hologram = (Hologram)itel.next();
/* 51 */       if (!worlds.contains(hologram.getLocation().getWorld()))
/*    */       {
/* 53 */         itel.remove();
/* 54 */         hologram.stop();
/*    */       }
/*    */       else
/*    */       {
/* 58 */         if (hologram.getEntityFollowing() != null)
/*    */         {
/* 60 */           Entity following = hologram.getEntityFollowing();
/* 61 */           if ((hologram.isRemoveOnEntityDeath()) && (!following.isValid()))
/*    */           {
/* 63 */             itel.remove();
/* 64 */             hologram.stop();
/* 65 */             continue;
/*    */           }
/* 67 */           if (!hologram.relativeToEntity.equals(following.getLocation().subtract(hologram.getLocation()).toVector()))
/*    */           {
/*    */ 
/* 70 */             Vector vec = hologram.relativeToEntity.clone();
/* 71 */             hologram.setLocation(following.getLocation().add(hologram.relativeToEntity));
/* 72 */             hologram.relativeToEntity = vec;
/* 73 */             continue;
/*    */           }
/*    */         }
/* 76 */         ArrayList<Player> canSee = hologram.getNearbyPlayers();
/* 77 */         Iterator<Player> itel2 = hologram.getPlayersTracking().iterator();
/* 78 */         while (itel2.hasNext())
/*    */         {
/* 80 */           Player player = (Player)itel2.next();
/* 81 */           if (!canSee.contains(player))
/*    */           {
/* 83 */             itel2.remove();
/* 84 */             if (player.getWorld() == hologram.getLocation().getWorld())
/*    */             {
/* 86 */               ((CraftPlayer)player).getHandle().playerConnection.sendPacket(hologram.getDestroyPacket(player));
/*    */             }
/*    */           }
/*    */         }
/* 90 */         for (Player player : canSee)
/*    */         {
/* 92 */           if (!hologram.getPlayersTracking().contains(player))
/*    */           {
/* 94 */             hologram.getPlayersTracking().add(player);
/* 95 */             Packet[] arrayOfPacket; int j = (arrayOfPacket = hologram.getSpawnPackets(player)).length; for (int i = 0; i < j; i++) { Packet packet = arrayOfPacket[i];
/*    */               
/* 97 */               ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\hologram\HologramManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */