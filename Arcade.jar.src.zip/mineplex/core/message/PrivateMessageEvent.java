/*    */ package mineplex.core.message;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class PrivateMessageEvent
/*    */   extends Event
/*    */ {
/* 11 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/* 13 */   private boolean _cancelled = false;
/*    */   private Player _sender;
/*    */   private Player _recipient;
/*    */   private String _msg;
/*    */   
/*    */   public PrivateMessageEvent(Player sender, Player recipient, String msg)
/*    */   {
/* 20 */     this._sender = sender;
/* 21 */     this._recipient = recipient;
/* 22 */     this._msg = msg;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 27 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 32 */     return handlers;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 37 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 42 */     return this._cancelled;
/*    */   }
/*    */   
/*    */   public Player getSender()
/*    */   {
/* 47 */     return this._sender;
/*    */   }
/*    */   
/*    */   public Player getRecipient()
/*    */   {
/* 52 */     return this._recipient;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 57 */     return this._msg;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\PrivateMessageEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */