/*     */ package mineplex.core.message;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniClientPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.chat.Chat;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.friend.FriendManager;
/*     */ import mineplex.core.friend.data.FriendData;
/*     */ import mineplex.core.friend.data.FriendStatus;
/*     */ import mineplex.core.ignore.IgnoreManager;
/*     */ import mineplex.core.message.commands.AnnounceCommand;
/*     */ import mineplex.core.message.commands.GlobalCommand;
/*     */ import mineplex.core.message.commands.MessageCommand;
/*     */ import mineplex.core.message.redis.AnnouncementHandler;
/*     */ import mineplex.core.message.redis.MessageHandler;
/*     */ import mineplex.core.message.redis.RedisMessage;
/*     */ import mineplex.core.message.redis.RedisMessageCallback;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.preferences.UserPreferences;
/*     */ import mineplex.core.punish.Punish;
/*     */ import mineplex.core.punish.PunishClient;
/*     */ import mineplex.core.punish.Punishment;
/*     */ import mineplex.serverdata.commands.AnnouncementCommand;
/*     */ import mineplex.serverdata.commands.ServerCommandManager;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitRunnable;
/*     */ 
/*     */ public class MessageManager extends MiniClientPlugin<ClientMessage>
/*     */ {
/*     */   private CoreClientManager _clientManager;
/*     */   private FriendManager _friendsManager;
/*     */   private IgnoreManager _ignoreManager;
/*  47 */   private HashMap<UUID, BukkitRunnable> _messageTimeouts = new HashMap();
/*     */   
/*     */   private PreferencesManager _preferences;
/*     */   private Punish _punish;
/*     */   private Chat _chat;
/*     */   private ArrayList<String> _randomMessage;
/*     */   private String _serverName;
/*     */   
/*     */   public MessageManager(JavaPlugin plugin, CoreClientManager clientManager, PreferencesManager preferences, IgnoreManager ignoreManager, Punish punish, FriendManager friendManager, Chat chat)
/*     */   {
/*  57 */     super("Message", plugin);
/*     */     
/*  59 */     this._clientManager = clientManager;
/*  60 */     this._preferences = preferences;
/*  61 */     this._ignoreManager = ignoreManager;
/*  62 */     this._punish = punish;
/*  63 */     this._friendsManager = friendManager;
/*  64 */     this._chat = chat;
/*  65 */     this._serverName = getPlugin().getConfig().getString("serverstatus.name");
/*     */     
/*  67 */     MessageHandler messageHandler = new MessageHandler(this);
/*     */     
/*  69 */     ServerCommandManager.getInstance().registerCommandType("AnnouncementCommand", AnnouncementCommand.class, 
/*  70 */       new AnnouncementHandler());
/*     */     
/*  72 */     ServerCommandManager.getInstance().registerCommandType("RedisMessage", RedisMessage.class, messageHandler);
/*  73 */     ServerCommandManager.getInstance()
/*  74 */       .registerCommandType("RedisMessageCallback", RedisMessageCallback.class, messageHandler);
/*     */   }
/*     */   
/*     */   public void addCommands()
/*     */   {
/*  79 */     addCommand(new MessageCommand(this));
/*  80 */     addCommand(new mineplex.core.message.commands.ResendCommand(this));
/*     */     
/*  82 */     addCommand(new mineplex.core.message.commands.MessageAdminCommand(this));
/*  83 */     addCommand(new mineplex.core.message.commands.ResendAdminCommand(this));
/*     */     
/*  85 */     addCommand(new AnnounceCommand(this));
/*  86 */     addCommand(new GlobalCommand(this));
/*     */     
/*  88 */     addCommand(new mineplex.core.message.commands.AdminCommand(this));
/*     */   }
/*     */   
/*     */ 
/*     */   protected ClientMessage AddPlayer(String player)
/*     */   {
/*  94 */     Set(player, new ClientMessage());
/*  95 */     return (ClientMessage)Get(player);
/*     */   }
/*     */   
/*     */   public boolean canMessage(Player from, Player to)
/*     */   {
/* 100 */     if (!canSenderMessageThem(from, to.getName()))
/*     */     {
/* 102 */       return false;
/*     */     }
/*     */     
/* 105 */     String canMessage = canReceiverMessageThem(from.getName(), to);
/*     */     
/* 107 */     if (canMessage != null)
/*     */     {
/* 109 */       from.sendMessage(canMessage);
/*     */       
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String canReceiverMessageThem(String sender, Player target)
/*     */   {
/* 120 */     if (!((UserPreferences)this._preferences.Get(target)).PrivateMessaging)
/*     */     {
/* 122 */       return C.cPurple + target.getName() + " has private messaging disabled.";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 127 */     if (this._ignoreManager.isIgnoring(target, sender))
/*     */     {
/* 129 */       return F.main(this._ignoreManager.getName(), ChatColor.GRAY + "That player is ignoring you");
/*     */     }
/*     */     
/* 132 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isMuted(Player sender)
/*     */   {
/* 137 */     PunishClient client = this._punish.GetClient(sender.getName());
/*     */     
/* 139 */     if ((client != null) && (client.IsMuted()))
/*     */     {
/* 141 */       Punishment punishment = client.GetPunishment(mineplex.core.punish.PunishmentSentence.Mute);
/*     */       
/* 143 */       sender.sendMessage(F.main(this._punish.getName(), "Shh, you're muted because " + 
/*     */       
/* 145 */         punishment.GetReason() + 
/*     */         
/* 147 */         " by " + 
/*     */         
/* 149 */         punishment.GetAdmin() + 
/*     */         
/* 151 */         " for " + 
/*     */         
/* 153 */         C.cGreen + 
/*     */         
/* 155 */         mineplex.core.common.util.UtilTime.convertString(punishment.GetRemaining(), 1, mineplex.core.common.util.UtilTime.TimeUnit.FIT) + "."));
/*     */       
/* 157 */       return true;
/*     */     }
/*     */     
/* 160 */     return false;
/*     */   }
/*     */   
/*     */   public boolean canSenderMessageThem(Player sender, String target)
/*     */   {
/* 165 */     if (isMuted(sender))
/*     */     {
/* 167 */       return false;
/*     */     }
/*     */     
/* 170 */     if (this._ignoreManager.isIgnoring(sender, target))
/*     */     {
/* 172 */       sender.sendMessage(F.main(this._ignoreManager.getName(), ChatColor.GRAY + "You are ignoring that player"));
/*     */       
/* 174 */       return false;
/*     */     }
/*     */     
/* 177 */     return true;
/*     */   }
/*     */   
/*     */   public void DoMessage(Player from, Player to, String message)
/*     */   {
/* 182 */     PrivateMessageEvent pmEvent = new PrivateMessageEvent(from, to, message);
/* 183 */     Bukkit.getServer().getPluginManager().callEvent(pmEvent);
/* 184 */     if (pmEvent.isCancelled()) {
/* 185 */       return;
/*     */     }
/* 187 */     if (!canMessage(from, to))
/*     */     {
/* 189 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 194 */     if ((!GetClientManager().Get(from).GetRank().Has(Rank.HELPER)) && (((ClientMessage)Get(from)).LastTo != null) && 
/* 195 */       (!((ClientMessage)Get(from)).LastTo.equalsIgnoreCase(to.getName())))
/*     */     {
/* 197 */       long delta = System.currentTimeMillis() - ((ClientMessage)Get(from)).LastToTime;
/*     */       
/* 199 */       if ((((ClientMessage)Get(from)).SpamCounter > 3) && (delta < ((ClientMessage)Get(from)).SpamCounter * 1000))
/*     */       {
/* 201 */         from.sendMessage(F.main("Cooldown", "Try sending that message again in a few seconds"));
/* 202 */         ((ClientMessage)Get(from)).LastTo = to.getName();
/* 203 */         return;
/*     */       }
/* 205 */       if (delta < 8000L)
/*     */       {
/*     */ 
/* 208 */         ((ClientMessage)Get(from)).SpamCounter += 1;
/*     */       }
/*     */     }
/*     */     
/* 212 */     message = this._chat.getFilteredMessage(from, message);
/*     */     
/*     */ 
/* 215 */     UtilPlayer.message(from, C.cGold + "§l" + from.getName() + " > " + to.getName() + C.cYellow + " §l" + message);
/*     */     
/*     */ 
/* 218 */     ((ClientMessage)Get(from)).LastTo = to.getName();
/* 219 */     ((ClientMessage)Get(from)).LastToTime = System.currentTimeMillis();
/*     */     
/*     */ 
/* 222 */     if ((to.getName().equals("Chiss")) || (to.getName().equals("defek7")) || (to.getName().equals("Phinary")) || (to.getName().equals("fooify")))
/*     */     {
/* 224 */       UtilPlayer.message(from, C.cPurple + to.getName() + " is often AFK or minimized, due to plugin development.");
/* 225 */       UtilPlayer.message(from, C.cPurple + "Please be patient if he does not reply instantly.");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     from.playSound(to.getLocation(), Sound.NOTE_PIANO, 1.0F, 1.0F);
/* 233 */     to.playSound(to.getLocation(), Sound.NOTE_PIANO, 2.0F, 2.0F);
/*     */     
/*     */ 
/* 236 */     UtilPlayer.message(to, C.cGold + "§l" + from.getName() + " > " + to.getName() + C.cYellow + " §l" + message);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DoMessageAdmin(Player from, Player to, String message)
/*     */   {
/* 242 */     UtilPlayer.message(from, C.cPurple + "-> " + F.rank(this._clientManager.Get(to).GetRank()) + " " + to.getName() + " " + 
/* 243 */       C.cPurple + message);
/*     */     
/*     */     Player[] arrayOfPlayer;
/* 246 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player staff = arrayOfPlayer[i];
/*     */       
/* 248 */       if ((!to.equals(staff)) && (!from.equals(staff)))
/*     */       {
/* 250 */         if (this._clientManager.Get(staff).GetRank().Has(Rank.HELPER))
/*     */         {
/* 252 */           UtilPlayer.message(staff, F.rank(this._clientManager.Get(from).GetRank()) + " " + from.getName() + C.cPurple + 
/* 253 */             " -> " + F.rank(this._clientManager.Get(to).GetRank()) + " " + to.getName() + " " + C.cPurple + message);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 259 */     ((ClientMessage)Get(from)).LastAdminTo = to.getName();
/*     */     
/*     */ 
/* 262 */     UtilPlayer.message(to, C.cPurple + "<- " + F.rank(this._clientManager.Get(from).GetRank()) + " " + from.getName() + " " + 
/* 263 */       C.cPurple + message);
/*     */     
/*     */ 
/* 266 */     from.playSound(to.getLocation(), Sound.NOTE_PIANO, 1.0F, 1.0F);
/* 267 */     to.playSound(to.getLocation(), Sound.NOTE_PIANO, 2.0F, 2.0F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void enable()
/*     */   {
/* 277 */     this._randomMessage = new ArrayList();
/* 278 */     this._randomMessage.clear();
/* 279 */     this._randomMessage.add("Hello, do you have any wild boars for purchase?");
/* 280 */     this._randomMessage.add("There's a snake in my boot!");
/* 281 */     this._randomMessage.add("Monk, I need a Monk!");
/* 282 */     this._randomMessage.add("Hi, I'm from planet minecraft, op me plz dooooood!");
/* 283 */     this._randomMessage.add("Somebody's poisoned the waterhole!");
/* 284 */     this._randomMessage.add("MORE ORBZ MORE ORBZ MORE ORBZ MORE ORBZ!");
/* 285 */     this._randomMessage.add("Chiss is a chiss and chiss chiss.");
/* 286 */     this._randomMessage.add("*_*");
/* 287 */     this._randomMessage.add("#swag");
/* 288 */     this._randomMessage.add("Everything went better then I thought.");
/* 289 */     this._randomMessage.add("HAVE A CHICKEN!");
/* 290 */     this._randomMessage.add("follow me, i have xrays");
/* 291 */     this._randomMessage.add("I'm making a java");
/* 292 */     this._randomMessage.add("Do you talk to strangers?  I have candy if it helps.");
/* 293 */     this._randomMessage.add("Solid 2.9/10");
/* 294 */     this._randomMessage.add("close your eyes to sleep");
/* 295 */     this._randomMessage.add("I crashed because my internet ran out.");
/* 296 */     this._randomMessage.add("I saw morgan freeman on a breaking bad ad on a bus.");
/* 297 */     this._randomMessage.add("Where is the volume control?");
/* 298 */     this._randomMessage.add("I saw you playing on youtube with that guy and stuff.");
/* 299 */     this._randomMessage.add("Your worms must be worse than useless.");
/* 300 */     this._randomMessage.add("meow");
/* 301 */     this._randomMessage.add("7");
/* 302 */     this._randomMessage.add("Don't you wish your girlfriend was hot like me?");
/* 303 */     this._randomMessage.add("how do you play mindcrafts?");
/* 304 */     this._randomMessage.add("7 cats meow meow meow meow meow meow meow");
/* 305 */     this._randomMessage.add("For King Jonalon!!!!!");
/* 306 */     this._randomMessage.add("Do you like apples?");
/* 307 */     this._randomMessage.add("I'm Happy Happy Happy.");
/* 308 */     this._randomMessage.add("kthxbye");
/* 309 */     this._randomMessage.add("i like pie.");
/* 310 */     this._randomMessage.add("Do you play Clash of Clans?");
/* 311 */     this._randomMessage.add("Mmm...Steak!");
/* 312 */     this._randomMessage.add("Poop! Poop everywhere!");
/* 313 */     this._randomMessage.add("I'm so forgetful. Like I was going to say somethin...wait what were we talking about?");
/* 314 */     this._randomMessage.add("Mmm...Steak!");
/*     */   }
/*     */   
/*     */   public CoreClientManager GetClientManager()
/*     */   {
/* 319 */     return this._clientManager;
/*     */   }
/*     */   
/*     */   public String GetRandomMessage()
/*     */   {
/* 324 */     if (this._randomMessage.isEmpty()) {
/* 325 */       return "meow";
/*     */     }
/* 327 */     return (String)this._randomMessage.get(UtilMath.r(this._randomMessage.size()));
/*     */   }
/*     */   
/*     */   public ArrayList<String> GetRandomMessages()
/*     */   {
/* 332 */     return this._randomMessage;
/*     */   }
/*     */   
/*     */   public void Help(Player caller)
/*     */   {
/* 337 */     Help(caller, null);
/*     */   }
/*     */   
/*     */   public void Help(Player caller, String message)
/*     */   {
/* 342 */     UtilPlayer.message(caller, F.main(this._moduleName, ChatColor.RED + "Err...something went wrong?"));
/*     */   }
/*     */   
/*     */   public void receiveMessage(Player to, RedisMessage globalMessage)
/*     */   {
/* 347 */     if (globalMessage.isStaffMessage())
/*     */     {
/*     */ 
/* 350 */       UtilPlayer.message(to, C.cPurple + "<- " + globalMessage.getRank() + " " + globalMessage.getSender() + " " + 
/* 351 */         C.cPurple + globalMessage.getMessage());
/*     */       
/* 353 */       to.playSound(to.getLocation(), Sound.NOTE_PIANO, 2.0F, 2.0F);
/*     */       
/* 355 */       String toRank = F.rank(this._clientManager.Get(to).GetRank());
/*     */       
/*     */ 
/* 358 */       RedisMessageCallback message = new RedisMessageCallback(globalMessage, true, to.getName(), 
/*     */       
/* 360 */         C.cPurple + "-> " + toRank + " " + to.getName() + " " + C.cPurple + globalMessage.getMessage());
/*     */       
/*     */       Player[] arrayOfPlayer;
/* 363 */       int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player staff = arrayOfPlayer[i];
/*     */         
/* 365 */         if (!to.equals(staff))
/*     */         {
/* 367 */           if (this._clientManager.Get(staff).GetRank().Has(Rank.HELPER))
/*     */           {
/* 369 */             UtilPlayer.message(staff, 
/*     */             
/* 371 */               globalMessage.getRank() + " " + globalMessage.getSender() + C.cPurple + " " + message.getMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 376 */       message.publish();
/*     */     }
/*     */     else
/*     */     {
/* 380 */       String canMessage = canReceiverMessageThem(globalMessage.getSender(), to);
/*     */       
/* 382 */       if (canMessage != null)
/*     */       {
/*     */ 
/* 385 */         RedisMessageCallback message = new RedisMessageCallback(globalMessage, false, null, canMessage);
/*     */         
/* 387 */         message.publish();
/*     */         
/* 389 */         return;
/*     */       }
/*     */       
/* 392 */       String message = C.cGold + "§l" + globalMessage.getSender() + " > " + to.getName() + C.cYellow + " §l" + 
/* 393 */         globalMessage.getMessage();
/*     */       
/*     */ 
/* 396 */       UtilPlayer.message(to, message);
/*     */       
/* 398 */       to.playSound(to.getLocation(), Sound.NOTE_PIANO, 2.0F, 2.0F);
/*     */       
/*     */ 
/* 401 */       RedisMessageCallback redisMessage = new RedisMessageCallback(globalMessage, false, to.getName(), message);
/*     */       
/* 403 */       redisMessage.publish();
/*     */     }
/*     */   }
/*     */   
/*     */   public void receiveMessageCallback(RedisMessageCallback message)
/*     */   {
/* 409 */     BukkitRunnable runnable = (BukkitRunnable)this._messageTimeouts.remove(message.getUUID());
/*     */     
/* 411 */     if (runnable != null)
/*     */     {
/* 413 */       runnable.cancel();
/*     */     }
/*     */     
/* 416 */     Player target = Bukkit.getPlayerExact(message.getTarget());
/*     */     
/* 418 */     if (target != null)
/*     */     {
/* 420 */       target.sendMessage(message.getMessage());
/*     */       
/* 422 */       target.playSound(target.getLocation(), Sound.NOTE_PIANO, 2.0F, 2.0F);
/*     */       
/* 424 */       if (message.getLastReplied() != null)
/*     */       {
/* 426 */         if (message.isStaffMessage())
/*     */         {
/* 428 */           ((ClientMessage)Get(target)).LastAdminTo = message.getLastReplied();
/*     */         }
/*     */         else
/*     */         {
/* 432 */           ((ClientMessage)Get(target)).LastTo = message.getLastReplied();
/*     */         }
/*     */       }
/*     */       
/* 436 */       if ((message.isStaffMessage()) && (message.getLastReplied() != null))
/*     */       {
/* 438 */         String recevierRank = F.rank(this._clientManager.Get(target).GetRank());
/*     */         
/*     */         Player[] arrayOfPlayer;
/* 441 */         int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player staff = arrayOfPlayer[i];
/*     */           
/* 443 */           if (!target.equals(staff))
/*     */           {
/* 445 */             if (this._clientManager.Get(staff).GetRank().Has(Rank.HELPER))
/*     */             {
/* 447 */               UtilPlayer.message(staff, 
/*     */               
/* 449 */                 recevierRank + " " + target.getName() + " " + C.cPurple + message.getMessage());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void sendMessage(final Player sender, final String target, String message, final boolean isReply, final boolean adminMessage)
/*     */   {
/* 460 */     FriendData friends = (FriendData)this._friendsManager.Get(sender);
/* 461 */     FriendStatus friend = null;
/*     */     
/* 463 */     if (!adminMessage)
/*     */     {
/*     */ 
/* 466 */       for (FriendStatus friendInfo : friends.getFriends())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 471 */         if (((isReply) || (friendInfo.Online)) && (friendInfo.Name.equalsIgnoreCase(target)))
/*     */         {
/* 473 */           friend = friendInfo;
/* 474 */           break;
/*     */         }
/*     */         
/*     */ 
/* 478 */         if ((!isReply) && (friend == null) && (friendInfo.Online) && 
/* 479 */           (friendInfo.Name.toLowerCase().startsWith(target.toLowerCase())))
/*     */         {
/* 481 */           friend = friendInfo;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 486 */     final FriendStatus friendInfo = friend;
/*     */     
/* 488 */     new BukkitRunnable()
/*     */     {
/*     */       final String newMessage;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void run()
/*     */       {
/* 504 */         new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 501 */             MessageManager.this.sendMessage(this.val$sender, this.val$target, MessageManager.1.this.newMessage, this.val$adminMessage, this.val$isReply, this.val$friendInfo);
/*     */           }
/*     */           
/* 504 */         }.runTask(MessageManager.this.getPlugin());
/*     */       }
/*     */       
/* 507 */     }.runTaskAsynchronously(getPlugin());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void sendMessage(final Player sender, String target, String message, final boolean adminMessage, boolean isReply, FriendStatus friend)
/*     */   {
/* 516 */     Player to = UtilPlayer.searchOnline(sender, target, (!adminMessage) && (friend == null) && (!isReply));
/*     */     
/*     */ 
/* 519 */     if ((!adminMessage) && ((friend == null) || (!friend.Online)) && (to == null))
/*     */     {
/*     */ 
/* 522 */       if (isReply)
/*     */       {
/* 524 */         UtilPlayer.message(sender, F.main(getName(), F.name(target) + " is no longer online."));
/*     */       }
/*     */       
/* 527 */       return;
/*     */     }
/*     */     
/*     */ 
/* 531 */     if (to != null)
/*     */     {
/* 533 */       if (adminMessage)
/*     */       {
/* 535 */         DoMessageAdmin(sender, to, message);
/*     */       }
/*     */       else
/*     */       {
/* 539 */         DoMessage(sender, to, message);
/*     */       }
/*     */       
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 547 */       final String playerTarget = adminMessage ? target : friend.Name;
/*     */       
/*     */ 
/* 550 */       if ((adminMessage) || (canSenderMessageThem(sender, playerTarget)))
/*     */       {
/*     */ 
/* 553 */         RedisMessage globalMessage = new RedisMessage(this._serverName, 
/*     */         
/* 555 */           sender.getName(), 
/*     */           
/* 557 */           adminMessage ? null : friend.ServerName, 
/*     */           
/* 559 */           playerTarget, 
/*     */           
/* 561 */           message, 
/*     */           
/*     */ 
/* 564 */           adminMessage ? F.rank(this._clientManager.Get(sender).GetRank()) : null);
/*     */         
/* 566 */         final UUID uuid = globalMessage.getUUID();
/*     */         
/*     */ 
/* 569 */         BukkitRunnable runnable = new BukkitRunnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 573 */             MessageManager.this._messageTimeouts.remove(uuid);
/*     */             
/*     */ 
/* 576 */             UtilPlayer.message(
/* 577 */               sender, 
/* 578 */               F.main((adminMessage ? "Admin " : "") + "Message", C.mBody + " Failed to send message to [" + 
/* 579 */               C.mElem + playerTarget + C.mBody + "]."));
/*     */           }
/*     */           
/*     */ 
/* 583 */         };
/* 584 */         runnable.runTaskLater(getPlugin(), 40L);
/*     */         
/*     */ 
/* 587 */         this._messageTimeouts.put(uuid, runnable);
/*     */         
/*     */ 
/* 590 */         globalMessage.publish();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\MessageManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */