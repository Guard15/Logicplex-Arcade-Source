/*    */ package mineplex.core.message.redis;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ 
/*    */ 
/*    */ public class RedisMessageCallback
/*    */   extends ServerCommand
/*    */ {
/*    */   private String _message;
/*    */   private String _setLastMessage;
/*    */   private String _target;
/*    */   private boolean _staffMessage;
/*    */   private UUID _uuid;
/*    */   
/*    */   public RedisMessageCallback(RedisMessage globalMessage, boolean staffMessage, String receivedPlayer, String message)
/*    */   {
/* 18 */     super(new String[0]);
/*    */     
/* 20 */     this._target = globalMessage.getSender();
/* 21 */     this._message = message;
/* 22 */     this._setLastMessage = receivedPlayer;
/* 23 */     this._uuid = globalMessage.getUUID();
/* 24 */     this._staffMessage = staffMessage;
/*    */     
/* 26 */     if (globalMessage.getSendingServer() != null)
/*    */     {
/* 28 */       setTargetServers(new String[] { globalMessage.getSendingServer() });
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean isStaffMessage()
/*    */   {
/* 34 */     return this._staffMessage;
/*    */   }
/*    */   
/*    */   public String getLastReplied()
/*    */   {
/* 39 */     return this._setLastMessage;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 44 */     return this._message;
/*    */   }
/*    */   
/*    */   public String getTarget()
/*    */   {
/* 49 */     return this._target;
/*    */   }
/*    */   
/*    */   public UUID getUUID()
/*    */   {
/* 54 */     return this._uuid;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\redis\RedisMessageCallback.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */