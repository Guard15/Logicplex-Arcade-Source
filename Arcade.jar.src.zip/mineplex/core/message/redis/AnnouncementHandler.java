/*    */ package mineplex.core.message.redis;
/*    */ 
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilTextMiddle;
/*    */ import mineplex.serverdata.commands.AnnouncementCommand;
/*    */ import mineplex.serverdata.commands.CommandCallback;
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class AnnouncementHandler
/*    */   implements CommandCallback
/*    */ {
/*    */   public void run(ServerCommand command)
/*    */   {
/* 18 */     if ((command instanceof AnnouncementCommand))
/*    */     {
/* 20 */       AnnouncementCommand announcementCommand = (AnnouncementCommand)command;
/*    */       
/* 22 */       String message = announcementCommand.getMessage();
/*    */       
/* 24 */       if (announcementCommand.getDisplayTitle()) {
/* 25 */         UtilTextMiddle.display(C.cYellow + "Announcement", message, 10, 120, 10);
/*    */       }
/* 27 */       for (Player player : Bukkit.getOnlinePlayers())
/*    */       {
/* 29 */         UtilPlayer.message(player, F.main("Announcement", C.cAqua + message));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\redis\AnnouncementHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */