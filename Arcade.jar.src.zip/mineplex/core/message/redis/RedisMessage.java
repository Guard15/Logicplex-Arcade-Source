/*    */ package mineplex.core.message.redis;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RedisMessage
/*    */   extends ServerCommand
/*    */ {
/*    */   private String _message;
/*    */   private String _sender;
/*    */   private String _sendingServer;
/*    */   private String _target;
/*    */   private String _rank;
/* 17 */   private UUID _uuid = UUID.randomUUID();
/*    */   
/* 19 */   public RedisMessage(String sendingServer, String sender, String targetServer, String target, String message, String rank) { super(new String[0]);
/*    */     
/* 21 */     this._sender = sender;
/* 22 */     this._target = target;
/* 23 */     this._message = message;
/* 24 */     this._sendingServer = sendingServer;
/* 25 */     this._rank = rank;
/*    */     
/* 27 */     if (targetServer != null)
/*    */     {
/* 29 */       setTargetServers(new String[] { targetServer });
/*    */     }
/*    */   }
/*    */   
/*    */   public UUID getUUID()
/*    */   {
/* 35 */     return this._uuid;
/*    */   }
/*    */   
/*    */   public String getRank()
/*    */   {
/* 40 */     return this._rank;
/*    */   }
/*    */   
/*    */   public boolean isStaffMessage()
/*    */   {
/* 45 */     return getTargetServers().length == 0;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 50 */     return this._message;
/*    */   }
/*    */   
/*    */   public String getSender()
/*    */   {
/* 55 */     return this._sender;
/*    */   }
/*    */   
/*    */   public String getSendingServer()
/*    */   {
/* 60 */     return this._sendingServer;
/*    */   }
/*    */   
/*    */   public String getTarget()
/*    */   {
/* 65 */     return this._target;
/*    */   }
/*    */   
/*    */   public void run() {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\redis\RedisMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */