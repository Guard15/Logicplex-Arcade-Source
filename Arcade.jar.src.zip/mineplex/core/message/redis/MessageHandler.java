/*    */ package mineplex.core.message.redis;
/*    */ 
/*    */ import mineplex.core.message.MessageManager;
/*    */ import mineplex.serverdata.commands.CommandCallback;
/*    */ import mineplex.serverdata.commands.ServerCommand;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class MessageHandler
/*    */   implements CommandCallback
/*    */ {
/*    */   private MessageManager _messageManager;
/*    */   
/*    */   public MessageHandler(MessageManager messageManager)
/*    */   {
/* 16 */     this._messageManager = messageManager;
/*    */   }
/*    */   
/*    */   public void run(ServerCommand command)
/*    */   {
/* 21 */     if ((command instanceof RedisMessage))
/*    */     {
/* 23 */       RedisMessage message = (RedisMessage)command;
/*    */       
/* 25 */       Player target = Bukkit.getPlayerExact(message.getTarget());
/*    */       
/* 27 */       if (target != null)
/*    */       {
/* 29 */         this._messageManager.receiveMessage(target, message);
/*    */       }
/*    */     }
/* 32 */     else if ((command instanceof RedisMessageCallback))
/*    */     {
/*    */ 
/* 35 */       this._messageManager.receiveMessageCallback((RedisMessageCallback)command);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\redis\MessageHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */