/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import mineplex.serverdata.commands.AnnouncementCommand;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AnnounceCommand
/*    */   extends CommandBase<MessageManager>
/*    */ {
/*    */   public AnnounceCommand(MessageManager plugin)
/*    */   {
/* 19 */     super(plugin, Rank.ADMIN, new String[] { "announce" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 25 */     if (args == null)
/*    */     {
/* 27 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 31 */       new AnnouncementCommand(true, F.combine(args, 0, null, false)).publish();
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\AnnounceCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */