/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class AdminCommand extends CommandBase<MessageManager>
/*    */ {
/*    */   public AdminCommand(MessageManager plugin)
/*    */   {
/* 18 */     super(plugin, Rank.ALL, new String[] { "a", "admin" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 24 */     if (args == null)
/*    */     {
/* 26 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 30 */       if (args.length == 0)
/*    */       {
/* 32 */         UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "Message argument missing."));
/* 33 */         return;
/*    */       }
/*    */       
/* 36 */       if (((MessageManager)this.Plugin).isMuted(caller))
/*    */       {
/* 38 */         return;
/*    */       }
/*    */       
/*    */ 
/* 42 */       String message = F.combine(args, 0, null, false);
/*    */       
/*    */ 
/* 45 */       UtilPlayer.message(caller, F.rank(((MessageManager)this.Plugin).GetClientManager().Get(caller).GetRank()) + " " + caller.getName() + " " + C.cPurple + message);
/*    */       
/*    */ 
/* 48 */       boolean staff = false;
/* 49 */       Player[] arrayOfPlayer; int j = (arrayOfPlayer = mineplex.core.common.util.UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player to = arrayOfPlayer[i];
/*    */         
/* 51 */         if (((MessageManager)this.Plugin).GetClientManager().Get(to).GetRank().Has(Rank.HELPER))
/*    */         {
/* 53 */           if (!to.equals(caller)) {
/* 54 */             UtilPlayer.message(to, F.rank(((MessageManager)this.Plugin).GetClientManager().Get(caller).GetRank()) + " " + caller.getName() + " " + C.cPurple + message);
/*    */           }
/* 56 */           staff = true;
/*    */           
/*    */ 
/* 59 */           to.playSound(to.getLocation(), Sound.NOTE_PLING, 0.5F, 2.0F);
/*    */         }
/*    */       }
/*    */       
/* 63 */       if (!staff) {
/* 64 */         UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "There are no Staff Members online."));
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\AdminCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */