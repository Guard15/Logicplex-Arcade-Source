/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.message.ClientMessage;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ResendAdminCommand extends CommandBase<MessageManager>
/*    */ {
/*    */   public ResendAdminCommand(MessageManager plugin)
/*    */   {
/* 15 */     super(plugin, Rank.ALL, new String[] { "ra" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null)
/*    */     {
/* 23 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 27 */       if (!((MessageManager)this.Plugin).GetClientManager().Get(caller).GetRank().Has(caller, Rank.HELPER, true)) {
/* 28 */         return;
/*    */       }
/* 30 */       String lastTo = ((ClientMessage)((MessageManager)this.Plugin).Get(caller)).LastAdminTo;
/*    */       
/*    */ 
/* 33 */       if (lastTo == null)
/*    */       {
/* 35 */         mineplex.core.common.util.UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "You have not admin messaged anyone recently."));
/* 36 */         return;
/*    */       }
/*    */       
/*    */ 
/* 40 */       String message = "Beep!";
/* 41 */       if (args.length > 0)
/*    */       {
/* 43 */         message = F.combine(args, 0, null, false);
/*    */       }
/*    */       else
/*    */       {
/* 47 */         message = ((MessageManager)this.Plugin).GetRandomMessage();
/*    */       }
/*    */       
/* 50 */       ((MessageManager)this.Plugin).sendMessage(caller, lastTo, message, true, true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\ResendAdminCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */