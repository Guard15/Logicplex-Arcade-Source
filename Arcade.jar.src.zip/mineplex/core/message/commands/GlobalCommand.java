/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import mineplex.serverdata.commands.AnnouncementCommand;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GlobalCommand
/*    */   extends CommandBase<MessageManager>
/*    */ {
/*    */   public GlobalCommand(MessageManager plugin)
/*    */   {
/* 17 */     super(plugin, Rank.ADMIN, new String[] { "global" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 23 */     if (args == null)
/*    */     {
/* 25 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 29 */       new AnnouncementCommand(false, F.combine(args, 0, null, false)).publish();
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\GlobalCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */