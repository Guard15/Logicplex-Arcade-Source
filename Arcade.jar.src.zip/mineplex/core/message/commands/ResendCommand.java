/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.message.ClientMessage;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class ResendCommand extends CommandBase<MessageManager>
/*    */ {
/*    */   public ResendCommand(MessageManager plugin)
/*    */   {
/* 15 */     super(plugin, Rank.ALL, new String[] { "r" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null)
/*    */     {
/* 23 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 27 */       String lastTo = ((ClientMessage)((MessageManager)this.Plugin).Get(caller)).LastTo;
/*    */       
/*    */ 
/* 30 */       if (lastTo == null)
/*    */       {
/* 32 */         UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "You have not messaged anyone recently."));
/* 33 */         return;
/*    */       }
/*    */       
/*    */ 
/* 37 */       String message = "Beep!";
/* 38 */       if (args.length > 0)
/*    */       {
/* 40 */         message = F.combine(args, 0, null, false);
/*    */       }
/*    */       else
/*    */       {
/* 44 */         message = ((MessageManager)this.Plugin).GetRandomMessage();
/*    */       }
/*    */       
/* 47 */       ((MessageManager)this.Plugin).sendMessage(caller, lastTo, message, true, false);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\ResendCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */