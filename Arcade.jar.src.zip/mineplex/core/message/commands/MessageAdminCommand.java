/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class MessageAdminCommand extends CommandBase<MessageManager>
/*    */ {
/*    */   public MessageAdminCommand(MessageManager plugin)
/*    */   {
/* 15 */     super(plugin, Rank.ALL, new String[] { "ma" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null)
/*    */     {
/* 23 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 27 */       if (!((MessageManager)this.Plugin).GetClientManager().Get(caller).GetRank().Has(caller, Rank.HELPER, true)) {
/* 28 */         return;
/*    */       }
/* 30 */       if (args.length == 0)
/*    */       {
/* 32 */         mineplex.core.common.util.UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "Player argument missing."));
/* 33 */         return;
/*    */       }
/*    */       
/*    */ 
/* 37 */       String message = "Beep!";
/* 38 */       if (args.length > 1)
/*    */       {
/* 40 */         message = F.combine(args, 1, null, false);
/*    */       }
/*    */       else
/*    */       {
/* 44 */         message = ((MessageManager)this.Plugin).GetRandomMessage();
/*    */       }
/*    */       
/* 47 */       ((MessageManager)this.Plugin).sendMessage(caller, args[0], message, false, true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\MessageAdminCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */