/*    */ package mineplex.core.message.commands;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.message.MessageManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class AdminMessageCommand
/*    */   extends CommandBase<MessageManager>
/*    */ {
/*    */   public AdminMessageCommand(MessageManager plugin)
/*    */   {
/* 15 */     super(plugin, Rank.SNR_MODERATOR, new String[] { "am" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 21 */     if (args == null)
/*    */     {
/* 23 */       ((MessageManager)this.Plugin).Help(caller);
/*    */     }
/*    */     else
/*    */     {
/* 27 */       if (args.length == 0)
/*    */       {
/* 29 */         UtilPlayer.message(caller, F.main(((MessageManager)this.Plugin).getName(), "Player argument missing."));
/* 30 */         return;
/*    */       }
/*    */       
/*    */ 
/* 34 */       String message = "Beep!";
/* 35 */       if (args.length > 1)
/*    */       {
/* 37 */         message = F.combine(args, 1, null, false);
/*    */       }
/*    */       else
/*    */       {
/* 41 */         message = ((MessageManager)this.Plugin).GetRandomMessage();
/*    */       }
/*    */       
/* 44 */       ((MessageManager)this.Plugin).sendMessage(caller, args[0], message, false, true);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\commands\AdminMessageCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */