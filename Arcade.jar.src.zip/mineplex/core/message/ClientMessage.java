package mineplex.core.message;

public class ClientMessage
{
  public String LastTo;
  public String LastAdminTo;
  public long LastToTime;
  public int SpamCounter;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\message\ClientMessage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */