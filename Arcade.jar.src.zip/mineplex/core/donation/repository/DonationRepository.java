/*     */ package mineplex.core.donation.repository;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import mineplex.core.common.util.Callback;
/*     */ import mineplex.core.database.DBPool;
/*     */ import mineplex.core.database.DatabaseRunnable;
/*     */ import mineplex.core.database.RepositoryBase;
/*     */ import mineplex.core.database.column.Column;
/*     */ import mineplex.core.database.column.ColumnInt;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.donation.repository.token.GemRewardToken;
/*     */ import mineplex.core.donation.repository.token.PurchaseToken;
/*     */ import mineplex.core.donation.repository.token.UnknownPurchaseToken;
/*     */ import mineplex.core.server.remotecall.AsyncJsonWebCall;
/*     */ import mineplex.core.server.remotecall.JsonWebCall;
/*     */ import mineplex.core.server.util.TransactionResponse;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class DonationRepository extends RepositoryBase
/*     */ {
/*  25 */   private static String CREATE_COIN_TRANSACTION_TABLE = "CREATE TABLE IF NOT EXISTS accountCoinTransactions (id INT NOT NULL AUTO_INCREMENT, accountId INT, reason VARCHAR(100), coins INT, PRIMARY KEY (id), FOREIGN KEY (accountId) REFERENCES accounts(id));";
/*  26 */   private static String CREATE_GEM_TRANSACTION_TABLE = "CREATE TABLE IF NOT EXISTS accountGemTransactions (id INT NOT NULL AUTO_INCREMENT, accountId INT, reason VARCHAR(100), gems INT, PRIMARY KEY (id), FOREIGN KEY (accountId) REFERENCES accounts(id));";
/*  27 */   private static String INSERT_COIN_TRANSACTION = "INSERT INTO accountCoinTransactions(accountId, reason, coins) VALUES(?, ?, ?);";
/*  28 */   private static String UPDATE_ACCOUNT_COINS = "UPDATE accounts SET coins = coins + ? WHERE id = ?;";
/*  29 */   private static String UPDATE_ACCOUNT_GOLD = "UPDATE accounts SET gold = gold + ? WHERE id = ?;";
/*  30 */   private static String UPDATE_NULL_ACCOUNT_GEMS_AND_COINS_ = "UPDATE accounts SET gems = ?, coins = ? WHERE id = ? AND gems IS NULL AND coins IS NULL;";
/*     */   
/*     */   private String _webAddress;
/*     */   
/*     */   public DonationRepository(JavaPlugin plugin, String webAddress)
/*     */   {
/*  36 */     super(plugin, DBPool.ACCOUNT);
/*     */     
/*  38 */     this._webAddress = webAddress;
/*     */   }
/*     */   
/*     */   public void PurchaseKnownSalesPackage(final Callback<TransactionResponse> callback, String name, String uuid, int cost, int salesPackageId)
/*     */   {
/*  43 */     final PurchaseToken token = new PurchaseToken();
/*  44 */     token.AccountName = name;
/*  45 */     token.UsingCredits = false;
/*  46 */     token.SalesPackageId = salesPackageId;
/*     */     
/*  48 */     final Callback<TransactionResponse> extraCallback = new Callback()
/*     */     {
/*     */       public void run(final TransactionResponse response)
/*     */       {
/*  52 */         Bukkit.getServer().getScheduler().runTask(DonationRepository.this.Plugin, new Runnable()
/*     */         {
/*     */ 
/*     */           public void run()
/*     */           {
/*  57 */             this.val$callback.run(response);
/*     */           }
/*     */           
/*     */         });
/*     */       }
/*  62 */     };
/*  63 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  67 */         new JsonWebCall(DonationRepository.this._webAddress + "PlayerAccount/PurchaseKnownSalesPackage.php").Execute(TransactionResponse.class, extraCallback, token);
/*     */       }
/*  69 */     }), "Error purchasing known sales package in DonationRepository : ");
/*     */   }
/*     */   
/*     */   public void PurchaseUnknownSalesPackage(final Callback<TransactionResponse> callback, String name, final int accountId, String packageName, final boolean coinPurchase, final int cost)
/*     */   {
/*  74 */     final UnknownPurchaseToken token = new UnknownPurchaseToken();
/*  75 */     token.AccountName = name;
/*  76 */     token.SalesPackageName = packageName;
/*  77 */     token.CoinPurchase = coinPurchase;
/*  78 */     token.Cost = cost;
/*  79 */     token.Premium = false;
/*     */     
/*  81 */     final Callback<TransactionResponse> extraCallback = new Callback()
/*     */     {
/*     */       public void run(final TransactionResponse response)
/*     */       {
/*  85 */         if (response == TransactionResponse.Success)
/*     */         {
/*  87 */           if (coinPurchase)
/*     */           {
/*  89 */             DonationRepository.this.executeUpdate(DonationRepository.UPDATE_ACCOUNT_COINS, new Column[] { new ColumnInt("coins", -cost), new ColumnInt("id", accountId) });
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*  94 */         Bukkit.getServer().getScheduler().runTask(DonationRepository.this.Plugin, new Runnable()
/*     */         {
/*     */ 
/*     */           public void run()
/*     */           {
/*  99 */             this.val$callback.run(response);
/*     */           }
/*     */           
/*     */         });
/*     */       }
/* 104 */     };
/* 105 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 109 */         new JsonWebCall(DonationRepository.this._webAddress + "PlayerAccount/PurchaseUnknownSalesPackage.php").Execute(TransactionResponse.class, extraCallback, token);
/*     */       }
/* 111 */     }), "Error purchasing unknown sales package in DonationRepository : ");
/*     */   }
/*     */   
/*     */   public void gemReward(final Callback<Boolean> callback, String giver, String name, String uuid, int greenGems)
/*     */   {
/* 116 */     final GemRewardToken token = new GemRewardToken();
/* 117 */     token.Source = giver;
/* 118 */     token.Name = name;
/* 119 */     token.Amount = greenGems;
/*     */     
/* 121 */     final Callback<Boolean> extraCallback = new Callback()
/*     */     {
/*     */       public void run(final Boolean response)
/*     */       {
/* 125 */         Bukkit.getServer().getScheduler().runTask(DonationRepository.this.Plugin, new Runnable()
/*     */         {
/*     */ 
/*     */           public void run()
/*     */           {
/* 130 */             this.val$callback.run(response);
/*     */           }
/*     */           
/*     */         });
/*     */       }
/* 135 */     };
/* 136 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 140 */         new JsonWebCall(DonationRepository.this._webAddress + "PlayerAccount/GemReward.php").Execute(Boolean.class, extraCallback, token);
/*     */       }
/* 142 */     }), "Error updating player gem amount in DonationRepository : ");
/*     */   }
/*     */   
/*     */   public void rewardCoins(final Callback<Boolean> callback, String giver, String name, final int accountId, final int coins)
/*     */   {
/* 147 */     final GemRewardToken token = new GemRewardToken();
/* 148 */     token.Source = giver;
/* 149 */     token.Name = name;
/* 150 */     token.Amount = coins;
/*     */     
/* 152 */     final Callback<Boolean> extraCallback = new Callback()
/*     */     {
/*     */       public void run(final Boolean response)
/*     */       {
/* 156 */         if (response.booleanValue())
/*     */         {
/* 158 */           DonationRepository.this.executeUpdate(DonationRepository.UPDATE_ACCOUNT_COINS, new Column[] { new ColumnInt("coins", coins), new ColumnInt("id", accountId) });
/*     */         }
/*     */         
/*     */ 
/* 162 */         Bukkit.getServer().getScheduler().runTask(DonationRepository.this.Plugin, new Runnable()
/*     */         {
/*     */ 
/*     */           public void run()
/*     */           {
/* 167 */             this.val$callback.run(response);
/*     */           }
/*     */           
/*     */         });
/*     */       }
/* 172 */     };
/* 173 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 177 */         new JsonWebCall(DonationRepository.this._webAddress + "PlayerAccount/CoinReward.php").Execute(Boolean.class, extraCallback, token);
/*     */       }
/* 179 */     }), "Error updating player coin amount in DonationRepository : ");
/*     */   }
/*     */   
/*     */   public void rewardGold(final Callback<Boolean> callback, String giver, String name, final int accountId, final int gold)
/*     */   {
/* 184 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 188 */         if (DonationRepository.this.executeUpdate(DonationRepository.UPDATE_ACCOUNT_GOLD, new Column[] { new ColumnInt("gold", gold), new ColumnInt("id", accountId) }) < 1)
/*     */         {
/* 190 */           callback.run(Boolean.valueOf(false));
/*     */         }
/*     */         else
/* 193 */           callback.run(Boolean.valueOf(true));
/*     */       }
/* 195 */     }), "Error updating player gold amount in DonationRepository : ");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initialize() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void update() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void updateGemsAndCoins(final int accountId, final int gems, final int coins)
/*     */   {
/* 212 */     handleDatabaseCall(new DatabaseRunnable(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 216 */         DonationRepository.this.executeUpdate(DonationRepository.UPDATE_NULL_ACCOUNT_GEMS_AND_COINS_, new Column[] { new ColumnInt("gems", gems), new ColumnInt("coins", coins), new ColumnInt("id", accountId) });
/*     */       }
/* 218 */     }), "Error updating player's null gems and coins DonationRepository : ");
/*     */   }
/*     */   
/*     */   public void applyKits(String playerName)
/*     */   {
/* 223 */     new AsyncJsonWebCall(this._webAddress + "PlayerAccount/ApplyKits.php").Execute(playerName);
/*     */   }
/*     */   
/*     */   public Donor retrieveDonorInfo(ResultSet resultSet) throws SQLException
/*     */   {
/* 228 */     Donor donor = new Donor();
/*     */     
/* 230 */     while (resultSet.next())
/*     */     {
/* 232 */       donor.addGold(resultSet.getInt(1));
/*     */     }
/*     */     
/* 235 */     return donor;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\repository\DonationRepository.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */