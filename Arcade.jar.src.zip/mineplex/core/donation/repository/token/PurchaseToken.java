package mineplex.core.donation.repository.token;

public class PurchaseToken
{
  public String AccountName;
  public boolean UsingCredits;
  public int SalesPackageId;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\repository\token\PurchaseToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */