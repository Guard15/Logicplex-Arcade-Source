package mineplex.core.donation.repository.token;

public class UnknownPurchaseToken
{
  public String AccountName;
  public String SalesPackageName;
  public int Cost;
  public boolean Premium;
  public boolean CoinPurchase;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\repository\token\UnknownPurchaseToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */