package mineplex.core.donation.repository.token;

public class CoinTransactionToken
{
  public long Date;
  public String Source;
  public int Amount;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\repository\token\CoinTransactionToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */