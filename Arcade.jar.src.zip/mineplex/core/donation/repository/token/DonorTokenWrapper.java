package mineplex.core.donation.repository.token;

public class DonorTokenWrapper
{
  public String Name;
  public DonorToken DonorToken;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\repository\token\DonorTokenWrapper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */