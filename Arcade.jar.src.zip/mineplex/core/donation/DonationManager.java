/*     */ package mineplex.core.donation;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniDbClientPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.account.event.ClientWebResponseEvent;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.Callback;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.donation.command.GemCommand;
/*     */ import mineplex.core.donation.command.GoldCommand;
/*     */ import mineplex.core.donation.command.ShardsCommand;
/*     */ import mineplex.core.donation.repository.DonationRepository;
/*     */ import mineplex.core.donation.repository.token.DonorTokenWrapper;
/*     */ import mineplex.core.server.util.TransactionResponse;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.craftbukkit.libs.com.google.gson.Gson;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class DonationManager extends MiniDbClientPlugin<Donor>
/*     */ {
/*     */   private DonationRepository _repository;
/*  33 */   private NautHashMap<Player, NautHashMap<String, Integer>> _gemQueue = new NautHashMap();
/*  34 */   private NautHashMap<Player, NautHashMap<String, Integer>> _coinQueue = new NautHashMap();
/*  35 */   private NautHashMap<Player, NautHashMap<String, Integer>> _goldQueue = new NautHashMap();
/*     */   
/*     */   public DonationManager(JavaPlugin plugin, CoreClientManager clientManager, String webAddress)
/*     */   {
/*  39 */     super("Donation", plugin, clientManager);
/*     */     
/*  41 */     this._repository = new DonationRepository(plugin, webAddress);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/*  47 */     addCommand(new GemCommand(this));
/*  48 */     addCommand(new mineplex.core.donation.command.CoinCommand(this));
/*  49 */     addCommand(new ShardsCommand(this));
/*  50 */     addCommand(new GoldCommand(this));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void OnClientWebResponse(ClientWebResponseEvent event)
/*     */   {
/*  56 */     DonorTokenWrapper token = (DonorTokenWrapper)new Gson().fromJson(event.GetResponse(), DonorTokenWrapper.class);
/*  57 */     LoadDonor(token, event.getUniqueId());
/*     */   }
/*     */   
/*     */   private void LoadDonor(DonorTokenWrapper token, UUID uuid)
/*     */   {
/*  62 */     ((Donor)Get(token.Name)).loadToken(token.DonorToken);
/*     */   }
/*     */   
/*     */ 
/*     */   public void PurchaseUnknownSalesPackage(final Callback<TransactionResponse> callback, String name, int accountId, final String packageName, final boolean coinPurchase, final int cost, boolean oneTimePurchase)
/*     */   {
/*  68 */     final Donor donor = Bukkit.getPlayerExact(name) != null ? (Donor)Get(name) : null;
/*     */     
/*  70 */     if (donor != null)
/*     */     {
/*  72 */       if ((oneTimePurchase) && (donor.OwnsUnknownPackage(packageName)))
/*     */       {
/*  74 */         if (callback != null) {
/*  75 */           callback.run(TransactionResponse.AlreadyOwns);
/*     */         }
/*  77 */         return;
/*     */       }
/*     */     }
/*     */     
/*  81 */     this._repository.PurchaseUnknownSalesPackage(new Callback()
/*     */     {
/*     */       public void run(TransactionResponse response)
/*     */       {
/*  85 */         if (response == TransactionResponse.Success)
/*     */         {
/*  87 */           if (donor != null)
/*     */           {
/*  89 */             donor.AddUnknownSalesPackagesOwned(packageName);
/*  90 */             donor.DeductCost(cost, coinPurchase ? CurrencyType.Coins : CurrencyType.Gems);
/*     */           }
/*     */         }
/*     */         
/*  94 */         if (callback != null)
/*  95 */           callback.run(response);
/*     */       }
/*  97 */     }, name, accountId, packageName, coinPurchase, cost);
/*     */   }
/*     */   
/*     */   public void PurchaseKnownSalesPackage(final Callback<TransactionResponse> callback, final String name, UUID uuid, int cost, final int salesPackageId)
/*     */   {
/* 102 */     this._repository.PurchaseKnownSalesPackage(new Callback()
/*     */     {
/*     */       public void run(TransactionResponse response)
/*     */       {
/* 106 */         if (response == TransactionResponse.Success)
/*     */         {
/* 108 */           Donor donor = (Donor)DonationManager.this.Get(name);
/*     */           
/* 110 */           if (donor != null)
/*     */           {
/* 112 */             donor.AddSalesPackagesOwned(salesPackageId);
/*     */           }
/*     */         }
/*     */         
/* 116 */         if (callback != null)
/* 117 */           callback.run(response);
/*     */       }
/* 119 */     }, name, uuid.toString(), cost, salesPackageId);
/*     */   }
/*     */   
/*     */   public void RewardGems(Callback<Boolean> callback, String caller, String name, UUID uuid, int amount)
/*     */   {
/* 124 */     RewardGems(callback, caller, name, uuid, amount, true);
/*     */   }
/*     */   
/*     */   public void RewardGems(final Callback<Boolean> callback, String caller, final String name, UUID uuid, final int amount, final boolean updateTotal)
/*     */   {
/* 129 */     this._repository.gemReward(new Callback()
/*     */     {
/*     */       public void run(Boolean success)
/*     */       {
/* 133 */         if (success.booleanValue())
/*     */         {
/* 135 */           if (updateTotal)
/*     */           {
/* 137 */             Donor donor = (Donor)DonationManager.this.Get(name);
/*     */             
/* 139 */             if (donor != null)
/*     */             {
/* 141 */               donor.AddGems(amount);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 146 */         if (callback != null)
/* 147 */           callback.run(success);
/*     */       }
/* 149 */     }, caller, name, uuid.toString(), amount);
/*     */   }
/*     */   
/*     */   public void RewardGemsLater(String caller, Player player, int amount)
/*     */   {
/* 154 */     if (!this._gemQueue.containsKey(player)) {
/* 155 */       this._gemQueue.put(player, new NautHashMap());
/*     */     }
/* 157 */     int totalAmount = amount;
/*     */     
/* 159 */     if (((NautHashMap)this._gemQueue.get(player)).containsKey(caller)) {
/* 160 */       totalAmount += ((Integer)((NautHashMap)this._gemQueue.get(player)).get(caller)).intValue();
/*     */     }
/* 162 */     ((NautHashMap)this._gemQueue.get(player)).put(caller, Integer.valueOf(totalAmount));
/*     */     
/*     */ 
/* 165 */     Donor donor = (Donor)Get(player.getName());
/*     */     
/* 167 */     if (donor != null) {
/* 168 */       donor.AddGems(amount);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void UpdateGemQueue(UpdateEvent event) {
/* 174 */     if (event.getType() != UpdateType.SLOWER) {
/* 175 */       return;
/*     */     }
/* 177 */     for (Player player : this._gemQueue.keySet())
/*     */     {
/* 179 */       String caller = null;
/* 180 */       int total = 0;
/*     */       
/* 182 */       for (String curCaller : ((NautHashMap)this._gemQueue.get(player)).keySet())
/*     */       {
/* 184 */         caller = curCaller;
/* 185 */         total += ((Integer)((NautHashMap)this._gemQueue.get(player)).get(curCaller)).intValue();
/*     */       }
/*     */       
/* 188 */       if (caller != null)
/*     */       {
/*     */ 
/*     */ 
/* 192 */         RewardGems(null, caller, player.getName(), player.getUniqueId(), total, false);
/*     */         
/* 194 */         System.out.println("Queue Added [" + player + "] with Gems [" + total + "] for [" + caller + "]");
/*     */         
/*     */ 
/* 197 */         ((NautHashMap)this._gemQueue.get(player)).clear();
/*     */       }
/*     */     }
/*     */     
/* 201 */     this._gemQueue.clear();
/*     */   }
/*     */   
/*     */   public void RewardCoins(Callback<Boolean> callback, String caller, String name, int accountId, int amount)
/*     */   {
/* 206 */     RewardCoins(callback, caller, name, accountId, amount, true);
/*     */   }
/*     */   
/*     */   public void RewardCoins(final Callback<Boolean> callback, String caller, final String name, int accountId, final int amount, final boolean updateTotal)
/*     */   {
/* 211 */     this._repository.rewardCoins(new Callback()
/*     */     {
/*     */       public void run(Boolean success)
/*     */       {
/* 215 */         if (success.booleanValue())
/*     */         {
/* 217 */           if (updateTotal)
/*     */           {
/* 219 */             Donor donor = (Donor)DonationManager.this.Get(name);
/*     */             
/* 221 */             if (donor != null)
/*     */             {
/* 223 */               donor.addCoins(amount);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 228 */         if (callback != null)
/* 229 */           callback.run(success);
/*     */       }
/* 231 */     }, caller, name, accountId, amount);
/*     */   }
/*     */   
/*     */   public void RewardCoinsLater(String caller, Player player, int amount)
/*     */   {
/* 236 */     if (!this._coinQueue.containsKey(player)) {
/* 237 */       this._coinQueue.put(player, new NautHashMap());
/*     */     }
/* 239 */     int totalAmount = amount;
/*     */     
/* 241 */     if (((NautHashMap)this._coinQueue.get(player)).containsKey(caller)) {
/* 242 */       totalAmount += ((Integer)((NautHashMap)this._coinQueue.get(player)).get(caller)).intValue();
/*     */     }
/* 244 */     ((NautHashMap)this._coinQueue.get(player)).put(caller, Integer.valueOf(totalAmount));
/*     */     
/*     */ 
/* 247 */     Donor donor = (Donor)Get(player.getName());
/*     */     
/* 249 */     if (donor != null) {
/* 250 */       donor.addCoins(amount);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void UpdateCoinQueue(UpdateEvent event) {
/* 256 */     if (event.getType() != UpdateType.SLOWER) {
/* 257 */       return;
/*     */     }
/* 259 */     for (final Player player : this._coinQueue.keySet())
/*     */     {
/* 261 */       String tempCaller = null;
/* 262 */       int tempTotal = 0;
/*     */       
/* 264 */       for (String curCaller : ((NautHashMap)this._coinQueue.get(player)).keySet())
/*     */       {
/* 266 */         tempCaller = curCaller;
/* 267 */         tempTotal += ((Integer)((NautHashMap)this._coinQueue.get(player)).get(curCaller)).intValue();
/*     */       }
/*     */       
/* 270 */       final int total = tempTotal;
/* 271 */       final String caller = tempCaller;
/*     */       
/* 273 */       if (caller != null)
/*     */       {
/*     */ 
/* 276 */         if ((player.isOnline()) && (player.isValid())) {
/* 277 */           RewardCoins(null, caller, player.getName(), this.ClientManager.Get(player).getAccountId(), total, false);
/*     */         }
/*     */         else {
/* 280 */           Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 284 */               DonationManager.this.RewardCoins(null, caller, player.getName(), DonationManager.this.ClientManager.getCachedClientAccountId(player.getUniqueId()), total, false);
/*     */             }
/*     */           });
/*     */         }
/*     */         
/* 289 */         System.out.println("Queue Added [" + player + "] with Coins [" + total + "] for [" + caller + "]");
/*     */         
/*     */ 
/* 292 */         ((NautHashMap)this._coinQueue.get(player)).clear();
/*     */       }
/*     */     }
/*     */     
/* 296 */     this._coinQueue.clear();
/*     */   }
/*     */   
/*     */   public void RewardGold(Callback<Boolean> callback, String caller, String name, int accountId, int amount)
/*     */   {
/* 301 */     RewardGold(callback, caller, name, accountId, amount, true);
/*     */   }
/*     */   
/*     */   public void RewardGold(final Callback<Boolean> callback, String caller, final String name, int accountId, final int amount, final boolean updateTotal)
/*     */   {
/* 306 */     this._repository.rewardGold(new Callback()
/*     */     {
/*     */       public void run(Boolean success)
/*     */       {
/* 310 */         if (success.booleanValue())
/*     */         {
/* 312 */           if (updateTotal)
/*     */           {
/* 314 */             Donor donor = (Donor)DonationManager.this.Get(name);
/*     */             
/* 316 */             if (donor != null)
/*     */             {
/* 318 */               donor.addGold(amount);
/*     */             }
/*     */             
/*     */           }
/*     */         }
/*     */         else {
/* 324 */           System.out.println("REWARD GOLD FAILED...");
/*     */         }
/*     */         
/* 327 */         if (callback != null)
/* 328 */           callback.run(Boolean.valueOf(true));
/*     */       }
/* 330 */     }, caller, name, accountId, amount);
/*     */   }
/*     */   
/*     */   public void RewardGoldLater(String caller, Player player, int amount)
/*     */   {
/* 335 */     if (!this._goldQueue.containsKey(player)) {
/* 336 */       this._goldQueue.put(player, new NautHashMap());
/*     */     }
/* 338 */     int totalAmount = amount;
/*     */     
/* 340 */     if (((NautHashMap)this._goldQueue.get(player)).containsKey(caller)) {
/* 341 */       totalAmount += ((Integer)((NautHashMap)this._goldQueue.get(player)).get(caller)).intValue();
/*     */     }
/* 343 */     ((NautHashMap)this._goldQueue.get(player)).put(caller, Integer.valueOf(totalAmount));
/*     */     
/*     */ 
/* 346 */     Donor donor = (Donor)Get(player.getName());
/*     */     
/* 348 */     if (donor != null) {
/* 349 */       donor.addGold(amount);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void UpdateGoldQueue(UpdateEvent event) {
/* 355 */     if (event.getType() != UpdateType.SLOWER) {
/* 356 */       return;
/*     */     }
/* 358 */     for (Player player : this._goldQueue.keySet())
/*     */     {
/* 360 */       String caller = null;
/* 361 */       int total = 0;
/*     */       
/* 363 */       for (String curCaller : ((NautHashMap)this._goldQueue.get(player)).keySet())
/*     */       {
/* 365 */         caller = curCaller;
/* 366 */         total += ((Integer)((NautHashMap)this._goldQueue.get(player)).get(curCaller)).intValue();
/*     */       }
/*     */       
/* 369 */       if (caller != null)
/*     */       {
/*     */ 
/*     */ 
/* 373 */         RewardGold(null, caller, player.getName(), this.ClientManager.Get(player).getAccountId(), total, false);
/*     */         
/* 375 */         System.out.println("Queue Added [" + player + "] with Gold [" + total + "] for [" + caller + "]");
/*     */         
/*     */ 
/* 378 */         ((NautHashMap)this._goldQueue.get(player)).clear();
/*     */       }
/*     */     }
/*     */     
/* 382 */     this._goldQueue.clear();
/*     */   }
/*     */   
/*     */   public void applyKits(String playerName)
/*     */   {
/* 387 */     this._repository.applyKits(playerName);
/*     */   }
/*     */   
/*     */   public void processLoginResultSet(String playerName, int accountId, ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 393 */     ((Donor)Get(playerName)).addGold(this._repository.retrieveDonorInfo(resultSet).getGold());
/*     */   }
/*     */   
/*     */ 
/*     */   protected Donor AddPlayer(String player)
/*     */   {
/* 399 */     return new Donor();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQuery(int accountId, String uuid, String name)
/*     */   {
/* 405 */     return "SELECT gold FROM accounts WHERE id = '" + accountId + "';";
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\DonationManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */