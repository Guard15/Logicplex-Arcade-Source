/*     */ package mineplex.core.donation;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.donation.repository.token.CoinTransactionToken;
/*     */ import mineplex.core.donation.repository.token.DonorToken;
/*     */ import mineplex.core.donation.repository.token.TransactionToken;
/*     */ 
/*     */ 
/*     */ public class Donor
/*     */ {
/*     */   private int _gems;
/*     */   private int _coins;
/*     */   private int _gold;
/*     */   private boolean _donated;
/*  17 */   private List<Integer> _salesPackagesOwned = new ArrayList();
/*  18 */   private List<String> _unknownSalesPackagesOwned = new ArrayList();
/*  19 */   private List<TransactionToken> _transactions = new ArrayList();
/*  20 */   private List<CoinTransactionToken> _coinTransactions = new ArrayList();
/*     */   
/*  22 */   private boolean _update = true;
/*     */   
/*     */ 
/*     */ 
/*     */   public void loadToken(DonorToken token)
/*     */   {
/*  28 */     this._gems = token.Gems;
/*  29 */     this._coins = token.Coins;
/*  30 */     this._donated = token.Donated;
/*     */     
/*  32 */     this._salesPackagesOwned = token.SalesPackages;
/*  33 */     this._unknownSalesPackagesOwned = token.UnknownSalesPackages;
/*  34 */     this._transactions = token.Transactions;
/*  35 */     this._coinTransactions = token.CoinRewards;
/*     */   }
/*     */   
/*     */   public int GetGems()
/*     */   {
/*  40 */     return this._gems;
/*     */   }
/*     */   
/*     */   public List<Integer> GetSalesPackagesOwned()
/*     */   {
/*  45 */     return this._salesPackagesOwned;
/*     */   }
/*     */   
/*     */   public List<String> GetUnknownSalesPackagesOwned()
/*     */   {
/*  50 */     return this._unknownSalesPackagesOwned;
/*     */   }
/*     */   
/*     */   public boolean Owns(Integer salesPackageId)
/*     */   {
/*  55 */     return (salesPackageId.intValue() == -1) || (this._salesPackagesOwned.contains(salesPackageId));
/*     */   }
/*     */   
/*     */   public void AddSalesPackagesOwned(int salesPackageId)
/*     */   {
/*  60 */     this._salesPackagesOwned.add(Integer.valueOf(salesPackageId));
/*     */   }
/*     */   
/*     */   public boolean HasDonated()
/*     */   {
/*  65 */     return this._donated;
/*     */   }
/*     */   
/*     */   public void DeductCost(int cost, CurrencyType currencyType)
/*     */   {
/*  70 */     switch (currencyType)
/*     */     {
/*     */     case Tokens: 
/*  73 */       this._gems -= cost;
/*  74 */       this._update = true;
/*  75 */       break;
/*     */     case Gems: 
/*  77 */       this._coins -= cost;
/*  78 */       this._update = true;
/*  79 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public int GetBalance(CurrencyType currencyType)
/*     */   {
/*  87 */     switch (currencyType)
/*     */     {
/*     */     case Tokens: 
/*  90 */       return this._gems;
/*     */     case Gems: 
/*  92 */       return this._coins;
/*     */     case Coins: 
/*  94 */       return 0;
/*     */     }
/*  96 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void AddGems(int gems)
/*     */   {
/* 102 */     this._gems += gems;
/*     */   }
/*     */   
/*     */   public boolean OwnsUnknownPackage(String packageName)
/*     */   {
/* 107 */     return this._unknownSalesPackagesOwned.contains(packageName);
/*     */   }
/*     */   
/*     */   public boolean Updated()
/*     */   {
/* 112 */     return this._update;
/*     */   }
/*     */   
/*     */   public void AddUnknownSalesPackagesOwned(String packageName)
/*     */   {
/* 117 */     this._unknownSalesPackagesOwned.add(packageName);
/*     */   }
/*     */   
/*     */   public List<TransactionToken> getTransactions()
/*     */   {
/* 122 */     return this._transactions;
/*     */   }
/*     */   
/*     */   public boolean OwnsUltraPackage()
/*     */   {
/* 127 */     for (String packageName : this._unknownSalesPackagesOwned)
/*     */     {
/* 129 */       if (packageName.contains("ULTRA")) {
/* 130 */         return true;
/*     */       }
/*     */     }
/* 133 */     return false;
/*     */   }
/*     */   
/*     */   public int getCoins()
/*     */   {
/* 138 */     return this._coins;
/*     */   }
/*     */   
/*     */   public void addCoins(int amount)
/*     */   {
/* 143 */     this._coins += amount;
/*     */   }
/*     */   
/*     */   public void addGold(int amount)
/*     */   {
/* 148 */     this._gold += amount;
/*     */   }
/*     */   
/*     */   public List<CoinTransactionToken> getCoinTransactions()
/*     */   {
/* 153 */     return this._coinTransactions;
/*     */   }
/*     */   
/*     */   public int getGold()
/*     */   {
/* 158 */     return this._gold;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\Donor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */