/*    */ package mineplex.core.donation.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.donation.Donor;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class GoldCommand extends CommandBase<DonationManager>
/*    */ {
/*    */   public GoldCommand(DonationManager plugin)
/*    */   {
/* 17 */     super(plugin, mineplex.core.common.Rank.ADMIN, new String[] { "givegold" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 23 */     if ((args == null) || (args.length == 0))
/*    */     {
/* 25 */       UtilPlayer.message(caller, F.main("Gold", "Your Gold: " + F.elem(new StringBuilder().append(((Donor)((DonationManager)this.Plugin).Get(caller)).getGold()).toString())));
/*    */     }
/* 27 */     else if (args.length < 2)
/*    */     {
/* 29 */       UtilPlayer.message(caller, F.main("Gold", "Missing Args: " + F.elem("/gold <player> <amount>")));
/* 30 */       return;
/*    */     }
/*    */     
/* 33 */     final String targetName = args[0];
/* 34 */     final String goldString = args[1];
/* 35 */     Player target = UtilPlayer.searchExact(targetName);
/*    */     
/* 37 */     if (target == null)
/*    */     {
/* 39 */       ((DonationManager)this.Plugin).getClientManager().loadClientByName(targetName, new Runnable()
/*    */       {
/*    */         public void run()
/*    */         {
/* 43 */           CoreClient client = ((DonationManager)GoldCommand.this.Plugin).getClientManager().Get(targetName);
/*    */           
/* 45 */           if (client != null) {
/* 46 */             GoldCommand.this.rewardGold(caller, null, targetName, client.getAccountId(), goldString);
/*    */           }
/*    */           else {
/* 49 */             UtilPlayer.message(caller, F.main("Gold", "Could not find player " + F.name(targetName)));
/*    */           }
/*    */           
/*    */         }
/*    */         
/*    */       });
/*    */     } else {
/* 56 */       rewardGold(caller, target, target.getName(), ((DonationManager)this.Plugin).getClientManager().Get(target).getAccountId(), goldString);
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardGold(Player caller, Player target, String targetName, int accountId, String goldString)
/*    */   {
/*    */     try
/*    */     {
/* 64 */       int gold = Integer.parseInt(goldString);
/* 65 */       rewardGold(caller, target, targetName, accountId, gold);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 69 */       UtilPlayer.message(caller, F.main("Gold", "Invalid Gold Amount"));
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardGold(final Player caller, final Player target, final String targetName, int accountId, final int gold)
/*    */   {
/* 75 */     ((DonationManager)this.Plugin).RewardGold(new Callback()
/*    */     {
/*    */       public void run(Boolean completed)
/*    */       {
/* 79 */         UtilPlayer.message(caller, F.main("Gold", "You gave " + F.elem(new StringBuilder(String.valueOf(gold)).append(" Gold").toString()) + " to " + F.name(targetName) + "."));
/*    */         
/* 81 */         if (target != null)
/*    */         {
/* 83 */           UtilPlayer.message(target, F.main("Gold", F.name(caller.getName()) + " gave you " + F.elem(new StringBuilder(String.valueOf(gold)).append(" Gold").toString()) + "."));
/*    */         }
/*    */       }
/* 86 */     }, caller.getName(), targetName, accountId, gold);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\command\GoldCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */