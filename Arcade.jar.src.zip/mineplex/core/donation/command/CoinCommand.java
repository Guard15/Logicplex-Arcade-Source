/*    */ package mineplex.core.donation.command;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class CoinCommand extends CommandBase<DonationManager>
/*    */ {
/*    */   public CoinCommand(DonationManager plugin)
/*    */   {
/* 17 */     super(plugin, Rank.ADMIN, new String[] { "coin" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 23 */     if (args.length < 2)
/*    */     {
/* 25 */       UtilPlayer.message(caller, F.main("Shards", "Missing Args: " + F.elem("/coin <player> <amount>")));
/* 26 */       return;
/*    */     }
/*    */     
/* 29 */     final String targetName = args[0];
/* 30 */     final String coinsString = args[1];
/* 31 */     Player target = UtilPlayer.searchExact(targetName);
/*    */     
/* 33 */     if (target == null)
/*    */     {
/* 35 */       ((DonationManager)this.Plugin).getClientManager().loadClientByName(targetName, new Runnable()
/*    */       {
/*    */         public void run()
/*    */         {
/* 39 */           CoreClient client = ((DonationManager)CoinCommand.this.Plugin).getClientManager().Get(targetName);
/*    */           
/* 41 */           if (client != null) {
/* 42 */             CoinCommand.this.rewardCoins(caller, null, targetName, client.getAccountId(), coinsString);
/*    */           }
/*    */           else {
/* 45 */             UtilPlayer.message(caller, F.main("Shards", "Could not find player " + F.name(targetName)));
/*    */           }
/*    */           
/*    */         }
/*    */         
/*    */       });
/*    */     } else {
/* 52 */       rewardCoins(caller, target, target.getName(), ((DonationManager)this.Plugin).getClientManager().Get(target).getAccountId(), coinsString);
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardCoins(Player caller, Player target, String targetName, int accountId, String coinsString)
/*    */   {
/*    */     try
/*    */     {
/* 60 */       int coins = Integer.parseInt(coinsString);
/* 61 */       rewardCoins(caller, target, targetName, accountId, coins);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 65 */       UtilPlayer.message(caller, F.main("Shards", "Invalid Shards Amount"));
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardCoins(final Player caller, final Player target, final String targetName, int accountId, final int coins)
/*    */   {
/* 71 */     ((DonationManager)this.Plugin).RewardCoins(new Callback()
/*    */     {
/*    */       public void run(Boolean completed)
/*    */       {
/* 75 */         if (completed.booleanValue())
/*    */         {
/* 77 */           UtilPlayer.message(caller, F.main("Shards", "You gave " + F.elem(new StringBuilder(String.valueOf(coins)).append(" Shards").toString()) + " to " + F.name(targetName) + "."));
/*    */           
/* 79 */           if (target != null)
/*    */           {
/* 81 */             UtilPlayer.message(target, F.main("Shards", F.name(caller.getName()) + " gave you " + F.elem(new StringBuilder(String.valueOf(coins)).append(" Shards").toString()) + "."));
/*    */           }
/*    */         }
/*    */         else
/*    */         {
/* 86 */           UtilPlayer.message(caller, F.main("Shards", "There was an error giving " + F.elem(new StringBuilder(String.valueOf(coins)).append("Shards").toString()) + " to " + F.name(targetName) + "."));
/*    */         }
/*    */       }
/* 89 */     }, caller.getName(), targetName, accountId, coins);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\command\CoinCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */