/*    */ package mineplex.core.donation.command;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UUIDFetcher;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class GemCommand
/*    */   extends CommandBase<DonationManager>
/*    */ {
/*    */   public GemCommand(DonationManager plugin)
/*    */   {
/* 19 */     super(plugin, Rank.ADMIN, new String[] { "gem" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 25 */     if (args.length < 2)
/*    */     {
/* 27 */       UtilPlayer.message(caller, F.main("gem", "Missing Args: " + F.elem("/gem <player> <amount>")));
/* 28 */       return;
/*    */     }
/*    */     
/* 31 */     String targetName = args[0];
/* 32 */     String gemsString = args[1];
/* 33 */     Player target = UtilPlayer.searchExact(targetName);
/*    */     
/* 35 */     if (target == null)
/*    */     {
/* 37 */       UUID uuid = UUIDFetcher.getUUIDOf(targetName);
/* 38 */       if (uuid != null)
/*    */       {
/* 40 */         rewardGems(caller, null, targetName, uuid, gemsString);
/*    */       }
/*    */       else
/*    */       {
/* 44 */         UtilPlayer.message(caller, F.main("Gem", "Could not find player " + F.name(targetName)));
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 49 */       rewardGems(caller, target, target.getName(), target.getUniqueId(), gemsString);
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardGems(Player caller, Player target, String targetName, UUID uuid, String gemsString)
/*    */   {
/*    */     try
/*    */     {
/* 57 */       int gems = Integer.parseInt(gemsString);
/* 58 */       rewardGems(caller, target, targetName, uuid, gems);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 62 */       UtilPlayer.message(caller, F.main("gem", "Invalid gems Amount"));
/*    */     }
/*    */   }
/*    */   
/*    */   private void rewardGems(final Player caller, final Player target, final String targetName, UUID uuid, final int gems)
/*    */   {
/* 68 */     ((DonationManager)this.Plugin).RewardGems(new Callback()
/*    */     {
/*    */       public void run(Boolean completed)
/*    */       {
/* 72 */         if (completed.booleanValue())
/*    */         {
/* 74 */           UtilPlayer.message(caller, F.main("gem", "You gave " + F.elem(new StringBuilder(String.valueOf(gems)).append(" gems").toString()) + " to " + F.name(targetName) + "."));
/*    */           
/* 76 */           if (target != null)
/*    */           {
/* 78 */             UtilPlayer.message(target, F.main("gem", F.name(caller.getName()) + " gave you " + F.elem(new StringBuilder(String.valueOf(gems)).append(" gems").toString()) + "."));
/*    */           }
/*    */         }
/*    */         else
/*    */         {
/* 83 */           UtilPlayer.message(caller, F.main("gem", "There was an error giving " + F.elem(new StringBuilder(String.valueOf(gems)).append(" gems").toString()) + " to " + F.name(targetName) + "."));
/*    */         }
/*    */       }
/* 86 */     }, caller.getName(), targetName, uuid, gems);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\donation\command\GemCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */