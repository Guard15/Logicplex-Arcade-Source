/*     */ package mineplex.core.gadget;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.blockrestore.BlockRestore;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.event.GadgetCollideEntityEvent;
/*     */ import mineplex.core.gadget.gadgets.ItemEtherealPearl;
/*     */ import mineplex.core.gadget.gadgets.ItemMelonLauncher;
/*     */ import mineplex.core.gadget.gadgets.OutfitRaveSuit;
/*     */ import mineplex.core.gadget.gadgets.OutfitSpaceSuit;
/*     */ import mineplex.core.gadget.types.Gadget;
/*     */ import mineplex.core.gadget.types.GadgetType;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.gadget.types.MusicGadget;
/*     */ import mineplex.core.gadget.types.OutfitGadget;
/*     */ import mineplex.core.gadget.types.OutfitGadget.ArmorSlot;
/*     */ import mineplex.core.gadget.types.ParticleGadget;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.mount.MountManager;
/*     */ import mineplex.core.pet.PetManager;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.projectile.ProjectileManager;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerToggleSneakEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class GadgetManager extends MiniPlugin
/*     */ {
/*     */   private CoreClientManager _clientManager;
/*     */   private DonationManager _donationManager;
/*     */   private InventoryManager _inventoryManager;
/*     */   private PetManager _petManager;
/*     */   private PreferencesManager _preferencesManager;
/*     */   private DisguiseManager _disguiseManager;
/*     */   private BlockRestore _blockRestore;
/*     */   private ProjectileManager _projectileManager;
/*     */   private NautHashMap<GadgetType, List<Gadget>> _gadgets;
/*  58 */   private NautHashMap<Player, Long> _lastMove = new NautHashMap();
/*  59 */   private NautHashMap<Player, NautHashMap<GadgetType, Gadget>> _playerActiveGadgetMap = new NautHashMap();
/*     */   
/*  61 */   private boolean _hideParticles = false;
/*  62 */   private int _activeItemSlot = 3;
/*     */   
/*     */ 
/*     */ 
/*     */   public GadgetManager(JavaPlugin plugin, CoreClientManager clientManager, DonationManager donationManager, InventoryManager inventoryManager, MountManager mountManager, PetManager petManager, PreferencesManager preferencesManager, DisguiseManager disguiseManager, BlockRestore blockRestore, ProjectileManager projectileManager)
/*     */   {
/*  68 */     super("Gadget Manager", plugin);
/*     */     
/*  70 */     this._clientManager = clientManager;
/*  71 */     this._donationManager = donationManager;
/*  72 */     this._inventoryManager = inventoryManager;
/*  73 */     this._petManager = petManager;
/*  74 */     this._preferencesManager = preferencesManager;
/*  75 */     this._disguiseManager = disguiseManager;
/*  76 */     this._blockRestore = blockRestore;
/*  77 */     this._projectileManager = projectileManager;
/*     */     
/*  79 */     CreateGadgets();
/*     */   }
/*     */   
/*     */   private void CreateGadgets()
/*     */   {
/*  84 */     this._gadgets = new NautHashMap();
/*     */     
/*     */ 
/*  87 */     addGadget(new ItemEtherealPearl(this));
/*  88 */     addGadget(new mineplex.core.gadget.gadgets.ItemFirework(this));
/*  89 */     addGadget(new mineplex.core.gadget.gadgets.ItemTNT(this));
/*  90 */     addGadget(new ItemMelonLauncher(this));
/*  91 */     addGadget(new mineplex.core.gadget.gadgets.ItemFleshHook(this));
/*  92 */     addGadget(new mineplex.core.gadget.gadgets.ItemPaintballGun(this));
/*  93 */     addGadget(new mineplex.core.gadget.gadgets.ItemBatGun(this));
/*  94 */     addGadget(new mineplex.core.gadget.gadgets.ItemCoinBomb(this));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */     addGadget(new OutfitRaveSuit(this, "Rave Hat", -2, OutfitGadget.ArmorSlot.Helmet, Material.LEATHER_HELMET, (byte)0));
/* 101 */     addGadget(new OutfitRaveSuit(this, "Rave Shirt", -2, OutfitGadget.ArmorSlot.Chest, Material.LEATHER_CHESTPLATE, (byte)0));
/* 102 */     addGadget(new OutfitRaveSuit(this, "Rave Pants", -2, OutfitGadget.ArmorSlot.Legs, Material.LEATHER_LEGGINGS, (byte)0));
/* 103 */     addGadget(new OutfitRaveSuit(this, "Rave Boots", -2, OutfitGadget.ArmorSlot.Boots, Material.LEATHER_BOOTS, (byte)0));
/*     */     
/* 105 */     addGadget(new OutfitSpaceSuit(this, "Space Helmet", -2, OutfitGadget.ArmorSlot.Helmet, Material.GLASS, (byte)0));
/* 106 */     addGadget(new OutfitSpaceSuit(this, "Space Jacket", -2, OutfitGadget.ArmorSlot.Chest, Material.GOLD_CHESTPLATE, (byte)0));
/* 107 */     addGadget(new OutfitSpaceSuit(this, "Space Pants", -2, OutfitGadget.ArmorSlot.Legs, Material.GOLD_LEGGINGS, (byte)0));
/* 108 */     addGadget(new OutfitSpaceSuit(this, "Space Boots", -2, OutfitGadget.ArmorSlot.Boots, Material.GOLD_BOOTS, (byte)0));
/*     */     
/*     */ 
/* 111 */     addGadget(new mineplex.core.gadget.gadgets.MorphVillager(this));
/* 112 */     addGadget(new mineplex.core.gadget.gadgets.MorphCow(this));
/* 113 */     addGadget(new mineplex.core.gadget.gadgets.MorphChicken(this));
/* 114 */     addGadget(new mineplex.core.gadget.gadgets.MorphBlock(this));
/* 115 */     addGadget(new mineplex.core.gadget.gadgets.MorphEnderman(this));
/* 116 */     addGadget(new mineplex.core.gadget.gadgets.MorphBat(this));
/*     */     
/* 118 */     addGadget(new mineplex.core.gadget.gadgets.MorphPumpkinKing(this));
/* 119 */     addGadget(new mineplex.core.gadget.gadgets.MorphPig(this));
/* 120 */     addGadget(new mineplex.core.gadget.gadgets.MorphCreeper(this));
/* 121 */     addGadget(new mineplex.core.gadget.gadgets.MorphBlaze(this));
/*     */     
/* 123 */     addGadget(new mineplex.core.gadget.gadgets.MorphWither(this));
/* 124 */     addGadget(new mineplex.core.gadget.gadgets.MorphBunny(this));
/*     */     
/*     */ 
/* 127 */     addGadget(new mineplex.core.gadget.gadgets.ParticleFoot(this));
/* 128 */     addGadget(new mineplex.core.gadget.gadgets.ParticleEnchant(this));
/* 129 */     addGadget(new mineplex.core.gadget.gadgets.ParticleFireRings(this));
/* 130 */     addGadget(new mineplex.core.gadget.gadgets.ParticleRain(this));
/* 131 */     addGadget(new mineplex.core.gadget.gadgets.ParticleHelix(this));
/* 132 */     addGadget(new mineplex.core.gadget.gadgets.ParticleGreen(this));
/* 133 */     addGadget(new mineplex.core.gadget.gadgets.ParticleHeart(this));
/* 134 */     addGadget(new mineplex.core.gadget.gadgets.ParticleFairy(this));
/* 135 */     addGadget(new mineplex.core.gadget.gadgets.ParticleLegend(this));
/* 136 */     addGadget(new mineplex.core.gadget.gadgets.ParticleBlizzard(this));
/*     */     
/*     */ 
/* 139 */     addGadget(new MusicGadget(this, "13 Disc", new String[] { "" }, -2, 2256, 178000L));
/* 140 */     addGadget(new MusicGadget(this, "Cat Disc", new String[] { "" }, -2, 2257, 185000L));
/* 141 */     addGadget(new MusicGadget(this, "Blocks Disc", new String[] { "" }, -2, 2258, 345000L));
/* 142 */     addGadget(new MusicGadget(this, "Chirp Disc", new String[] { "" }, -2, 2259, 185000L));
/* 143 */     addGadget(new MusicGadget(this, "Far Disc", new String[] { "" }, -2, 2260, 174000L));
/* 144 */     addGadget(new MusicGadget(this, "Mall Disc", new String[] { "" }, -2, 2261, 197000L));
/* 145 */     addGadget(new MusicGadget(this, "Mellohi Disc", new String[] { "" }, -2, 2262, 96000L));
/* 146 */     addGadget(new MusicGadget(this, "Stal Disc", new String[] { "" }, -2, 2263, 150000L));
/* 147 */     addGadget(new MusicGadget(this, "Strad Disc", new String[] { "" }, -2, 2264, 188000L));
/* 148 */     addGadget(new MusicGadget(this, "Ward Disc", new String[] { "" }, -2, 2265, 251000L));
/*     */     
/* 150 */     addGadget(new MusicGadget(this, "Wait Disc", new String[] { "" }, -2, 2267, 238000L));
/*     */   }
/*     */   
/*     */   private void addGadget(Gadget gadget)
/*     */   {
/* 155 */     if (!this._gadgets.containsKey(gadget.getGadgetType())) {
/* 156 */       this._gadgets.put(gadget.getGadgetType(), new ArrayList());
/*     */     }
/* 158 */     ((List)this._gadgets.get(gadget.getGadgetType())).add(gadget);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent event)
/*     */   {
/* 164 */     if (this._clientManager.Get(event.getPlayer()).GetRank().Has(Rank.MODERATOR)) { Iterator localIterator2;
/*     */       label149:
/* 166 */       for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */           
/*     */ 
/*     */ 
/* 170 */           localIterator2.hasNext())
/*     */       {
/* 166 */         GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */         
/* 168 */         if ((gadgetType != GadgetType.Particle) || (!this._clientManager.Get(event.getPlayer()).GetRank().Has(Rank.ADMIN)))
/*     */           break label149;
/* 170 */         localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */         
/* 172 */         ((Donor)this._donationManager.Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(gadget.GetName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Gadget> getGadgets(GadgetType gadgetType)
/*     */   {
/* 181 */     return (List)this._gadgets.get(gadgetType);
/*     */   }
/*     */   
/*     */   public void RemoveOutfit(Player player, OutfitGadget.ArmorSlot slot)
/*     */   {
/*     */     Iterator localIterator2;
/* 187 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 189 */         localIterator2.hasNext())
/*     */     {
/* 187 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 189 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 191 */       if ((gadget instanceof OutfitGadget))
/*     */       {
/* 193 */         OutfitGadget armor = (OutfitGadget)gadget;
/*     */         
/* 195 */         if (armor.GetSlot() == slot)
/*     */         {
/* 197 */           armor.RemoveArmor(player);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void RemoveItem(Player player)
/*     */   {
/*     */     Iterator localIterator2;
/* 206 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 208 */         localIterator2.hasNext())
/*     */     {
/* 206 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 208 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 210 */       if ((gadget instanceof ItemGadget))
/*     */       {
/* 212 */         ItemGadget item = (ItemGadget)gadget;
/*     */         
/* 214 */         item.RemoveItem(player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void RemoveParticle(Player player)
/*     */   {
/*     */     Iterator localIterator2;
/* 222 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 224 */         localIterator2.hasNext())
/*     */     {
/* 222 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 224 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 226 */       if ((gadget instanceof ParticleGadget))
/*     */       {
/* 228 */         ParticleGadget part = (ParticleGadget)gadget;
/*     */         
/* 230 */         part.Disable(player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void RemoveMorph(Player player)
/*     */   {
/*     */     Iterator localIterator2;
/* 238 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 240 */         localIterator2.hasNext())
/*     */     {
/* 238 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 240 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 242 */       if ((gadget instanceof MorphGadget))
/*     */       {
/* 244 */         MorphGadget part = (MorphGadget)gadget;
/*     */         
/* 246 */         part.Disable(player);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void DisableAll()
/*     */   {
/*     */     Iterator localIterator2;
/* 254 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 256 */         localIterator2.hasNext())
/*     */     {
/* 254 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 256 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 258 */       if (!(gadget instanceof ParticleGadget))
/*     */       {
/*     */         Player[] arrayOfPlayer;
/* 261 */         int j = (arrayOfPlayer = mineplex.core.common.util.UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 262 */           gadget.Disable(player);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void DisableAll(Player player) { Iterator localIterator2;
/* 269 */     for (Iterator localIterator1 = this._gadgets.keySet().iterator(); localIterator1.hasNext(); 
/*     */         
/* 271 */         localIterator2.hasNext())
/*     */     {
/* 269 */       GadgetType gadgetType = (GadgetType)localIterator1.next();
/*     */       
/* 271 */       localIterator2 = ((List)this._gadgets.get(gadgetType)).iterator(); continue;Gadget gadget = (Gadget)localIterator2.next();
/*     */       
/* 273 */       gadget.Disable(player);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public PetManager getPetManager()
/*     */   {
/* 280 */     return this._petManager;
/*     */   }
/*     */   
/*     */   public CoreClientManager getClientManager()
/*     */   {
/* 285 */     return this._clientManager;
/*     */   }
/*     */   
/*     */   public DonationManager getDonationManager()
/*     */   {
/* 290 */     return this._donationManager;
/*     */   }
/*     */   
/*     */   public PreferencesManager getPreferencesManager()
/*     */   {
/* 295 */     return this._preferencesManager;
/*     */   }
/*     */   
/*     */   public ProjectileManager getProjectileManager()
/*     */   {
/* 300 */     return this._projectileManager;
/*     */   }
/*     */   
/*     */   public DisguiseManager getDisguiseManager()
/*     */   {
/* 305 */     return this._disguiseManager;
/*     */   }
/*     */   
/*     */   public InventoryManager getInventoryManager()
/*     */   {
/* 310 */     return this._inventoryManager;
/*     */   }
/*     */   
/*     */   public boolean collideEvent(Gadget gadget, Player other)
/*     */   {
/* 315 */     GadgetCollideEntityEvent collideEvent = new GadgetCollideEntityEvent(gadget, other);
/*     */     
/* 317 */     org.bukkit.Bukkit.getServer().getPluginManager().callEvent(collideEvent);
/*     */     
/* 319 */     return collideEvent.isCancelled();
/*     */   }
/*     */   
/*     */   public BlockRestore getBlockRestore()
/*     */   {
/* 324 */     return this._blockRestore;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void setMoving(PlayerMoveEvent event)
/*     */   {
/* 330 */     if (UtilMath.offset(event.getFrom(), event.getTo()) <= 0.0D) {
/* 331 */       return;
/*     */     }
/* 333 */     this._lastMove.put(event.getPlayer(), Long.valueOf(System.currentTimeMillis()));
/*     */   }
/*     */   
/*     */   public boolean isMoving(Player player)
/*     */   {
/* 338 */     if (!this._lastMove.containsKey(player)) {
/* 339 */       return false;
/*     */     }
/* 341 */     return !mineplex.core.common.util.UtilTime.elapsed(((Long)this._lastMove.get(player)).longValue(), 500L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void quit(PlayerQuitEvent event)
/*     */   {
/* 347 */     DisableAll(event.getPlayer());
/*     */     
/* 349 */     this._lastMove.remove(event.getPlayer());
/*     */     
/* 351 */     this._playerActiveGadgetMap.remove(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void death(PlayerDeathEvent event)
/*     */   {
/* 357 */     this._lastMove.remove(event.getEntity());
/*     */     
/* 359 */     this._playerActiveGadgetMap.remove(event.getEntity());
/*     */   }
/*     */   
/*     */   public void setActive(Player player, Gadget gadget)
/*     */   {
/* 364 */     if (!this._playerActiveGadgetMap.containsKey(player)) {
/* 365 */       this._playerActiveGadgetMap.put(player, new NautHashMap());
/*     */     }
/* 367 */     ((NautHashMap)this._playerActiveGadgetMap.get(player)).put(gadget.getGadgetType(), gadget);
/*     */   }
/*     */   
/*     */   public Gadget getActive(Player player, GadgetType gadgetType)
/*     */   {
/* 372 */     if (!this._playerActiveGadgetMap.containsKey(player)) {
/* 373 */       this._playerActiveGadgetMap.put(player, new NautHashMap());
/*     */     }
/* 375 */     return (Gadget)((NautHashMap)this._playerActiveGadgetMap.get(player)).get(gadgetType);
/*     */   }
/*     */   
/*     */   public void removeActive(Player player, Gadget gadget)
/*     */   {
/* 380 */     if (!this._playerActiveGadgetMap.containsKey(player)) {
/* 381 */       this._playerActiveGadgetMap.put(player, new NautHashMap());
/*     */     }
/* 383 */     ((NautHashMap)this._playerActiveGadgetMap.get(player)).remove(gadget.getGadgetType());
/*     */   }
/*     */   
/*     */   public void setHideParticles(boolean b)
/*     */   {
/* 388 */     this._hideParticles = b;
/*     */   }
/*     */   
/*     */   public boolean hideParticles()
/*     */   {
/* 393 */     return this._hideParticles;
/*     */   }
/*     */   
/*     */   public void setActiveItemSlot(int i)
/*     */   {
/* 398 */     this._activeItemSlot = i;
/*     */   }
/*     */   
/*     */   public int getActiveItemSlot()
/*     */   {
/* 403 */     return this._activeItemSlot;
/*     */   }
/*     */   
/*     */   public void redisplayActiveItem(Player player)
/*     */   {
/* 408 */     for (Gadget gadget : (List)this._gadgets.get(GadgetType.Item))
/*     */     {
/* 410 */       if ((gadget instanceof ItemGadget))
/*     */       {
/* 412 */         if (gadget.IsActive(player))
/*     */         {
/* 414 */           ((ItemGadget)gadget).ApplyItem(player, false);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canPlaySongAt(Location location)
/*     */   {
/* 422 */     for (Gadget gadget : (List)this._gadgets.get(GadgetType.MusicDisc))
/*     */     {
/* 424 */       if ((gadget instanceof MusicGadget))
/*     */       {
/* 426 */         if (!((MusicGadget)gadget).canPlayAt(location))
/*     */         {
/* 428 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 433 */     return true;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void chissMeow(PlayerToggleSneakEvent event)
/*     */   {
/* 439 */     if (event.getPlayer().getName().equals("Chiss"))
/*     */     {
/* 441 */       if (!event.getPlayer().isSneaking())
/*     */       {
/* 443 */         event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), org.bukkit.Sound.CAT_MEOW, 1.0F, 1.0F);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\GadgetManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */