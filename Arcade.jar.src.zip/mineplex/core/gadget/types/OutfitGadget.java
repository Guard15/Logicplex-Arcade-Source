/*    */ package mineplex.core.gadget.types;
/*    */ 
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.itemstack.ItemStackFactory;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ 
/*    */ public abstract class OutfitGadget extends Gadget
/*    */ {
/*    */   private ArmorSlot _slot;
/*    */   
/*    */   public static enum ArmorSlot
/*    */   {
/* 15 */     Helmet, 
/* 16 */     Chest, 
/* 17 */     Legs, 
/* 18 */     Boots;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public OutfitGadget(mineplex.core.gadget.GadgetManager manager, String name, String[] desc, int cost, ArmorSlot slot, Material mat, byte data)
/*    */   {
/* 25 */     super(manager, GadgetType.Costume, name, desc, cost, mat, data);
/*    */     
/* 27 */     this._slot = slot;
/*    */   }
/*    */   
/*    */   public ArmorSlot GetSlot()
/*    */   {
/* 32 */     return this._slot;
/*    */   }
/*    */   
/*    */   public void ApplyArmor(Player player)
/*    */   {
/* 37 */     this.Manager.RemoveMorph(player);
/*    */     
/* 39 */     this.Manager.RemoveOutfit(player, this._slot);
/*    */     
/* 41 */     this._active.add(player);
/*    */     
/* 43 */     mineplex.core.common.util.UtilPlayer.message(player, F.main("Gadget", "You put on " + F.elem(GetName()) + "."));
/*    */     
/* 45 */     if (this._slot == ArmorSlot.Helmet) { player.getInventory().setHelmet(
/* 46 */         ItemStackFactory.Instance.CreateStack(GetDisplayMaterial().getId(), GetDisplayData(), 1, GetName()));
/*    */     }
/* 48 */     else if (this._slot == ArmorSlot.Chest) { player.getInventory().setChestplate(
/* 49 */         ItemStackFactory.Instance.CreateStack(GetDisplayMaterial().getId(), GetDisplayData(), 1, GetName()));
/*    */     }
/* 51 */     else if (this._slot == ArmorSlot.Legs) { player.getInventory().setLeggings(
/* 52 */         ItemStackFactory.Instance.CreateStack(GetDisplayMaterial().getId(), GetDisplayData(), 1, GetName()));
/*    */     }
/* 54 */     else if (this._slot == ArmorSlot.Boots) player.getInventory().setBoots(
/* 55 */         ItemStackFactory.Instance.CreateStack(GetDisplayMaterial().getId(), GetDisplayData(), 1, GetName()));
/*    */   }
/*    */   
/*    */   public void RemoveArmor(Player player)
/*    */   {
/* 60 */     if (!this._active.remove(player)) {
/* 61 */       return;
/*    */     }
/* 63 */     mineplex.core.common.util.UtilPlayer.message(player, F.main("Gadget", "You took off " + F.elem(GetName()) + "."));
/*    */     
/* 65 */     if (this._slot == ArmorSlot.Helmet) { player.getInventory().setHelmet(null);
/* 66 */     } else if (this._slot == ArmorSlot.Chest) { player.getInventory().setChestplate(null);
/* 67 */     } else if (this._slot == ArmorSlot.Legs) { player.getInventory().setLeggings(null);
/* 68 */     } else if (this._slot == ArmorSlot.Boots) player.getInventory().setBoots(null);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\OutfitGadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */