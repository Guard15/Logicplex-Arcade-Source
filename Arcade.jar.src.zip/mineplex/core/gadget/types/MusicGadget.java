/*     */ package mineplex.core.gadget.types;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.event.GadgetActivateEvent;
/*     */ import mineplex.core.gadget.event.GadgetBlockEvent;
/*     */ import mineplex.core.gadget.gadgets.SongData;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ public class MusicGadget extends Gadget
/*     */ {
/*     */   private int _id;
/*     */   private long _duration;
/*  31 */   private ArrayList<SongData> _songs = new ArrayList();
/*     */   
/*     */   public MusicGadget(GadgetManager manager, String name, String[] desc, int cost, int id, long duration)
/*     */   {
/*  35 */     super(manager, GadgetType.MusicDisc, name, desc, cost, Material.getMaterial(id), (byte)0);
/*     */     
/*  37 */     this._id = id;
/*  38 */     this._duration = duration;
/*     */   }
/*     */   
/*     */ 
/*     */   public void Enable(Player player)
/*     */   {
/*  44 */     GadgetActivateEvent gadgetEvent = new GadgetActivateEvent(player, this);
/*  45 */     Bukkit.getServer().getPluginManager().callEvent(gadgetEvent);
/*     */     
/*  47 */     if (gadgetEvent.isCancelled())
/*     */     {
/*  49 */       UtilPlayer.message(player, F.main("Inventory", GetName() + " is not enabled."));
/*  50 */       return;
/*     */     }
/*     */     
/*  53 */     if (!this.Manager.canPlaySongAt(player.getLocation()))
/*     */     {
/*  55 */       UtilPlayer.message(player, F.main("Music", "There is already a song playing."));
/*  56 */       return;
/*     */     }
/*     */     
/*     */ 
/*  60 */     for (Block block : UtilBlock.getInRadius(player.getLocation(), 3.0D).keySet())
/*     */     {
/*  62 */       if (block.getType() == Material.PORTAL)
/*     */       {
/*  64 */         UtilPlayer.message(player, F.main("Music", "Cannot play songs near Portals."));
/*  65 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  70 */     Block block = player.getLocation().getBlock();
/*  71 */     for (int x = -1; x <= 1; x++) {
/*  72 */       for (int z = -1; z <= 1; z++) {
/*  73 */         if (!UtilBlock.airFoliage(block.getRelative(x, 0, z)))
/*     */         {
/*  75 */           UtilPlayer.message(player, F.main("Music", "You cannot place a Jukebox here."));
/*  76 */           return;
/*     */         }
/*     */       }
/*     */     }
/*  80 */     Object blocks = new ArrayList();
/*  81 */     ((ArrayList)blocks).add(block);
/*  82 */     GadgetBlockEvent gadgetBlockEvent = new GadgetBlockEvent(this, (List)blocks);
/*  83 */     Bukkit.getServer().getPluginManager().callEvent(gadgetBlockEvent);
/*     */     
/*  85 */     if (gadgetEvent.isCancelled())
/*     */     {
/*  87 */       UtilPlayer.message(player, F.main("Music", "You cannot place a Jukebox here."));
/*  88 */       return;
/*     */     }
/*     */     
/*  91 */     player.getWorld().playEffect(player.getLocation(), Effect.RECORD_PLAY, this._id);
/*     */     
/*  93 */     this._songs.add(new SongData(player.getLocation().getBlock(), this._duration));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void EnableCustom(Player player) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void DisableCustom(Player player) {}
/*     */   
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event)
/*     */   {
/* 111 */     if (event.getType() != UpdateType.FASTER) {
/* 112 */       return;
/*     */     }
/* 114 */     Iterator<SongData> songIterator = this._songs.iterator();
/*     */     
/* 116 */     while (songIterator.hasNext())
/*     */     {
/* 118 */       SongData song = (SongData)songIterator.next();
/*     */       
/* 120 */       if (song.update()) {
/* 121 */         songIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void gadgetBlockChange(GadgetBlockEvent event) {
/* 128 */     for (Iterator<Block> iterator = event.getBlocks().iterator(); iterator.hasNext();)
/*     */     {
/* 130 */       Block block = (Block)iterator.next();
/*     */       
/* 132 */       for (SongData data : this._songs)
/*     */       {
/* 134 */         if (data.Block.equals(block))
/*     */         {
/* 136 */           iterator.remove();
/* 137 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean canPlayAt(Location location)
/*     */   {
/* 145 */     if (!this._songs.isEmpty()) {
/* 146 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     return true;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\MusicGadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */