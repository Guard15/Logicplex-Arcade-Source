/*    */ package mineplex.core.gadget.types;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.event.GadgetActivateEvent;
/*    */ import mineplex.core.shop.item.SalesPackageBase;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.Listener;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public abstract class Gadget
/*    */   extends SalesPackageBase implements Listener
/*    */ {
/*    */   public GadgetManager Manager;
/*    */   private GadgetType _gadgetType;
/* 26 */   protected HashSet<Player> _active = new HashSet();
/*    */   
/*    */   public Gadget(GadgetManager manager, GadgetType gadgetType, String name, String[] desc, int cost, Material mat, byte data)
/*    */   {
/* 30 */     this(manager, gadgetType, name, desc, cost, mat, data, 1);
/*    */   }
/*    */   
/*    */   public Gadget(GadgetManager manager, GadgetType gadgetType, String name, String[] desc, int cost, Material mat, byte data, int quantity)
/*    */   {
/* 35 */     super(name, mat, data, desc, cost, quantity);
/*    */     
/* 37 */     this._gadgetType = gadgetType;
/* 38 */     this.KnownPackage = false;
/*    */     
/* 40 */     this.Manager = manager;
/*    */     
/* 42 */     this.Manager.getPlugin().getServer().getPluginManager().registerEvents(this, this.Manager.getPlugin());
/*    */   }
/*    */   
/*    */   public GadgetType getGadgetType()
/*    */   {
/* 47 */     return this._gadgetType;
/*    */   }
/*    */   
/*    */   public HashSet<Player> GetActive()
/*    */   {
/* 52 */     return this._active;
/*    */   }
/*    */   
/*    */   public boolean IsActive(Player player)
/*    */   {
/* 57 */     return this._active.contains(player);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void PlayerQuit(PlayerQuitEvent event)
/*    */   {
/* 63 */     Disable(event.getPlayer());
/*    */   }
/*    */   
/*    */   public void Enable(Player player)
/*    */   {
/* 68 */     GadgetActivateEvent gadgetEvent = new GadgetActivateEvent(player, this);
/* 69 */     Bukkit.getServer().getPluginManager().callEvent(gadgetEvent);
/*    */     
/* 71 */     if (gadgetEvent.isCancelled())
/*    */     {
/* 73 */       UtilPlayer.message(player, F.main("Inventory", GetName() + " is not enabled."));
/* 74 */       return;
/*    */     }
/*    */     
/* 77 */     EnableCustom(player);
/* 78 */     this.Manager.setActive(player, this);
/*    */   }
/*    */   
/*    */   public void DisableForAll() {
/*    */     Player[] arrayOfPlayer;
/* 83 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 84 */       Disable(player);
/*    */     }
/*    */   }
/*    */   
/*    */   public void Disable(Player player) {
/* 89 */     if (IsActive(player)) {
/* 90 */       this.Manager.removeActive(player, this);
/*    */     }
/* 92 */     DisableCustom(player);
/*    */   }
/*    */   
/*    */   public abstract void EnableCustom(Player paramPlayer);
/*    */   
/*    */   public abstract void DisableCustom(Player paramPlayer);
/*    */   
/*    */   public void Sold(Player player, CurrencyType currencyType) {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\Gadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */