/*    */ package mineplex.core.gadget.types;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.entity.PlayerDeathEvent;
/*    */ 
/*    */ public abstract class MorphGadget
/*    */   extends Gadget
/*    */ {
/*    */   public MorphGadget(GadgetManager manager, String name, String[] desc, int cost, Material mat, byte data)
/*    */   {
/* 17 */     super(manager, GadgetType.Morph, name, desc, cost, mat, data);
/*    */   }
/*    */   
/*    */   public void ApplyArmor(Player player)
/*    */   {
/* 22 */     this.Manager.RemoveMorph(player);
/*    */     
/* 24 */     this._active.add(player);
/*    */     
/* 26 */     UtilPlayer.message(player, F.main("Gadget", "You morphed into " + F.elem(GetName()) + "."));
/*    */   }
/*    */   
/*    */   public void RemoveArmor(Player player)
/*    */   {
/* 31 */     if (this._active.remove(player)) {
/* 32 */       UtilPlayer.message(player, F.main("Gadget", "You unmorphed from " + F.elem(GetName()) + "."));
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void playerDeath(PlayerDeathEvent event) {
/* 38 */     Disable(event.getEntity());
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\MorphGadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */