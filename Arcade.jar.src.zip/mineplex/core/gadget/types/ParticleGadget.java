/*    */ package mineplex.core.gadget.types;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public abstract class ParticleGadget
/*    */   extends Gadget
/*    */ {
/*    */   public ParticleGadget(GadgetManager manager, String name, String[] desc, int cost, Material mat, byte data)
/*    */   {
/* 15 */     super(manager, GadgetType.Particle, name, desc, cost, mat, data);
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 21 */     this.Manager.RemoveParticle(player);
/*    */     
/* 23 */     this._active.add(player);
/*    */     
/* 25 */     UtilPlayer.message(player, F.main("Gadget", "You summoned " + F.elem(GetName()) + "."));
/*    */   }
/*    */   
/*    */ 
/*    */   public void DisableCustom(Player player)
/*    */   {
/* 31 */     if (this._active.remove(player)) {
/* 32 */       UtilPlayer.message(player, F.main("Gadget", "You unsummoned " + F.elem(GetName()) + "."));
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean shouldDisplay(Player player) {
/* 37 */     if (UtilPlayer.isSpectator(player)) {
/* 38 */       return false;
/*    */     }
/* 40 */     if (this.Manager.hideParticles()) {
/* 41 */       return false;
/*    */     }
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\ParticleGadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */