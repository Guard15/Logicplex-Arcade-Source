/*     */ package mineplex.core.gadget.types;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilGear;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.event.ItemGadgetOutOfAmmoEvent;
/*     */ import mineplex.core.gadget.gadgets.Ammo;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ public abstract class ItemGadget extends Gadget
/*     */ {
/*     */   private Ammo _ammo;
/*     */   protected long _recharge;
/*     */   
/*     */   public ItemGadget(GadgetManager manager, String name, String[] desc, int cost, Material mat, byte data, long recharge, Ammo ammo)
/*     */   {
/*  36 */     super(manager, GadgetType.Item, name, desc, cost, mat, data);
/*     */     
/*  38 */     this._ammo = ammo;
/*  39 */     this._recharge = recharge;
/*  40 */     this.Free = true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  46 */     ApplyItem(player, true);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  52 */     RemoveItem(player);
/*     */   }
/*     */   
/*     */   public HashSet<Player> GetActive()
/*     */   {
/*  57 */     return this._active;
/*     */   }
/*     */   
/*     */   public boolean IsActive(Player player)
/*     */   {
/*  62 */     return this._active.contains(player);
/*     */   }
/*     */   
/*     */   public void ApplyItem(Player player, boolean inform)
/*     */   {
/*  67 */     this.Manager.RemoveItem(player);
/*     */     
/*  69 */     this._active.add(player);
/*     */     
/*  71 */     List<String> itemLore = new ArrayList();
/*  72 */     itemLore.addAll(java.util.Arrays.asList(GetDescription()));
/*  73 */     itemLore.add(C.cBlack);
/*  74 */     itemLore.add(C.cWhite + "Your Ammo : " + ((ClientInventory)this.Manager.getInventoryManager().Get(player)).getItemCount(GetName()));
/*     */     
/*  76 */     player.getInventory().setItem(this.Manager.getActiveItemSlot(), ItemStackFactory.Instance.CreateStack(GetDisplayMaterial(), GetDisplayData(), 1, F.item(((ClientInventory)this.Manager.getInventoryManager().Get(player)).getItemCount(GetName()) + " " + GetName())));
/*     */     
/*  78 */     if (inform) {
/*  79 */       UtilPlayer.message(player, F.main("Gadget", "You equipped " + F.elem(GetName()) + "."));
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void orderThatChest(PlayerDropItemEvent event) {
/*  85 */     if ((IsActive(event.getPlayer())) && (event.getItemDrop().getItemStack().getType() == GetDisplayMaterial()))
/*     */     {
/*  87 */       final Player player = event.getPlayer();
/*     */       
/*  89 */       Bukkit.getScheduler().scheduleSyncDelayedTask(this.Manager.getPlugin(), new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*  93 */           if (player.isOnline())
/*     */           {
/*  95 */             player.getInventory().remove(ItemGadget.this.GetDisplayMaterial());
/*  96 */             player.getInventory().setItem(ItemGadget.this.Manager.getActiveItemSlot(), ItemStackFactory.Instance.CreateStack(ItemGadget.this.GetDisplayMaterial(), ItemGadget.this.GetDisplayData(), 1, F.item(((ClientInventory)ItemGadget.this.Manager.getInventoryManager().Get(player)).getItemCount(ItemGadget.this.GetName()) + " " + ItemGadget.this.GetName())));
/*  97 */             UtilInv.Update(player);
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */   public void RemoveItem(Player player)
/*     */   {
/* 106 */     if (this._active.remove(player))
/*     */     {
/* 108 */       player.getInventory().setItem(this.Manager.getActiveItemSlot(), null);
/*     */       
/* 110 */       UtilPlayer.message(player, F.main("Gadget", "You unequipped " + F.elem(GetName()) + "."));
/*     */     }
/*     */   }
/*     */   
/*     */   public Ammo getAmmo()
/*     */   {
/* 116 */     return this._ammo;
/*     */   }
/*     */   
/*     */   public boolean IsItem(Player player)
/*     */   {
/* 121 */     return UtilInv.IsItem(player.getItemInHand(), GetDisplayMaterial(), GetDisplayData());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Activate(PlayerInteractEvent event)
/*     */   {
/* 127 */     if ((event.getAction() != Action.RIGHT_CLICK_AIR) && (event.getAction() != Action.RIGHT_CLICK_BLOCK)) {
/* 128 */       return;
/*     */     }
/* 130 */     if (mineplex.core.common.util.UtilBlock.usable(event.getClickedBlock())) {
/* 131 */       return;
/*     */     }
/* 133 */     if (!UtilGear.isMat(event.getPlayer().getItemInHand(), GetDisplayMaterial())) {
/* 134 */       return;
/*     */     }
/* 136 */     Player player = event.getPlayer();
/*     */     
/* 138 */     if (!IsActive(player)) {
/* 139 */       return;
/*     */     }
/* 141 */     event.setCancelled(true);
/*     */     
/*     */ 
/* 144 */     if (((ClientInventory)this.Manager.getInventoryManager().Get(player)).getItemCount(GetName()) <= 0)
/*     */     {
/*     */ 
/* 147 */       UtilPlayer.message(player, F.main("Gadget", "You do not have any " + GetName() + " left."));
/*     */       
/* 149 */       ItemGadgetOutOfAmmoEvent ammoEvent = new ItemGadgetOutOfAmmoEvent(event.getPlayer(), this);
/* 150 */       Bukkit.getServer().getPluginManager().callEvent(ammoEvent);
/*     */       
/* 152 */       return;
/*     */     }
/*     */     
/*     */ 
/* 156 */     if (!Recharge.Instance.use(player, GetName(), this._recharge, this._recharge > 1000L, false))
/*     */     {
/* 158 */       UtilInv.Update(player);
/* 159 */       return;
/*     */     }
/*     */     
/* 162 */     this.Manager.getInventoryManager().addItemToInventory(player, getGadgetType().name(), GetName(), -1);
/*     */     
/* 164 */     player.getInventory().setItem(this.Manager.getActiveItemSlot(), ItemStackFactory.Instance.CreateStack(GetDisplayMaterial(), GetDisplayData(), 1, F.item(((ClientInventory)this.Manager.getInventoryManager().Get(player)).getItemCount(GetName()) + " " + GetName())));
/*     */     
/* 166 */     ActivateCustom(event.getPlayer());
/*     */   }
/*     */   
/*     */   public abstract void ActivateCustom(Player paramPlayer);
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\types\ItemGadget.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */