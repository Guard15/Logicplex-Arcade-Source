/*    */ package mineplex.core.gadget.event;
/*    */ 
/*    */ import mineplex.core.gadget.types.Gadget;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class GadgetCollideEntityEvent
/*    */   extends Event
/*    */ {
/* 11 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Gadget _gadget;
/*    */   
/*    */   private Entity _other;
/* 16 */   private boolean _cancelled = false;
/*    */   
/*    */   public GadgetCollideEntityEvent(Gadget gadget, Entity other)
/*    */   {
/* 20 */     this._gadget = gadget;
/* 21 */     this._other = other;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 26 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 31 */     return handlers;
/*    */   }
/*    */   
/*    */   public Gadget getGadget()
/*    */   {
/* 36 */     return this._gadget;
/*    */   }
/*    */   
/*    */   public Entity getOther()
/*    */   {
/* 41 */     return this._other;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 46 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 51 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\event\GadgetCollideEntityEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */