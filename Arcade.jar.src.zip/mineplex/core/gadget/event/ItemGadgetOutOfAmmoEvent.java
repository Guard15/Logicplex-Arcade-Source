/*    */ package mineplex.core.gadget.event;
/*    */ 
/*    */ import mineplex.core.gadget.types.ItemGadget;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class ItemGadgetOutOfAmmoEvent
/*    */   extends Event
/*    */ {
/* 11 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Player _player;
/*    */   private ItemGadget _gadget;
/*    */   
/*    */   public ItemGadgetOutOfAmmoEvent(Player player, ItemGadget gadget)
/*    */   {
/* 18 */     this._player = player;
/* 19 */     this._gadget = gadget;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 24 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 29 */     return handlers;
/*    */   }
/*    */   
/*    */   public ItemGadget getGadget()
/*    */   {
/* 34 */     return this._gadget;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 39 */     return this._player;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\event\ItemGadgetOutOfAmmoEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */