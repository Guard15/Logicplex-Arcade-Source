/*    */ package mineplex.core.gadget.event;
/*    */ 
/*    */ import java.util.List;
/*    */ import mineplex.core.gadget.types.Gadget;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class GadgetBlockEvent
/*    */   extends Event
/*    */ {
/* 13 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Gadget _gadget;
/*    */   
/*    */   private List<Block> _blocks;
/* 18 */   private boolean _cancelled = false;
/*    */   
/*    */   public GadgetBlockEvent(Gadget gadget, List<Block> blocks)
/*    */   {
/* 22 */     this._gadget = gadget;
/* 23 */     this._blocks = blocks;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 28 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 33 */     return handlers;
/*    */   }
/*    */   
/*    */   public Gadget getGadget()
/*    */   {
/* 38 */     return this._gadget;
/*    */   }
/*    */   
/*    */   public List<Block> getBlocks()
/*    */   {
/* 43 */     return this._blocks;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 48 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 53 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\event\GadgetBlockEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */