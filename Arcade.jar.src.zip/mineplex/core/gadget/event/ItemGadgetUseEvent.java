/*    */ package mineplex.core.gadget.event;
/*    */ 
/*    */ import mineplex.core.gadget.types.ItemGadget;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class ItemGadgetUseEvent
/*    */   extends Event
/*    */ {
/* 11 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Player _player;
/*    */   
/*    */   private ItemGadget _gadget;
/*    */   private int _count;
/* 17 */   private boolean _cancelled = false;
/*    */   
/*    */   public ItemGadgetUseEvent(Player player, ItemGadget gadget, int count)
/*    */   {
/* 21 */     this._player = player;
/* 22 */     this._gadget = gadget;
/* 23 */     this._count = count;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 28 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 33 */     return handlers;
/*    */   }
/*    */   
/*    */   public int getCount()
/*    */   {
/* 38 */     return this._count;
/*    */   }
/*    */   
/*    */   public ItemGadget getGadget()
/*    */   {
/* 43 */     return this._gadget;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 48 */     return this._player;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 53 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 58 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\event\ItemGadgetUseEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */