/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.UtilParticle;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ParticleGadget;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleHelix
/*    */   extends ParticleGadget
/*    */ {
/*    */   public ParticleHelix(GadgetManager manager)
/*    */   {
/* 31 */     super(manager, "Blood Helix", new String[] {C.cWhite + "Ancient legend says this magic", C.cWhite + "empowers the blood of its user,", C.cWhite + "giving them godly powers." }, -2, Material.REDSTONE, (byte)0);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void playParticle(UpdateEvent event)
/*    */   {
/* 37 */     if (event.getType() != UpdateType.TICK) {
/* 38 */       return;
/*    */     }
/* 40 */     for (Player player : GetActive())
/*    */     {
/* 42 */       if (shouldDisplay(player))
/*    */       {
/*    */ 
/* 45 */         if (this.Manager.isMoving(player))
/*    */         {
/* 47 */           UtilParticle.PlayParticle(UtilParticle.ParticleType.RED_DUST, player.getLocation().add(0.0D, 1.0D, 0.0D), 0.2F, 0.2F, 0.2F, 0.0F, 4, 
/* 48 */             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */         }
/*    */         else
/*    */         {
/* 52 */           for (int height = 0; height <= 20; height++)
/*    */           {
/* 54 */             for (int i = 0; i < 2; i++)
/*    */             {
/* 56 */               double lead = i * 3.141592653589793D;
/*    */               
/* 58 */               double heightLead = height * 0.3141592653589793D;
/*    */               
/* 60 */               float x = (float)(Math.sin(player.getTicksLived() / 20.0D + lead + heightLead) * 1.2000000476837158D);
/* 61 */               float z = (float)(Math.cos(player.getTicksLived() / 20.0D + lead + heightLead) * 1.2000000476837158D);
/*    */               
/* 63 */               float y = 0.15F * height;
/*    */               
/* 65 */               UtilParticle.PlayParticle(UtilParticle.ParticleType.RED_DUST, player.getLocation().add(x * (1.0D - height / 22.0D), y, z * (1.0D - height / 22.0D)), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 66 */                 UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */             }
/*    */           }
/*    */           
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 75 */           player.getWorld().playSound(player.getLocation(), Sound.LAVA, 0.3F, 1.0F);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleHelix.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */