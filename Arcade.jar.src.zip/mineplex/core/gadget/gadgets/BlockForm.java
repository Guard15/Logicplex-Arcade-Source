/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.MapUtil;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseCat;
/*     */ import mineplex.core.disguise.disguises.DisguiseChicken;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.event.GadgetBlockEvent;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import net.minecraft.server.v1_7_R4.DataWatcher;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftEntity;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftFallingSand;
/*     */ import org.bukkit.entity.FallingBlock;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ 
/*     */ public class BlockForm
/*     */ {
/*     */   private MorphBlock _host;
/*     */   private Player _player;
/*     */   private Material _mat;
/*     */   private Block _block;
/*     */   private Location _loc;
/*     */   
/*     */   public BlockForm(MorphBlock host, Player player, Material mat)
/*     */   {
/*  40 */     this._host = host;
/*  41 */     this._player = player;
/*     */     
/*  43 */     this._mat = mat;
/*  44 */     this._loc = player.getLocation();
/*     */     
/*  46 */     Apply();
/*     */   }
/*     */   
/*     */ 
/*     */   public void Apply()
/*     */   {
/*  52 */     if (this._player.getPassenger() != null)
/*     */     {
/*  54 */       Recharge.Instance.useForce(this._player, "PassengerChange", 100L);
/*     */       
/*  56 */       this._player.getPassenger().remove();
/*  57 */       this._player.eject();
/*     */     }
/*     */     
/*  60 */     ((CraftEntity)this._player).getHandle().getDataWatcher().watch(0, Byte.valueOf((byte)32));
/*     */     
/*     */ 
/*  63 */     DisguiseChicken disguise = new DisguiseChicken(this._player);
/*  64 */     disguise.setBaby();
/*  65 */     disguise.setSoundDisguise(new DisguiseCat(this._player));
/*  66 */     disguise.setInvisible(true);
/*  67 */     this._host.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */     
/*     */ 
/*  70 */     FallingBlockCheck();
/*     */     
/*     */ 
/*  73 */     String blockName = F.elem(ItemStackFactory.Instance.GetName(this._mat, (byte)0, false));
/*  74 */     if (!blockName.contains("Block")) {
/*  75 */       UtilPlayer.message(this._player, F.main("Morph", "You are now a " + F.elem(new StringBuilder(String.valueOf(ItemStackFactory.Instance.GetName(this._mat, (byte)0, false))).append(" Block").toString()) + "!"));
/*     */     } else {
/*  77 */       UtilPlayer.message(this._player, F.main("Morph", "You are now a " + F.elem(ItemStackFactory.Instance.GetName(this._mat, (byte)0, false)) + "!"));
/*     */     }
/*     */     
/*  80 */     this._player.playSound(this._player.getLocation(), Sound.ZOMBIE_UNFECT, 2.0F, 2.0F);
/*     */   }
/*     */   
/*     */   public void Remove()
/*     */   {
/*  85 */     SolidifyRemove();
/*     */     
/*  87 */     this._host.Manager.getDisguiseManager().undisguise(this._player);
/*     */     
/*     */ 
/*  90 */     if (this._player.getPassenger() != null)
/*     */     {
/*  92 */       Recharge.Instance.useForce(this._player, "PassengerChange", 100L);
/*     */       
/*  94 */       this._player.getPassenger().remove();
/*  95 */       this._player.eject();
/*     */     }
/*     */     
/*  98 */     ((CraftEntity)this._player).getHandle().getDataWatcher().watch(0, Byte.valueOf((byte)0));
/*     */   }
/*     */   
/*     */   public void SolidifyUpdate()
/*     */   {
/* 103 */     if (!this._player.isSprinting()) {
/* 104 */       ((CraftEntity)this._player).getHandle().getDataWatcher().watch(0, Byte.valueOf((byte)32));
/*     */     }
/*     */     
/* 107 */     if (this._block == null)
/*     */     {
/*     */ 
/* 110 */       if (!this._loc.getBlock().equals(this._player.getLocation().getBlock()))
/*     */       {
/* 112 */         this._player.setExp(0.0F);
/* 113 */         this._loc = this._player.getLocation();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 118 */         double hideBoost = 0.025D;
/*     */         
/* 120 */         this._player.setExp((float)Math.min(0.9990000128746033D, this._player.getExp() + hideBoost));
/*     */         
/*     */ 
/* 123 */         if (this._player.getExp() >= 0.999F)
/*     */         {
/* 125 */           Block block = this._player.getLocation().getBlock();
/*     */           
/* 127 */           List<Block> blockList = new ArrayList();
/* 128 */           blockList.add(block);
/*     */           
/* 130 */           GadgetBlockEvent event = new GadgetBlockEvent(this._host, blockList);
/*     */           
/* 132 */           org.bukkit.Bukkit.getServer().getPluginManager().callEvent(event);
/*     */           
/*     */ 
/* 135 */           if ((block.getType() != Material.AIR) || (!UtilBlock.solid(block.getRelative(BlockFace.DOWN))) || (event.getBlocks().isEmpty()) || (event.isCancelled()))
/*     */           {
/* 137 */             UtilPlayer.message(this._player, F.main("Morph", "You cannot become a Solid Block here."));
/* 138 */             this._player.setExp(0.0F);
/* 139 */             return;
/*     */           }
/*     */           
/*     */ 
/* 143 */           this._block = block;
/*     */           
/*     */ 
/* 146 */           this._player.playEffect(this._player.getLocation(), org.bukkit.Effect.STEP_SOUND, this._mat);
/*     */           
/*     */ 
/*     */ 
/* 150 */           SolidifyVisual();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */           this._player.playSound(this._player.getLocation(), Sound.NOTE_PLING, 1.0F, 2.0F);
/*     */ 
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */ 
/*     */     }
/* 164 */     else if (!this._loc.getBlock().equals(this._player.getLocation().getBlock()))
/*     */     {
/* 166 */       SolidifyRemove();
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 171 */       SolidifyVisual();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void SolidifyRemove()
/*     */   {
/* 178 */     if (this._block != null)
/*     */     {
/* 180 */       MapUtil.QuickChangeBlockAt(this._block.getLocation(), 0, (byte)0);
/* 181 */       this._block = null;
/*     */     }
/*     */     
/* 184 */     this._player.setExp(0.0F);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     this._player.playSound(this._player.getLocation(), Sound.NOTE_PLING, 1.0F, 0.5F);
/*     */     
/* 191 */     FallingBlockCheck();
/*     */   }
/*     */   
/*     */ 
/*     */   public void SolidifyVisual()
/*     */   {
/* 197 */     if (this._block == null) {
/* 198 */       return;
/*     */     }
/*     */     
/* 201 */     if (this._player.getPassenger() != null)
/*     */     {
/* 203 */       Recharge.Instance.useForce(this._player, "PassengerChange", 100L);
/*     */       
/* 205 */       this._player.getPassenger().remove();
/* 206 */       this._player.eject();
/*     */     }
/*     */     
/*     */     Player[] arrayOfPlayer;
/* 210 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/* 211 */       other.sendBlockChange(this._player.getLocation(), this._mat, (byte)0);
/*     */     }
/*     */     
/* 214 */     this._player.sendBlockChange(this._player.getLocation(), 36, (byte)0);
/*     */     
/* 216 */     FallingBlockCheck();
/*     */   }
/*     */   
/*     */ 
/*     */   public void FallingBlockCheck()
/*     */   {
/* 222 */     if (this._block != null) {
/* 223 */       return;
/*     */     }
/*     */     
/* 226 */     if ((this._player.getPassenger() == null) || (!this._player.getPassenger().isValid()))
/*     */     {
/* 228 */       if (!Recharge.Instance.use(this._player, "PassengerChange", 100L, false, false)) {
/* 229 */         return;
/*     */       }
/*     */       
/* 232 */       FallingBlock block = this._player.getWorld().spawnFallingBlock(this._player.getEyeLocation(), this._mat, (byte)0);
/*     */       
/*     */ 
/* 235 */       ((CraftFallingSand)block).getHandle().spectating = true;
/*     */       
/* 237 */       this._player.setPassenger(block);
/*     */       
/* 239 */       this._host.fallingBlockRegister(block);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 245 */       ((CraftFallingSand)this._player.getPassenger()).getHandle().ticksLived = 1;
/* 246 */       this._player.getPassenger().setTicksLived(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public Block GetBlock()
/*     */   {
/* 253 */     return this._block;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\BlockForm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */