/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ParticleGadget;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ public class ParticleFoot
/*     */   extends ParticleGadget
/*     */ {
/*  32 */   private boolean _foot = false;
/*     */   
/*  34 */   private HashMap<Location, Long> _steps = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParticleFoot(GadgetManager manager)
/*     */   {
/*  46 */     super(manager, "Shadow Walk", new String[] {C.cWhite + "In a world where footprints", C.cWhite + "do not exist, leaving your", C.cWhite + "shadow behind is the next", C.cWhite + "best thing." }, -2, Material.LEATHER_BOOTS, (byte)0);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playParticle(UpdateEvent event)
/*     */   {
/*  52 */     if (event.getType() != UpdateType.FASTEST) {
/*  53 */       return;
/*     */     }
/*  55 */     this._foot = (!this._foot);
/*     */     
/*  57 */     cleanSteps();
/*     */     
/*  59 */     for (Player player : GetActive())
/*     */     {
/*  61 */       if (shouldDisplay(player))
/*     */       {
/*     */ 
/*  64 */         if (this.Manager.isMoving(player))
/*     */         {
/*     */ 
/*  67 */           if (UtilEnt.isGrounded(player))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*  72 */             Vector dir = player.getLocation().getDirection();
/*  73 */             dir.setY(0);
/*  74 */             dir.normalize();
/*     */             Vector offset;
/*  76 */             Vector offset; if (this._foot)
/*     */             {
/*  78 */               offset = new Vector(dir.getZ() * -1.0D, 0.1D, dir.getX());
/*     */             }
/*     */             else
/*     */             {
/*  82 */               offset = new Vector(dir.getZ(), 0.1D, dir.getX() * -1.0D);
/*     */             }
/*     */             
/*  85 */             Location loc = player.getLocation().add(offset.multiply(0.2D));
/*     */             
/*  87 */             if (!nearStep(loc))
/*     */             {
/*     */ 
/*  90 */               if (UtilBlock.solid(loc.getBlock().getRelative(BlockFace.DOWN)))
/*     */               {
/*     */ 
/*  93 */                 this._steps.put(loc, Long.valueOf(System.currentTimeMillis()));
/*     */                 
/*  95 */                 UtilParticle.PlayParticle(UtilParticle.ParticleType.FOOTSTEP, loc, 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/*  96 */                   UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */                 
/*  98 */                 UtilParticle.PlayParticle(UtilParticle.ParticleType.LARGE_SMOKE, loc.clone().add(0.0D, 0.1D, 0.0D), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/*  99 */                   UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */               } }
/*     */           } } } }
/*     */   }
/*     */   
/*     */   public void cleanSteps() {
/* 105 */     if (this._steps.isEmpty()) {
/* 106 */       return;
/*     */     }
/* 108 */     Iterator<Map.Entry<Location, Long>> stepIterator = this._steps.entrySet().iterator();
/*     */     
/* 110 */     while (stepIterator.hasNext())
/*     */     {
/* 112 */       Map.Entry<Location, Long> entry = (Map.Entry)stepIterator.next();
/*     */       
/* 114 */       if (UtilTime.elapsed(((Long)entry.getValue()).longValue(), 10000L)) {
/* 115 */         stepIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean nearStep(Location loc) {
/* 121 */     for (Location other : this._steps.keySet())
/*     */     {
/* 123 */       if (UtilMath.offset(loc, other) < 0.3D) {
/* 124 */         return true;
/*     */       }
/*     */     }
/* 127 */     return false;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleFoot.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */