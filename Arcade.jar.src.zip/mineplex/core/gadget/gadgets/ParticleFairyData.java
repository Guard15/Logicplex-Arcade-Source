/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.UtilAlg;
/*    */ import mineplex.core.common.util.UtilMath;
/*    */ import mineplex.core.common.util.UtilParticle;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.util.Vector;
/*    */ 
/*    */ public class ParticleFairyData
/*    */ {
/*    */   public Player Player;
/*    */   public Location Fairy;
/*    */   public Vector Direction;
/*    */   public Location Target;
/*    */   public double Speed;
/*    */   public long IdleTime;
/*    */   
/*    */   public ParticleFairyData(Player player)
/*    */   {
/* 26 */     this.Player = player;
/* 27 */     this.Direction = new Vector(1, 0, 0);
/* 28 */     this.Fairy = player.getEyeLocation();
/* 29 */     this.Target = getNewTarget();
/*    */     
/* 31 */     this.Speed = 0.2D;
/*    */     
/* 33 */     this.IdleTime = 0L;
/*    */   }
/*    */   
/*    */ 
/*    */   public void Update()
/*    */   {
/* 39 */     if ((UtilMath.offset(this.Player.getEyeLocation(), this.Target) > 3.0D) || (UtilMath.offset(this.Fairy, this.Target) < 1.0D)) {
/* 40 */       this.Target = getNewTarget();
/*    */     }
/*    */     
/* 43 */     if (Math.random() > 0.98D) {
/* 44 */       this.IdleTime = (System.currentTimeMillis() + (Math.random() * 3000.0D));
/*    */     }
/*    */     
/* 47 */     if (UtilMath.offset(this.Player.getEyeLocation(), this.Fairy) < 3.0D)
/*    */     {
/* 49 */       if (this.IdleTime > System.currentTimeMillis())
/*    */       {
/* 51 */         this.Speed = Math.max(0.0D, this.Speed - 0.005D);
/*    */       }
/*    */       else
/*    */       {
/* 55 */         this.Speed = Math.min(0.15D, this.Speed + 0.005D);
/*    */       }
/*    */     }
/*    */     else
/*    */     {
/* 60 */       this.IdleTime = 0L;
/*    */       
/* 62 */       this.Speed = Math.min(0.15D + UtilMath.offset(this.Player.getEyeLocation(), this.Fairy) * 0.05D, this.Speed + 0.02D);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 67 */     this.Direction.add(UtilAlg.getTrajectory(this.Fairy, this.Target).multiply(0.15D));
/* 68 */     if (this.Direction.length() < 1.0D)
/* 69 */       this.Speed *= this.Direction.length();
/* 70 */     UtilAlg.Normalize(this.Direction);
/*    */     
/*    */ 
/* 73 */     if (UtilMath.offset(this.Fairy, this.Target) > 0.1D) {
/* 74 */       this.Fairy.add(this.Direction.clone().multiply(this.Speed));
/*    */     }
/*    */     
/* 77 */     UtilParticle.PlayParticle(UtilParticle.ParticleType.FLAME, this.Fairy, 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 78 */       UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/* 79 */     UtilParticle.PlayParticle(UtilParticle.ParticleType.LAVA, this.Fairy, 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 80 */       UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */     
/*    */ 
/* 83 */     this.Fairy.getWorld().playSound(this.Fairy, Sound.CAT_PURREOW, 0.1F, 3.0F);
/*    */   }
/*    */   
/*    */   private Location getNewTarget()
/*    */   {
/* 88 */     return this.Player.getEyeLocation().add(Math.random() * 6.0D - 3.0D, Math.random() * 1.5D, Math.random() * 6.0D - 3.0D);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleFairyData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */