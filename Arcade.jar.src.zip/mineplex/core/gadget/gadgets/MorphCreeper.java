/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseBase;
/*     */ import mineplex.core.disguise.disguises.DisguiseCreeper;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.EntityEffect;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ 
/*     */ public class MorphCreeper extends MorphGadget
/*     */ {
/*  32 */   private HashMap<Player, Long> _active = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphCreeper(GadgetManager manager)
/*     */   {
/*  45 */     super(manager, "Creeper Morph", new String[] {C.cWhite + "Transforms the wearer into a creepy Creeper!", " ", C.cYellow + "Crouch" + C.cGray + " to use " + C.cGreen + "Detonate", " ", C.cPurple + "Unlocked with Hero Rank" }, -1, Material.SKULL_ITEM, (byte)4);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  51 */     ApplyArmor(player);
/*     */     
/*  53 */     DisguiseCreeper disguise = new DisguiseCreeper(player);
/*  54 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  55 */     disguise.setCustomNameVisible(true);
/*  56 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  62 */     RemoveArmor(player);
/*  63 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Trigger(UpdateEvent event)
/*     */   {
/*  69 */     if (event.getType() == UpdateType.TICK)
/*     */     {
/*  71 */       for (Player player : GetActive())
/*     */       {
/*  73 */         if (player.isSneaking())
/*     */         {
/*  75 */           player.leaveVehicle();
/*  76 */           player.eject();
/*     */           
/*  78 */           if (!this._active.containsKey(player)) {
/*  79 */             this._active.put(player, Long.valueOf(System.currentTimeMillis()));
/*     */           }
/*  81 */           double elapsed = (System.currentTimeMillis() - ((Long)this._active.get(player)).longValue()) / 1000.0D;
/*     */           
/*  83 */           player.setExp(Math.min(0.99F, (float)(elapsed / 1.5D)));
/*     */           
/*     */ 
/*  86 */           player.getWorld().playSound(player.getLocation(), Sound.CREEPER_HISS, (float)(0.5D + elapsed / 3.0D), (float)(0.5D + elapsed));
/*     */           
/*  88 */           IncreaseSize(player);
/*     */         }
/*  90 */         else if (this._active.containsKey(player))
/*     */         {
/*     */ 
/*  93 */           DecreaseSize(player);
/*     */           
/*  95 */           player.setExp(0.0F);
/*     */           
/*  97 */           double elapsed = (System.currentTimeMillis() - ((Long)this._active.remove(player)).longValue()) / 1000.0D;
/*     */           
/*  99 */           if (elapsed >= 1.5D)
/*     */           {
/*     */ 
/*     */ 
/* 103 */             UtilParticle.PlayParticle(mineplex.core.common.util.UtilParticle.ParticleType.HUGE_EXPLOSION, player.getLocation(), 0.0F, 0.5F, 0.0F, 0.0F, 1, 
/* 104 */               UtilParticle.ViewDist.MAX, UtilServer.getPlayers());
/* 105 */             player.getWorld().playSound(player.getLocation(), Sound.EXPLODE, 1.0F, 0.8F);
/*     */             
/* 107 */             player.playEffect(EntityEffect.HURT);
/*     */             
/*     */ 
/* 110 */             HashMap<Player, Double> players = UtilPlayer.getInRadius(player.getLocation(), 8.0D);
/* 111 */             for (Player other : players.keySet())
/*     */             {
/* 113 */               if (!other.equals(player))
/*     */               {
/*     */ 
/* 116 */                 if (!this.Manager.collideEvent(this, other))
/*     */                 {
/*     */ 
/* 119 */                   double mult = ((Double)players.get(other)).doubleValue();
/*     */                   
/*     */ 
/* 122 */                   mineplex.core.common.util.UtilAction.velocity(other, UtilAlg.getTrajectory(player.getLocation(), other.getLocation()), 1.0D + 1.5D * mult, false, 0.0D, 0.5D + 1.0D * mult, 3.0D, true);
/*     */                 } }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public DisguiseCreeper GetDisguise(Player player) {
/* 132 */     DisguiseBase disguise = this.Manager.getDisguiseManager().getDisguise(player);
/* 133 */     if (disguise == null) {
/* 134 */       return null;
/*     */     }
/* 136 */     if (!(disguise instanceof DisguiseCreeper)) {
/* 137 */       return null;
/*     */     }
/* 139 */     return (DisguiseCreeper)disguise;
/*     */   }
/*     */   
/*     */   public int GetSize(Player player)
/*     */   {
/* 144 */     DisguiseCreeper creeper = GetDisguise(player);
/* 145 */     if (creeper == null) { return 0;
/*     */     }
/* 147 */     return creeper.bV();
/*     */   }
/*     */   
/*     */   public void DecreaseSize(Player player)
/*     */   {
/* 152 */     DisguiseCreeper creeper = GetDisguise(player);
/* 153 */     if (creeper == null) { return;
/*     */     }
/* 155 */     creeper.a(-1);
/*     */     
/* 157 */     this.Manager.getDisguiseManager().updateDisguise(creeper);
/*     */   }
/*     */   
/*     */   public void IncreaseSize(Player player)
/*     */   {
/* 162 */     DisguiseCreeper creeper = GetDisguise(player);
/* 163 */     if (creeper == null) { return;
/*     */     }
/* 165 */     creeper.a(1);
/*     */     
/* 167 */     this.Manager.getDisguiseManager().updateDisguise(creeper);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void HeroOwner(PlayerJoinEvent event)
/*     */   {
/* 173 */     if (this.Manager.getClientManager().Get(event.getPlayer()).GetRank().Has(Rank.HERO))
/*     */     {
/* 175 */       ((Donor)this.Manager.getDonationManager().Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(GetName());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Clean(PlayerQuitEvent event)
/*     */   {
/* 182 */     this._active.remove(event.getPlayer());
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphCreeper.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */