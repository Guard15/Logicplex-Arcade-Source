/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.common.util.UtilGear;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.OutfitGadget;
/*     */ import mineplex.core.gadget.types.OutfitGadget.ArmorSlot;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.LeatherArmorMeta;
/*     */ 
/*     */ 
/*     */ public class OutfitRaveSuit
/*     */   extends OutfitGadget
/*     */ {
/*  23 */   private HashMap<String, Integer> _colorPhase = new HashMap();
/*     */   
/*     */ 
/*     */   public OutfitRaveSuit(GadgetManager manager, String name, int cost, OutfitGadget.ArmorSlot slot, Material mat, byte data)
/*     */   {
/*  28 */     super(manager, name, new String[] { "Wear the complete set for", "awesome bonus effects!", "Bonus coming soon..." }, cost, slot, mat, data);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  34 */     ApplyArmor(player);
/*  35 */     this._colorPhase.put(player.getName(), Integer.valueOf(-1));
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  41 */     RemoveArmor(player);
/*  42 */     this._colorPhase.remove(player.getName());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void updateColor(UpdateEvent event)
/*     */   {
/*  48 */     if (event.getType() != UpdateType.TICK)
/*     */       return;
/*     */     Player[] arrayOfPlayer;
/*  51 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/*  53 */       if (IsActive(player))
/*     */       {
/*     */         ItemStack stack;
/*     */         
/*     */ 
/*     */ 
/*  59 */         if (GetSlot() == OutfitGadget.ArmorSlot.Helmet)
/*     */         {
/*  61 */           ItemStack stack = player.getInventory().getHelmet();
/*     */           
/*  63 */           if (!UtilGear.isMat(stack, GetDisplayMaterial()))
/*     */           {
/*  65 */             Disable(player);
/*  66 */             continue;
/*     */           }
/*     */         }
/*  69 */         else if (GetSlot() == OutfitGadget.ArmorSlot.Chest)
/*     */         {
/*  71 */           ItemStack stack = player.getInventory().getChestplate();
/*     */           
/*  73 */           if (!UtilGear.isMat(stack, GetDisplayMaterial()))
/*     */           {
/*  75 */             Disable(player);
/*  76 */             continue;
/*     */           }
/*     */         }
/*  79 */         else if (GetSlot() == OutfitGadget.ArmorSlot.Legs)
/*     */         {
/*  81 */           ItemStack stack = player.getInventory().getLeggings();
/*     */           
/*  83 */           if (!UtilGear.isMat(stack, GetDisplayMaterial()))
/*     */           {
/*  85 */             Disable(player);
/*  86 */             continue;
/*     */           }
/*     */         } else {
/*  89 */           if (GetSlot() != OutfitGadget.ArmorSlot.Boots)
/*     */             continue;
/*  91 */           stack = player.getInventory().getBoots();
/*     */           
/*  93 */           if (!UtilGear.isMat(stack, GetDisplayMaterial()))
/*     */           {
/*  95 */             Disable(player);
/*  96 */             continue;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */         int phase = ((Integer)this._colorPhase.get(player.getName())).intValue();
/*     */         
/* 107 */         LeatherArmorMeta meta = (LeatherArmorMeta)stack.getItemMeta();
/*     */         
/* 109 */         if (phase == -1)
/*     */         {
/* 111 */           meta.setColor(Color.fromRGB(250, 0, 0));
/* 112 */           this._colorPhase.put(player.getName(), Integer.valueOf(0));
/*     */ 
/*     */         }
/* 115 */         else if (phase == 0)
/*     */         {
/* 117 */           meta.setColor(Color.fromRGB(250, Math.min(250, meta.getColor().getGreen() + 25), 0));
/*     */           
/* 119 */           if (meta.getColor().getGreen() >= 250) {
/* 120 */             this._colorPhase.put(player.getName(), Integer.valueOf(1));
/*     */           }
/*     */         }
/* 123 */         else if (phase == 1)
/*     */         {
/* 125 */           meta.setColor(Color.fromRGB(Math.max(0, meta.getColor().getRed() - 25), 250, 0));
/*     */           
/* 127 */           if (meta.getColor().getRed() <= 0) {
/* 128 */             this._colorPhase.put(player.getName(), Integer.valueOf(2));
/*     */           }
/*     */         }
/* 131 */         else if (phase == 2)
/*     */         {
/* 133 */           meta.setColor(Color.fromRGB(0, Math.max(0, meta.getColor().getGreen() - 25), Math.min(250, meta.getColor().getBlue() + 25)));
/*     */           
/* 135 */           if (meta.getColor().getGreen() <= 0) {
/* 136 */             this._colorPhase.put(player.getName(), Integer.valueOf(3));
/*     */           }
/*     */         }
/* 139 */         else if (phase == 3)
/*     */         {
/* 141 */           meta.setColor(Color.fromRGB(Math.min(250, meta.getColor().getRed() + 25), 0, Math.max(0, meta.getColor().getBlue() - 25)));
/*     */           
/* 143 */           if (meta.getColor().getBlue() <= 0) {
/* 144 */             this._colorPhase.put(player.getName(), Integer.valueOf(0));
/*     */           }
/*     */         }
/* 147 */         stack.setItemMeta(meta);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\OutfitRaveSuit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */