/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilEvent;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.event.StackerEvent;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.FallingBlock;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityChangeBlockEvent;
/*     */ import org.bukkit.event.entity.ItemSpawnEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ 
/*     */ public class MorphBlock
/*     */   extends MorphGadget
/*     */ {
/*  30 */   private HashMap<Player, BlockForm> _active = new HashMap();
/*  31 */   private HashSet<FallingBlock> _blocks = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphBlock(GadgetManager manager)
/*     */   {
/*  43 */     super(manager, "Block Morph", new String[] {C.cWhite + "The blockiest block that ever blocked.", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Change Block", C.cYellow + "Stay Still" + C.cGray + " to use " + C.cGreen + "Solidify" }, 30000, Material.EMERALD_BLOCK, (byte)0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  49 */     ApplyArmor(player);
/*     */     
/*  51 */     this._active.put(player, new BlockForm(this, player, Material.EMERALD_BLOCK));
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  57 */     RemoveArmor(player);
/*     */     
/*     */ 
/*  60 */     BlockForm form = (BlockForm)this._active.remove(player);
/*  61 */     if (form != null)
/*     */     {
/*  63 */       form.Remove();
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void formUpdate(UpdateEvent event)
/*     */   {
/*  70 */     if (event.getType() != UpdateType.TICK) {
/*  71 */       return;
/*     */     }
/*  73 */     for (BlockForm form : this._active.values())
/*     */     {
/*  75 */       form.SolidifyUpdate();
/*  76 */       form.FallingBlockCheck();
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void formChange(PlayerInteractEvent event)
/*     */   {
/*  83 */     if (event.getClickedBlock() == null) {
/*  84 */       return;
/*     */     }
/*  86 */     if ((!UtilEvent.isAction(event, UtilEvent.ActionType.L_BLOCK)) && (!UtilEvent.isAction(event, UtilEvent.ActionType.R_BLOCK))) {
/*  87 */       return;
/*     */     }
/*  89 */     if (!UtilBlock.solid(event.getClickedBlock())) {
/*  90 */       return;
/*     */     }
/*  92 */     if (!Recharge.Instance.use(event.getPlayer(), GetName(), 500L, false, false)) {
/*  93 */       return;
/*     */     }
/*  95 */     BlockForm form = (BlockForm)this._active.get(event.getPlayer());
/*     */     
/*  97 */     if (form == null) {
/*  98 */       return;
/*     */     }
/* 100 */     form.Remove();
/*     */     
/* 102 */     this._active.put(event.getPlayer(), new BlockForm(this, event.getPlayer(), event.getClickedBlock().getType()));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void stacker(StackerEvent event)
/*     */   {
/* 108 */     if (this._active.containsKey(event.getEntity())) {
/* 109 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void fallingBlockRegister(FallingBlock block) {
/* 114 */     this._blocks.add(block);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void fallingBlockForm(EntityChangeBlockEvent event)
/*     */   {
/* 120 */     if (this._blocks.remove(event.getEntity()))
/*     */     {
/* 122 */       event.getEntity().remove();
/* 123 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void fallingBlockClean(UpdateEvent event)
/*     */   {
/* 130 */     if (event.getType() != UpdateType.SEC) {
/* 131 */       return;
/*     */     }
/* 133 */     Iterator<FallingBlock> blockIterator = this._blocks.iterator();
/*     */     
/* 135 */     while (blockIterator.hasNext())
/*     */     {
/* 137 */       FallingBlock block = (FallingBlock)blockIterator.next();
/*     */       
/* 139 */       if ((!block.isValid()) || (block.getVehicle() == null))
/*     */       {
/* 141 */         block.remove();
/* 142 */         blockIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void itemSpawnCancel(ItemSpawnEvent event)
/*     */   {
/* 150 */     Iterator<FallingBlock> blockIterator = this._blocks.iterator();
/*     */     
/* 152 */     while (blockIterator.hasNext())
/*     */     {
/* 154 */       FallingBlock block = (FallingBlock)blockIterator.next();
/*     */       
/* 156 */       if (UtilMath.offset(block, event.getEntity()) < 0.1D)
/*     */       {
/* 158 */         block.remove();
/* 159 */         blockIterator.remove();
/* 160 */         event.setCancelled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphBlock.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */