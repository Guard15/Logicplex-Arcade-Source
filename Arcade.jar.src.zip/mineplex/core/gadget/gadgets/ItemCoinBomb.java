/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.FireworkEffect;
/*     */ import org.bukkit.FireworkEffect.Builder;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ItemCoinBomb extends ItemGadget
/*     */ {
/*  32 */   private HashMap<Item, Long> _active = new HashMap();
/*  33 */   private HashSet<Item> _coins = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemCoinBomb(GadgetManager manager)
/*     */   {
/*  45 */     super(manager, "Coin Party Bomb", new String[] {C.cWhite + "It's party time! You will be", C.cWhite + "everyones favourite player", C.cWhite + "when you use one of these!" }, -1, Material.getMaterial(175), (byte)0, 30000L, new Ammo("Coin Party Bomb", "1 Coin Party Bomb", Material.getMaterial(175), (byte)0, new String[] { C.cWhite + "1 Coin Party Bomb to PARTY!" }, 2000, 1));
/*     */   }
/*     */   
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  51 */     Item item = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), new ItemStack(Material.GOLD_BLOCK));
/*  52 */     UtilAction.velocity(item, player.getLocation().getDirection(), 1.0D, false, 0.0D, 0.2D, 1.0D, false);
/*  53 */     this._active.put(item, Long.valueOf(System.currentTimeMillis()));
/*     */     
/*     */     Player[] arrayOfPlayer;
/*  56 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/*  57 */       UtilPlayer.message(other, C.cYellow + C.Bold + player.getName() + C.cWhite + C.Bold + " has thrown a " + C.cYellow + C.Bold + "Coin Party Bomb" + C.cWhite + C.Bold + "!");
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event) {
/*  63 */     if (event.getType() != UpdateType.TICK) {
/*  64 */       return;
/*     */     }
/*  66 */     Iterator<Item> itemIterator = this._active.keySet().iterator();
/*     */     
/*  68 */     while (itemIterator.hasNext())
/*     */     {
/*  70 */       Item item = (Item)itemIterator.next();
/*  71 */       long time = ((Long)this._active.get(item)).longValue();
/*     */       
/*  73 */       if (UtilTime.elapsed(time, 3000L))
/*     */       {
/*  75 */         if (Math.random() > 0.8D) {
/*  76 */           mineplex.core.common.util.UtilFirework.playFirework(item.getLocation(), FireworkEffect.builder().flicker(false).withColor(Color.YELLOW).with(org.bukkit.FireworkEffect.Type.BURST).trail(false).build());
/*     */         } else {
/*  78 */           item.getWorld().playSound(item.getLocation(), Sound.FIREWORK_LAUNCH, 1.0F, 1.0F);
/*     */         }
/*  80 */         Item coin = item.getWorld().dropItem(item.getLocation().add(0.0D, 1.0D, 0.0D), new ItemStack(Material.getMaterial(175)));
/*     */         
/*     */ 
/*  83 */         long passed = System.currentTimeMillis() - time;
/*  84 */         Vector vel = new Vector(Math.sin(passed / 300.0D), 0.0D, Math.cos(passed / 300.0D));
/*     */         
/*  86 */         UtilAction.velocity(coin, vel, Math.abs(Math.sin(passed / 3000.0D)), false, 0.0D, 0.2D + Math.abs(Math.cos(passed / 3000.0D)) * 0.8D, 1.0D, false);
/*     */         
/*  88 */         coin.setPickupDelay(40);
/*     */         
/*  90 */         this._coins.add(coin);
/*     */       }
/*     */       
/*  93 */       if (UtilTime.elapsed(time, 23000L))
/*     */       {
/*  95 */         item.remove();
/*  96 */         itemIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Pickup(PlayerPickupItemEvent event)
/*     */   {
/* 104 */     if (this._active.keySet().contains(event.getItem()))
/*     */     {
/* 106 */       event.setCancelled(true);
/*     */     }
/* 108 */     else if (this._coins.contains(event.getItem()))
/*     */     {
/* 110 */       event.setCancelled(true);
/* 111 */       event.getItem().remove();
/*     */       
/* 113 */       this.Manager.getDonationManager().RewardCoinsLater(GetName() + " Pickup", event.getPlayer(), 4);
/*     */       
/* 115 */       event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.ORB_PICKUP, 1.0F, 2.0F);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void Clean(UpdateEvent event)
/*     */   {
/* 124 */     if (event.getType() != UpdateType.FAST) {
/* 125 */       return;
/*     */     }
/* 127 */     Iterator<Item> coinIterator = this._coins.iterator();
/*     */     
/* 129 */     while (coinIterator.hasNext())
/*     */     {
/* 131 */       Item coin = (Item)coinIterator.next();
/*     */       
/* 133 */       if ((!coin.isValid()) || (coin.getTicksLived() > 1200))
/*     */       {
/* 135 */         coin.remove();
/* 136 */         coinIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemCoinBomb.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */