/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilEvent;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.common.util.UtilFirework;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseRabbit;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.ItemDespawnEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.event.player.PlayerToggleSneakEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ 
/*     */ public class MorphBunny extends MorphGadget
/*     */ {
/*  48 */   private HashSet<Player> _jumpCharge = new HashSet();
/*  49 */   private HashMap<Item, String> _eggs = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphBunny(GadgetManager manager)
/*     */   {
/*  66 */     super(manager, "Easter Bunny Morph", new String[] {C.cWhite + "Happy Easter!", " ", C.cYellow + "Charge Crouch" + C.cGray + " to use " + C.cGreen + "Super Jump", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Hide Easter Egg", " ", C.cRed + C.Bold + "WARNING: " + ChatColor.RESET + "Hide Easter Egg uses 500 Shards", " ", C.cPurple + "Special Limited Time Morph", C.cPurple + "Purchase at www.mineplex.com/shop" }, -1, Material.MONSTER_EGG, (byte)98);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  72 */     ApplyArmor(player);
/*     */     
/*  74 */     DisguiseRabbit disguise = new DisguiseRabbit(player);
/*  75 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  76 */     disguise.setCustomNameVisible(true);
/*  77 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */     
/*  79 */     player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 999999999, 1));
/*  80 */     player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 999999999, 1));
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  86 */     this._jumpCharge.remove(player);
/*  87 */     RemoveArmor(player);
/*  88 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */     
/*  90 */     player.removePotionEffect(PotionEffectType.SPEED);
/*  91 */     player.removePotionEffect(PotionEffectType.JUMP);
/*     */   }
/*     */   
/*     */ 
/*     */   @EventHandler
/*     */   public void jumpTrigger(PlayerToggleSneakEvent event)
/*     */   {
/*  98 */     Player player = event.getPlayer();
/*     */     
/* 100 */     if (!IsActive(player)) {
/* 101 */       return;
/*     */     }
/*     */     
/* 104 */     if (!event.getPlayer().isSneaking())
/*     */     {
/* 106 */       if (UtilEnt.isGrounded(event.getPlayer())) {
/* 107 */         this._jumpCharge.add(event.getPlayer());
/*     */       }
/*     */     }
/* 110 */     else if (this._jumpCharge.remove(event.getPlayer()))
/*     */     {
/* 112 */       float power = player.getExp();
/* 113 */       player.setExp(0.0F);
/*     */       
/* 115 */       UtilAction.velocity(player, power * 4.0F, 0.4D, 4.0D, true);
/*     */       
/* 117 */       player.getWorld().playSound(player.getLocation(), Sound.CAT_HIT, 0.75F, 2.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void jumpBoost(UpdateEvent event)
/*     */   {
/* 124 */     if (event.getType() != UpdateType.TICK) {
/* 125 */       return;
/*     */     }
/* 127 */     Iterator<Player> jumpIter = this._jumpCharge.iterator();
/*     */     
/* 129 */     while (jumpIter.hasNext())
/*     */     {
/* 131 */       Player player = (Player)jumpIter.next();
/*     */       
/* 133 */       if ((!player.isValid()) || (!player.isOnline()) || (!player.isSneaking()))
/*     */       {
/* 135 */         jumpIter.remove();
/*     */       }
/*     */       else
/*     */       {
/* 139 */         player.setExp(Math.min(0.9999F, player.getExp() + 0.03F));
/*     */         
/* 141 */         player.playSound(player.getLocation(), Sound.FIZZ, 0.25F + player.getExp() * 0.5F, 0.5F + player.getExp());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void eggHide(PlayerInteractEvent event) {
/* 148 */     Player player = event.getPlayer();
/*     */     
/* 150 */     if (!IsActive(player)) {
/* 151 */       return;
/*     */     }
/* 153 */     if (!UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/* 154 */       return;
/*     */     }
/* 156 */     if (((Donor)this.Manager.getDonationManager().Get(player.getName())).GetBalance(CurrencyType.Coins) < 500)
/*     */     {
/* 158 */       UtilPlayer.message(player, mineplex.core.common.util.F.main("Gadget", "You do not have enough Coins."));
/* 159 */       return;
/*     */     }
/*     */     
/* 162 */     if (!Recharge.Instance.use(player, "Hide Egg", 30000L, true, false)) {
/* 163 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 169 */     ItemStack eggStack = ItemStackFactory.Instance.CreateStack(Material.MONSTER_EGG, (byte)0, 1, "Hidden Egg" + System.currentTimeMillis());
/* 170 */     eggStack.setDurability((short)98);
/*     */     
/* 172 */     Item egg = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), eggStack);
/* 173 */     UtilAction.velocity(egg, player.getLocation().getDirection(), 0.2D, false, 0.0D, 0.2D, 1.0D, false);
/*     */     
/*     */ 
/* 176 */     this.Manager.getDonationManager().RewardCoinsLater(GetName() + " Egg Hide", player, 65036);
/*     */     
/* 178 */     egg.setPickupDelay(40);
/*     */     
/* 180 */     this._eggs.put(egg, player.getName());
/*     */     
/*     */ 
/* 183 */     Bukkit.broadcastMessage(C.cYellow + C.Bold + player.getName() + 
/* 184 */       ChatColor.RESET + C.Bold + " hid an " + 
/* 185 */       C.cYellow + C.Bold + "Easter Egg" + 
/* 186 */       ChatColor.RESET + C.Bold + " worth " + 
/* 187 */       C.cYellow + C.Bold + "450 Coins");
/*     */     Player[] arrayOfPlayer;
/* 189 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/* 190 */       other.playSound(other.getLocation(), Sound.CAT_HIT, 1.5F, 1.5F);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void eggPickup(PlayerPickupItemEvent event) {
/* 196 */     if ((this._eggs.containsKey(event.getItem())) && (!((String)this._eggs.get(event.getItem())).equals(event.getPlayer().getName())))
/*     */     {
/* 198 */       this._eggs.remove(event.getItem());
/*     */       
/* 200 */       event.setCancelled(true);
/* 201 */       event.getItem().remove();
/*     */       
/* 203 */       this.Manager.getDonationManager().RewardCoinsLater(GetName() + " Egg Pickup", event.getPlayer(), 450);
/*     */       
/* 205 */       event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.ORB_PICKUP, 1.5F, 0.75F);
/* 206 */       event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.ORB_PICKUP, 1.5F, 1.25F);
/*     */       
/* 208 */       UtilFirework.playFirework(event.getItem().getLocation(), org.bukkit.FireworkEffect.Type.BURST, Color.YELLOW, true, true);
/*     */       
/*     */ 
/* 211 */       Bukkit.broadcastMessage(C.cGold + C.Bold + event.getPlayer().getName() + 
/* 212 */         ChatColor.RESET + C.Bold + " found an " + 
/* 213 */         C.cGold + C.Bold + "Easter Egg" + 
/* 214 */         ChatColor.RESET + C.Bold + "! " + this._eggs.size() + " Eggs left!");
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void eggClean(UpdateEvent event)
/*     */   {
/* 221 */     if (event.getType() != UpdateType.FAST) {
/* 222 */       return;
/*     */     }
/* 224 */     Iterator<Item> eggIter = this._eggs.keySet().iterator();
/*     */     
/* 226 */     while (eggIter.hasNext())
/*     */     {
/* 228 */       Item egg = (Item)eggIter.next();
/*     */       
/* 230 */       if ((!egg.isValid()) || (egg.getTicksLived() > 24000))
/*     */       {
/* 232 */         egg.remove();
/* 233 */         eggIter.remove();
/*     */         
/*     */ 
/* 236 */         Bukkit.broadcastMessage(
/* 237 */           ChatColor.RESET + C.Bold + "No one found an " + 
/* 238 */           C.cGold + C.Bold + "Easter Egg" + 
/* 239 */           ChatColor.RESET + C.Bold + "! " + this._eggs.size() + " Eggs left!");
/*     */       }
/*     */       else
/*     */       {
/* 243 */         UtilParticle.PlayParticle(mineplex.core.common.util.UtilParticle.ParticleType.SPELL, egg.getLocation().add(0.0D, 0.1D, 0.0D), 0.1F, 0.1F, 0.1F, 0.0F, 1, 
/* 244 */           UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void eggDespawnCancel(ItemDespawnEvent event)
/*     */   {
/* 252 */     if (this._eggs.containsKey(event.getEntity())) {
/* 253 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphBunny.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */