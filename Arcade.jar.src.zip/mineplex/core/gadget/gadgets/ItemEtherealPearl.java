/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilFirework;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.FireworkEffect;
/*     */ import org.bukkit.FireworkEffect.Builder;
/*     */ import org.bukkit.FireworkEffect.Type;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*     */ import org.bukkit.entity.EnderPearl;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemEtherealPearl
/*     */   extends ItemGadget
/*     */ {
/*  33 */   private HashSet<String> _riding = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemEtherealPearl(GadgetManager manager)
/*     */   {
/*  44 */     super(manager, "Ethereal Pearl", new String[] {C.cWhite + "Take a ride through the skies", C.cWhite + "on your very own Ethereal Pearl!" }, -1, Material.ENDER_PEARL, (byte)0, 500L, new Ammo("Ethereal Pearl", "50 Pearls", Material.ENDER_PEARL, (byte)0, new String[] { C.cWhite + "50 Pearls to get around with!" }, 500, 50));
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  50 */     super.DisableCustom(player);
/*     */   }
/*     */   
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  56 */     player.eject();
/*  57 */     player.leaveVehicle();
/*     */     
/*  59 */     EnderPearl pearl = (EnderPearl)player.launchProjectile(EnderPearl.class);
/*  60 */     pearl.setPassenger(player);
/*     */     
/*     */ 
/*  63 */     UtilPlayer.message(player, F.main("Skill", "You threw " + F.skill(GetName()) + "."));
/*     */     
/*     */ 
/*  66 */     ((CraftPlayer)player).getHandle().spectating = true;
/*     */     
/*  68 */     UtilInv.Update(player);
/*     */     
/*  70 */     this._riding.add(player.getName());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void teleportCancel(PlayerTeleportEvent event)
/*     */   {
/*  76 */     if (!IsActive(event.getPlayer())) {
/*  77 */       return;
/*     */     }
/*  79 */     if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL)
/*     */     {
/*     */ 
/*  82 */       FireworkEffect effect = FireworkEffect.builder().flicker(false).withColor(Color.PURPLE).with(FireworkEffect.Type.BALL).trail(true).build();
/*     */       
/*     */       try
/*     */       {
/*  86 */         UtilFirework.playFirework(event.getTo(), effect);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*  90 */         e.printStackTrace();
/*     */       }
/*     */       
/*  93 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void disableNoCollide(UpdateEvent event)
/*     */   {
/* 100 */     if (event.getType() != UpdateType.SEC)
/*     */       return;
/*     */     Player[] arrayOfPlayer;
/* 103 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/* 104 */       if ((this._riding.contains(player.getName())) && 
/* 105 */         (player.getVehicle() == null))
/*     */       {
/* 107 */         ((CraftPlayer)player).getHandle().spectating = false;
/* 108 */         this._riding.remove(player.getName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void clean(PlayerQuitEvent event) {
/* 115 */     this._riding.remove(event.getPlayer().getName());
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemEtherealPearl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */