/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.OutfitGadget;
/*    */ import mineplex.core.gadget.types.OutfitGadget.ArmorSlot;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class OutfitSpaceSuit
/*    */   extends OutfitGadget
/*    */ {
/*    */   public OutfitSpaceSuit(GadgetManager manager, String name, int cost, OutfitGadget.ArmorSlot slot, Material mat, byte data)
/*    */   {
/* 14 */     super(manager, name, new String[] { "Wear the complete set for", "awesome bonus effects!", "Bonus coming soon..." }, cost, slot, mat, data);
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 20 */     ApplyArmor(player);
/*    */   }
/*    */   
/*    */ 
/*    */   public void DisableCustom(Player player)
/*    */   {
/* 26 */     RemoveArmor(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\OutfitSpaceSuit.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */