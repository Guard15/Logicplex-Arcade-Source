/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilEvent;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseChicken;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Egg;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphChicken
/*     */   extends MorphGadget
/*     */ {
/*     */   public MorphChicken(GadgetManager manager)
/*     */   {
/*  44 */     super(manager, "Chicken Morph", new String[] {C.cWhite + "Soar through the air like a fat Chicken!", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Egg Shot", C.cYellow + "Double Jump" + C.cGray + " to use " + C.cGreen + "Flap" }, 20000, Material.FEATHER, (byte)0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  50 */     ApplyArmor(player);
/*     */     
/*  52 */     DisguiseChicken disguise = new DisguiseChicken(player);
/*  53 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  54 */     disguise.setCustomNameVisible(true);
/*  55 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  61 */     RemoveArmor(player);
/*  62 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */     
/*  64 */     player.setAllowFlight(false);
/*  65 */     player.setFlying(false);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Egg(PlayerInteractEvent event)
/*     */   {
/*  71 */     Player player = event.getPlayer();
/*     */     
/*  73 */     if (!IsActive(player)) {
/*  74 */       return;
/*     */     }
/*  76 */     if (!UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/*  77 */       return;
/*     */     }
/*  79 */     if (!Recharge.Instance.use(player, GetName(), 100L, false, false)) {
/*  80 */       return;
/*     */     }
/*  82 */     Vector offset = player.getLocation().getDirection();
/*  83 */     if (offset.getY() < 0.0D) {
/*  84 */       offset.setY(0);
/*     */     }
/*  86 */     Egg egg = (Egg)player.getWorld().spawn(player.getLocation().add(0.0D, 0.5D, 0.0D).add(offset), Egg.class);
/*  87 */     egg.setVelocity(player.getLocation().getDirection().add(new Vector(0.0D, 0.2D, 0.0D)));
/*  88 */     egg.setShooter(player);
/*     */     
/*     */ 
/*  91 */     player.getWorld().playSound(player.getLocation(), Sound.CHICKEN_EGG_POP, 0.5F, 1.0F);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Flap(PlayerToggleFlightEvent event)
/*     */   {
/*  97 */     Player player = event.getPlayer();
/*     */     
/*  99 */     if (player.getGameMode() == GameMode.CREATIVE) {
/* 100 */       return;
/*     */     }
/* 102 */     if (!IsActive(player)) {
/* 103 */       return;
/*     */     }
/* 105 */     event.setCancelled(true);
/* 106 */     player.setFlying(false);
/*     */     
/*     */ 
/* 109 */     player.setAllowFlight(false);
/*     */     
/* 111 */     double power = 0.4D + 0.5D * player.getExp();
/*     */     
/*     */ 
/* 114 */     UtilAction.velocity(player, player.getLocation().getDirection(), power, true, power, 0.0D, 10.0D, true);
/*     */     
/*     */ 
/* 117 */     player.getWorld().playSound(player.getLocation(), Sound.BAT_TAKEOFF, (float)(0.3D + player.getExp()), (float)(Math.random() / 2.0D + 1.0D));
/*     */     
/*     */ 
/* 120 */     Recharge.Instance.use(player, GetName(), 80L, false, false);
/*     */     
/*     */ 
/* 123 */     player.setExp(Math.max(0.0F, player.getExp() - 0.11111111F));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void FlapUpdate(UpdateEvent event)
/*     */   {
/* 129 */     if (event.getType() != UpdateType.TICK) {
/* 130 */       return;
/*     */     }
/* 132 */     for (Player player : GetActive())
/*     */     {
/* 134 */       if (player.getGameMode() != GameMode.CREATIVE)
/*     */       {
/*     */ 
/* 137 */         if ((UtilEnt.isGrounded(player)) || (UtilBlock.solid(player.getLocation().getBlock().getRelative(BlockFace.DOWN))))
/*     */         {
/* 139 */           player.setExp(0.999F);
/* 140 */           player.setAllowFlight(true);
/*     */         }
/* 142 */         else if ((Recharge.Instance.usable(player, GetName())) && (player.getExp() > 0.0F))
/*     */         {
/* 144 */           player.setAllowFlight(true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void EggHit(EntityDamageByEntityEvent event) {
/* 152 */     if ((event.getDamager() instanceof Egg))
/*     */     {
/* 154 */       event.getEntity().setVelocity(new Vector(0, 0, 0));
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphChicken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */