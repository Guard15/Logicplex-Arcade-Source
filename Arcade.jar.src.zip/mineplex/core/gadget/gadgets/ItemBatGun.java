/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.preferences.PreferencesManager;
/*     */ import mineplex.core.preferences.UserPreferences;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Bat;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ItemBatGun extends ItemGadget
/*     */ {
/*  33 */   private HashMap<Player, Long> _active = new HashMap();
/*  34 */   private HashMap<Player, Location> _velocity = new HashMap();
/*  35 */   private HashMap<Player, ArrayList<Bat>> _bats = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemBatGun(GadgetManager manager)
/*     */   {
/*  46 */     super(manager, "Bat Blaster", new String[] {C.cWhite + "Launch waves of annoying bats", C.cWhite + "at people you don't like!" }, -1, Material.IRON_BARDING, (byte)0, 5000L, new Ammo("Bat Blaster", "50 Bats", Material.IRON_BARDING, (byte)0, new String[] { C.cWhite + "50 Bats for your Bat Blaster!" }, 500, 50));
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  52 */     super.DisableCustom(player);
/*     */     
/*  54 */     Clear(player);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  61 */     this._velocity.put(player, player.getEyeLocation());
/*  62 */     this._active.put(player, Long.valueOf(System.currentTimeMillis()));
/*     */     
/*  64 */     this._bats.put(player, new ArrayList());
/*     */     
/*  66 */     for (int i = 0; i < 16; i++) {
/*  67 */       ((ArrayList)this._bats.get(player)).add((Bat)player.getWorld().spawn(player.getEyeLocation(), Bat.class));
/*     */     }
/*     */     
/*  70 */     UtilPlayer.message(player, F.main("Skill", "You used " + F.skill(GetName()) + "."));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event)
/*     */   {
/*  76 */     if (event.getType() != UpdateType.TICK)
/*     */       return;
/*     */     Player[] arrayOfPlayer1;
/*  79 */     int j = (arrayOfPlayer1 = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer1[i];
/*     */       
/*  81 */       if (this._active.containsKey(cur))
/*     */       {
/*     */ 
/*  84 */         if (UtilTime.elapsed(((Long)this._active.get(cur)).longValue(), 3000L))
/*     */         {
/*  86 */           Clear(cur);
/*     */         }
/*     */         else
/*     */         {
/*  90 */           Location loc = (Location)this._velocity.get(cur);
/*     */           
/*     */ 
/*  93 */           for (Bat bat : (ArrayList)this._bats.get(cur))
/*     */           {
/*  95 */             if (bat.isValid())
/*     */             {
/*  97 */               Vector rand = new Vector((Math.random() - 0.5D) / 3.0D, (Math.random() - 0.5D) / 3.0D, (Math.random() - 0.5D) / 3.0D);
/*  98 */               bat.setVelocity(loc.getDirection().clone().multiply(0.5D).add(rand));
/*     */               Player[] arrayOfPlayer2;
/* 100 */               int m = (arrayOfPlayer2 = UtilServer.getPlayers()).length; for (int k = 0; k < m; k++) { Player other = arrayOfPlayer2[k];
/*     */                 
/* 102 */                 if (!other.equals(cur))
/*     */                 {
/*     */ 
/* 105 */                   if ((((UserPreferences)this.Manager.getPreferencesManager().Get(other)).HubGames) && (((UserPreferences)this.Manager.getPreferencesManager().Get(other)).ShowPlayers))
/*     */                   {
/*     */ 
/* 108 */                     if (Recharge.Instance.usable(other, "Hit by Bat"))
/*     */                     {
/*     */ 
/* 111 */                       if (UtilEnt.hitBox(bat.getLocation(), other, 2.0D, null))
/*     */                       {
/* 113 */                         if (!this.Manager.collideEvent(this, other))
/*     */                         {
/*     */ 
/*     */ 
/* 117 */                           UtilAction.velocity(other, UtilAlg.getTrajectory(cur, other), 0.4D, false, 0.0D, 0.2D, 10.0D, true);
/*     */                           
/*     */ 
/* 120 */                           bat.getWorld().playSound(bat.getLocation(), org.bukkit.Sound.BAT_HURT, 1.0F, 1.0F);
/* 121 */                           UtilParticle.PlayParticle(UtilParticle.ParticleType.LARGE_SMOKE, bat.getLocation(), 0.0F, 0.0F, 0.0F, 0.0F, 3, 
/* 122 */                             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */                           
/* 124 */                           bat.remove();
/*     */                           
/*     */ 
/* 127 */                           Recharge.Instance.useForce(other, "Hit by Bat", 200L);
/*     */                         } } } } }
/*     */               }
/*     */             } }
/*     */         } }
/*     */     }
/*     */   }
/*     */   
/*     */   public void Clear(Player player) {
/* 136 */     this._active.remove(player);
/* 137 */     this._velocity.remove(player);
/* 138 */     if (this._bats.containsKey(player))
/*     */     {
/* 140 */       for (Bat bat : (ArrayList)this._bats.get(player))
/*     */       {
/* 142 */         if (bat.isValid()) {
/* 143 */           UtilParticle.PlayParticle(UtilParticle.ParticleType.LARGE_SMOKE, bat.getLocation(), 0.0F, 0.0F, 0.0F, 0.0F, 3, 
/* 144 */             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */         }
/* 146 */         bat.remove();
/*     */       }
/*     */       
/* 149 */       this._bats.remove(player);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemBatGun.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */