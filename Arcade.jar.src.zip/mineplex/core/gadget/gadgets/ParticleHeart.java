/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ParticleGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ParticleHeart extends ParticleGadget
/*     */ {
/*  31 */   private HashMap<Player, HashMap<Player, Location>> _target = new HashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParticleHeart(GadgetManager manager)
/*     */   {
/*  42 */     super(manager, "I Heart You", new String[] {C.cWhite + "With these particles, you can", C.cWhite + "show off how much you heart", C.cWhite + "everyone on Mineplex!" }, -2, Material.APPLE, (byte)0);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playParticle(UpdateEvent event)
/*     */   {
/*  48 */     if (event.getType() != mineplex.core.updater.UpdateType.FASTEST) {
/*  49 */       return;
/*     */     }
/*     */     
/*  52 */     for (Player player : GetActive())
/*     */     {
/*  54 */       if (shouldDisplay(player))
/*     */       {
/*     */ 
/*     */ 
/*  58 */         if (!this._target.containsKey(player)) {
/*  59 */           this._target.put(player, new HashMap());
/*     */         }
/*  61 */         if (Recharge.Instance.use(player, GetName(), 500L, false, false)) {
/*     */           Player[] arrayOfPlayer;
/*  63 */           int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/*     */             
/*  65 */             if (!other.equals(player))
/*     */             {
/*     */ 
/*  68 */               if (UtilPlayer.isSpectator(other))
/*     */               {
/*     */ 
/*  71 */                 if (!((HashMap)this._target.get(player)).containsKey(other))
/*     */                 {
/*     */ 
/*  74 */                   if (UtilMath.offset(player, other) <= 6.0D)
/*     */                   {
/*     */ 
/*  77 */                     ((HashMap)this._target.get(player)).put(other, player.getLocation().add(0.0D, 1.0D, 0.0D));
/*     */                     
/*  79 */                     break;
/*     */                   } } } }
/*     */           }
/*     */         }
/*  83 */         if (this.Manager.isMoving(player)) {
/*  84 */           UtilParticle.PlayParticle(UtilParticle.ParticleType.HEART, player.getLocation().add(0.0D, 1.0D, 0.0D), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/*  85 */             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */         } else {
/*  87 */           UtilParticle.PlayParticle(UtilParticle.ParticleType.HEART, player.getLocation().add(0.0D, 1.0D, 0.0D), 0.5F, 0.5F, 0.5F, 0.0F, 1, 
/*  88 */             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */         }
/*     */       }
/*     */     }
/*     */     Iterator<Map.Entry<Player, Location>> heartIterator;
/*  93 */     for (??? = this._target.values().iterator(); ???.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*  97 */         heartIterator.hasNext())
/*     */     {
/*  93 */       HashMap<Player, Location> heart = (HashMap)???.next();
/*     */       
/*  95 */       heartIterator = heart.entrySet().iterator();
/*     */       
/*  97 */       continue;
/*     */       
/*  99 */       Object entry = (Map.Entry)heartIterator.next();
/*     */       
/* 101 */       ((Location)((Map.Entry)entry).getValue()).add(UtilAlg.getTrajectory((Location)((Map.Entry)entry).getValue(), ((Player)((Map.Entry)entry).getKey()).getEyeLocation()).multiply(0.6D));
/*     */       
/* 103 */       UtilParticle.PlayParticle(UtilParticle.ParticleType.HEART, (Location)((Map.Entry)entry).getValue(), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 104 */         UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */       
/* 106 */       if (UtilMath.offset((Location)((Map.Entry)entry).getValue(), ((Player)((Map.Entry)entry).getKey()).getEyeLocation()) < 0.6D) {
/* 107 */         heartIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/* 115 */     if (this._active.remove(player)) {
/* 116 */       UtilPlayer.message(player, F.main("Gadget", "You unsummoned " + F.elem(GetName()) + "."));
/*     */     }
/* 118 */     clean(player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void quit(PlayerQuitEvent event)
/*     */   {
/* 124 */     clean(event.getPlayer());
/*     */   }
/*     */   
/*     */   private void clean(Player player)
/*     */   {
/* 129 */     this._target.remove(player);
/*     */     
/* 131 */     for (HashMap<Player, Location> map : this._target.values()) {
/* 132 */       map.remove(player);
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleHeart.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */