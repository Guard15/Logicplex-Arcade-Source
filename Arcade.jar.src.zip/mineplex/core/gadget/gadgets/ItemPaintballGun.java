/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mineplex.core.blockrestore.BlockRestore;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.event.GadgetBlockEvent;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.EnderPearl;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.ProjectileHitEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ItemPaintballGun extends ItemGadget
/*     */ {
/*  32 */   private HashSet<Projectile> _balls = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemPaintballGun(GadgetManager manager)
/*     */   {
/*  42 */     super(manager, "Paintball Gun", new String[] {C.cWhite + "PEW PEW PEW PEW!" }, -1, Material.GOLD_BARDING, (byte)0, 200L, new Ammo("Paintball Gun", "100 Paintballs", Material.GOLD_BARDING, (byte)0, new String[] { C.cWhite + "100 Paintballs for you to shoot!" }, 500, 100));
/*     */   }
/*     */   
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  48 */     Projectile proj = player.launchProjectile(EnderPearl.class);
/*  49 */     proj.setVelocity(proj.getVelocity().multiply(2));
/*  50 */     this._balls.add(proj);
/*     */     
/*     */ 
/*  53 */     player.getWorld().playSound(player.getLocation(), org.bukkit.Sound.CHICKEN_EGG_POP, 1.5F, 1.2F);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Paint(ProjectileHitEvent event)
/*     */   {
/*  59 */     if (!this._balls.remove(event.getEntity())) {
/*  60 */       return;
/*     */     }
/*  62 */     Location loc = event.getEntity().getLocation().add(event.getEntity().getVelocity());
/*  63 */     loc.getWorld().playEffect(loc, org.bukkit.Effect.STEP_SOUND, 49);
/*     */     
/*  65 */     byte color = 2;
/*  66 */     double r = Math.random();
/*  67 */     if (r > 0.8D) { color = 4;
/*  68 */     } else if (r > 0.6D) { color = 5;
/*  69 */     } else if (r > 0.4D) { color = 9;
/*  70 */     } else if (r > 0.2D) { color = 14;
/*     */     }
/*  72 */     for (Block block : UtilBlock.getInRadius(loc, 3.0D).keySet())
/*     */     {
/*  74 */       if (block.getType() == Material.PORTAL) {
/*  75 */         return;
/*     */       }
/*  77 */       if (block.getType() == Material.CACTUS) {
/*  78 */         return;
/*     */       }
/*  80 */       if (block.getType() == Material.SUGAR_CANE_BLOCK) {
/*  81 */         return;
/*     */       }
/*     */     }
/*  84 */     List<Block> blocks = new ArrayList();
/*  85 */     blocks.addAll(UtilBlock.getInRadius(loc, 1.5D).keySet());
/*     */     
/*  87 */     GadgetBlockEvent gadgetEvent = new GadgetBlockEvent(this, blocks);
/*  88 */     org.bukkit.Bukkit.getServer().getPluginManager().callEvent(gadgetEvent);
/*     */     
/*  90 */     if (gadgetEvent.isCancelled()) {
/*  91 */       return;
/*     */     }
/*  93 */     for (Block block : gadgetEvent.getBlocks())
/*     */     {
/*  95 */       if (UtilBlock.solid(block))
/*     */       {
/*     */ 
/*  98 */         if (block.getType() == Material.CARPET) {
/*  99 */           this.Manager.getBlockRestore().Add(block, 171, color, 4000L);
/*     */         } else
/* 101 */           this.Manager.getBlockRestore().Add(block, 35, color, 4000L);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Teleport(PlayerTeleportEvent event) {
/* 108 */     if (event.getCause() == PlayerTeleportEvent.TeleportCause.ENDER_PEARL) {
/* 109 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void cleanupBalls(UpdateEvent event) {
/* 115 */     if (event.getType() != mineplex.core.updater.UpdateType.SLOW) {
/* 116 */       return;
/*     */     }
/* 118 */     for (Iterator<Projectile> ballIterator = this._balls.iterator(); ballIterator.hasNext();)
/*     */     {
/* 120 */       Projectile ball = (Projectile)ballIterator.next();
/*     */       
/* 122 */       if ((ball.isDead()) || (!ball.isValid())) {
/* 123 */         ballIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemPaintballGun.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */