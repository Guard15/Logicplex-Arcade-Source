/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.blood.BloodEvent;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ParticleGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Arrow;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.Projectile;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.ProjectileHitEvent;
/*     */ import org.bukkit.event.entity.ProjectileLaunchEvent;
/*     */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*     */ 
/*     */ public class ParticleBlizzard extends ParticleGadget
/*     */ {
/*  29 */   private HashSet<Arrow> _arrows = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParticleBlizzard(GadgetManager manager)
/*     */   {
/*  42 */     super(manager, "Frost Lord", new String[] {C.cWhite + "You are a mighty frost lord.", C.cWhite + "Your double jumps and arrows", C.cWhite + "are enchanted with snow powers.", " ", C.cPurple + "No longer available" }, -1, Material.SNOW_BALL, (byte)0);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playParticle(UpdateEvent event)
/*     */   {
/*  48 */     if (event.getType() != UpdateType.TICK) {
/*  49 */       return;
/*     */     }
/*  51 */     for (Player player : GetActive())
/*     */     {
/*  53 */       if (shouldDisplay(player))
/*     */       {
/*     */ 
/*  56 */         if (this.Manager.isMoving(player))
/*     */         {
/*  58 */           UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, player.getLocation().add(0.0D, 1.0D, 0.0D), 0.2F, 0.2F, 0.2F, 0.0F, 4, 
/*  59 */             UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */         }
/*     */         else
/*     */         {
/*  63 */           player.getWorld().playSound(player.getLocation(), Sound.AMBIENCE_RAIN, 0.015F, 0.2F);
/*     */           
/*  65 */           double scale = player.getTicksLived() % 50 / 50.0D;
/*     */           
/*  67 */           for (int i = 0; i < 8; i++)
/*     */           {
/*  69 */             double r = (1.0D - scale) * 3.141592653589793D * 2.0D;
/*     */             
/*  71 */             double x = Math.sin(r + i * 0.7853981633974483D) * (r % 12.566370614359172D) * 0.4D;
/*  72 */             double z = Math.cos(r + i * 0.7853981633974483D) * (r % 12.566370614359172D) * 0.4D;
/*     */             
/*  74 */             UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, player.getLocation().add(x, scale * 3.0D, z), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/*  75 */               UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */             
/*  77 */             if ((scale > 0.95D) && (Recharge.Instance.use(player, GetName(), 1000L, false, false)))
/*     */             {
/*  79 */               UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, player.getLocation().add(0.0D, scale * 3.5D, 0.0D), 0.0F, 0.0F, 0.0F, 0.2F, 60, 
/*  80 */                 UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*  81 */               player.getWorld().playSound(player.getLocation(), Sound.STEP_SNOW, 1.0F, 1.5F);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void jump(PlayerToggleFlightEvent event) {
/*  91 */     if (!shouldDisplay(event.getPlayer())) {
/*  92 */       return;
/*     */     }
/*  94 */     if ((!event.getPlayer().isFlying()) && 
/*  95 */       (IsActive(event.getPlayer()))) {
/*  96 */       UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, event.getPlayer().getLocation(), 0.0F, 0.0F, 0.0F, 0.6F, 100, 
/*  97 */         UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void arrow(ProjectileLaunchEvent event) {
/* 103 */     if (this.Manager.hideParticles()) {
/* 104 */       return;
/*     */     }
/* 106 */     if ((event.getEntity() instanceof Arrow))
/*     */     {
/* 108 */       if (event.getEntity().getShooter() != null)
/*     */       {
/* 110 */         if (GetActive().contains(event.getEntity().getShooter()))
/*     */         {
/* 112 */           this._arrows.add((Arrow)event.getEntity());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void arrow(ProjectileHitEvent event)
/*     */   {
/* 121 */     if (!this._arrows.remove(event.getEntity())) {
/* 122 */       return;
/*     */     }
/* 124 */     UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, event.getEntity().getLocation(), 0.0F, 0.0F, 0.0F, 0.4F, 12, 
/* 125 */       UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void arrowClean(UpdateEvent event)
/*     */   {
/* 131 */     if (event.getType() != UpdateType.TICK) {
/* 132 */       return;
/*     */     }
/* 134 */     for (Iterator<Arrow> arrowIterator = this._arrows.iterator(); arrowIterator.hasNext();)
/*     */     {
/* 136 */       Arrow arrow = (Arrow)arrowIterator.next();
/*     */       
/* 138 */       if ((arrow.isDead()) || (!arrow.isValid()) || (arrow.isOnGround()))
/*     */       {
/* 140 */         arrowIterator.remove();
/*     */       }
/*     */       else
/*     */       {
/* 144 */         UtilParticle.PlayParticle(UtilParticle.ParticleType.SNOW_SHOVEL, arrow.getLocation(), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 145 */           UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void death(BloodEvent event)
/*     */   {
/* 153 */     if (event.getPlayer() == null) {
/* 154 */       return;
/*     */     }
/* 156 */     if (!IsActive(event.getPlayer())) {
/* 157 */       return;
/*     */     }
/* 159 */     if (!shouldDisplay(event.getPlayer())) {
/* 160 */       return;
/*     */     }
/* 162 */     event.setItem(Material.SNOW_BALL, (byte)0);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleBlizzard.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */