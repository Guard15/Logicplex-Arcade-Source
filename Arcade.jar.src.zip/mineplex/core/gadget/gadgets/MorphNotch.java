/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.core.common.util.ProfileLoader;
/*    */ import mineplex.core.common.util.UUIDFetcher;
/*    */ import mineplex.core.common.util.UtilEvent;
/*    */ import mineplex.core.common.util.UtilEvent.ActionType;
/*    */ import mineplex.core.disguise.DisguiseManager;
/*    */ import mineplex.core.disguise.disguises.DisguisePlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.MorphGadget;
/*    */ import mineplex.core.recharge.Recharge;
/*    */ import net.minecraft.util.com.mojang.authlib.GameProfile;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ 
/*    */ public class MorphNotch
/*    */   extends MorphGadget
/*    */ {
/* 22 */   private GameProfile _notchProfile = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public MorphNotch(GadgetManager manager)
/*    */   {
/* 32 */     super(manager, "Notch", new String[] {"Who wouldn't want to be Notch?!" }, 50000, Material.SKULL_ITEM, (byte)3);
/*    */     
/* 34 */     this._notchProfile = new ProfileLoader(UUIDFetcher.getUUIDOf("Notch").toString(), "Notch").loadProfile();
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 40 */     ApplyArmor(player);
/*    */     
/* 42 */     DisguisePlayer disguise = new DisguisePlayer(player, this._notchProfile);
/* 43 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*    */   }
/*    */   
/*    */ 
/*    */   public void DisableCustom(Player player)
/*    */   {
/* 49 */     RemoveArmor(player);
/* 50 */     this.Manager.getDisguiseManager().undisguise(player);
/*    */   }
/*    */   
/*    */ 
/*    */   public void Action(PlayerInteractEvent event)
/*    */   {
/* 56 */     Player player = event.getPlayer();
/*    */     
/* 58 */     if (!IsActive(player)) {
/* 59 */       return;
/*    */     }
/* 61 */     if (!UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/* 62 */       return;
/*    */     }
/* 64 */     if (!Recharge.Instance.use(player, GetName(), 1500L, false, false)) {
/* 65 */       return;
/*    */     }
/* 67 */     player.sendMessage("You have enforced the EULA.");
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphNotch.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */