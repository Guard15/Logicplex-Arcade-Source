/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilAction;
/*    */ import mineplex.core.common.util.UtilAlg;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ItemGadget;
/*    */ import mineplex.core.itemstack.ItemStackFactory;
/*    */ import mineplex.core.projectile.IThrown;
/*    */ import mineplex.core.projectile.ProjectileManager;
/*    */ import mineplex.core.projectile.ProjectileUser;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import org.bukkit.EntityEffect;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.block.Block;
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.entity.Item;
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemFleshHook
/*    */   extends ItemGadget
/*    */   implements IThrown
/*    */ {
/*    */   public ItemFleshHook(GadgetManager manager)
/*    */   {
/* 37 */     super(manager, "Flesh Hook", new String[] {C.cWhite + "Make new friends by throwing a hook", C.cWhite + "into their face and pulling them", C.cWhite + "towards you!" }, -1, Material.getMaterial(131), (byte)0, 2000L, new Ammo("Flesh Hook", "50 Flesh Hooks", Material.getMaterial(131), (byte)0, new String[] { C.cWhite + "50 Flesh Hooks for you to use!" }, 1000, 50));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void ActivateCustom(Player player)
/*    */   {
/* 44 */     Item item = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), ItemStackFactory.Instance.CreateStack(131));
/* 45 */     UtilAction.velocity(item, player.getLocation().getDirection(), 
/* 46 */       1.6D, false, 0.0D, 0.2D, 10.0D, false);
/*    */     
/* 48 */     this.Manager.getProjectileManager().AddThrow(item, player, this, -1L, true, true, true, 
/* 49 */       Sound.FIRE_IGNITE, 1.4F, 0.8F, UtilParticle.ParticleType.CRIT, null, 0, UpdateType.TICK, 0.5F);
/*    */     
/*    */ 
/* 52 */     UtilPlayer.message(player, F.main("Skill", "You used " + F.skill(GetName()) + "."));
/*    */     
/*    */ 
/* 55 */     item.getWorld().playSound(item.getLocation(), Sound.IRONGOLEM_THROW, 2.0F, 0.8F);
/*    */   }
/*    */   
/*    */ 
/*    */   public void Collide(LivingEntity target, Block block, ProjectileUser data)
/*    */   {
/* 61 */     data.GetThrown().remove();
/*    */     
/* 63 */     if (!(data.GetThrower() instanceof Player)) {
/* 64 */       return;
/*    */     }
/* 66 */     Player player = (Player)data.GetThrower();
/*    */     
/* 68 */     if (target == null) {
/* 69 */       return;
/*    */     }
/* 71 */     if (((target instanceof Player)) && 
/* 72 */       (this.Manager.collideEvent(this, (Player)target))) {
/* 73 */       return;
/*    */     }
/*    */     
/* 76 */     UtilAction.velocity(target, 
/* 77 */       UtilAlg.getTrajectory(target.getLocation(), player.getLocation()), 
/* 78 */       3.0D, false, 0.0D, 0.8D, 1.5D, true);
/*    */     
/*    */ 
/* 81 */     target.playEffect(EntityEffect.HURT);
/*    */     
/*    */ 
/* 84 */     UtilPlayer.message(target, F.main("Skill", F.name(player.getName()) + " hit you with " + F.skill(GetName()) + "."));
/*    */   }
/*    */   
/*    */ 
/*    */   public void Idle(ProjectileUser data)
/*    */   {
/* 90 */     data.GetThrown().remove();
/*    */   }
/*    */   
/*    */ 
/*    */   public void Expire(ProjectileUser data)
/*    */   {
/* 96 */     data.GetThrown().remove();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemFleshHook.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */