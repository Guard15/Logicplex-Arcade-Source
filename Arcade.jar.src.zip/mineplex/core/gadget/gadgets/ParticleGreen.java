/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.UtilParticle;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ParticleGadget;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleGreen
/*    */   extends ParticleGadget
/*    */ {
/*    */   public ParticleGreen(GadgetManager manager)
/*    */   {
/* 31 */     super(manager, "Green Ring", new String[] {C.cWhite + "With these sparkles, you", C.cWhite + "can now sparkle while you", C.cWhite + "sparkle with CaptainSparklez." }, -2, Material.EMERALD, (byte)0);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void playParticle(UpdateEvent event)
/*    */   {
/* 37 */     if (event.getType() != UpdateType.TICK) {
/* 38 */       return;
/*    */     }
/* 40 */     for (Player player : GetActive())
/*    */     {
/* 42 */       if (shouldDisplay(player))
/*    */       {
/*    */ 
/* 45 */         float x = (float)(Math.sin(player.getTicksLived() / 7.0D) * 1.0D);
/* 46 */         float z = (float)(Math.cos(player.getTicksLived() / 7.0D) * 1.0D);
/* 47 */         float y = (float)(Math.cos(player.getTicksLived() / 17.0D) * 1.0D + 1.0D);
/*    */         
/* 49 */         UtilParticle.PlayParticle(UtilParticle.ParticleType.HAPPY_VILLAGER, player.getLocation().add(x, y, z), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 50 */           UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleGreen.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */