/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftFallingSand;
/*     */ import org.bukkit.entity.Bat;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.FallingBlock;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ 
/*     */ public class ItemFootball extends ItemGadget
/*     */ {
/*  33 */   private HashSet<Bat> _active = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemFootball(GadgetManager manager)
/*     */   {
/*  44 */     super(manager, "Football", new String[] {C.cWhite + "An amazing souvenier from the", C.cWhite + "Mineplex World Cup in 2053!" }, -1, Material.CLAY_BALL, (byte)3, 1000L, new Ammo("Melon Launcher", "10 Footballs", Material.CLAY_BALL, (byte)0, new String[] { C.cWhite + "10 Footballs to play with" }, 1000, 10));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  51 */     FallingBlock ball = player.getWorld().spawnFallingBlock(player.getLocation().add(0.0D, 1.0D, 0.0D), Material.SKULL, (byte)3);
/*     */     
/*  53 */     Bat bat = (Bat)player.getWorld().spawn(player.getLocation(), Bat.class);
/*  54 */     UtilEnt.Vegetate(bat);
/*  55 */     UtilEnt.ghost(bat, true, true);
/*  56 */     UtilEnt.silence(bat, true);
/*     */     
/*  58 */     bat.setPassenger(ball);
/*     */     
/*  60 */     this._active.add(bat);
/*     */     
/*     */ 
/*  63 */     UtilPlayer.message(player, F.main("Skill", "You used " + F.skill(GetName()) + "."));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Collide(UpdateEvent event)
/*     */   {
/*  69 */     if (event.getType() != UpdateType.TICK) return;
/*     */     int j;
/*     */     int i;
/*  72 */     for (Iterator localIterator = this._active.iterator(); localIterator.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */         i < j)
/*     */     {
/*  72 */       Bat ball = (Bat)localIterator.next();
/*     */       
/*  74 */       if (ball.getPassenger() != null)
/*     */       {
/*  76 */         ((CraftFallingSand)ball.getPassenger()).getHandle().ticksLived = 1;
/*  77 */         ball.getPassenger().setTicksLived(1);
/*     */       }
/*     */       Player[] arrayOfPlayer;
/*  80 */       j = (arrayOfPlayer = UtilServer.getPlayers()).length;i = 0; continue;Player other = arrayOfPlayer[i];
/*     */       
/*  82 */       if (UtilMath.offset(ball, other) <= 1.5D)
/*     */       {
/*     */ 
/*  85 */         if (Recharge.Instance.use(other, GetName() + " Bump", 200L, false, false))
/*     */         {
/*     */ 
/*     */ 
/*  89 */           double power = 0.4D;
/*  90 */           if (other.isSprinting()) {
/*  91 */             power = 0.7D;
/*     */           }
/*     */           
/*  94 */           UtilAction.velocity(ball, UtilAlg.getTrajectory2d(other, ball), power, false, 0.0D, 0.0D, 0.0D, false);
/*     */           
/*  96 */           other.getWorld().playSound(other.getLocation(), Sound.ITEM_PICKUP, 0.2F, 0.2F);
/*     */         }
/*     */       }
/*  80 */       i++;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void Snort(PlayerInteractEvent event)
/*     */   {
/* 104 */     Player player = event.getPlayer();
/*     */     
/* 106 */     if (!mineplex.core.common.util.UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/* 107 */       return;
/*     */     }
/* 109 */     for (Bat ball : this._active)
/*     */     {
/* 111 */       if (UtilMath.offset(ball, player) <= 2.0D)
/*     */       {
/*     */ 
/* 114 */         if (!Recharge.Instance.use(player, GetName() + " Kick", 1000L, false, false)) {
/* 115 */           return;
/*     */         }
/* 117 */         Recharge.Instance.useForce(player, GetName() + " Bump", 1000L);
/*     */         
/*     */ 
/* 120 */         UtilAction.velocity(ball, UtilAlg.getTrajectory2d(player, ball), 2.0D, false, 0.0D, 0.0D, 0.0D, false);
/*     */         
/* 122 */         player.getWorld().playSound(player.getLocation(), Sound.ITEM_PICKUP, 1.0F, 0.1F);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemFootball.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */