/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilFirework;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseEnderman;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.FireworkEffect;
/*     */ import org.bukkit.FireworkEffect.Builder;
/*     */ import org.bukkit.FireworkEffect.Type;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MorphEnderman
/*     */   extends MorphGadget
/*     */ {
/*     */   public MorphEnderman(GadgetManager manager)
/*     */   {
/*  39 */     super(manager, "Enderman Morph", new String[] {C.cWhite + "Transforms the wearer into an Enderman!", " ", C.cYellow + "Double Jump" + C.cGray + " to use " + C.cGreen + "Blink" }, 30000, Material.ENDER_PEARL, (byte)0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  45 */     ApplyArmor(player);
/*     */     
/*  47 */     DisguiseEnderman disguise = new DisguiseEnderman(player);
/*  48 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  49 */     disguise.setCustomNameVisible(true);
/*  50 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  56 */     RemoveArmor(player);
/*  57 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */     
/*  59 */     player.setAllowFlight(false);
/*  60 */     player.setFlying(false);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void teleport(PlayerToggleFlightEvent event)
/*     */   {
/*  66 */     Player player = event.getPlayer();
/*     */     
/*  68 */     if (player.getGameMode() == GameMode.CREATIVE) {
/*  69 */       return;
/*     */     }
/*  71 */     if (!IsActive(player)) {
/*  72 */       return;
/*     */     }
/*  74 */     event.setCancelled(true);
/*  75 */     player.setFlying(false);
/*     */     
/*     */ 
/*  78 */     player.setAllowFlight(false);
/*     */     
/*     */ 
/*  81 */     Recharge.Instance.use(player, GetName(), 2000L, false, false);
/*     */     
/*     */ 
/*  84 */     Block lastSmoke = player.getLocation().getBlock();
/*     */     
/*  86 */     double curRange = 0.0D;
/*  87 */     while (curRange <= 16.0D)
/*     */     {
/*  89 */       Location newTarget = player.getLocation().add(new Vector(0.0D, 0.2D, 0.0D)).add(player.getLocation().getDirection().multiply(curRange));
/*     */       
/*  91 */       if ((!UtilBlock.airFoliage(newTarget.getBlock())) || 
/*  92 */         (!UtilBlock.airFoliage(newTarget.getBlock().getRelative(BlockFace.UP)))) {
/*     */         break;
/*     */       }
/*     */       
/*  96 */       curRange += 0.2D;
/*     */       
/*     */ 
/*  99 */       if (!lastSmoke.equals(newTarget.getBlock()))
/*     */       {
/* 101 */         lastSmoke.getWorld().playEffect(lastSmoke.getLocation(), Effect.SMOKE, 4);
/*     */       }
/*     */       
/* 104 */       lastSmoke = newTarget.getBlock();
/*     */     }
/*     */     
/*     */ 
/* 108 */     curRange -= 0.4D;
/* 109 */     if (curRange < 0.0D) {
/* 110 */       curRange = 0.0D;
/*     */     }
/*     */     
/* 113 */     Location loc = player.getLocation().add(player.getLocation().getDirection().multiply(curRange).add(new Vector(0.0D, 0.4D, 0.0D)));
/*     */     
/* 115 */     if (curRange > 0.0D)
/*     */     {
/*     */ 
/* 118 */       FireworkEffect effect = FireworkEffect.builder().flicker(false).withColor(Color.BLACK).with(FireworkEffect.Type.BALL).trail(false).build();
/*     */       
/*     */       try
/*     */       {
/* 122 */         UtilFirework.playFirework(player.getEyeLocation(), effect);
/* 123 */         player.getWorld().playSound(player.getLocation(), Sound.ZOMBIE_UNFECT, 2.0F, 2.0F);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 127 */         e.printStackTrace();
/*     */       }
/*     */       
/* 130 */       player.teleport(loc);
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 135 */         UtilFirework.playFirework(player.getEyeLocation(), effect);
/* 136 */         player.getWorld().playSound(player.getLocation(), Sound.ZOMBIE_UNFECT, 2.0F, 2.0F);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 140 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 145 */     player.setFallDistance(0.0F);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void teleportUpdate(UpdateEvent event)
/*     */   {
/* 151 */     if (event.getType() != UpdateType.TICK) {
/* 152 */       return;
/*     */     }
/* 154 */     for (Player player : GetActive())
/*     */     {
/* 156 */       if (player.getGameMode() != GameMode.CREATIVE)
/*     */       {
/*     */ 
/* 159 */         if (Recharge.Instance.usable(player, GetName()))
/*     */         {
/* 161 */           player.setAllowFlight(true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphEnderman.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */