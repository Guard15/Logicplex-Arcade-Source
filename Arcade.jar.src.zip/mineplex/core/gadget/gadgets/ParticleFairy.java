/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ParticleGadget;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerQuitEvent;
/*    */ 
/*    */ public class ParticleFairy
/*    */   extends ParticleGadget
/*    */ {
/* 20 */   private HashMap<Player, ParticleFairyData> _fairy = new HashMap();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ParticleFairy(GadgetManager manager)
/*    */   {
/* 31 */     super(manager, "Flame Fairy", new String[] {C.cWhite + "HEY! LISTEN!", C.cWhite + "HEY! LISTEN!", C.cWhite + "HEY! LISTEN!" }, -2, Material.BLAZE_POWDER, (byte)0);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void playParticle(UpdateEvent event)
/*    */   {
/* 37 */     if (event.getType() != UpdateType.TICK) {
/* 38 */       return;
/*    */     }
/*    */     
/* 41 */     for (Player player : GetActive())
/*    */     {
/* 43 */       if (shouldDisplay(player))
/*    */       {
/*    */ 
/*    */ 
/* 47 */         if (!this._fairy.containsKey(player)) {
/* 48 */           this._fairy.put(player, new ParticleFairyData(player));
/*    */         }
/* 50 */         ((ParticleFairyData)this._fairy.get(player)).Update();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public void DisableCustom(Player player)
/*    */   {
/* 57 */     if (this._active.remove(player)) {
/* 58 */       UtilPlayer.message(player, F.main("Gadget", "You unsummoned " + F.elem(GetName()) + "."));
/*    */     }
/* 60 */     clean(player);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void quit(PlayerQuitEvent event)
/*    */   {
/* 66 */     clean(event.getPlayer());
/*    */   }
/*    */   
/*    */   private void clean(Player player)
/*    */   {
/* 71 */     this._fairy.remove(player);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleFairy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */