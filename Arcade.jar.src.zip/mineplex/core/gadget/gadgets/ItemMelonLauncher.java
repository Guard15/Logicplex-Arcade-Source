/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.projectile.IThrown;
/*     */ import mineplex.core.projectile.ProjectileManager;
/*     */ import mineplex.core.projectile.ProjectileUser;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.EntityEffect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.potion.PotionEffect;
/*     */ import org.bukkit.potion.PotionEffectType;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ItemMelonLauncher extends ItemGadget implements IThrown
/*     */ {
/*  37 */   private ArrayList<Item> _melon = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemMelonLauncher(GadgetManager manager)
/*     */   {
/*  49 */     super(manager, "Melon Launcher", new String[] {C.cWhite + "Deliciously fun!", C.cWhite + "Eat the melon slices for a", C.cWhite + "temporary speed boost!" }, -1, Material.MELON_BLOCK, (byte)0, 1000L, new Ammo("Melon Launcher", "100 Melons", Material.MELON_BLOCK, (byte)0, new String[] { C.cWhite + "100 Melons for you to launch!" }, 500, 100));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/*  56 */     Item item = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), ItemStackFactory.Instance.CreateStack(Material.MELON_BLOCK));
/*  57 */     UtilAction.velocity(item, player.getLocation().getDirection(), 
/*  58 */       1.0D, false, 0.0D, 0.2D, 10.0D, false);
/*     */     
/*  60 */     this.Manager.getProjectileManager().AddThrow(item, player, this, -1L, true, true, true, 
/*  61 */       null, 1.0F, 1.0F, null, null, 0, UpdateType.TICK, 0.5F);
/*     */     
/*     */ 
/*  64 */     UtilPlayer.message(player, F.main("Skill", "You used " + F.skill(GetName()) + "."));
/*     */     
/*     */ 
/*  67 */     item.getWorld().playSound(item.getLocation(), Sound.EXPLODE, 0.5F, 0.5F);
/*     */   }
/*     */   
/*     */ 
/*     */   public void Collide(LivingEntity target, Block block, ProjectileUser data)
/*     */   {
/*  73 */     if (target != null)
/*     */     {
/*     */ 
/*  76 */       UtilAction.velocity(target, 
/*  77 */         UtilAlg.getTrajectory2d(data.GetThrown().getLocation(), target.getLocation()), 
/*  78 */         1.4D, false, 0.0D, 0.8D, 1.5D, true);
/*     */       
/*     */ 
/*  81 */       target.playEffect(EntityEffect.HURT);
/*     */     }
/*     */     
/*  84 */     smash(data.GetThrown());
/*     */   }
/*     */   
/*     */ 
/*     */   public void Idle(ProjectileUser data)
/*     */   {
/*  90 */     smash(data.GetThrown());
/*     */   }
/*     */   
/*     */ 
/*     */   public void Expire(ProjectileUser data)
/*     */   {
/*  96 */     smash(data.GetThrown());
/*     */   }
/*     */   
/*     */ 
/*     */   public void smash(Entity ent)
/*     */   {
/* 102 */     ent.getWorld().playEffect(ent.getLocation(), org.bukkit.Effect.STEP_SOUND, Material.MELON_BLOCK);
/*     */     
/* 104 */     for (int i = 0; i < 10; i++)
/*     */     {
/* 106 */       Item item = ent.getWorld().dropItem(ent.getLocation(), ItemStackFactory.Instance.CreateStack(Material.MELON));
/* 107 */       item.setVelocity(new Vector(UtilMath.rr(0.5D, true), UtilMath.rr(0.5D, false), UtilMath.rr(0.5D, true)));
/* 108 */       item.setPickupDelay(30);
/*     */       
/* 110 */       this._melon.add(item);
/*     */     }
/*     */     
/*     */ 
/* 114 */     ent.remove();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void pickupMelon(PlayerPickupItemEvent event)
/*     */   {
/* 120 */     if (!this._melon.remove(event.getItem())) {
/* 121 */       return;
/*     */     }
/* 123 */     event.getItem().remove();
/*     */     
/* 125 */     event.setCancelled(true);
/*     */     
/* 127 */     event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.EAT, 1.0F, 1.0F);
/*     */     
/* 129 */     if (!event.getPlayer().hasPotionEffect(PotionEffectType.SPEED)) {
/* 130 */       event.getPlayer().addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 80, 1), true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void cleanupMelon(UpdateEvent event) {
/* 136 */     if (event.getType() != UpdateType.SLOW) {
/* 137 */       return;
/*     */     }
/* 139 */     for (Iterator<Item> melonIterator = this._melon.iterator(); melonIterator.hasNext();)
/*     */     {
/* 141 */       Item melon = (Item)melonIterator.next();
/*     */       
/* 143 */       if ((melon.isDead()) || (!melon.isValid()) || (melon.getTicksLived() > 400))
/*     */       {
/* 145 */         melonIterator.remove();
/* 146 */         melon.remove();
/*     */       }
/*     */     }
/*     */     
/* 150 */     while (this._melon.size() > 60)
/*     */     {
/* 152 */       Item item = (Item)this._melon.remove(0);
/* 153 */       item.remove();
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemMelonLauncher.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */