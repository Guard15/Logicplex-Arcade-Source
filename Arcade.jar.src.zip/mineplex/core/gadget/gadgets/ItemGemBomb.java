/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilFirework;
/*     */ import mineplex.core.common.util.UtilGear;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.common.util.UtilTime;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.event.ItemGadgetOutOfAmmoEvent;
/*     */ import mineplex.core.gadget.types.GadgetType;
/*     */ import mineplex.core.gadget.types.ItemGadget;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.InventoryManager;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.FireworkEffect;
/*     */ import org.bukkit.FireworkEffect.Builder;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.block.Action;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class ItemGemBomb extends ItemGadget
/*     */ {
/*  47 */   private HashMap<Item, Long> _activeBombs = new HashMap();
/*  48 */   private HashSet<Item> _gems = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ItemGemBomb(GadgetManager manager)
/*     */   {
/*  62 */     super(manager, "Gem Party Bomb", new String[] {C.cWhite + "It's party time! You will be", C.cWhite + "everyones favourite player", C.cWhite + "when you use one of these!", " ", C.cRed + C.Bold + "WARNING: " + org.bukkit.ChatColor.RESET + "This uses 2000 Gems" }, -1, Material.EMERALD, (byte)0, 30000L, new Ammo("Gem Party Bomb", "10 Gem Party Bomb", Material.EMERALD, (byte)0, new String[] { C.cWhite + "10 Coin Party Bomb to PARTY!" }, 10, 10));
/*     */   }
/*     */   
/*     */ 
/*     */   @EventHandler
/*     */   public void Activate(PlayerInteractEvent event)
/*     */   {
/*  69 */     if ((event.getAction() != Action.RIGHT_CLICK_AIR) && (event.getAction() != Action.RIGHT_CLICK_BLOCK)) {
/*  70 */       return;
/*     */     }
/*  72 */     if (mineplex.core.common.util.UtilBlock.usable(event.getClickedBlock())) {
/*  73 */       return;
/*     */     }
/*  75 */     if (!UtilGear.isMat(event.getPlayer().getItemInHand(), GetDisplayMaterial())) {
/*  76 */       return;
/*     */     }
/*  78 */     Player player = event.getPlayer();
/*     */     
/*  80 */     if (!IsActive(player)) {
/*  81 */       return;
/*     */     }
/*  83 */     event.setCancelled(true);
/*     */     
/*     */ 
/*  86 */     if (((ClientInventory)this.Manager.getInventoryManager().Get(player)).getItemCount(GetName()) <= 0)
/*     */     {
/*     */ 
/*  89 */       UtilPlayer.message(player, F.main("Gadget", "You do not have any " + GetName() + " left."));
/*     */       
/*  91 */       ItemGadgetOutOfAmmoEvent ammoEvent = new ItemGadgetOutOfAmmoEvent(event.getPlayer(), this);
/*  92 */       Bukkit.getServer().getPluginManager().callEvent(ammoEvent);
/*     */       
/*  94 */       return;
/*     */     }
/*     */     
/*     */ 
/*  98 */     if (((Donor)this.Manager.getDonationManager().Get(player.getName())).GetBalance(CurrencyType.Gems) < 2000)
/*     */     {
/* 100 */       UtilPlayer.message(player, F.main("Inventory", new StringBuilder("You do not have the required ").append(C.cGreen).append("2000 Gems").toString()) + ".");
/* 101 */       return;
/*     */     }
/*     */     
/*     */ 
/* 105 */     if (!this._activeBombs.isEmpty())
/*     */     {
/* 107 */       UtilPlayer.message(player, F.main("Inventory", new StringBuilder("There is already a ").append(F.elem(new StringBuilder(String.valueOf(C.cGreen)).append("Gem Bomb").toString())).toString()) + " being used.");
/* 108 */       return;
/*     */     }
/*     */     
/*     */ 
/* 112 */     if (!Recharge.Instance.use(player, GetName(), this._recharge, this._recharge > 1000L, false))
/*     */     {
/* 114 */       mineplex.core.common.util.UtilInv.Update(player);
/* 115 */       return;
/*     */     }
/*     */     
/*     */ 
/* 119 */     this.Manager.getInventoryManager().addItemToInventory(player, getGadgetType().name(), GetName(), -1);
/* 120 */     this.Manager.getDonationManager().RewardGems(null, GetName(), event.getPlayer().getName(), event.getPlayer().getUniqueId(), 63536);
/*     */     
/* 122 */     player.getInventory().setItem(this.Manager.getActiveItemSlot(), ItemStackFactory.Instance.CreateStack(GetDisplayMaterial(), GetDisplayData(), 1, F.item(GetName())));
/*     */     
/* 124 */     ActivateCustom(event.getPlayer());
/*     */   }
/*     */   
/*     */ 
/*     */   public void ActivateCustom(Player player)
/*     */   {
/* 130 */     Item item = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), new ItemStack(Material.EMERALD_BLOCK));
/* 131 */     UtilAction.velocity(item, player.getLocation().getDirection(), 1.0D, false, 0.0D, 0.2D, 1.0D, false);
/* 132 */     this._activeBombs.put(item, Long.valueOf(System.currentTimeMillis()));
/*     */     
/*     */     Player[] arrayOfPlayer;
/* 135 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/* 136 */       UtilPlayer.message(other, C.cGreen + C.Bold + player.getName() + C.cWhite + C.Bold + " has thrown a " + C.cGreen + C.Bold + "Gem Party Bomb" + C.cWhite + C.Bold + "!");
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event) {
/* 142 */     if (event.getType() != UpdateType.TICK) {
/* 143 */       return;
/*     */     }
/* 145 */     Iterator<Item> itemIterator = this._activeBombs.keySet().iterator();
/*     */     
/* 147 */     while (itemIterator.hasNext())
/*     */     {
/* 149 */       Item item = (Item)itemIterator.next();
/* 150 */       long time = ((Long)this._activeBombs.get(item)).longValue();
/*     */       
/* 152 */       if (UtilTime.elapsed(time, 3000L))
/*     */       {
/* 154 */         if (Math.random() > 0.8D) {
/* 155 */           UtilFirework.playFirework(item.getLocation(), FireworkEffect.builder().flicker(false).withColor(org.bukkit.Color.GREEN).with(org.bukkit.FireworkEffect.Type.BURST).trail(false).build());
/*     */         } else {
/* 157 */           item.getWorld().playSound(item.getLocation(), Sound.FIREWORK_LAUNCH, 1.0F, 1.0F);
/*     */         }
/* 159 */         Item gem = item.getWorld().dropItem(item.getLocation().add(0.0D, 1.0D, 0.0D), new ItemStack(Material.EMERALD));
/*     */         
/*     */ 
/* 162 */         long passed = System.currentTimeMillis() - time;
/* 163 */         Vector vel = new Vector(Math.sin(passed / 300.0D), 0.0D, Math.cos(passed / 300.0D));
/*     */         
/* 165 */         UtilAction.velocity(gem, vel, Math.abs(Math.sin(passed / 3000.0D)), false, 0.0D, 0.2D + Math.abs(Math.cos(passed / 3000.0D)) * 0.8D, 1.0D, false);
/*     */         
/* 167 */         gem.setPickupDelay(40);
/*     */         
/* 169 */         this._gems.add(gem);
/*     */       }
/*     */       
/* 172 */       if (UtilTime.elapsed(time, 23000L))
/*     */       {
/* 174 */         item.remove();
/* 175 */         itemIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Pickup(PlayerPickupItemEvent event)
/*     */   {
/* 183 */     if (this._activeBombs.keySet().contains(event.getItem()))
/*     */     {
/* 185 */       event.setCancelled(true);
/*     */     }
/* 187 */     else if (this._gems.contains(event.getItem()))
/*     */     {
/* 189 */       event.setCancelled(true);
/* 190 */       event.getItem().remove();
/*     */       
/* 192 */       this.Manager.getDonationManager().RewardGemsLater(GetName() + " Pickup", event.getPlayer(), 4);
/*     */       
/* 194 */       event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.ORB_PICKUP, 1.0F, 2.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Clean(UpdateEvent event)
/*     */   {
/* 201 */     if (event.getType() != UpdateType.FAST) {
/* 202 */       return;
/*     */     }
/* 204 */     Iterator<Item> gemIterator = this._gems.iterator();
/*     */     
/* 206 */     while (gemIterator.hasNext())
/*     */     {
/* 208 */       Item gem = (Item)gemIterator.next();
/*     */       
/* 210 */       if ((!gem.isValid()) || (gem.getTicksLived() > 1200))
/*     */       {
/* 212 */         gem.remove();
/* 213 */         gemIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemGemBomb.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */