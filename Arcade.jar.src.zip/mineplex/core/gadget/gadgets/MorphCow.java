/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.UtilEvent;
/*    */ import mineplex.core.common.util.UtilEvent.ActionType;
/*    */ import mineplex.core.disguise.DisguiseManager;
/*    */ import mineplex.core.disguise.disguises.DisguiseCow;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.MorphGadget;
/*    */ import mineplex.core.recharge.Recharge;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.Sound;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerInteractEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MorphCow
/*    */   extends MorphGadget
/*    */ {
/*    */   public MorphCow(GadgetManager manager)
/*    */   {
/* 28 */     super(manager, "Cow Morph", new String[] {C.cWhite + "How now brown cow?", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Moo" }, 6000, Material.LEATHER, (byte)0);
/*    */   }
/*    */   
/*    */ 
/*    */   public void EnableCustom(Player player)
/*    */   {
/* 34 */     ApplyArmor(player);
/*    */     
/* 36 */     DisguiseCow disguise = new DisguiseCow(player);
/* 37 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/* 38 */     disguise.setCustomNameVisible(true);
/* 39 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*    */   }
/*    */   
/*    */ 
/*    */   public void DisableCustom(Player player)
/*    */   {
/* 45 */     RemoveArmor(player);
/* 46 */     this.Manager.getDisguiseManager().undisguise(player);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void Audio(PlayerInteractEvent event)
/*    */   {
/* 52 */     Player player = event.getPlayer();
/*    */     
/* 54 */     if (!IsActive(player)) {
/* 55 */       return;
/*    */     }
/* 57 */     if (!UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/* 58 */       return;
/*    */     }
/* 60 */     if (!Recharge.Instance.use(player, GetName(), 2500L, false, false)) {
/* 61 */       return;
/*    */     }
/* 63 */     player.getWorld().playSound(player.getLocation(), Sound.COW_IDLE, 1.0F, 1.0F);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphCow.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */