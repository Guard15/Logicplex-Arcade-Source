/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.shop.item.SalesPackageBase;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Ammo
/*    */   extends SalesPackageBase
/*    */ {
/*    */   public Ammo(String name, String displayName, Material material, byte displayData, String[] description, int coins, int quantity)
/*    */   {
/* 13 */     super(name, material, displayData, description, coins, quantity);
/*    */     
/* 15 */     this.DisplayName = displayName;
/* 16 */     this.KnownPackage = false;
/* 17 */     this.OneTimePurchaseOnly = false;
/*    */   }
/*    */   
/*    */   public void Sold(Player player, CurrencyType currencyType) {}
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\Ammo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */