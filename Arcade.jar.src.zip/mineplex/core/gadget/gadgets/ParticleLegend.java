/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.donation.Donor;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ParticleGadget;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import org.bukkit.Effect;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.player.PlayerJoinEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParticleLegend
/*    */   extends ParticleGadget
/*    */ {
/*    */   public ParticleLegend(GadgetManager manager)
/*    */   {
/* 28 */     super(manager, "Legendary Aura", new String[] {C.cWhite + "These mystic particle attach to", C.cWhite + "only the most legendary of players!", " ", C.cPurple + "Unlocked with Legend Rank" }, -2, Material.ENDER_PORTAL, (byte)0);
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void playParticle(UpdateEvent event)
/*    */   {
/* 34 */     if (event.getType() != UpdateType.TICK) {
/* 35 */       return;
/*    */     }
/* 37 */     for (Player player : GetActive())
/*    */     {
/* 39 */       if (shouldDisplay(player))
/*    */       {
/*    */ 
/* 42 */         player.getWorld().playEffect(player.getLocation().add(0.0D, 1.0D, 0.0D), Effect.ENDER_SIGNAL, 0);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   @EventHandler
/*    */   public void legendOwner(PlayerJoinEvent event) {
/* 49 */     if (this.Manager.getClientManager().Get(event.getPlayer()).GetRank().Has(Rank.LEGEND))
/*    */     {
/* 51 */       ((Donor)this.Manager.getDonationManager().Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(GetName());
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ParticleLegend.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */