/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEnt;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.common.util.UtilParticle;
/*     */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseWither;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.entity.WitherSkull;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.entity.EntityExplodeEvent;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.util.Vector;
/*     */ 
/*     */ public class MorphWither extends MorphGadget
/*     */ {
/*  40 */   private ArrayList<WitherSkull> _skulls = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphWither(GadgetManager manager)
/*     */   {
/*  53 */     super(manager, "Wither Morph", new String[] {C.cWhite + "Become a legendary Wither!", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Wither Skull", " ", C.cPurple + "Unlocked with Legend Rank" }, -1, Material.SKULL_ITEM, (byte)1);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  59 */     ApplyArmor(player);
/*     */     
/*  61 */     player.setMaxHealth(300.0D);
/*  62 */     player.setHealth(300.0D);
/*     */     
/*  64 */     DisguiseWither disguise = new DisguiseWither(player);
/*  65 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*     */     
/*  67 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */     
/*  69 */     player.setMaxHealth(20.0D);
/*  70 */     player.setHealth(20.0D);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  76 */     RemoveArmor(player);
/*  77 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */     
/*  79 */     player.setAllowFlight(false);
/*  80 */     player.setFlying(false);
/*     */     
/*  82 */     player.setMaxHealth(20.0D);
/*  83 */     player.setHealth(20.0D);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void witherSkull(PlayerInteractEvent event)
/*     */   {
/*  89 */     Player player = event.getPlayer();
/*     */     
/*  91 */     if (!IsActive(player)) {
/*  92 */       return;
/*     */     }
/*  94 */     if (!mineplex.core.common.util.UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/*  95 */       return;
/*     */     }
/*  97 */     if (!Recharge.Instance.use(player, GetName(), 1600L, false, false)) {
/*  98 */       return;
/*     */     }
/* 100 */     Vector offset = player.getLocation().getDirection();
/* 101 */     if (offset.getY() < 0.0D) {
/* 102 */       offset.setY(0);
/*     */     }
/* 104 */     this._skulls.add((WitherSkull)player.launchProjectile(WitherSkull.class));
/*     */     
/*     */ 
/* 107 */     player.getWorld().playSound(player.getLocation(), Sound.WITHER_SHOOT, 0.5F, 1.0F);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void explode(EntityExplodeEvent event)
/*     */   {
/* 113 */     if (!this._skulls.contains(event.getEntity())) {
/* 114 */       return;
/*     */     }
/* 116 */     event.setCancelled(true);
/*     */     
/* 118 */     WitherSkull skull = (WitherSkull)event.getEntity();
/*     */     
/* 120 */     UtilParticle.PlayParticle(mineplex.core.common.util.UtilParticle.ParticleType.LARGE_EXPLODE, skull.getLocation(), 0.0F, 0.0F, 0.0F, 0.0F, 1, 
/* 121 */       UtilParticle.ViewDist.MAX, UtilServer.getPlayers());
/* 122 */     skull.getWorld().playSound(skull.getLocation(), Sound.EXPLODE, 2.0F, 1.0F);
/*     */     
/* 124 */     HashMap<Player, Double> players = UtilPlayer.getInRadius(event.getLocation(), 6.0D);
/* 125 */     for (Player player : players.keySet())
/*     */     {
/* 127 */       if (!this.Manager.collideEvent(this, player))
/*     */       {
/*     */ 
/* 130 */         double mult = ((Double)players.get(player)).doubleValue();
/*     */         
/*     */ 
/* 133 */         mineplex.core.common.util.UtilAction.velocity(player, UtilAlg.getTrajectory(event.getLocation(), player.getLocation()), 2.0D * mult, false, 0.0D, 0.6D + 0.4D * mult, 2.0D, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void clean(UpdateEvent event) {
/* 140 */     if (event.getType() != UpdateType.FAST) {
/* 141 */       return;
/*     */     }
/* 143 */     Iterator<WitherSkull> skullIterator = this._skulls.iterator();
/*     */     
/* 145 */     while (skullIterator.hasNext())
/*     */     {
/* 147 */       WitherSkull skull = (WitherSkull)skullIterator.next();
/*     */       
/* 149 */       if (!skull.isValid())
/*     */       {
/* 151 */         skullIterator.remove();
/* 152 */         skull.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   @EventHandler
/*     */   public void flight(UpdateEvent event)
/*     */   {
/* 161 */     if (event.getType() != UpdateType.TICK) {
/* 162 */       return;
/*     */     }
/* 164 */     for (Player player : GetActive())
/*     */     {
/* 166 */       if (!UtilPlayer.isSpectator(player))
/*     */       {
/*     */ 
/* 169 */         player.setAllowFlight(true);
/* 170 */         player.setFlying(true);
/*     */         
/* 172 */         if (UtilEnt.isGrounded(player))
/* 173 */           player.setVelocity(new Vector(0, 1, 0));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void legendOwner(PlayerJoinEvent event) {
/* 180 */     if ((this.Manager.getClientManager().Get(event.getPlayer()).GetRank() == Rank.LEGEND) || 
/* 181 */       (this.Manager.getClientManager().Get(event.getPlayer()).GetRank() == Rank.ADMIN) || 
/* 182 */       (this.Manager.getClientManager().Get(event.getPlayer()).GetRank() == Rank.DEVELOPER) || 
/* 183 */       (this.Manager.getClientManager().Get(event.getPlayer()).GetRank() == Rank.OWNER))
/*     */     {
/* 185 */       ((Donor)this.Manager.getDonationManager().Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(GetName());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setWitherData(String text, double healthPercent)
/*     */   {
/* 191 */     Iterator<Player> activeIterator = GetActive().iterator();
/*     */     
/* 193 */     while (activeIterator.hasNext())
/*     */     {
/* 195 */       Player player = (Player)activeIterator.next();
/*     */       
/* 197 */       mineplex.core.disguise.disguises.DisguiseBase disguise = this.Manager.getDisguiseManager().getDisguise(player);
/*     */       
/* 199 */       if ((disguise == null) || (!(disguise instanceof DisguiseWither)))
/*     */       {
/* 201 */         DisableCustom(player);
/* 202 */         activeIterator.remove();
/*     */       }
/*     */       else
/*     */       {
/* 206 */         ((DisguiseWither)disguise).setName(text);
/* 207 */         ((DisguiseWither)disguise).setHealth((float)(healthPercent * 300.0D));
/* 208 */         this.Manager.getDisguiseManager().updateDisguise(disguise);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphWither.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */