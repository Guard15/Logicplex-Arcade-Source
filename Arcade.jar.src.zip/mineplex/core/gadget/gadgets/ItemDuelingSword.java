/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.C;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilGear;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.gadget.GadgetManager;
/*    */ import mineplex.core.gadget.types.ItemGadget;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.inventory.PlayerInventory;
/*    */ import org.bukkit.inventory.meta.ItemMeta;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemDuelingSword
/*    */   extends ItemGadget
/*    */ {
/*    */   public ItemDuelingSword(GadgetManager manager)
/*    */   {
/* 33 */     super(manager, "Dueling Sword", new String[] {C.cWhite + "While active, you are able to fight", C.cWhite + "against other people who are also", C.cWhite + "wielding a dueling sword." }, -1, Material.WOOD_SWORD, (byte)3, 1000L, new Ammo("Dueling Sword", "10 Swords", Material.WOOD_SWORD, (byte)0, new String[] { C.cWhite + "10 Swords to duel with" }, 1000, 10));
/*    */   }
/*    */   
/*    */ 
/*    */   public void ActivateCustom(Player player)
/*    */   {
/* 39 */     ItemStack stack = new ItemStack(Material.GOLD_SWORD);
/* 40 */     ItemMeta meta = stack.getItemMeta();
/* 41 */     meta.setDisplayName("Dueling Sword");
/* 42 */     stack.setItemMeta(meta);
/*    */     
/* 44 */     player.getInventory().setItem(this.Manager.getActiveItemSlot(), stack);
/*    */     
/*    */ 
/* 47 */     UtilPlayer.message(player, F.main("Skill", "You used " + F.skill(GetName()) + "."));
/*    */   }
/*    */   
/*    */   @EventHandler(priority=EventPriority.HIGHEST)
/*    */   public void damage(EntityDamageByEntityEvent event)
/*    */   {
/* 53 */     if ((!(event.getEntity() instanceof Player)) || (!(event.getDamager() instanceof Player))) {
/* 54 */       return;
/*    */     }
/* 56 */     Player damager = (Player)event.getDamager();
/* 57 */     Player damagee = (Player)event.getEntity();
/*    */     
/* 59 */     if ((!UtilGear.isMat(damager.getItemInHand(), Material.GOLD_SWORD)) || (!UtilGear.isMat(damagee.getItemInHand(), Material.GOLD_SWORD))) {
/* 60 */       return;
/*    */     }
/* 62 */     event.setCancelled(false);
/*    */     
/* 64 */     event.setDamage(4.0D);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\ItemDuelingSword.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */