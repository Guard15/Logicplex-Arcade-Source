/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import mineplex.core.common.CurrencyType;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguiseVillager;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.projectile.IThrown;
/*     */ import mineplex.core.projectile.ProjectileManager;
/*     */ import mineplex.core.projectile.ProjectileUser;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.EntityEffect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ 
/*     */ public class MorphVillager extends MorphGadget implements IThrown
/*     */ {
/*  39 */   private HashSet<Item> _gems = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphVillager(GadgetManager manager)
/*     */   {
/*  52 */     super(manager, "Villager Morph", new String[] {C.cWhite + "HURRRR! MURR HURRR!", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Gem Throw", " ", C.cRed + C.Bold + "WARNING: " + ChatColor.RESET + "Gem Throw uses 20 Gems" }, 12000, Material.EMERALD, (byte)0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  58 */     ApplyArmor(player);
/*     */     
/*  60 */     DisguiseVillager disguise = new DisguiseVillager(player);
/*  61 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  62 */     disguise.setCustomNameVisible(true);
/*  63 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  69 */     RemoveArmor(player);
/*  70 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void skill(PlayerInteractEvent event)
/*     */   {
/*  76 */     Player player = event.getPlayer();
/*     */     
/*  78 */     if (!IsActive(player)) {
/*  79 */       return;
/*     */     }
/*  81 */     if (!mineplex.core.common.util.UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/*  82 */       return;
/*     */     }
/*  84 */     if (((Donor)this.Manager.getDonationManager().Get(player.getName())).GetBalance(CurrencyType.Gems) < 20)
/*     */     {
/*  86 */       mineplex.core.common.util.UtilPlayer.message(player, mineplex.core.common.util.F.main("Gadget", "You do not have enough Gems."));
/*  87 */       return;
/*     */     }
/*     */     
/*  90 */     if (!Recharge.Instance.use(player, GetName(), 800L, false, false)) {
/*  91 */       return;
/*     */     }
/*  93 */     player.getWorld().playSound(player.getLocation(), Sound.VILLAGER_IDLE, 1.0F, 1.0F);
/*     */     
/*     */ 
/*  96 */     Item gem = player.getWorld().dropItem(player.getEyeLocation().add(player.getLocation().getDirection()), new org.bukkit.inventory.ItemStack(Material.EMERALD));
/*  97 */     UtilAction.velocity(gem, player.getLocation().getDirection(), 1.0D, false, 0.0D, 0.2D, 1.0D, false);
/*     */     
/*     */ 
/* 100 */     this.Manager.getProjectileManager().AddThrow(gem, player, this, -1L, true, true, true, 
/* 101 */       null, 1.4F, 0.8F, null, null, 0, UpdateType.TICK, 0.5F);
/*     */     
/* 103 */     this.Manager.getDonationManager().RewardGems(null, GetName() + " Throw", player.getName(), player.getUniqueId(), -20);
/*     */     
/* 105 */     gem.setPickupDelay(40);
/*     */     
/* 107 */     this._gems.add(gem);
/*     */   }
/*     */   
/*     */ 
/*     */   public void Collide(LivingEntity target, Block block, ProjectileUser data)
/*     */   {
/* 113 */     if (target == null) {
/* 114 */       return;
/*     */     }
/* 116 */     if (((target instanceof Player)) && 
/* 117 */       (this.Manager.collideEvent(this, (Player)target))) {
/* 118 */       return;
/*     */     }
/*     */     
/* 121 */     UtilAction.velocity(target, 
/* 122 */       UtilAlg.getTrajectory(data.GetThrown().getLocation(), target.getEyeLocation()), 
/* 123 */       1.0D, false, 0.0D, 0.2D, 0.8D, true);
/*     */     
/* 125 */     UtilAction.velocity(data.GetThrown(), 
/* 126 */       UtilAlg.getTrajectory(target, data.GetThrown()), 
/* 127 */       0.5D, false, 0.0D, 0.0D, 0.8D, true);
/*     */     
/*     */ 
/* 130 */     target.playEffect(EntityEffect.HURT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void Idle(ProjectileUser data) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void Expire(ProjectileUser data) {}
/*     */   
/*     */ 
/*     */ 
/*     */   @EventHandler
/*     */   public void Pickup(PlayerPickupItemEvent event)
/*     */   {
/* 148 */     if (this._gems.contains(event.getItem()))
/*     */     {
/* 150 */       event.setCancelled(true);
/* 151 */       event.getItem().remove();
/*     */       
/* 153 */       this.Manager.getDonationManager().RewardGemsLater(GetName() + " Pickup", event.getPlayer(), 16);
/*     */       
/* 155 */       event.getPlayer().getWorld().playSound(event.getPlayer().getLocation(), Sound.ORB_PICKUP, 1.0F, 2.0F);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Clean(UpdateEvent event)
/*     */   {
/* 162 */     if (event.getType() != UpdateType.FAST) {
/* 163 */       return;
/*     */     }
/* 165 */     Iterator<Item> gemIterator = this._gems.iterator();
/*     */     
/* 167 */     while (gemIterator.hasNext())
/*     */     {
/* 169 */       Item gem = (Item)gemIterator.next();
/*     */       
/* 171 */       if ((!gem.isValid()) || (gem.getTicksLived() > 1200))
/*     */       {
/* 173 */         gem.remove();
/* 174 */         gemIterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphVillager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */