/*     */ package mineplex.core.gadget.gadgets;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilAction;
/*     */ import mineplex.core.common.util.UtilAlg;
/*     */ import mineplex.core.common.util.UtilEvent.ActionType;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.disguise.DisguiseManager;
/*     */ import mineplex.core.disguise.disguises.DisguisePig;
/*     */ import mineplex.core.donation.Donor;
/*     */ import mineplex.core.gadget.GadgetManager;
/*     */ import mineplex.core.gadget.types.MorphGadget;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerToggleFlightEvent;
/*     */ 
/*     */ public class MorphPig extends MorphGadget
/*     */ {
/*  30 */   private HashSet<Player> _double = new HashSet();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MorphPig(GadgetManager manager)
/*     */   {
/*  44 */     super(manager, "Pig Morph", new String[] {C.cWhite + "Oink. Oink. Oink.... Oink?", " ", C.cYellow + "Left Click" + C.cGray + " to use " + C.cGreen + "Oink", C.cYellow + "Collide" + C.cGray + " to use " + C.cGreen + "Pig Bounce", " ", C.cPurple + "Unlocked with Ultra Rank" }, -1, org.bukkit.Material.PORK, (byte)0);
/*     */   }
/*     */   
/*     */ 
/*     */   public void EnableCustom(Player player)
/*     */   {
/*  50 */     ApplyArmor(player);
/*     */     
/*  52 */     DisguisePig disguise = new DisguisePig(player);
/*  53 */     disguise.setName(player.getName(), this.Manager.getClientManager().Get(player).GetRank());
/*  54 */     disguise.setCustomNameVisible(true);
/*  55 */     this.Manager.getDisguiseManager().disguise(disguise, new Player[0]);
/*     */   }
/*     */   
/*     */ 
/*     */   public void DisableCustom(Player player)
/*     */   {
/*  61 */     RemoveArmor(player);
/*  62 */     this.Manager.getDisguiseManager().undisguise(player);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Snort(PlayerInteractEvent event)
/*     */   {
/*  68 */     Player player = event.getPlayer();
/*     */     
/*  70 */     if (!IsActive(player)) {
/*  71 */       return;
/*     */     }
/*  73 */     if (!mineplex.core.common.util.UtilEvent.isAction(event, UtilEvent.ActionType.L)) {
/*  74 */       return;
/*     */     }
/*  76 */     if (!Recharge.Instance.use(player, GetName(), 400L, false, false)) {
/*  77 */       return;
/*     */     }
/*  79 */     player.getWorld().playSound(player.getLocation(), Sound.PIG_IDLE, 1.0F, (float)(0.75D + Math.random() * 0.5D));
/*     */   }
/*     */   
/*     */ 
/*     */   @EventHandler
/*     */   public void HeroOwner(PlayerJoinEvent event)
/*     */   {
/*  86 */     if (this.Manager.getClientManager().Get(event.getPlayer()).GetRank().Has(Rank.ULTRA))
/*     */     {
/*  88 */       ((Donor)this.Manager.getDonationManager().Get(event.getPlayer().getName())).AddUnknownSalesPackagesOwned(GetName());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Collide(PlayerToggleFlightEvent event)
/*     */   {
/*  95 */     this._double.add(event.getPlayer());
/*  96 */     Recharge.Instance.useForce(event.getPlayer(), GetName() + " Double Jump", 200L);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Collide(UpdateEvent event)
/*     */   {
/* 102 */     if (event.getType() != mineplex.core.updater.UpdateType.TICK) {
/* 103 */       return;
/*     */     }
/* 105 */     for (Player player : GetActive())
/*     */     {
/*     */ 
/* 108 */       if ((this._double.contains(player)) && 
/* 109 */         (mineplex.core.common.util.UtilEnt.isGrounded(player)) && 
/* 110 */         (Recharge.Instance.usable(player, GetName() + " Double Jump"))) {
/* 111 */         this._double.remove(player);
/*     */       }
/* 113 */       double range = 1.0D;
/*     */       
/* 115 */       if (this._double.contains(player)) {
/* 116 */         range += 0.5D;
/*     */       }
/* 118 */       if (player.getVehicle() == null)
/*     */       {
/*     */ 
/* 121 */         if (Recharge.Instance.usable(player, GetName() + " Collide"))
/*     */         {
/*     */           Player[] arrayOfPlayer;
/* 124 */           int j = (arrayOfPlayer = mineplex.core.common.util.UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player other = arrayOfPlayer[i];
/*     */             
/* 126 */             if (!other.equals(player))
/*     */             {
/*     */ 
/* 129 */               if (other.getVehicle() == null)
/*     */               {
/*     */ 
/* 132 */                 if (Recharge.Instance.usable(other, GetName() + " Collide"))
/*     */                 {
/*     */ 
/* 135 */                   if (UtilMath.offset(player, other) <= range)
/*     */                   {
/*     */ 
/* 138 */                     if (!this.Manager.collideEvent(this, other))
/*     */                     {
/*     */ 
/*     */ 
/* 142 */                       Recharge.Instance.useForce(other, GetName() + " Collide", 200L);
/* 143 */                       Recharge.Instance.useForce(player, GetName() + " Collide", 200L);
/*     */                       
/* 145 */                       double power = 0.4D;
/* 146 */                       double height = 0.1D;
/* 147 */                       if (player.isSprinting())
/*     */                       {
/* 149 */                         power = 0.6D;
/* 150 */                         height = 0.2D;
/*     */                       }
/*     */                       
/* 153 */                       if (this._double.contains(player))
/*     */                       {
/* 155 */                         power = 1.0D;
/* 156 */                         height = 0.3D;
/*     */                       }
/*     */                       
/*     */ 
/*     */ 
/* 161 */                       UtilAction.velocity(player, UtilAlg.getTrajectory2d(other, player), power, false, 0.0D, height, 1.0D, true);
/* 162 */                       UtilAction.velocity(other, UtilAlg.getTrajectory2d(player, other), power, false, 0.0D, height, 1.0D, true);
/*     */                       
/*     */ 
/* 165 */                       if (this._double.contains(player))
/*     */                       {
/* 167 */                         player.getWorld().playSound(player.getLocation(), Sound.PIG_DEATH, (float)(0.8D + Math.random() * 0.4D), (float)(0.8D + Math.random() * 0.4D));
/*     */                       }
/*     */                       else
/*     */                       {
/* 171 */                         player.getWorld().playSound(player.getLocation(), Sound.PIG_IDLE, 1.0F, (float)(1.5D + Math.random() * 0.5D)); }
/*     */                     } } } } }
/*     */           }
/*     */         } }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Clean(PlayerQuitEvent event) {
/* 180 */     this._double.remove(event.getPlayer());
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\MorphPig.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */