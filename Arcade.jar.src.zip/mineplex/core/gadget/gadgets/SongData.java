/*    */ package mineplex.core.gadget.gadgets;
/*    */ 
/*    */ import mineplex.core.common.util.UtilParticle;
/*    */ import mineplex.core.common.util.UtilParticle.ParticleType;
/*    */ import mineplex.core.common.util.UtilParticle.ViewDist;
/*    */ import mineplex.core.common.util.UtilServer;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.block.Block;
/*    */ 
/*    */ public class SongData
/*    */ {
/*    */   public Block Block;
/*    */   public long EndTime;
/*    */   
/*    */   public SongData(Block block, long duration)
/*    */   {
/* 18 */     this.Block = block;
/* 19 */     this.EndTime = (System.currentTimeMillis() + duration);
/*    */     
/* 21 */     this.Block.setType(Material.JUKEBOX);
/*    */   }
/*    */   
/*    */   public boolean update()
/*    */   {
/* 26 */     if (System.currentTimeMillis() > this.EndTime)
/*    */     {
/* 28 */       if (this.Block.getType() == Material.JUKEBOX) {
/* 29 */         this.Block.setType(Material.AIR);
/*    */       }
/* 31 */       return true;
/*    */     }
/*    */     
/* 34 */     UtilParticle.PlayParticle(UtilParticle.ParticleType.NOTE, this.Block.getLocation().add(0.5D, 1.0D, 0.5D), 0.5F, 0.5F, 0.5F, 0.0F, 2, 
/* 35 */       UtilParticle.ViewDist.NORMAL, UtilServer.getPlayers());
/*    */     
/* 37 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\gadget\gadgets\SongData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */