/*     */ package mineplex.core.energy;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import mineplex.core.MiniClientPlugin;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.energy.event.EnergyEvent;
/*     */ import mineplex.core.energy.event.EnergyEvent.EnergyChangeReason;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerExpChangeEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerRespawnEvent;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Energy extends MiniClientPlugin<ClientEnergy>
/*     */ {
/*  21 */   private double _baseEnergy = 180.0D;
/*  22 */   private boolean _enabled = true;
/*     */   
/*     */   public Energy(JavaPlugin plugin)
/*     */   {
/*  26 */     super("Energy", plugin);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void Update(UpdateEvent event)
/*     */   {
/*  32 */     if (!this._enabled) {
/*  33 */       return;
/*     */     }
/*  35 */     if (event.getType() != UpdateType.TICK)
/*     */       return;
/*     */     Player[] arrayOfPlayer;
/*  38 */     int j = (arrayOfPlayer = mineplex.core.common.util.UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/*  39 */       UpdateEnergy(cur);
/*     */     }
/*     */   }
/*     */   
/*     */   private void UpdateEnergy(Player cur) {
/*  44 */     if (cur.isDead()) {
/*  45 */       return;
/*     */     }
/*     */     
/*  48 */     double energy = 0.4D;
/*     */     
/*     */ 
/*  51 */     EnergyEvent energyEvent = new EnergyEvent(cur, energy, EnergyEvent.EnergyChangeReason.Recharge);
/*  52 */     this._plugin.getServer().getPluginManager().callEvent(energyEvent);
/*     */     
/*  54 */     if (energyEvent.isCancelled()) {
/*  55 */       return;
/*     */     }
/*     */     
/*  58 */     ModifyEnergy(cur, energyEvent.GetTotalAmount());
/*     */   }
/*     */   
/*     */   public void ModifyEnergy(Player player, double energy)
/*     */   {
/*  63 */     if (!this._enabled) {
/*  64 */       return;
/*     */     }
/*  66 */     ClientEnergy client = (ClientEnergy)Get(player);
/*     */     
/*  68 */     if (energy > 0.0D)
/*     */     {
/*  70 */       client.Energy = Math.min(GetMax(player), client.Energy + energy);
/*     */     }
/*     */     else
/*     */     {
/*  74 */       client.Energy = Math.max(0.0D, client.Energy + energy);
/*     */     }
/*     */     
/*     */ 
/*  78 */     if (energy < 0.0D)
/*     */     {
/*  80 */       client.LastEnergy = System.currentTimeMillis();
/*     */     }
/*     */     
/*  83 */     player.setExp(Math.min(0.999F, (float)client.Energy / (float)GetMax(player)));
/*     */   }
/*     */   
/*     */   public double GetMax(Player player)
/*     */   {
/*  88 */     return this._baseEnergy + ((ClientEnergy)Get(player)).EnergyBonus();
/*     */   }
/*     */   
/*     */   public double GetCurrent(Player player)
/*     */   {
/*  93 */     return ((ClientEnergy)Get(player)).Energy;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void HandleRespawn(PlayerRespawnEvent event)
/*     */   {
/*  99 */     ((ClientEnergy)Get(event.getPlayer())).Energy = 0.0D;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void HandleJoin(PlayerJoinEvent event)
/*     */   {
/* 105 */     ((ClientEnergy)Get(event.getPlayer())).Energy = 0.0D;
/*     */   }
/*     */   
/*     */   public boolean Use(Player player, String ability, double amount, boolean use, boolean inform)
/*     */   {
/* 110 */     ClientEnergy client = (ClientEnergy)Get(player);
/*     */     
/* 112 */     if (client.Energy < amount)
/*     */     {
/* 114 */       if (inform) {
/* 115 */         mineplex.core.common.util.UtilPlayer.message(player, F.main(this._moduleName, "You are too exhausted to use " + F.skill(ability) + "."));
/*     */       }
/* 117 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 121 */     if (!use) {
/* 122 */       return true;
/*     */     }
/* 124 */     ModifyEnergy(player, -amount);
/*     */     
/* 126 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   @EventHandler
/*     */   public void handleExp(PlayerExpChangeEvent event)
/*     */   {
/* 133 */     if (!this._enabled) {
/* 134 */       return;
/*     */     }
/* 136 */     event.setAmount(0);
/*     */   }
/*     */   
/*     */ 
/*     */   protected ClientEnergy AddPlayer(String player)
/*     */   {
/* 142 */     return new ClientEnergy();
/*     */   }
/*     */   
/*     */   public void AddEnergyMaxMod(Player player, String reason, int amount)
/*     */   {
/* 147 */     ((ClientEnergy)Get(player)).MaxEnergyMods.put(reason, Integer.valueOf(amount));
/*     */   }
/*     */   
/*     */   public void RemoveEnergyMaxMod(Player player, String reason)
/*     */   {
/* 152 */     ((ClientEnergy)Get(player)).MaxEnergyMods.remove(reason);
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean b)
/*     */   {
/* 157 */     this._enabled = b;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\energy\Energy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */