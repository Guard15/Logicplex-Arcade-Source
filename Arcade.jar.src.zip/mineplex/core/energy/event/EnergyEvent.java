/*    */ package mineplex.core.energy.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class EnergyEvent extends Event implements Cancellable
/*    */ {
/*    */   public static enum EnergyChangeReason
/*    */   {
/* 12 */     Recharge, 
/* 13 */     Use;
/*    */   }
/*    */   
/* 16 */   private static final HandlerList handlers = new HandlerList();
/* 17 */   private boolean _cancelled = false;
/*    */   
/*    */   private Player _player;
/*    */   private double _amount;
/*    */   private double _mods;
/*    */   private EnergyChangeReason _reason;
/*    */   
/*    */   public EnergyEvent(Player player, double amount, EnergyChangeReason reason)
/*    */   {
/* 26 */     this._player = player;
/* 27 */     this._amount = amount;
/* 28 */     this._reason = reason;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 33 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 38 */     return handlers;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 44 */     return this._cancelled;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 50 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public Player GetPlayer()
/*    */   {
/* 55 */     return this._player;
/*    */   }
/*    */   
/*    */   public double GetAmount()
/*    */   {
/* 60 */     return this._amount;
/*    */   }
/*    */   
/*    */   public void AddMod(double mod)
/*    */   {
/* 65 */     this._mods += mod;
/*    */   }
/*    */   
/*    */   public double GetTotalAmount()
/*    */   {
/* 70 */     return this._amount + this._mods;
/*    */   }
/*    */   
/*    */   public EnergyChangeReason GetReason()
/*    */   {
/* 75 */     return this._reason;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\energy\event\EnergyEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */