/*    */ package mineplex.core.energy;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class ClientEnergy
/*    */ {
/*    */   public double Energy;
/*    */   public long LastEnergy;
/* 10 */   public HashMap<String, Integer> MaxEnergyMods = new HashMap();
/* 11 */   public HashMap<String, Integer> SwingEnergyMods = new HashMap();
/*    */   
/*    */   public int EnergyBonus()
/*    */   {
/* 15 */     int bonus = 0;
/*    */     
/* 17 */     for (Iterator localIterator = this.MaxEnergyMods.values().iterator(); localIterator.hasNext();) { int i = ((Integer)localIterator.next()).intValue();
/* 18 */       bonus += i;
/*    */     }
/* 20 */     return bonus;
/*    */   }
/*    */   
/*    */   public int SwingEnergy()
/*    */   {
/* 25 */     int mod = 0;
/*    */     
/* 27 */     for (Iterator localIterator = this.SwingEnergyMods.values().iterator(); localIterator.hasNext();) { int i = ((Integer)localIterator.next()).intValue();
/* 28 */       mod += i;
/*    */     }
/* 30 */     return Math.max(0, 4 + mod);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\energy\ClientEnergy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */