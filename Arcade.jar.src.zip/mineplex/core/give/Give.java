/*     */ package mineplex.core.give;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilItem;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import mineplex.core.give.commands.GiveCommand;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class Give
/*     */   extends MiniPlugin
/*     */ {
/*     */   public static Give Instance;
/*     */   
/*     */   protected Give(JavaPlugin plugin)
/*     */   {
/*  28 */     super("Give Factory", plugin);
/*     */   }
/*     */   
/*     */   public static void Initialize(JavaPlugin plugin)
/*     */   {
/*  33 */     Instance = new Give(plugin);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/*  39 */     addCommand(new GiveCommand(this));
/*     */   }
/*     */   
/*     */   public void parseInput(Player player, String[] args)
/*     */   {
/*  44 */     if (args.length == 0) {
/*  45 */       help(player);
/*     */     }
/*  47 */     else if (args.length == 1) {
/*  48 */       give(player, player.getName(), args[0], "1", "");
/*     */     }
/*  50 */     else if (args.length == 2) {
/*  51 */       give(player, args[0], args[1], "1", "");
/*     */     }
/*  53 */     else if (args.length == 3) {
/*  54 */       give(player, args[0], args[1], args[2], "");
/*     */     }
/*     */     else {
/*  57 */       give(player, args[0], args[1], args[2], args[3]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void help(Player player) {
/*  62 */     UtilPlayer.message(player, F.main("Give", "Commands List;"));
/*     */   }
/*     */   
/*     */ 
/*     */   public void give(Player player, String target, String itemNames, String amount, String enchants)
/*     */   {
/*  68 */     LinkedList<Map.Entry<Material, Byte>> itemList = new LinkedList();
/*  69 */     itemList = UtilItem.matchItem(player, itemNames, true);
/*  70 */     if (itemList.isEmpty()) {
/*  71 */       return;
/*     */     }
/*     */     
/*  74 */     LinkedList<Player> giveList = new LinkedList();
/*     */     
/*  76 */     if (target.equalsIgnoreCase("all")) {
/*     */       Player[] arrayOfPlayer;
/*  78 */       int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player cur = arrayOfPlayer[i];
/*  79 */         giveList.add(cur);
/*     */       }
/*     */     }
/*     */     else {
/*  83 */       giveList = UtilPlayer.matchOnline(player, target, true);
/*  84 */       if (giveList.isEmpty()) {
/*  85 */         return;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  90 */     int count = 1;
/*     */     try
/*     */     {
/*  93 */       count = Integer.parseInt(amount);
/*     */       
/*  95 */       if (count < 1)
/*     */       {
/*  97 */         UtilPlayer.message(player, F.main("Give", "Invalid Amount [" + amount + "]. Defaulting to [1]."));
/*  98 */         count = 1;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 103 */       UtilPlayer.message(player, F.main("Give", "Invalid Amount [" + amount + "]. Defaulting to [1]."));
/*     */     }
/*     */     
/*     */ 
/* 107 */     Object enchs = new HashMap();
/* 108 */     if (enchants.length() > 0) {
/*     */       String[] arrayOfString1;
/* 110 */       int m = (arrayOfString1 = enchants.split(",")).length; for (int k = 0; k < m; k++) { String cur = arrayOfString1[k];
/*     */         
/*     */         try
/*     */         {
/* 114 */           String[] tokens = cur.split(":");
/* 115 */           ((HashMap)enchs).put(Enchantment.getByName(tokens[0]), Integer.valueOf(Integer.parseInt(tokens[1])));
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 119 */           UtilPlayer.message(player, F.main("Give", "Invalid Enchantment [" + cur + "]."));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 125 */     String givenList = "";
/* 126 */     for (Player cur : giveList)
/* 127 */       givenList = givenList + cur.getName() + " ";
/* 128 */     if (givenList.length() > 0) {
/* 129 */       givenList = givenList.substring(0, givenList.length() - 1);
/*     */     }
/* 131 */     for (Object curItem : itemList)
/*     */     {
/* 133 */       for (Player cur : giveList)
/*     */       {
/* 135 */         ItemStack stack = ItemStackFactory.Instance.CreateStack((Material)((Map.Entry)curItem).getKey(), ((Byte)((Map.Entry)curItem).getValue()).byteValue(), count);
/*     */         
/*     */ 
/* 138 */         stack.addUnsafeEnchantments((Map)enchs);
/*     */         
/*     */ 
/* 141 */         if (UtilInv.insert(cur, stack))
/*     */         {
/*     */ 
/* 144 */           if (!cur.equals(player)) {
/* 145 */             UtilPlayer.message(cur, F.main("Give", "You received " + F.item(new StringBuilder(String.valueOf(count)).append(" ").append(ItemStackFactory.Instance.GetName((Material)((Map.Entry)curItem).getKey(), ((Byte)((Map.Entry)curItem).getValue()).byteValue(), false)).toString()) + " from " + F.elem(player.getName()) + "."));
/*     */           }
/*     */         }
/*     */       }
/* 149 */       if (target.equalsIgnoreCase("all")) {
/* 150 */         UtilPlayer.message(player, F.main("Give", new StringBuilder("You gave ").append(F.item(new StringBuilder(String.valueOf(count)).append(" ").append(ItemStackFactory.Instance.GetName((Material)((Map.Entry)curItem).getKey(), ((Byte)((Map.Entry)curItem).getValue()).byteValue(), false)).toString())).append(" to ").append(F.elem("ALL")).toString()) + ".");
/*     */       }
/* 152 */       else if (giveList.size() > 1) {
/* 153 */         UtilPlayer.message(player, F.main("Give", "You gave " + F.item(new StringBuilder(String.valueOf(count)).append(" ").append(ItemStackFactory.Instance.GetName((Material)((Map.Entry)curItem).getKey(), ((Byte)((Map.Entry)curItem).getValue()).byteValue(), false)).toString()) + " to " + F.elem(givenList) + "."));
/*     */       }
/*     */       else {
/* 156 */         UtilPlayer.message(player, F.main("Give", "You gave " + F.item(new StringBuilder(String.valueOf(count)).append(" ").append(ItemStackFactory.Instance.GetName((Material)((Map.Entry)curItem).getKey(), ((Byte)((Map.Entry)curItem).getValue()).byteValue(), false)).toString()) + " to " + F.elem(((Player)giveList.getFirst()).getName()) + "."));
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\give\Give.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */