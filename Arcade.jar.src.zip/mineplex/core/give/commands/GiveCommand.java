/*    */ package mineplex.core.give.commands;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.give.Give;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class GiveCommand
/*    */   extends CommandBase<Give>
/*    */ {
/*    */   public GiveCommand(Give plugin)
/*    */   {
/* 13 */     super(plugin, Rank.ADMIN, new String[] { "give", "g", "item", "i" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 19 */     ((Give)this.Plugin).parseInput(caller, args);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\give\commands\GiveCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */