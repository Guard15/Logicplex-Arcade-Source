/*    */ package mineplex.core.npc.event;
/*    */ 
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ 
/*    */ public class NpcDamageByEntityEvent extends NpcEvent
/*    */ {
/*    */   private LivingEntity _damager;
/*    */   
/*    */   public NpcDamageByEntityEvent(LivingEntity npc, LivingEntity damager)
/*    */   {
/* 11 */     super(npc);
/*    */     
/* 13 */     this._damager = damager;
/*    */   }
/*    */   
/*    */   public LivingEntity getDamager()
/*    */   {
/* 18 */     return this._damager;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\event\NpcDamageByEntityEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */