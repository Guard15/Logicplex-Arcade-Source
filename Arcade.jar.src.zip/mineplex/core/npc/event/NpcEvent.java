/*    */ package mineplex.core.npc.event;
/*    */ 
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class NpcEvent extends Event
/*    */ {
/*  9 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private LivingEntity _npc;
/*    */   
/* 13 */   private boolean _cancelled = false;
/*    */   
/*    */   public NpcEvent(LivingEntity npc)
/*    */   {
/* 17 */     this._npc = npc;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 22 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 27 */     return handlers;
/*    */   }
/*    */   
/*    */   public LivingEntity getNpc()
/*    */   {
/* 32 */     return this._npc;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 37 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 42 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\event\NpcEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */