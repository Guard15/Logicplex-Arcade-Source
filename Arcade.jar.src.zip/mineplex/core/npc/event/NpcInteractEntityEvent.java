/*    */ package mineplex.core.npc.event;
/*    */ 
/*    */ import org.bukkit.entity.LivingEntity;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class NpcInteractEntityEvent extends NpcEvent
/*    */ {
/*    */   private Player _player;
/*    */   
/*    */   public NpcInteractEntityEvent(LivingEntity npc, Player player)
/*    */   {
/* 12 */     super(npc);
/*    */     
/* 14 */     this._player = player;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 19 */     return this._player;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\event\NpcInteractEntityEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */