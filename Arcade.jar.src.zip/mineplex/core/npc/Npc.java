/*     */ package mineplex.core.npc;
/*     */ 
/*     */ import java.util.Map;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.database.tables.records.NpcsRecord;
/*     */ import net.minecraft.server.v1_7_R4.EntityCreature;
/*     */ import net.minecraft.server.v1_7_R4.Navigation;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Chunk;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftCreature;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ 
/*     */ public class Npc
/*     */ {
/*     */   private final NpcManager _npcManager;
/*     */   private final NpcsRecord _databaseRecord;
/*     */   private final Location _location;
/*     */   private LivingEntity _entity;
/*  20 */   private int _failedAttempts = 0;
/*  21 */   private boolean _returning = false;
/*     */   private final String[] _info;
/*     */   private final Double _infoRadiusSquared;
/*     */   
/*     */   public Npc(NpcManager npcManager, NpcsRecord databaseRecord)
/*     */   {
/*  27 */     this._npcManager = npcManager;
/*  28 */     this._databaseRecord = databaseRecord;
/*     */     
/*  30 */     this._location = new Location(org.bukkit.Bukkit.getWorld(getDatabaseRecord().getWorld()), getDatabaseRecord().getX().doubleValue(), getDatabaseRecord().getY().doubleValue(), getDatabaseRecord().getZ().doubleValue());
/*     */     
/*  32 */     if (getDatabaseRecord().getInfo() == null) {
/*  33 */       this._info = null;
/*     */     }
/*     */     else {
/*  36 */       String[] info = getDatabaseRecord().getInfo().split("\\r?\\n");
/*     */       
/*  38 */       for (int i = 0; i < info.length; i++) {
/*     */         ChatColor[] arrayOfChatColor;
/*  40 */         int j = (arrayOfChatColor = ChatColor.values()).length; for (int i = 0; i < j; i++) { ChatColor color = arrayOfChatColor[i];
/*  41 */           info[i] = info[i].replace("(" + color.name().toLowerCase() + ")", color.toString()); }
/*  42 */         info[i] = ChatColor.translateAlternateColorCodes('&', info[i]);
/*     */       }
/*     */       
/*  45 */       this._info = new String[info.length + 2];
/*     */       
/*  47 */       for (int i = 0; i < this._info.length; i++)
/*     */       {
/*  49 */         if ((i == 0) || (i == this._info.length - 1))
/*     */         {
/*  51 */           this._info[i] = (C.cGold + C.Strike + "=============================================");
/*     */         }
/*     */         else
/*     */         {
/*  55 */           this._info[i] = info[(i - 1)];
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  60 */     if (getDatabaseRecord().getInfoRadius() == null) {
/*  61 */       this._infoRadiusSquared = null;
/*     */     } else {
/*  63 */       this._infoRadiusSquared = Double.valueOf(getDatabaseRecord().getInfoRadius().doubleValue() * getDatabaseRecord().getInfoRadius().doubleValue());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setEntity(LivingEntity entity) {
/*  68 */     if (this._entity != null) {
/*  69 */       getNpcManager()._npcMap.remove(this._entity.getUniqueId());
/*     */     }
/*  71 */     this._entity = entity;
/*     */     
/*  73 */     if (this._entity != null) {
/*  74 */       getNpcManager()._npcMap.put(this._entity.getUniqueId(), this);
/*     */     }
/*     */   }
/*     */   
/*     */   public LivingEntity getEntity() {
/*  79 */     return this._entity;
/*     */   }
/*     */   
/*     */   public NpcsRecord getDatabaseRecord()
/*     */   {
/*  84 */     return this._databaseRecord;
/*     */   }
/*     */   
/*     */   public int getFailedAttempts()
/*     */   {
/*  89 */     return this._failedAttempts;
/*     */   }
/*     */   
/*     */   public void setFailedAttempts(int failedAttempts)
/*     */   {
/*  94 */     this._failedAttempts = failedAttempts;
/*     */   }
/*     */   
/*     */   public int incrementFailedAttempts()
/*     */   {
/*  99 */     return ++this._failedAttempts;
/*     */   }
/*     */   
/*     */   public Location getLocation()
/*     */   {
/* 104 */     return this._location;
/*     */   }
/*     */   
/*     */   public double getRadius()
/*     */   {
/* 109 */     return getDatabaseRecord().getRadius().doubleValue();
/*     */   }
/*     */   
/*     */   public boolean isInRadius(Location location)
/*     */   {
/* 114 */     if (location.getWorld() != getLocation().getWorld()) {
/* 115 */       return false;
/*     */     }
/* 117 */     return location.distanceSquared(getLocation()) <= getRadius() * getRadius();
/*     */   }
/*     */   
/*     */   public void returnToPost()
/*     */   {
/* 122 */     if ((this._entity instanceof CraftCreature))
/*     */     {
/* 124 */       EntityCreature ec = ((CraftCreature)this._entity).getHandle();
/*     */       
/* 126 */       ec.getNavigation().a(getLocation().getX(), getLocation().getY(), getLocation().getZ(), 0.800000011920929D);
/*     */       
/* 128 */       this._returning = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isReturning()
/*     */   {
/* 134 */     return this._returning;
/*     */   }
/*     */   
/*     */   public void clearGoals()
/*     */   {
/* 139 */     if ((this._entity instanceof CraftCreature))
/*     */     {
/* 141 */       this._returning = false;
/*     */       
/* 143 */       Location entityLocation = this._entity.getLocation();
/* 144 */       EntityCreature ec = ((CraftCreature)this._entity).getHandle();
/* 145 */       ec.getNavigation().a(entityLocation.getX(), entityLocation.getY(), entityLocation.getZ(), 0.800000011920929D);
/*     */     }
/*     */   }
/*     */   
/*     */   public NpcManager getNpcManager()
/*     */   {
/* 151 */     return this._npcManager;
/*     */   }
/*     */   
/*     */   public Chunk getChunk()
/*     */   {
/* 156 */     return getLocation().getChunk();
/*     */   }
/*     */   
/*     */   public String[] getInfo()
/*     */   {
/* 161 */     return this._info;
/*     */   }
/*     */   
/*     */   public Double getInfoRadiusSquared()
/*     */   {
/* 166 */     return this._infoRadiusSquared;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\Npc.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */