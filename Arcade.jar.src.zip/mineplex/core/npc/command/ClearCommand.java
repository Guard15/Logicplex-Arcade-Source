/*    */ package mineplex.core.npc.command;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.npc.NpcManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class ClearCommand
/*    */   extends CommandBase<NpcManager>
/*    */ {
/*    */   public ClearCommand(NpcManager plugin)
/*    */   {
/* 17 */     super(plugin, Rank.DEVELOPER, new String[] { "clear" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 23 */     if (args != null) {
/* 24 */       ((NpcManager)this.Plugin).help(caller);
/*    */     }
/*    */     else {
/*    */       try
/*    */       {
/* 29 */         ((NpcManager)this.Plugin).clearNpcs(true);
/*    */         
/* 31 */         UtilPlayer.message(caller, F.main(((NpcManager)this.Plugin).getName(), "Cleared NPCs."));
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 35 */         ((NpcManager)this.Plugin).help(caller, "Database error.");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\command\ClearCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */