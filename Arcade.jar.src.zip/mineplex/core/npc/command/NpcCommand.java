/*    */ package mineplex.core.npc.command;
/*    */ 
/*    */ import mineplex.core.command.MultiCommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.npc.NpcManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class NpcCommand
/*    */   extends MultiCommandBase<NpcManager>
/*    */ {
/*    */   public NpcCommand(NpcManager plugin)
/*    */   {
/* 13 */     super(plugin, Rank.DEVELOPER, new Rank[] { Rank.JNR_DEV }, new String[] { "npc" });
/*    */     
/* 15 */     AddCommand(new AddCommand(plugin));
/* 16 */     AddCommand(new DeleteCommand(plugin));
/* 17 */     AddCommand(new HomeCommand(plugin));
/* 18 */     AddCommand(new ClearCommand(plugin));
/* 19 */     AddCommand(new RefreshCommand(plugin));
/*    */   }
/*    */   
/*    */ 
/*    */   protected void Help(Player caller, String[] args)
/*    */   {
/* 25 */     ((NpcManager)this.Plugin).help(caller);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\command\NpcCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */