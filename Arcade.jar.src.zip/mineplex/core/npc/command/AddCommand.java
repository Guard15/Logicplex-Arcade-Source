/*    */ package mineplex.core.npc.command;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.npc.NpcManager;
/*    */ import org.bukkit.entity.EntityType;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class AddCommand
/*    */   extends CommandBase<NpcManager>
/*    */ {
/*    */   public AddCommand(NpcManager plugin)
/*    */   {
/* 16 */     super(plugin, Rank.DEVELOPER, new String[] { "add" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 22 */     if (args == null) {
/* 23 */       ((NpcManager)this.Plugin).help(caller);
/*    */     }
/*    */     else
/*    */     {
/*    */       try
/*    */       {
/* 29 */         type = EntityType.valueOf(args[0].toUpperCase());
/*    */       }
/*    */       catch (IllegalArgumentException e) {
/*    */         EntityType type;
/* 33 */         ((NpcManager)this.Plugin).help(caller, "Invalid entity."); return;
/*    */       }
/*    */       
/*    */       EntityType type;
/*    */       
/* 38 */       double radius = 0.0D;
/* 39 */       if (args.length >= 2)
/*    */       {
/*    */         try
/*    */         {
/* 43 */           radius = Double.parseDouble(args[1]);
/*    */         }
/*    */         catch (NumberFormatException e)
/*    */         {
/* 47 */           ((NpcManager)this.Plugin).help(caller, "Invalid radius.");
/*    */           
/* 49 */           return;
/*    */         }
/*    */       }
/*    */       
/* 53 */       boolean adult = true;
/* 54 */       if (args.length >= 3) {
/* 55 */         adult = Boolean.parseBoolean(args[2]);
/*    */       }
/* 57 */       String name = null;
/* 58 */       if (args.length >= 4)
/*    */       {
/* 60 */         name = args[3];
/* 61 */         for (int i = 4; i < args.length; i++) {
/* 62 */           name = name + " " + args[i];
/*    */         }
/*    */       }
/*    */       try
/*    */       {
/* 67 */         ((NpcManager)this.Plugin).addNpc(caller, type, radius, adult, name, null);
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 71 */         ((NpcManager)this.Plugin).help(caller, "Database error.");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\command\AddCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */