/*    */ package mineplex.core.npc.command;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.npc.NpcManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ public class RefreshCommand
/*    */   extends CommandBase<NpcManager>
/*    */ {
/*    */   public RefreshCommand(NpcManager plugin)
/*    */   {
/* 17 */     super(plugin, Rank.SNR_MODERATOR, new String[] { "refresh" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 23 */     if (args != null) {
/* 24 */       ((NpcManager)this.Plugin).help(caller);
/*    */     }
/*    */     else {
/*    */       try
/*    */       {
/* 29 */         ((NpcManager)this.Plugin).clearNpcs(false);
/* 30 */         ((NpcManager)this.Plugin).loadNpcs();
/*    */         
/* 32 */         UtilPlayer.message(caller, F.main(((NpcManager)this.Plugin).getName(), "Refreshed NPCs."));
/*    */       }
/*    */       catch (SQLException e)
/*    */       {
/* 36 */         ((NpcManager)this.Plugin).help(caller, "Database error.");
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\command\RefreshCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */