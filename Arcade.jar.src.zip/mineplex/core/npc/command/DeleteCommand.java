/*    */ package mineplex.core.npc.command;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.npc.NpcManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class DeleteCommand
/*    */   extends CommandBase<NpcManager>
/*    */ {
/*    */   public DeleteCommand(NpcManager plugin)
/*    */   {
/* 15 */     super(plugin, Rank.DEVELOPER, new String[] { "del" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 21 */     if (args != null) {
/* 22 */       ((NpcManager)this.Plugin).help(caller);
/*    */     }
/*    */     else {
/* 25 */       ((NpcManager)this.Plugin).prepDeleteNpc(caller);
/*    */       
/* 27 */       UtilPlayer.message(caller, F.main(((NpcManager)this.Plugin).getName(), "Now right click npc."));
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\npc\command\DeleteCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */