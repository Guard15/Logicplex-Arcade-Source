/*    */ package mineplex.core.achievement.command;
/*    */ 
/*    */ import mineplex.core.achievement.AchievementManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StatsCommand
/*    */   extends CommandBase<AchievementManager>
/*    */ {
/*    */   public StatsCommand(AchievementManager plugin)
/*    */   {
/* 19 */     super(plugin, Rank.ALL, new String[] { "stats" });
/*    */   }
/*    */   
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 24 */     if ((args == null) || (args.length == 0)) {
/* 25 */       ((AchievementManager)this.Plugin).openShop(caller);
/*    */     } else {
/* 27 */       Player target = UtilPlayer.searchOnline(caller, args[0], true);
/* 28 */       if (target == null) {
/* 29 */         return;
/*    */       }
/* 31 */       ((AchievementManager)this.Plugin).openShop(caller, target);
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\command\StatsCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */