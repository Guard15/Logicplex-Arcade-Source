/*    */ package mineplex.core.achievement;
/*    */ 
/*    */ 
/*    */ public class AchievementData
/*    */ {
/*    */   private int _level;
/*    */   private long _expRemainder;
/*    */   private long _expNextLevel;
/*    */   
/*    */   public AchievementData(int level, long expRemainder, long expNextLevel)
/*    */   {
/* 12 */     this._level = level;
/* 13 */     this._expRemainder = expRemainder;
/* 14 */     this._expNextLevel = expNextLevel;
/*    */   }
/*    */   
/*    */   public int getLevel() {
/* 18 */     return this._level;
/*    */   }
/*    */   
/*    */   public long getExpRemainder() {
/* 22 */     return this._expRemainder;
/*    */   }
/*    */   
/*    */   public long getExpNextLevel() {
/* 26 */     return this._expNextLevel;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\AchievementData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */