/*    */ package mineplex.core.achievement;
/*    */ 
/*    */ 
/*    */ public class AchievementLog
/*    */ {
/*    */   public long Amount;
/*    */   public boolean LevelUp;
/*    */   
/*    */   public AchievementLog(long amount, boolean levelUp)
/*    */   {
/* 11 */     this.Amount = amount;
/* 12 */     this.LevelUp = levelUp;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\AchievementLog.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */