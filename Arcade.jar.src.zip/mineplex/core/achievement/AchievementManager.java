/*     */ package mineplex.core.achievement;
/*     */ 
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.achievement.command.StatsCommand;
/*     */ import mineplex.core.achievement.ui.AchievementShop;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.common.util.UtilGear;
/*     */ import mineplex.core.common.util.UtilInv;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.stats.PlayerStats;
/*     */ import mineplex.core.stats.StatsManager;
/*     */ import mineplex.core.stats.event.StatChangeEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AchievementManager
/*     */   extends MiniPlugin
/*     */ {
/*     */   private StatsManager _statsManager;
/*     */   private AchievementShop _shop;
/*  58 */   private int _interfaceSlot = 7;
/*  59 */   private boolean _giveInterfaceItem = false;
/*  60 */   private NautHashMap<String, NautHashMap<Achievement, AchievementLog>> _log = new NautHashMap();
/*  61 */   private boolean _shopEnabled = true;
/*     */   public static String _mineplexName;
/*     */   
/*     */   public AchievementManager(StatsManager statsManager, CoreClientManager clientManager, DonationManager donationManager, String mineplexName)
/*     */   {
/*  66 */     super("Achievement Manager", statsManager.getPlugin());
/*  67 */     this._statsManager = statsManager;
/*  68 */     this._shop = new AchievementShop(this, this._statsManager, clientManager, donationManager, "Achievement");
/*     */     
/*  70 */     _mineplexName = mineplexName;
/*     */   }
/*     */   
/*     */   public AchievementData get(Player player, Achievement type) {
/*  74 */     return get(player.getName(), type);
/*     */   }
/*     */   
/*     */   public AchievementData get(String playerName, Achievement type) {
/*  78 */     int exp = 0;
/*  79 */     String[] arrayOfString; int j = (arrayOfString = type.getStats()).length; for (int i = 0; i < j; i++) { String stat = arrayOfString[i];
/*  80 */       exp = (int)(exp + ((PlayerStats)this._statsManager.Get(playerName)).getStat(stat));
/*     */     }
/*  82 */     return type.getLevelData(exp);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void informLevelUp(StatChangeEvent event) {
/*  87 */     Player player = UtilPlayer.searchExact(event.getPlayerName());
/*  88 */     if (player == null)
/*     */       return;
/*     */     Achievement[] arrayOfAchievement;
/*  91 */     int j = (arrayOfAchievement = Achievement.values()).length; for (int i = 0; i < j; i++) { Achievement type = arrayOfAchievement[i];
/*  92 */       String[] arrayOfString; int m = (arrayOfString = type.getStats()).length; for (int k = 0; k < m; k++) { String stat = arrayOfString[k];
/*     */         
/*  94 */         if (stat.equalsIgnoreCase(event.getStatName())) {
/*  95 */           if (!this._log.containsKey(player.getName())) {
/*  96 */             this._log.put(player.getName(), new NautHashMap());
/*     */           }
/*  98 */           if (type.getLevelData(event.getValueAfter()).getLevel() > type.getLevelData(event.getValueBefore()).getLevel()) {
/*  99 */             if (!((NautHashMap)this._log.get(player.getName())).containsKey(type)) {
/* 100 */               ((NautHashMap)this._log.get(player.getName())).put(type, new AchievementLog(event.getValueAfter() - event.getValueBefore(), true));
/*     */             }
/*     */             else {
/* 103 */               AchievementLog log = (AchievementLog)((NautHashMap)this._log.get(player.getName())).get(type);
/* 104 */               log.Amount += event.getValueAfter() - event.getValueBefore();
/* 105 */               log.LevelUp = true;
/*     */             }
/*     */           }
/* 108 */           else if (!((NautHashMap)this._log.get(player.getName())).containsKey(type))
/* 109 */             if (!((NautHashMap)this._log.get(player.getName())).containsKey(type)) {
/* 110 */               ((NautHashMap)this._log.get(player.getName())).put(type, new AchievementLog(event.getValueAfter() - event.getValueBefore(), false));
/*     */             }
/*     */             else {
/* 113 */               AchievementLog log = (AchievementLog)((NautHashMap)this._log.get(player.getName())).get(type);
/* 114 */               log.Amount += event.getValueAfter() - event.getValueBefore();
/*     */             }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 121 */   public void addCommands() { addCommand(new StatsCommand(this)); }
/*     */   
/*     */   public void openShop(Player player)
/*     */   {
/* 125 */     this._shop.attemptShopOpen(player);
/*     */   }
/*     */   
/*     */   public void openShop(Player player, Player target) {
/* 129 */     this._shop.attemptShopOpen(player, target);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerQuit(PlayerQuitEvent event) {
/* 134 */     this._log.remove(event.getPlayer().getName());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerJoin(PlayerJoinEvent event) {
/* 139 */     if (this._giveInterfaceItem) {
/* 140 */       giveInterfaceItem(event.getPlayer());
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearLog(Player player) {
/* 145 */     this._log.remove(player.getName());
/*     */   }
/*     */   
/*     */   public NautHashMap<Achievement, AchievementLog> getLog(Player player) {
/* 149 */     return (NautHashMap)this._log.remove(player.getName());
/*     */   }
/*     */   
/*     */   public void setGiveInterfaceItem(boolean giveInterfaceItem) {
/* 153 */     this._giveInterfaceItem = giveInterfaceItem;
/*     */   }
/*     */   
/*     */   public void giveInterfaceItem(Player player)
/*     */   {
/* 158 */     if (!UtilGear.isMat(player.getInventory().getItem(this._interfaceSlot), Material.SKULL_ITEM))
/*     */     {
/* 160 */       ItemStack item = ItemStackFactory.Instance.CreateStack(Material.SKULL_ITEM, (byte)3, 1, ChatColor.RESET + C.cGreen + "/stats");
/* 161 */       SkullMeta meta = (SkullMeta)item.getItemMeta();
/* 162 */       meta.setOwner(player.getName());
/* 163 */       item.setItemMeta(meta);
/*     */       
/* 165 */       player.getInventory().setItem(this._interfaceSlot, item);
/*     */       
/* 167 */       UtilInv.Update(player);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void openShop(PlayerInteractEvent event) {
/* 173 */     if (!this._shopEnabled) {
/* 174 */       return;
/*     */     }
/* 176 */     if ((event.hasItem()) && (event.getItem().getType() == Material.SKULL_ITEM)) {
/* 177 */       event.setCancelled(true);
/* 178 */       openShop(event.getPlayer());
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasCategory(Player player, Achievement[] required) {
/* 183 */     if ((required == null) || (required.length == 0))
/* 184 */       return false;
/*     */     Achievement[] arrayOfAchievement;
/* 186 */     int j = (arrayOfAchievement = required).length; for (int i = 0; i < j; i++) { Achievement cur = arrayOfAchievement[i];
/* 187 */       if (get(player, cur).getLevel() < cur.getMaxLevel())
/* 188 */         return false;
/*     */     }
/* 190 */     return true;
/*     */   }
/*     */   
/*     */   public int getMineplexLevelNumber(Player sender, Rank rank) {
/* 194 */     int level = get(sender, Achievement.GLOBAL_MINEPLEX_LEVEL).getLevel();
/* 195 */     if (sender.getName().equalsIgnoreCase("B2_mp")) {
/* 196 */       return 101;
/*     */     }
/* 198 */     if (rank.Has(Rank.MODERATOR)) {
/* 199 */       level = Math.max(level, 5);
/*     */     }
/* 201 */     if (rank.Has(Rank.SNR_MODERATOR)) {
/* 202 */       level = Math.max(level, 15);
/*     */     }
/* 204 */     if (rank.Has(Rank.JNR_DEV)) {
/* 205 */       level = Math.max(level, 25);
/*     */     }
/* 207 */     if (rank.Has(Rank.ADMIN)) {
/* 208 */       level = Math.max(level, 30 + get(sender, Achievement.GLOBAL_GEM_HUNTER).getLevel());
/*     */     }
/* 210 */     if (rank.Has(Rank.OWNER)) {
/* 211 */       level = Math.max(level, 50 + get(sender, Achievement.GLOBAL_GEM_HUNTER).getLevel());
/*     */     }
/* 213 */     if (sender.getName().equalsIgnoreCase("Phinary")) {
/* 214 */       level = -level;
/*     */     }
/* 216 */     return level;
/*     */   }
/*     */   
/*     */   public String getMineplexLevel(Player sender, Rank rank) {
/* 220 */     return Achievement.getExperienceString(getMineplexLevelNumber(sender, rank)) + " " + ChatColor.RESET;
/*     */   }
/*     */   
/*     */   public void setShopEnabled(boolean var) {
/* 224 */     this._shopEnabled = var;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\AchievementManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */