/*     */ package mineplex.core.achievement.ui.page;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.achievement.Achievement;
/*     */ import mineplex.core.achievement.AchievementCategory;
/*     */ import mineplex.core.achievement.AchievementCategory.GameCategory;
/*     */ import mineplex.core.achievement.AchievementData;
/*     */ import mineplex.core.achievement.AchievementManager;
/*     */ import mineplex.core.achievement.ui.AchievementShop;
/*     */ import mineplex.core.achievement.ui.button.ArcadeButton;
/*     */ import mineplex.core.achievement.ui.button.CategoryButton;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.itemstack.ItemLayout;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import mineplex.core.shop.page.ShopPageBase;
/*     */ import mineplex.core.stats.StatsManager;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class AchievementMainPage
/*     */   extends ShopPageBase<AchievementManager, AchievementShop>
/*     */ {
/*     */   protected Player _target;
/*     */   protected StatsManager _statsManager;
/*     */   
/*     */   public AchievementMainPage(AchievementManager plugin, StatsManager statsManager, AchievementShop shop, CoreClientManager clientManager, DonationManager donationManager, String name, Player player, Player target)
/*     */   {
/*  32 */     super(plugin, shop, clientManager, donationManager, name, player, 36);
/*     */     
/*  34 */     this._target = target;
/*  35 */     this._statsManager = statsManager;
/*     */     
/*  37 */     buildPage();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void buildPage()
/*     */   {
/*  43 */     ArrayList<Integer> pageLayout = new ItemLayout(new String[] {
/*  44 */       "XXXXOXXXX", 
/*  45 */       "OXOXOXOXO", 
/*  46 */       "OXOXOXOXO", 
/*  47 */       "XXOXOXOXX" }).getItemSlots();
/*  48 */     int listSlot = 0;
/*     */     AchievementCategory[] arrayOfAchievementCategory;
/*  50 */     int j = (arrayOfAchievementCategory = AchievementCategory.values()).length; for (int i = 0; i < j; i++) { AchievementCategory category = arrayOfAchievementCategory[i];
/*     */       
/*  52 */       if (category.getGameCategory() != AchievementCategory.GameCategory.ARCADE)
/*     */       {
/*     */ 
/*  55 */         CategoryButton button = new CategoryButton((AchievementShop)getShop(), (AchievementManager)getPlugin(), this._statsManager, category, getDonationManager(), 
/*  56 */           getClientManager(), this._target);
/*     */         
/*  58 */         ArrayList<String> lore = new ArrayList();
/*  59 */         lore.add(" ");
/*  60 */         category.addStats(getClientManager(), this._statsManager, lore, category == AchievementCategory.GLOBAL ? 5 : 2, 
/*  61 */           getPlayer(), this._target);
/*  62 */         lore.add(" ");
/*  63 */         addAchievements(category, lore, 9);
/*  64 */         lore.add(" ");
/*  65 */         lore.add(ChatColor.RESET + "Click for more details!");
/*     */         
/*  67 */         ShopItem shopItem = new ShopItem(category.getIcon(), category.getIconData(), C.Bold + category.getFriendlyName(), 
/*  68 */           (String[])lore.toArray(new String[0]), 1, false, false);
/*  69 */         addButton(((Integer)pageLayout.get(listSlot++)).intValue(), shopItem, button);
/*     */       }
/*     */     }
/*  72 */     addArcadeButton(((Integer)pageLayout.get(listSlot++)).intValue());
/*     */   }
/*     */   
/*     */   protected void addArcadeButton(int slot)
/*     */   {
/*  77 */     ArcadeButton button = new ArcadeButton((AchievementShop)getShop(), (AchievementManager)getPlugin(), this._statsManager, getDonationManager(), getClientManager(), this._target);
/*  78 */     ShopItem shopItem = new ShopItem(Material.BOW, (byte)0, C.Bold + "Arcade Games", new String[] { " ", ChatColor.RESET + "Click for more!" }, 1, false, false);
/*     */     
/*  80 */     addButton(slot, shopItem, button);
/*     */   }
/*     */   
/*     */   protected void addAchievements(AchievementCategory category, List<String> lore, int max)
/*     */   {
/*  85 */     int achievementCount = 0;
/*  86 */     for (int i = 0; (i < Achievement.values().length) && (achievementCount < max); i++)
/*     */     {
/*  88 */       Achievement achievement = Achievement.values()[i];
/*  89 */       if (achievement.getCategory() == category)
/*     */       {
/*     */ 
/*  92 */         if (achievement.getMaxLevel() <= 1)
/*     */         {
/*     */ 
/*  95 */           AchievementData data = ((AchievementManager)getPlugin()).get(this._target, achievement);
/*  96 */           boolean finished = data.getLevel() >= achievement.getMaxLevel();
/*     */           
/*  98 */           lore.add((finished ? C.cGreen : C.cRed) + achievement.getName());
/*     */           
/* 100 */           achievementCount++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\ui\page\AchievementMainPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */