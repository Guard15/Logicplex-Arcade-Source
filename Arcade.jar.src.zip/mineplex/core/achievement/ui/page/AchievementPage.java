/*     */ package mineplex.core.achievement.ui.page;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.achievement.Achievement;
/*     */ import mineplex.core.achievement.AchievementCategory;
/*     */ import mineplex.core.achievement.AchievementCategory.GameCategory;
/*     */ import mineplex.core.achievement.AchievementData;
/*     */ import mineplex.core.achievement.AchievementManager;
/*     */ import mineplex.core.achievement.ui.AchievementShop;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.donation.DonationManager;
/*     */ import mineplex.core.shop.item.IButton;
/*     */ import mineplex.core.shop.item.ShopItem;
/*     */ import mineplex.core.shop.page.ShopPageBase;
/*     */ import mineplex.core.stats.StatsManager;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Sound;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.inventory.ClickType;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ 
/*     */ public class AchievementPage
/*     */   extends ShopPageBase<AchievementManager, AchievementShop>
/*     */ {
/*  29 */   private static int ACHIEVEMENT_MIDDLE_INDEX = 31;
/*     */   
/*     */   private AchievementCategory _category;
/*     */   private StatsManager _statsManager;
/*     */   private Player _target;
/*     */   
/*     */   public AchievementPage(AchievementManager plugin, StatsManager statsManager, AchievementCategory category, AchievementShop shop, CoreClientManager clientManager, DonationManager donationManager, Player player, Player target)
/*     */   {
/*  37 */     super(plugin, shop, clientManager, donationManager, category.getFriendlyName(), player);
/*     */     
/*  39 */     this._statsManager = statsManager;
/*  40 */     this._category = category;
/*  41 */     this._target = target;
/*     */     
/*  43 */     buildPage();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void buildPage()
/*     */   {
/*  49 */     int currentIndex = ACHIEVEMENT_MIDDLE_INDEX - getAchievements().size() / 2;
/*  50 */     boolean hasAllAchievements = true;
/*  51 */     int achievementCount = 0;
/*     */     
/*  53 */     ArrayList<String> masterAchievementLore = new ArrayList();
/*  54 */     masterAchievementLore.add(" ");
/*     */     
/*  56 */     List<Achievement> achievements = getAchievements();
/*  57 */     for (Achievement achievement : achievements)
/*     */     {
/*  59 */       AchievementData data = ((AchievementManager)getPlugin()).get(this._target, achievement);
/*  60 */       boolean singleLevel = achievement.isSingleLevel();
/*  61 */       boolean hasUnlocked = data.getLevel() >= achievement.getMaxLevel();
/*     */       
/*  63 */       if (!hasUnlocked)
/*     */       {
/*  65 */         hasAllAchievements = false;
/*     */       }
/*     */       
/*     */ 
/*  69 */       Material material = hasUnlocked ? Material.EXP_BOTTLE : Material.GLASS_BOTTLE;
/*  70 */       String itemName = (hasUnlocked ? C.cGreen : C.cRed) + achievement.getName();
/*     */       
/*  72 */       if (!singleLevel) {
/*  73 */         itemName = itemName + ChatColor.WHITE + " Level " + data.getLevel() + "/" + achievement.getMaxLevel();
/*     */       }
/*  75 */       ArrayList<String> lore = new ArrayList();
/*  76 */       lore.add(" ");
/*  77 */       String[] arrayOfString; int j = (arrayOfString = achievement.getDesc()).length; for (int i = 0; i < j; i++) { String descLine = arrayOfString[i];
/*     */         
/*  79 */         lore.add(ChatColor.RESET + descLine);
/*     */       }
/*     */       
/*     */ 
/*  83 */       if ((!hasUnlocked) && (achievement.isOngoing()))
/*     */       {
/*  85 */         lore.add(" ");
/*  86 */         lore.add(C.cYellow + (singleLevel ? "Progress: " : "Next Level: ") + C.cWhite + data.getExpRemainder() + "/" + data.getExpNextLevel());
/*     */       }
/*     */       
/*  89 */       if ((!hasUnlocked) && (singleLevel))
/*     */       {
/*  91 */         lore.add(" ");
/*  92 */         lore.add(C.cYellow + "Reward: " + C.cGreen + achievement.getGemReward() + " Gems");
/*     */       }
/*     */       
/*  95 */       if ((hasUnlocked) && (data.getLevel() == achievement.getMaxLevel()))
/*     */       {
/*  97 */         lore.add(" ");
/*  98 */         lore.add(C.cAqua + "Complete!");
/*     */       }
/*     */       
/*     */ 
/* 102 */       addItem(currentIndex, new ShopItem(material, (byte)(hasUnlocked ? 0 : 0), itemName, (String[])lore.toArray(new String[0]), 1, false, false));
/*     */       
/*     */ 
/* 105 */       masterAchievementLore.add((hasUnlocked ? C.cGreen : C.cRed) + achievement.getName());
/*     */       
/* 107 */       currentIndex++;
/* 108 */       achievementCount++;
/*     */     }
/*     */     
/*     */ 
/* 112 */     if ((!this._category.getFriendlyName().startsWith("Global")) && (achievementCount > 0))
/*     */     {
/* 114 */       String itemName = ChatColor.RESET + this._category.getFriendlyName() + " Master Achievement";
/* 115 */       masterAchievementLore.add(" ");
/* 116 */       if (getPlayer().equals(this._target))
/*     */       {
/* 118 */         if (this._category.getReward() != null) {
/* 119 */           masterAchievementLore.add(C.cYellow + C.Bold + "Reward: " + ChatColor.RESET + this._category.getReward());
/*     */         } else {
/* 121 */           masterAchievementLore.add(C.cYellow + C.Bold + "Reward: " + ChatColor.RESET + "Coming Soon...");
/*     */         }
/*     */       }
/* 124 */       addItem(40, new ShopItem(hasAllAchievements ? Material.EMERALD_BLOCK : Material.REDSTONE_BLOCK, (byte)0, itemName, (String[])masterAchievementLore.toArray(new String[0]), 1, false, true));
/*     */     }
/*     */     
/* 127 */     addBackButton();
/* 128 */     addStats();
/*     */   }
/*     */   
/*     */   private void addBackButton()
/*     */   {
/* 133 */     addButton(4, new ShopItem(Material.BED, C.cGray + " ⇽ Go Back", new String[0], 1, false), new IButton()
/*     */     {
/*     */       public void onClick(Player player, ClickType clickType) {
/*     */         AchievementMainPage page;
/*     */         AchievementMainPage page;
/* 138 */         if (AchievementPage.this._category.getGameCategory() == AchievementCategory.GameCategory.ARCADE) {
/* 139 */           page = new ArcadeMainPage((AchievementManager)AchievementPage.this.getPlugin(), AchievementPage.this._statsManager, (AchievementShop)AchievementPage.this.getShop(), AchievementPage.this.getClientManager(), AchievementPage.this.getDonationManager(), "Arcade Games", player, AchievementPage.this._target);
/*     */         } else {
/* 141 */           page = new AchievementMainPage((AchievementManager)AchievementPage.this.getPlugin(), AchievementPage.this._statsManager, (AchievementShop)AchievementPage.this.getShop(), AchievementPage.this.getClientManager(), AchievementPage.this.getDonationManager(), AchievementPage.this._target.getName() + "'s Stats", player, AchievementPage.this._target);
/*     */         }
/*     */         
/* 144 */         ((AchievementShop)AchievementPage.this.getShop()).openPageForPlayer(AchievementPage.this.getPlayer(), page);
/* 145 */         player.playSound(player.getLocation(), Sound.CLICK, 1.0F, 1.0F);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private void addStats()
/*     */   {
/* 153 */     if (this._category.getStatsToDisplay().length == 0) {
/* 154 */       return;
/*     */     }
/* 156 */     Material material = Material.BOOK;
/* 157 */     String itemName = C.Bold + this._category.getFriendlyName() + " Stats";
/* 158 */     List<String> lore = new ArrayList();
/* 159 */     lore.add(" ");
/* 160 */     this._category.addStats(getClientManager(), this._statsManager, lore, getPlayer(), this._target);
/*     */     
/* 162 */     ItemStack item = new ItemStack(material);
/* 163 */     ItemMeta meta = item.getItemMeta();
/* 164 */     meta.setDisplayName(ChatColor.RESET + itemName);
/* 165 */     meta.setLore(lore);
/* 166 */     item.setItemMeta(meta);
/*     */     
/* 168 */     setItem(22, item);
/*     */   }
/*     */   
/*     */   public List<Achievement> getAchievements()
/*     */   {
/* 173 */     List<Achievement> achievements = new ArrayList();
/*     */     Achievement[] arrayOfAchievement;
/* 175 */     int j = (arrayOfAchievement = Achievement.values()).length; for (int i = 0; i < j; i++) { Achievement achievement = arrayOfAchievement[i];
/*     */       
/* 177 */       if (achievement.getCategory() == this._category) {
/* 178 */         achievements.add(achievement);
/*     */       }
/*     */     }
/* 181 */     return achievements;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\ui\page\AchievementPage.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */