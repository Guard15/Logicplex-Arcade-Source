/*    */ package mineplex.core.achievement.ui;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.achievement.AchievementManager;
/*    */ import mineplex.core.achievement.ui.page.AchievementMainPage;
/*    */ import mineplex.core.common.CurrencyType;
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ import mineplex.core.donation.DonationManager;
/*    */ import mineplex.core.shop.ShopBase;
/*    */ import mineplex.core.shop.page.ShopPageBase;
/*    */ import mineplex.core.stats.StatsManager;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AchievementShop
/*    */   extends ShopBase<AchievementManager>
/*    */ {
/*    */   private StatsManager _statsManager;
/*    */   
/*    */   public AchievementShop(AchievementManager plugin, StatsManager statsManager, CoreClientManager clientManager, DonationManager donationManager, String name)
/*    */   {
/* 26 */     super(plugin, clientManager, donationManager, name, new CurrencyType[0]);
/* 27 */     this._statsManager = statsManager;
/*    */   }
/*    */   
/*    */   protected ShopPageBase<AchievementManager, ? extends ShopBase<AchievementManager>> buildPagesFor(Player player)
/*    */   {
/* 32 */     return BuildPagesFor(player, player);
/*    */   }
/*    */   
/*    */   protected ShopPageBase<AchievementManager, ? extends ShopBase<AchievementManager>> BuildPagesFor(Player player, Player target) {
/* 36 */     return new AchievementMainPage((AchievementManager)getPlugin(), this._statsManager, this, getClientManager(), getDonationManager(), target.getName() + "'s Stats", player, target);
/*    */   }
/*    */   
/*    */   public boolean attemptShopOpen(Player player, Player target) {
/* 40 */     if (!getOpenedShop().contains(player.getName())) {
/* 41 */       if (!canOpenShop(player)) {
/* 42 */         return false;
/*    */       }
/* 44 */       getOpenedShop().add(player.getName());
/* 45 */       openShopForPlayer(player);
/* 46 */       if (!getPlayerPageMap().containsKey(player.getName())) {
/* 47 */         getPlayerPageMap().put(player.getName(), BuildPagesFor(player, target));
/*    */       }
/* 49 */       openPageForPlayer(player, getOpeningPageForPlayer(player));
/* 50 */       return true;
/*    */     }
/* 52 */     return false;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\ui\AchievementShop.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */