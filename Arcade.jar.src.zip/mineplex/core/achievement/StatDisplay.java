/*    */ package mineplex.core.achievement;
/*    */ 
/*    */ 
/*    */ public class StatDisplay
/*    */ {
/*    */   public String _displayName;
/*    */   
/*    */   public String[] _stats;
/*  9 */   public static final StatDisplay WINS = new StatDisplay("Wins");
/* 10 */   public static final StatDisplay LOSSES = new StatDisplay("Losses");
/* 11 */   public static final StatDisplay KILLS = new StatDisplay("Kills");
/* 12 */   public static final StatDisplay DEATHS = new StatDisplay("Deaths");
/* 13 */   public static final StatDisplay GEMS_EARNED = new StatDisplay("Gems Earned", new String[] { "GemsEarned" });
/* 14 */   public static final StatDisplay TIME_IN_GAME = new StatDisplay("Time In Game", new String[] { "TimeInGame" });
/* 15 */   public static final StatDisplay GAMES_PLAYED = new StatDisplay("Games Played", new String[] { "Wins", "Losses" });
/*    */   
/*    */   public StatDisplay(String stat) {
/* 18 */     this._displayName = stat;
/* 19 */     this._stats = new String[] { stat };
/*    */   }
/*    */   
/*    */   public StatDisplay(String displayName, String... stats) {
/* 23 */     this._displayName = displayName;
/* 24 */     this._stats = stats;
/*    */   }
/*    */   
/*    */   public String getDisplayName() {
/* 28 */     return this._displayName;
/*    */   }
/*    */   
/*    */   public String[] getStats() {
/* 32 */     return this._stats;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\achievement\StatDisplay.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */