/*    */ package mineplex.core.itemstack;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ 
/*    */ 
/*    */ public class ItemLayout
/*    */ {
/* 10 */   private int _invSize = 0;
/* 11 */   private ArrayList<Integer> _size = new ArrayList();
/*    */   
/*    */   public ItemLayout(String... strings)
/*    */   {
/* 15 */     this._invSize = (strings.length * 9);
/* 16 */     for (int row = 0; row < strings.length; row++)
/*    */     {
/* 18 */       String string = strings[row];
/* 19 */       if (string.length() != 9)
/* 20 */         throw new IllegalArgumentException("String '" + string + "' does not a length of 9 but instead has a length of " + 
/* 21 */           string.length());
/* 22 */       char[] cArray = string.toCharArray();
/* 23 */       for (int slot = 0; slot < 9; slot++)
/*    */       {
/* 25 */         char letter = cArray[slot];
/* 26 */         if ('x' != Character.toLowerCase(letter))
/*    */         {
/*    */ 
/*    */ 
/* 30 */           if ('o' == Character.toLowerCase(letter))
/*    */           {
/* 32 */             this._size.add(Integer.valueOf(row * 9 + slot));
/*    */           }
/*    */           else
/* 35 */             throw new IllegalArgumentException("Unrecognised character " + letter);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public ArrayList<Integer> getItemSlots() {
/* 42 */     return this._size;
/*    */   }
/*    */   
/*    */   public ItemStack[] generate(ArrayList<ItemStack> items)
/*    */   {
/* 47 */     return generate((ItemStack[])items.toArray(new ItemStack[0]));
/*    */   }
/*    */   
/*    */   public ItemStack[] generate(ItemStack... items)
/*    */   {
/* 52 */     return generate(true, items);
/*    */   }
/*    */   
/*    */   public ItemStack[] generate(boolean doRepeats, ItemStack... items)
/*    */   {
/* 57 */     ItemStack[] itemArray = new ItemStack[this._invSize];
/*    */     
/* 59 */     if (items.length == 0) {
/* 60 */       return itemArray;
/*    */     }
/* 62 */     int i = 0;
/* 63 */     for (Iterator localIterator = this._size.iterator(); localIterator.hasNext();) { int slot = ((Integer)localIterator.next()).intValue();
/*    */       
/* 65 */       if (i < items.length)
/*    */       {
/* 67 */         if (!doRepeats) break;
/* 68 */         i = 0;
/*    */       }
/*    */       
/*    */ 
/*    */ 
/* 73 */       itemArray[slot] = items[i];
/*    */     }
/*    */     
/* 76 */     return itemArray;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\itemstack\ItemLayout.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */