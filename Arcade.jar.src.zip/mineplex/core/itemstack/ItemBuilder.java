/*     */ package mineplex.core.itemstack;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Color;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.enchantments.Enchantment;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.ItemMeta.Spigot;
/*     */ import org.bukkit.inventory.meta.LeatherArmorMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ 
/*     */ public class ItemBuilder
/*     */ {
/*     */   private int _amount;
/*     */   private Color _color;
/*     */   private short _data;
/*     */   
/*     */   private static ArrayList<String> split(String string, int maxLength)
/*     */   {
/*  25 */     String[] split = string.split(" ");
/*  26 */     string = "";
/*  27 */     ArrayList<String> newString = new ArrayList();
/*  28 */     for (int i = 0; i < split.length; i++)
/*     */     {
/*  30 */       string = string + (string.length() == 0 ? "" : " ") + split[i];
/*  31 */       if (ChatColor.stripColor(string).length() > maxLength)
/*     */       {
/*     */ 
/*  34 */         newString.add((newString.size() > 0 ? ChatColor.getLastColors((String)newString.get(newString.size() - 1)) : "") + string);
/*  35 */         string = "";
/*     */       }
/*     */     }
/*  38 */     if (string.length() > 0)
/*  39 */       newString.add((newString.size() > 0 ? ChatColor.getLastColors((String)newString.get(newString.size() - 1)) : "") + string);
/*  40 */     return newString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private final HashMap<Enchantment, Integer> _enchants = new HashMap();
/*  47 */   private final List<String> _lore = new ArrayList();
/*     */   
/*     */   private Material _mat;
/*  50 */   private String _title = null;
/*     */   private boolean _unbreakable;
/*  52 */   private String _playerHeadName = null;
/*     */   
/*     */   public ItemBuilder(ItemStack item)
/*     */   {
/*  56 */     this(item.getType(), item.getDurability());
/*  57 */     this._amount = item.getAmount();
/*  58 */     this._enchants.putAll(item.getEnchantments());
/*  59 */     item.getType();
/*     */     
/*     */ 
/*     */ 
/*  63 */     if (item.hasItemMeta())
/*     */     {
/*  65 */       ItemMeta meta = item.getItemMeta();
/*  66 */       if (meta.hasDisplayName())
/*     */       {
/*  68 */         this._title = meta.getDisplayName();
/*     */       }
/*  70 */       if (meta.hasLore())
/*     */       {
/*  72 */         this._lore.addAll(meta.getLore());
/*     */       }
/*  74 */       if ((meta instanceof LeatherArmorMeta))
/*     */       {
/*  76 */         setColor(((LeatherArmorMeta)meta).getColor());
/*     */       }
/*  78 */       this._unbreakable = meta.spigot().isUnbreakable();
/*     */     }
/*     */   }
/*     */   
/*     */   public ItemBuilder(Material mat)
/*     */   {
/*  84 */     this(mat, 1);
/*     */   }
/*     */   
/*     */   public ItemBuilder(Material mat, int amount)
/*     */   {
/*  89 */     this(mat, amount, (short)0);
/*     */   }
/*     */   
/*     */   public ItemBuilder(Material mat, int amount, short data)
/*     */   {
/*  94 */     this._mat = mat;
/*  95 */     this._amount = amount;
/*  96 */     this._data = data;
/*     */   }
/*     */   
/*     */   public ItemBuilder(Material mat, short data)
/*     */   {
/* 101 */     this(mat, 1, data);
/*     */   }
/*     */   
/*     */   public ItemBuilder addEnchantment(Enchantment enchant, int level)
/*     */   {
/* 106 */     if (this._enchants.containsKey(enchant))
/*     */     {
/* 108 */       this._enchants.remove(enchant);
/*     */     }
/* 110 */     this._enchants.put(enchant, Integer.valueOf(level));
/* 111 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder addLore(String... lores) {
/*     */     String[] arrayOfString;
/* 116 */     int j = (arrayOfString = lores).length; for (int i = 0; i < j; i++) { String lore = arrayOfString[i];
/*     */       
/* 118 */       this._lore.add(ChatColor.GRAY + lore);
/*     */     }
/* 120 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder addLore(String lore, int maxLength)
/*     */   {
/* 125 */     this._lore.addAll(split(lore, maxLength));
/* 126 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder addLores(List<String> lores)
/*     */   {
/* 131 */     this._lore.addAll(lores);
/* 132 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder addLores(List<String> lores, int maxLength)
/*     */   {
/* 137 */     for (String lore : lores)
/*     */     {
/* 139 */       addLore(lore, maxLength);
/*     */     }
/* 141 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder addLores(String[] description, int maxLength)
/*     */   {
/* 146 */     return addLores(java.util.Arrays.asList(description), maxLength);
/*     */   }
/*     */   
/*     */   public ItemStack build()
/*     */   {
/* 151 */     Material mat = this._mat;
/* 152 */     if (mat == null)
/*     */     {
/* 154 */       mat = Material.AIR;
/* 155 */       org.bukkit.Bukkit.getLogger().warning("Null material!");
/*     */     }
/* 157 */     else if (mat == Material.AIR)
/*     */     {
/* 159 */       org.bukkit.Bukkit.getLogger().warning("Air material!");
/*     */     }
/* 161 */     ItemStack item = new ItemStack(mat, this._amount, this._data);
/* 162 */     ItemMeta meta = item.getItemMeta();
/* 163 */     if (meta != null)
/*     */     {
/* 165 */       if (this._title != null)
/*     */       {
/* 167 */         meta.setDisplayName(this._title);
/*     */       }
/* 169 */       if (!this._lore.isEmpty())
/*     */       {
/* 171 */         meta.setLore(this._lore);
/*     */       }
/* 173 */       if ((meta instanceof LeatherArmorMeta))
/*     */       {
/* 175 */         ((LeatherArmorMeta)meta).setColor(this._color);
/*     */       }
/* 177 */       else if (((meta instanceof SkullMeta)) && (this._playerHeadName != null))
/*     */       {
/* 179 */         ((SkullMeta)meta).setOwner(this._playerHeadName);
/*     */       }
/* 181 */       meta.spigot().setUnbreakable(isUnbreakable());
/* 182 */       item.setItemMeta(meta);
/*     */     }
/* 184 */     item.addUnsafeEnchantments(this._enchants);
/*     */     
/*     */ 
/*     */ 
/* 188 */     return item;
/*     */   }
/*     */   
/*     */ 
/*     */   public ItemBuilder clone()
/*     */   {
/* 194 */     ItemBuilder newBuilder = new ItemBuilder(this._mat);
/*     */     
/* 196 */     newBuilder.setTitle(this._title);
/* 197 */     for (String lore : this._lore)
/*     */     {
/* 199 */       newBuilder.addLore(new String[] { lore });
/*     */     }
/* 201 */     for (Map.Entry<Enchantment, Integer> entry : this._enchants.entrySet())
/*     */     {
/* 203 */       newBuilder.addEnchantment((Enchantment)entry.getKey(), ((Integer)entry.getValue()).intValue());
/*     */     }
/* 205 */     newBuilder.setColor(this._color);
/*     */     
/*     */ 
/* 208 */     return newBuilder;
/*     */   }
/*     */   
/*     */   public HashMap<Enchantment, Integer> getAllEnchantments()
/*     */   {
/* 213 */     return this._enchants;
/*     */   }
/*     */   
/*     */   public Color getColor()
/*     */   {
/* 218 */     return this._color;
/*     */   }
/*     */   
/*     */   public short getData()
/*     */   {
/* 223 */     return this._data;
/*     */   }
/*     */   
/*     */   public int getEnchantmentLevel(Enchantment enchant)
/*     */   {
/* 228 */     return ((Integer)this._enchants.get(enchant)).intValue();
/*     */   }
/*     */   
/*     */   public List<String> getLore()
/*     */   {
/* 233 */     return this._lore;
/*     */   }
/*     */   
/*     */   public String getTitle()
/*     */   {
/* 238 */     return this._title;
/*     */   }
/*     */   
/*     */   public Material getType()
/*     */   {
/* 243 */     return this._mat;
/*     */   }
/*     */   
/*     */   public boolean hasEnchantment(Enchantment enchant)
/*     */   {
/* 248 */     return this._enchants.containsKey(enchant);
/*     */   }
/*     */   
/*     */   public boolean isItem(ItemStack item)
/*     */   {
/* 253 */     ItemMeta meta = item.getItemMeta();
/* 254 */     if (item.getType() != getType())
/*     */     {
/* 256 */       return false;
/*     */     }
/* 258 */     if ((!meta.hasDisplayName()) && (getTitle() != null))
/*     */     {
/* 260 */       return false;
/*     */     }
/* 262 */     if (!meta.getDisplayName().equals(getTitle()))
/*     */     {
/* 264 */       return false;
/*     */     }
/* 266 */     if ((!meta.hasLore()) && (!getLore().isEmpty()))
/*     */     {
/* 268 */       return false;
/*     */     }
/* 270 */     if (meta.hasLore())
/*     */     {
/* 272 */       for (String lore : meta.getLore())
/*     */       {
/* 274 */         if (!getLore().contains(lore))
/*     */         {
/* 276 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 280 */     for (Enchantment enchant : item.getEnchantments().keySet())
/*     */     {
/* 282 */       if (!hasEnchantment(enchant))
/*     */       {
/* 284 */         return false;
/*     */       }
/*     */     }
/* 287 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isUnbreakable()
/*     */   {
/* 292 */     return this._unbreakable;
/*     */   }
/*     */   
/*     */   public ItemBuilder setAmount(int amount)
/*     */   {
/* 297 */     this._amount = amount;
/* 298 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setColor(Color color)
/*     */   {
/* 303 */     if (!this._mat.name().contains("LEATHER_"))
/*     */     {
/* 305 */       throw new IllegalArgumentException("Can only dye leather armor!");
/*     */     }
/* 307 */     this._color = color;
/* 308 */     return this;
/*     */   }
/*     */   
/*     */   public void setData(short newData)
/*     */   {
/* 313 */     this._data = newData;
/*     */   }
/*     */   
/*     */   public ItemBuilder setPotion(org.bukkit.potion.Potion potion)
/*     */   {
/* 318 */     if (this._mat != Material.POTION)
/*     */     {
/* 320 */       this._mat = Material.POTION;
/*     */     }
/*     */     
/* 323 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setRawTitle(String title)
/*     */   {
/* 328 */     this._title = title;
/* 329 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setTitle(String title)
/*     */   {
/* 334 */     this._title = 
/*     */     
/* 336 */       (((title.length() > 2) && (ChatColor.getLastColors(title.substring(0, 2)).length() == 0) ? ChatColor.WHITE : title == null ? null : "") + title);
/* 337 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setTitle(String title, int maxLength)
/*     */   {
/* 342 */     if ((title != null) && (ChatColor.stripColor(title).length() > maxLength))
/*     */     {
/* 344 */       ArrayList<String> lores = split(title, maxLength);
/* 345 */       for (int i = 1; i < lores.size(); i++)
/*     */       {
/* 347 */         this._lore.add((String)lores.get(i));
/*     */       }
/* 349 */       title = (String)lores.get(0);
/*     */     }
/* 351 */     setTitle(title);
/* 352 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setType(Material mat)
/*     */   {
/* 357 */     this._mat = mat;
/* 358 */     return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setUnbreakable(boolean setUnbreakable)
/*     */   {
/* 363 */     this._unbreakable = setUnbreakable;return this;
/*     */   }
/*     */   
/*     */   public ItemBuilder setPlayerHead(String playerName)
/*     */   {
/* 368 */     this._playerHeadName = playerName;
/* 369 */     return this;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\itemstack\ItemBuilder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */