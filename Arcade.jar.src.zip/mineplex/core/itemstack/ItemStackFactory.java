/*     */ package mineplex.core.itemstack;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.inventory.CraftItemStack;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.Item;
/*     */ import org.bukkit.entity.Monster;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.entity.EntityShootBowEvent;
/*     */ import org.bukkit.event.entity.ItemSpawnEvent;
/*     */ import org.bukkit.event.inventory.FurnaceSmeltEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.inventory.InventoryType.SlotType;
/*     */ import org.bukkit.event.inventory.PrepareItemCraftEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.inventory.CraftingInventory;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.ItemMeta.Spigot;
/*     */ import org.bukkit.material.MaterialData;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class ItemStackFactory extends MiniPlugin
/*     */ {
/*     */   public static ItemStackFactory Instance;
/*     */   private HashMap<Integer, HashMap<Byte, Map.Entry<String, Boolean>>> _names;
/*     */   private HashMap<Integer, HashMap<Byte, String[]>> _lores;
/*  47 */   private String _nameFormat = "§r" + C.mItem;
/*     */   
/*  49 */   private HashSet<Listener> _statListeners = new HashSet();
/*     */   
/*  51 */   private boolean _customNames = false;
/*     */   
/*     */   protected ItemStackFactory(JavaPlugin plugin, boolean customNames)
/*     */   {
/*  55 */     super("ItemStack Factory", plugin);
/*     */     
/*  57 */     AddDefault();
/*     */     
/*  59 */     if (customNames) {
/*  60 */       SetCustom();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void Initialize(JavaPlugin plugin, boolean customNames) {
/*  65 */     Instance = new ItemStackFactory(plugin, customNames);
/*     */   }
/*     */   
/*     */   public void AddStatListener(Listener listener)
/*     */   {
/*  70 */     this._statListeners.add(listener);
/*  71 */     registerEvents(listener);
/*     */   }
/*     */   
/*     */   private void SetCustom()
/*     */   {
/*  76 */     Add(0, (byte)0, "Unarmed", false);
/*     */     
/*  78 */     Add(Material.DIAMOND_SWORD, (byte)0, ChatColor.GOLD + "Diamond Sword", 
/*  79 */       new String[] {
/*  80 */       C.cGray + "Damage: " + C.cYellow + "6", 
/*  81 */       "" }, 
/*  82 */       true);
/*     */     
/*  84 */     Add(Material.IRON_SWORD, (byte)0, "Iron Sword", 
/*  85 */       new String[] {
/*  86 */       C.cGray + "Damage: " + C.cYellow + "6", 
/*  87 */       "" }, 
/*  88 */       true);
/*     */     
/*  90 */     Add(Material.GOLD_SWORD, (byte)0, ChatColor.GOLD + "Power Sword", 
/*  91 */       new String[] {
/*  92 */       C.cGray + "Damage: " + C.cYellow + "7", 
/*  93 */       "" }, 
/*  94 */       true);
/*     */     
/*  96 */     Add(Material.DIAMOND_AXE, (byte)0, ChatColor.GOLD + "Diamond Axe", 
/*  97 */       new String[] {
/*  98 */       C.cGray + "Damage: " + C.cYellow + "6", 
/*  99 */       "" }, 
/* 100 */       true);
/*     */     
/* 102 */     Add(Material.IRON_AXE, (byte)0, "Iron Axe", 
/* 103 */       new String[] {
/* 104 */       C.cGray + "Damage: " + C.cYellow + "6", 
/* 105 */       "" }, 
/* 106 */       true);
/*     */     
/* 108 */     Add(Material.GOLD_AXE, (byte)0, ChatColor.GOLD + "Power Axe", 
/* 109 */       new String[] {
/* 110 */       C.cGray + "Damage: " + C.cYellow + "7", 
/* 111 */       "" }, 
/* 112 */       true);
/*     */     
/* 114 */     Add(Material.RECORD_5, (byte)0, "50,000 Coin Token", true);
/*     */     
/* 116 */     Add(Material.IRON_HELMET, (byte)0, "Knights Helm", true);
/* 117 */     Add(Material.IRON_CHESTPLATE, (byte)0, "Knights Chestplate", true);
/* 118 */     Add(Material.IRON_LEGGINGS, (byte)0, "Knights Leggings", true);
/* 119 */     Add(Material.IRON_BOOTS, (byte)0, "Knights Boots", true);
/*     */     
/* 121 */     Add(Material.CHAINMAIL_HELMET, (byte)0, "Rangers Cap", true);
/* 122 */     Add(Material.CHAINMAIL_CHESTPLATE, (byte)0, "Rangers Vest", true);
/* 123 */     Add(Material.CHAINMAIL_LEGGINGS, (byte)0, "Rangers Leggings", true);
/* 124 */     Add(Material.CHAINMAIL_BOOTS, (byte)0, "Rangers Boots", true);
/*     */     
/* 126 */     Add(Material.LEATHER_HELMET, (byte)0, "Assassins Cap", true);
/* 127 */     Add(Material.LEATHER_CHESTPLATE, (byte)0, "Assassins Vest", true);
/* 128 */     Add(Material.LEATHER_LEGGINGS, (byte)0, "Assassins Chaps", true);
/* 129 */     Add(Material.LEATHER_BOOTS, (byte)0, "Assassins Boots", true);
/*     */     
/* 131 */     Add(Material.DIAMOND_HELMET, (byte)0, "Brutes Helm", true);
/* 132 */     Add(Material.DIAMOND_CHESTPLATE, (byte)0, "Brutes Chestplate", true);
/* 133 */     Add(Material.DIAMOND_LEGGINGS, (byte)0, "Brutes Leggings", true);
/* 134 */     Add(Material.DIAMOND_BOOTS, (byte)0, "Brutes Boots", true);
/*     */     
/* 136 */     Add(Material.GOLD_HELMET, (byte)0, "Mages Helm", true);
/* 137 */     Add(Material.GOLD_CHESTPLATE, (byte)0, "Mages Chestplate", true);
/* 138 */     Add(Material.GOLD_LEGGINGS, (byte)0, "Mages Leggings", true);
/* 139 */     Add(Material.GOLD_BOOTS, (byte)0, "Mages Boots", true);
/*     */     
/* 141 */     Add(Material.ENDER_CHEST, (byte)0, "Class Unlock Shop", true);
/* 142 */     Add(Material.ENCHANTMENT_TABLE, (byte)0, "Class Setup Table", true);
/* 143 */     Add(Material.BREWING_STAND, (byte)0, "TNT Generator", true);
/* 144 */     Add(Material.BEACON, (byte)0, "Clan Outpost", true);
/*     */     
/* 146 */     Add(Material.GOLD_NUGGET, (byte)0, ChatColor.YELLOW + "Power Charge", true);
/*     */     
/*     */ 
/*     */ 
/* 150 */     Add(Material.MUSHROOM_SOUP, (byte)0, ChatColor.YELLOW + "Mushroom Soup", 
/* 151 */       new String[] {
/* 152 */       C.cGray + "Right-Click: " + C.cYellow + "Consume", 
/* 153 */       C.cGray + "  " + "Regeneration I for 4 Seconds", 
/* 154 */       C.cGray + "  " + "4 Food", 
/* 155 */       "" }, 
/* 156 */       true);
/*     */     
/*     */ 
/* 159 */     Add(Material.POTION, (byte)0, ChatColor.YELLOW + "Water Bottle", 
/* 160 */       new String[] {
/* 161 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 162 */       C.cGray + "  " + "Douses Players", 
/* 163 */       C.cGray + "  " + "Douses Fires", 
/* 164 */       "", 
/* 165 */       C.cGray + "Right-Click: " + C.cYellow + "Drink", 
/* 166 */       C.cGray + "  " + "Douse Self", 
/* 167 */       C.cGray + "  " + "Fire Resistance I for 4 Seconds" }, 
/* 168 */       true);
/*     */     
/* 170 */     Add(Material.SLIME_BALL, (byte)0, ChatColor.YELLOW + "Poison Ball", 
/* 171 */       new String[] {
/* 172 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 173 */       C.cGray + "  " + "Poison I for 6 Seconds", 
/* 174 */       C.cGray + "  " + "Returns to Thrower" }, 
/* 175 */       true);
/*     */     
/* 177 */     Add(Material.ENDER_PEARL, (byte)0, ChatColor.YELLOW + "Ender Pearl", 
/* 178 */       new String[] {
/* 179 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 180 */       C.cGray + "  " + "Ride Ender Pearl", 
/* 181 */       "", 
/* 182 */       C.cGray + "Right-Click: " + C.cYellow + "Consume", 
/* 183 */       C.cGray + "  " + "Removes Negative Effects", 
/* 184 */       C.cGray + "  " + "4 Food" }, 
/* 185 */       true);
/*     */     
/* 187 */     Add(Material.NOTE_BLOCK, (byte)0, ChatColor.YELLOW + "Proximity Incendiary", 
/* 188 */       new String[] {
/* 189 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 190 */       C.cGray + "  " + "Activates after 4 Seconds", 
/* 191 */       C.cGray + "  " + "Detonates on player proximity;", 
/* 192 */       C.cGray + "    " + "30 Fires spew out", 
/* 193 */       C.cGray + "    " + "Fires ignite for 3 Seconds", 
/* 194 */       C.cGray + "    " + "Fires remains for 15 Seconds" }, 
/* 195 */       true);
/*     */     
/* 197 */     Add(Material.REDSTONE_LAMP_ON, (byte)0, ChatColor.YELLOW + "Proximity Zapper", 
/* 198 */       new String[] {
/* 199 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 200 */       C.cGray + "  " + "Activates after 4 Seconds", 
/* 201 */       C.cGray + "  " + "Detonates on player proximity;", 
/* 202 */       C.cGray + "    " + "Lightning strikes the Zapper", 
/* 203 */       C.cGray + "    " + "Silence for 6 seconds", 
/* 204 */       C.cGray + "    " + "Shock for 6 seconds", 
/* 205 */       C.cGray + "    " + "Slow IV for 6 seconds" }, 
/* 206 */       true);
/*     */     
/* 208 */     Add(Material.COMMAND, (byte)0, ChatColor.YELLOW + "Proximity Explosive", 
/* 209 */       new String[] {
/* 210 */       C.cGray + "Left-Click: " + C.cYellow + "Throw", 
/* 211 */       C.cGray + "  " + "Activates after 4 Seconds", 
/* 212 */       C.cGray + "  " + "Detonates on player proximity;", 
/* 213 */       C.cGray + "    " + "8 Range", 
/* 214 */       C.cGray + "    " + "Strong Knockback" }, 
/* 215 */       true);
/*     */     
/*     */ 
/* 218 */     Add(Material.SHEARS, (byte)0, ChatColor.YELLOW + "Scanner VR-9000", 
/* 219 */       new String[] {
/* 220 */       C.cGray + "Right-Click: " + C.cYellow + "Scan Player", 
/* 221 */       C.cGray + "  " + "100 Blocks Range", 
/* 222 */       C.cGray + "  " + "Shows Targets Skills", 
/* 223 */       "" }, 
/* 224 */       true);
/*     */   }
/*     */   
/*     */   private void Add(Material mat, byte data, String name, boolean special)
/*     */   {
/* 229 */     Add(mat.getId(), data, name, null, special);
/*     */   }
/*     */   
/*     */   private void Add(int id, byte data, String name, boolean special)
/*     */   {
/* 234 */     Add(id, data, name, null, special);
/*     */   }
/*     */   
/*     */   private void Add(Material mat, byte data, String name, String[] lore, boolean special)
/*     */   {
/* 239 */     Add(mat.getId(), data, name, lore, special);
/*     */   }
/*     */   
/*     */   private void Add(int id, byte data, String name, String[] lore, boolean special)
/*     */   {
/* 244 */     if (!this._names.containsKey(Integer.valueOf(id))) {
/* 245 */       this._names.put(Integer.valueOf(id), new HashMap());
/*     */     }
/* 247 */     ((HashMap)this._names.get(Integer.valueOf(id))).put(Byte.valueOf(data), new AbstractMap.SimpleEntry(name, Boolean.valueOf(special)));
/*     */     
/* 249 */     if (lore == null) {
/* 250 */       return;
/*     */     }
/* 252 */     if (!this._lores.containsKey(Integer.valueOf(id))) {
/* 253 */       this._lores.put(Integer.valueOf(id), new HashMap());
/*     */     }
/* 255 */     ((HashMap)this._lores.get(Integer.valueOf(id))).put(Byte.valueOf(data), lore);
/*     */   }
/*     */   
/*     */   private void AddDefault()
/*     */   {
/* 260 */     this._names = new HashMap();
/* 261 */     this._lores = new HashMap();
/*     */     
/* 263 */     for (int id = 0; id < 10000; id++)
/*     */     {
/* 265 */       Material mat = Material.getMaterial(id);
/*     */       
/* 267 */       if (mat != null)
/*     */       {
/*     */ 
/*     */ 
/* 271 */         HashMap<Byte, Map.Entry<String, Boolean>> variants = new HashMap();
/* 272 */         this._names.put(Integer.valueOf(id), variants);
/*     */         
/* 274 */         for (byte data = 0; data < 50; data = (byte)(data + 1))
/*     */         {
/*     */           try
/*     */           {
/* 278 */             String name = "";
/*     */             
/*     */ 
/* 281 */             org.bukkit.inventory.ItemStack stack = new org.bukkit.inventory.ItemStack(id, 1, data);
/* 282 */             if ((CraftItemStack.asNMSCopy(stack) != null) && (CraftItemStack.asNMSCopy(stack).getName() != null)) {
/* 283 */               name = CraftItemStack.asNMSCopy(stack).getName();
/*     */             }
/* 285 */             if (id == 140) {
/* 286 */               name = "Flower Pot";
/*     */             }
/* 288 */             if (name.length() == 0) {
/* 289 */               name = Clean(mat.toString());
/*     */             }
/*     */             
/* 292 */             boolean duplicate = false;
/* 293 */             for (Map.Entry<String, Boolean> cur : variants.values()) {
/* 294 */               if (((String)cur.getKey()).equals(name))
/*     */               {
/* 296 */                 duplicate = true;
/* 297 */                 break;
/*     */               }
/*     */             }
/* 300 */             if (!duplicate)
/*     */             {
/*     */ 
/* 303 */               variants.put(Byte.valueOf(data), new AbstractMap.SimpleEntry(name, Boolean.valueOf(mat.getMaxStackSize() == 1)));
/*     */             }
/*     */           }
/*     */           catch (Exception localException) {}
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String Clean(String string)
/*     */   {
/* 317 */     String out = "";
/* 318 */     String[] words = string.split("_");
/*     */     String[] arrayOfString1;
/* 320 */     int j = (arrayOfString1 = words).length; for (int i = 0; i < j; i++) { String word = arrayOfString1[i];
/*     */       
/* 322 */       if (word.length() < 1) {
/* 323 */         return "Unknown";
/*     */       }
/* 325 */       out = out + word.charAt(0) + word.substring(1, word.length()).toLowerCase() + " ";
/*     */     }
/*     */     
/* 328 */     return out.substring(0, out.length() - 1);
/*     */   }
/*     */   
/*     */   public String GetItemStackName(org.bukkit.inventory.ItemStack stack)
/*     */   {
/* 333 */     return ((CraftItemStack)stack).getHandle().getName();
/*     */   }
/*     */   
/*     */   public String GetName(org.bukkit.inventory.ItemStack stack, boolean formatted)
/*     */   {
/* 338 */     if (stack == null) {
/* 339 */       return "Unarmed";
/*     */     }
/* 341 */     if (stack.getData() != null) {
/* 342 */       return GetName(stack.getTypeId(), stack.getData().getData(), formatted);
/*     */     }
/* 344 */     return GetName(stack.getTypeId(), (byte)0, formatted);
/*     */   }
/*     */   
/*     */   public String GetName(Block block, boolean formatted)
/*     */   {
/* 349 */     return GetName(block.getTypeId(), block.getData(), formatted);
/*     */   }
/*     */   
/*     */   public String GetName(Material mat, byte data, boolean formatted)
/*     */   {
/* 354 */     return GetName(mat.getId(), data, formatted);
/*     */   }
/*     */   
/*     */   public String GetName(int id, byte data, boolean formatted)
/*     */   {
/* 359 */     String out = "";
/* 360 */     if (formatted) {
/* 361 */       out = this._nameFormat;
/*     */     }
/* 363 */     if (!this._names.containsKey(Integer.valueOf(id))) {
/* 364 */       return out + "Unknown";
/*     */     }
/* 366 */     if (!((HashMap)this._names.get(Integer.valueOf(id))).containsKey(Byte.valueOf(data)))
/*     */     {
/* 368 */       if (((HashMap)this._names.get(Integer.valueOf(id))).containsKey(Integer.valueOf(0))) {
/* 369 */         return out + (String)((Map.Entry)((HashMap)this._names.get(Integer.valueOf(id))).get(Integer.valueOf(0))).getKey();
/*     */       }
/* 371 */       Iterator localIterator = ((HashMap)this._names.get(Integer.valueOf(id))).values().iterator(); if (localIterator.hasNext()) { Map.Entry<String, Boolean> cur = (Map.Entry)localIterator.next();
/* 372 */         return (String)cur.getKey();
/*     */       }
/* 374 */       return out + "Unknown";
/*     */     }
/*     */     
/* 377 */     return out + (String)((Map.Entry)((HashMap)this._names.get(Integer.valueOf(id))).get(Byte.valueOf(data))).getKey();
/*     */   }
/*     */   
/*     */   public boolean IsSpecial(org.bukkit.inventory.ItemStack stack)
/*     */   {
/* 382 */     if (stack == null) {
/* 383 */       return false;
/*     */     }
/* 385 */     if (stack.getData() != null) {
/* 386 */       return IsSpecial(stack.getTypeId(), stack.getData().getData());
/*     */     }
/* 388 */     return IsSpecial(stack.getTypeId(), (byte)0);
/*     */   }
/*     */   
/*     */   public boolean IsSpecial(Material mat, byte data)
/*     */   {
/* 393 */     return IsSpecial(mat.getId(), data);
/*     */   }
/*     */   
/*     */   public boolean IsSpecial(int id, byte data)
/*     */   {
/* 398 */     if (!this._names.containsKey(Integer.valueOf(id))) {
/* 399 */       return false;
/*     */     }
/* 401 */     if (!((HashMap)this._names.get(Integer.valueOf(id))).containsKey(Byte.valueOf(data))) {
/* 402 */       if (((HashMap)this._names.get(Integer.valueOf(id))).containsKey(Integer.valueOf(0))) {
/* 403 */         return ((Boolean)((Map.Entry)((HashMap)this._names.get(Integer.valueOf(id))).get(Integer.valueOf(0))).getValue()).booleanValue();
/*     */       }
/* 405 */       return false;
/*     */     }
/* 407 */     return ((Boolean)((Map.Entry)((HashMap)this._names.get(Integer.valueOf(id))).get(Byte.valueOf(data))).getValue()).booleanValue();
/*     */   }
/*     */   
/*     */   public void StatsArmorRename(org.bukkit.inventory.ItemStack item, int damage)
/*     */   {
/* 412 */     if (!this._customNames) {
/* 413 */       return;
/*     */     }
/* 415 */     if (item == null) {
/* 416 */       return;
/*     */     }
/* 418 */     if (item.getMaxStackSize() > 1) {
/* 419 */       return;
/*     */     }
/* 421 */     damage += GetLoreVar(item, "Damage Tanked", 0);
/*     */     
/* 423 */     SetLoreVar(item, "Damage Tanked", damage);
/*     */     
/* 425 */     if (damage >= 10000) item.addEnchantment(org.bukkit.enchantments.Enchantment.DURABILITY, 1);
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void StatsBlockMined(BlockBreakEvent event)
/*     */   {
/* 431 */     if (!this._customNames) {
/* 432 */       return;
/*     */     }
/* 434 */     if (event.isCancelled()) {
/* 435 */       return;
/*     */     }
/* 437 */     org.bukkit.inventory.ItemStack item = event.getPlayer().getItemInHand();
/*     */     
/* 439 */     if (item == null) {
/* 440 */       return;
/*     */     }
/* 442 */     if (item.getMaxStackSize() > 1) {
/* 443 */       return;
/*     */     }
/* 445 */     int blocks = 1 + GetLoreVar(item, "Blocks Mined", 0);
/* 446 */     SetLoreVar(item, "Blocks Mined", blocks);
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.HIGHEST)
/*     */   public void StatsKillMob(EntityDeathEvent event)
/*     */   {
/* 452 */     if (!this._customNames) {
/* 453 */       return;
/*     */     }
/* 455 */     if (!(event.getEntity() instanceof Monster)) {
/* 456 */       return;
/*     */     }
/* 458 */     Monster ent = (Monster)event.getEntity();
/*     */     
/* 460 */     if (ent.getKiller() == null) {
/* 461 */       return;
/*     */     }
/* 463 */     if (ent.getKiller().isBlocking()) {
/* 464 */       return;
/*     */     }
/* 466 */     org.bukkit.inventory.ItemStack item = ent.getKiller().getItemInHand();
/*     */     
/* 468 */     if (item == null) {
/* 469 */       return;
/*     */     }
/* 471 */     if (item.getMaxStackSize() > 1) {
/* 472 */       return;
/*     */     }
/* 474 */     int kills = 1 + GetLoreVar(item, "Monster Kills", 0);
/*     */     
/* 476 */     SetLoreVar(item, "Monster Kills", kills);
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void StatsBowShoot(EntityShootBowEvent event)
/*     */   {
/* 482 */     if (!this._customNames) {
/* 483 */       return;
/*     */     }
/* 485 */     if (event.isCancelled()) {
/* 486 */       return;
/*     */     }
/* 488 */     int shots = 1 + GetLoreVar(event.getBow(), "Arrows Shot", 0);
/*     */     
/* 490 */     SetLoreVar(event.getBow(), "Arrows Shot", shots);
/*     */     
/* 492 */     int hits = GetLoreVar(event.getBow(), "Arrows Hit", 0);
/*     */     
/* 494 */     double acc = UtilMath.trim(1, hits / shots * 100.0D);
/*     */     
/* 496 */     SetLoreVar(event.getBow(), "Accuracy", acc + "%");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void RenameSpawn(ItemSpawnEvent event)
/*     */   {
/* 502 */     if (!this._customNames) {
/* 503 */       return;
/*     */     }
/* 505 */     if (event.isCancelled()) {
/* 506 */       return;
/*     */     }
/*     */     
/* 509 */     String color = ChatColor.getLastColors(GetItemStackName(event.getEntity().getItemStack()));
/* 510 */     if ((color != null) && (color.length() >= 2) && (color.charAt(1) != 'f')) {
/* 511 */       return;
/*     */     }
/* 513 */     int id = event.getEntity().getItemStack().getTypeId();
/* 514 */     byte data = 0;
/* 515 */     if (event.getEntity().getItemStack().getData() != null) {
/* 516 */       data = event.getEntity().getItemStack().getData().getData();
/*     */     }
/* 518 */     ((CraftItemStack)event.getEntity().getItemStack()).getHandle().c(GetName(id, data, true));
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void RenameArrow(PlayerPickupItemEvent event)
/*     */   {
/* 524 */     if (!this._customNames) {
/* 525 */       return;
/*     */     }
/* 527 */     if (event.isCancelled()) {
/* 528 */       return;
/*     */     }
/* 530 */     org.bukkit.inventory.ItemStack stack = event.getItem().getItemStack();
/*     */     
/* 532 */     if (stack.getType() != Material.ARROW) {
/* 533 */       return;
/*     */     }
/*     */     
/* 536 */     String color = ChatColor.getLastColors(GetItemStackName(stack));
/* 537 */     if ((color != null) && (color.length() >= 2) && (color.charAt(1) != 'f')) {
/* 538 */       return;
/*     */     }
/*     */     
/* 541 */     byte data = 0;
/* 542 */     if (stack.getData() != null) {
/* 543 */       data = stack.getData().getData();
/*     */     }
/*     */     
/* 546 */     event.setCancelled(true);
/* 547 */     event.getItem().remove();
/*     */     
/*     */ 
/* 550 */     if (data == 1) {
/* 551 */       return;
/*     */     }
/* 553 */     event.getPlayer().getInventory().addItem(new org.bukkit.inventory.ItemStack[] { CreateStack(stack.getTypeId(), data, stack.getAmount()) });
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void RenameSmelt(FurnaceSmeltEvent event)
/*     */   {
/* 559 */     if (!this._customNames) {
/* 560 */       return;
/*     */     }
/* 562 */     org.bukkit.inventory.ItemStack stack = event.getResult();
/*     */     
/* 564 */     byte data = 0;
/* 565 */     if (stack.getData() != null) {
/* 566 */       data = stack.getData().getData();
/*     */     }
/* 568 */     org.bukkit.inventory.ItemStack result = CreateStack(stack.getTypeId(), data, stack.getAmount());
/*     */     
/* 570 */     event.setResult(result);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void RenameCraft(PrepareItemCraftEvent event)
/*     */   {
/* 576 */     if (!this._customNames) {
/* 577 */       return;
/*     */     }
/* 579 */     org.bukkit.inventory.ItemStack stack = event.getInventory().getResult();
/*     */     
/* 581 */     byte data = 0;
/* 582 */     if (stack.getData() != null) {
/* 583 */       data = stack.getData().getData();
/*     */     }
/* 585 */     String crafter = null;
/* 586 */     if ((event.getViewers().size() == 1) && (stack.getMaxStackSize() == 1)) {
/* 587 */       crafter = ((HumanEntity)event.getViewers().get(0)).getName() + " Crafting";
/*     */     }
/* 589 */     org.bukkit.inventory.ItemStack result = CreateStack(stack.getTypeId(), data, stack.getAmount(), null, new String[0], crafter);
/*     */     
/* 591 */     event.getInventory().setResult(result);
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void RenameCraftAlg(InventoryClickEvent event)
/*     */   {
/* 597 */     if (!this._customNames) {
/* 598 */       return;
/*     */     }
/* 600 */     if (!event.isShiftClick()) {
/* 601 */       return;
/*     */     }
/* 603 */     if (event.getSlotType() != InventoryType.SlotType.RESULT) {
/* 604 */       return;
/*     */     }
/* 606 */     if (!(event.getInventory() instanceof CraftingInventory)) {
/* 607 */       return;
/*     */     }
/* 609 */     CraftingInventory inv = (CraftingInventory)event.getInventory();
/*     */     
/* 611 */     int make = 64;
/*     */     
/*     */     org.bukkit.inventory.ItemStack[] arrayOfItemStack;
/* 614 */     int j = (arrayOfItemStack = inv.getMatrix()).length; for (int i = 0; i < j; i++) { org.bukkit.inventory.ItemStack item = arrayOfItemStack[i];
/* 615 */       if ((item != null) && (item.getType() != Material.AIR) && 
/* 616 */         (item.getAmount() < make))
/* 617 */         make = item.getAmount();
/*     */     }
/* 619 */     make--;
/*     */     
/*     */ 
/* 622 */     for (int i = 0; i < inv.getMatrix().length; i++) {
/* 623 */       if ((inv.getMatrix()[i] != null) && (inv.getMatrix()[i].getType() != Material.AIR))
/*     */       {
/* 625 */         if (inv.getMatrix()[i].getAmount() > make) {
/* 626 */           inv.getMatrix()[i].setAmount(inv.getMatrix()[i].getAmount() - make);
/*     */         } else {
/* 628 */           inv.getMatrix()[i].setAmount(1);
/*     */         }
/*     */       }
/*     */     }
/* 632 */     int id = event.getCurrentItem().getTypeId();
/* 633 */     byte data = 0;
/* 634 */     if (event.getCurrentItem().getData() != null)
/* 635 */       data = event.getCurrentItem().getData().getData();
/* 636 */     int amount = event.getCurrentItem().getAmount();
/*     */     
/*     */ 
/* 639 */     String crafter = null;
/* 640 */     if ((event.getViewers().size() == 1) && (event.getCurrentItem().getMaxStackSize() == 1)) {
/* 641 */       crafter = ((HumanEntity)event.getViewers().get(0)).getName() + " Crafting";
/*     */     }
/*     */     
/* 644 */     for (int i = 0; i < make; i++)
/*     */     {
/* 646 */       org.bukkit.inventory.ItemStack result = CreateStack(id, data, amount, null, new String[0], crafter);
/*     */       
/* 648 */       if (result != null) {
/* 649 */         event.getWhoClicked().getInventory().addItem(new org.bukkit.inventory.ItemStack[] { result });
/*     */       }
/*     */     }
/*     */     
/* 653 */     if ((event.getWhoClicked() instanceof Player))
/*     */     {
/* 655 */       final Player player = (Player)event.getWhoClicked();
/* 656 */       this._plugin.getServer().getScheduler().scheduleSyncDelayedTask(this._plugin, new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/* 660 */           mineplex.core.common.util.UtilInv.Update(player);
/*     */         }
/* 662 */       }, 0L);
/*     */     }
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type)
/*     */   {
/* 668 */     return CreateStack(type.getId(), (byte)0, 1, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id)
/*     */   {
/* 673 */     return CreateStack(id, (byte)0, 1, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, int amount)
/*     */   {
/* 678 */     return CreateStack(type.getId(), (byte)0, amount, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, int amount)
/*     */   {
/* 683 */     return CreateStack(id, (byte)0, amount, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data)
/*     */   {
/* 688 */     return CreateStack(type.getId(), data, 1, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data)
/*     */   {
/* 693 */     return CreateStack(id, data, 1, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount)
/*     */   {
/* 698 */     return CreateStack(type.getId(), data, amount, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount)
/*     */   {
/* 703 */     return CreateStack(id, data, amount, (short)0, null, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, String name)
/*     */   {
/* 708 */     return CreateStack(type.getId(), data, amount, (short)0, name, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, String name)
/*     */   {
/* 713 */     return CreateStack(id, data, amount, (short)0, name, new String[0], null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, String name, List<String> lore)
/*     */   {
/* 718 */     return CreateStack(type.getId(), data, amount, (short)0, name, lore, null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, String name, List<String> lore)
/*     */   {
/* 723 */     return CreateStack(id, data, amount, (short)0, name, lore, null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, String name, String[] lore)
/*     */   {
/* 728 */     return CreateStack(type.getId(), data, amount, (short)0, name, ArrayToList(lore), null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, String name, String[] lore)
/*     */   {
/* 733 */     return CreateStack(id, data, amount, (short)0, name, ArrayToList(lore), null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, short damage, String name, String[] lore)
/*     */   {
/* 738 */     return CreateStack(type.getId(), data, amount, damage, name, ArrayToList(lore), null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, short damage, String name, String[] lore)
/*     */   {
/* 743 */     return CreateStack(id, data, amount, damage, name, ArrayToList(lore), null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, short damage, String name, List<String> lore)
/*     */   {
/* 748 */     return CreateStack(type.getId(), data, amount, damage, name, lore, null);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, String name, List<String> lore, String owner)
/*     */   {
/* 753 */     return CreateStack(type.getId(), data, amount, (short)0, name, lore, owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, String name, List<String> lore, String owner)
/*     */   {
/* 758 */     return CreateStack(id, data, amount, (short)0, name, lore, owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, String name, String[] lore, String owner)
/*     */   {
/* 763 */     return CreateStack(type.getId(), data, amount, (short)0, name, ArrayToList(lore), owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, String name, String[] lore, String owner)
/*     */   {
/* 768 */     return CreateStack(id, data, amount, (short)0, name, ArrayToList(lore), owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, short damage, String name, String[] lore, String owner)
/*     */   {
/* 773 */     return CreateStack(type.getId(), data, amount, damage, name, ArrayToList(lore), owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, short damage, String name, String[] lore, String owner)
/*     */   {
/* 778 */     return CreateStack(id, data, amount, damage, name, ArrayToList(lore), owner);
/*     */   }
/*     */   
/*     */   public org.bukkit.inventory.ItemStack CreateStack(Material type, byte data, int amount, short damage, String name, List<String> lore, String owner)
/*     */   {
/* 783 */     return CreateStack(type.getId(), data, amount, damage, name, lore, owner);
/*     */   }
/*     */   
/*     */ 
/*     */   public org.bukkit.inventory.ItemStack CreateStack(int id, byte data, int amount, short damage, String name, List<String> lore, String owner)
/*     */   {
/*     */     org.bukkit.inventory.ItemStack stack;
/*     */     
/*     */     org.bukkit.inventory.ItemStack stack;
/* 792 */     if (data == 0) {
/* 793 */       stack = new org.bukkit.inventory.ItemStack(id, amount, damage);
/*     */     } else {
/* 795 */       stack = new org.bukkit.inventory.ItemStack(id, amount, damage, Byte.valueOf(data));
/*     */     }
/* 797 */     ItemMeta itemMeta = stack.getItemMeta();
/*     */     
/* 799 */     if (itemMeta == null) {
/* 800 */       return null;
/*     */     }
/* 802 */     boolean setMeta = false;
/*     */     
/*     */ 
/* 805 */     if (name != null)
/*     */     {
/* 807 */       itemMeta.setDisplayName(name);
/* 808 */       setMeta = true;
/*     */     }
/* 810 */     else if (this._customNames)
/*     */     {
/* 812 */       itemMeta.setDisplayName(GetName(stack, true));
/* 813 */       setMeta = true;
/*     */     }
/*     */     
/*     */ 
/* 817 */     if ((this._lores != null) && (this._lores.containsKey(Integer.valueOf(id))) && (((HashMap)this._lores.get(Integer.valueOf(id))).containsKey(Byte.valueOf(data))) && (lore == null))
/*     */     {
/* 819 */       itemMeta.setLore(ArrayToList((String[])((HashMap)this._lores.get(Integer.valueOf(id))).get(Byte.valueOf(data))));
/* 820 */       setMeta = true;
/*     */     }
/*     */     
/*     */ 
/* 824 */     if (owner != null)
/*     */     {
/* 826 */       String[] tokens = owner.split(" ");
/*     */       
/* 828 */       String[] ownerLore = new String[tokens.length + 2];
/*     */       
/* 830 */       ownerLore[0] = (C.cGray + "Owner: " + C.cAqua + tokens[0]);
/*     */       
/* 832 */       if (ownerLore.length >= 3) {
/* 833 */         ownerLore[1] = (C.cGray + "Source: " + C.cAqua + tokens[1]);
/*     */       }
/* 835 */       ownerLore[(ownerLore.length - 2)] = (C.cGray + "Created: " + C.cAqua + mineplex.core.common.util.UtilTime.date());
/*     */       
/* 837 */       ownerLore[(ownerLore.length - 1)] = "";
/*     */       
/* 839 */       if (itemMeta.getLore() != null) itemMeta.setLore(CombineLore(itemMeta.getLore(), ArrayToList(ownerLore))); else {
/* 840 */         itemMeta.setLore(ArrayToList(ownerLore));
/*     */       }
/* 842 */       setMeta = true;
/*     */     }
/*     */     
/*     */ 
/* 846 */     if (lore != null)
/*     */     {
/* 848 */       if (itemMeta.getLore() != null) itemMeta.setLore(CombineLore(itemMeta.getLore(), lore)); else {
/* 849 */         itemMeta.setLore(lore);
/*     */       }
/* 851 */       setMeta = true;
/*     */     }
/*     */     
/* 854 */     if (setMeta) {
/* 855 */       stack.setItemMeta(itemMeta);
/*     */     }
/*     */     
/* 858 */     if (stack.getType().getMaxDurability() > 1)
/*     */     {
/* 860 */       ItemMeta meta = stack.getItemMeta();
/* 861 */       meta.spigot().setUnbreakable(true);
/* 862 */       stack.setItemMeta(meta);
/*     */     }
/*     */     
/* 865 */     return stack;
/*     */   }
/*     */   
/*     */   private List<String> CombineLore(List<String> A, List<String> B)
/*     */   {
/* 870 */     for (String b : B) {
/* 871 */       A.add(b);
/*     */     }
/* 873 */     return A;
/*     */   }
/*     */   
/*     */   public List<String> ArrayToList(String[] array)
/*     */   {
/* 878 */     if (array.length == 0) {
/* 879 */       return null;
/*     */     }
/* 881 */     List<String> list = new ArrayList();
/*     */     String[] arrayOfString;
/* 883 */     int j = (arrayOfString = array).length; for (int i = 0; i < j; i++) { String cur = arrayOfString[i];
/* 884 */       list.add(cur);
/*     */     }
/* 886 */     return list;
/*     */   }
/*     */   
/*     */   public String GetLoreVar(org.bukkit.inventory.ItemStack stack, String var)
/*     */   {
/* 891 */     if (stack == null) {
/* 892 */       return null;
/*     */     }
/* 894 */     ItemMeta meta = stack.getItemMeta();
/*     */     
/* 896 */     if (meta == null) {
/* 897 */       return null;
/*     */     }
/* 899 */     if (meta.getLore() == null) {
/* 900 */       return null;
/*     */     }
/* 902 */     for (String cur : meta.getLore()) {
/* 903 */       if (cur.contains(var))
/*     */       {
/* 905 */         int index = var.split(" ").length;
/*     */         
/* 907 */         String[] tokens = cur.split(" ");
/*     */         
/* 909 */         String out = "";
/* 910 */         for (int i = index; i < tokens.length; i++) {
/* 911 */           out = out + tokens[i] + " ";
/*     */         }
/* 913 */         if (out.length() > 0) {
/* 914 */           out = out.substring(0, out.length() - 1);
/*     */         }
/* 916 */         return out;
/*     */       }
/*     */     }
/* 919 */     return null;
/*     */   }
/*     */   
/*     */   public int GetLoreVar(org.bukkit.inventory.ItemStack stack, String var, int empty)
/*     */   {
/* 924 */     if (stack == null) {
/* 925 */       return empty;
/*     */     }
/* 927 */     ItemMeta meta = stack.getItemMeta();
/*     */     
/* 929 */     if (meta == null) {
/* 930 */       return 0;
/*     */     }
/* 932 */     if (meta.getLore() == null) {
/* 933 */       return 0;
/*     */     }
/* 935 */     for (String cur : meta.getLore()) {
/* 936 */       if (cur.contains(var))
/*     */       {
/* 938 */         String[] tokens = cur.split(" ");
/*     */         
/*     */         try
/*     */         {
/* 942 */           return Integer.parseInt(tokens[(tokens.length - 1)]);
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 946 */           return empty;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 951 */     return 0;
/*     */   }
/*     */   
/*     */   public void SetLoreVar(org.bukkit.inventory.ItemStack stack, String var, String value)
/*     */   {
/* 956 */     if (stack == null) {
/* 957 */       return;
/*     */     }
/* 959 */     ItemMeta meta = stack.getItemMeta();
/*     */     
/* 961 */     if (meta == null) {
/* 962 */       return;
/*     */     }
/* 964 */     ArrayList<String> newLore = new ArrayList();
/*     */     
/* 966 */     boolean inserted = false;
/*     */     
/* 968 */     if (meta.getLore() != null) {
/* 969 */       for (String lore : meta.getLore())
/*     */       {
/* 971 */         if (!lore.contains(var))
/*     */         {
/* 973 */           newLore.add(lore);
/*     */         }
/*     */         else
/*     */         {
/* 977 */           newLore.add(C.cGray + var + ":" + C.cGreen + " " + value);
/* 978 */           inserted = true;
/*     */         }
/*     */       }
/*     */     }
/* 982 */     if (!inserted) {
/* 983 */       newLore.add(C.cGray + var + ":" + C.cGreen + " " + value);
/*     */     }
/* 985 */     meta.setLore(newLore);
/*     */     
/* 987 */     stack.setItemMeta(meta);
/*     */   }
/*     */   
/*     */   public void SetUseCustomNames(boolean var)
/*     */   {
/* 992 */     this._customNames = var;
/*     */   }
/*     */   
/*     */   public void SetCustomNameFormat(String format)
/*     */   {
/* 997 */     this._nameFormat = format;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\itemstack\ItemStackFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */