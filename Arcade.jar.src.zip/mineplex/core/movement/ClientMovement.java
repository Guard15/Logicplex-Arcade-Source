/*   */ package mineplex.core.movement;
/*   */ 
/*   */ import org.bukkit.Location;
/*   */ 
/*   */ public class ClientMovement
/*   */ {
/* 7 */   public long LastGrounded = 0L;
/* 8 */   public long LastMovement = 0L;
/*   */   public Location LastLocation;
/*   */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\movement\ClientMovement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */