/*    */ package mineplex.core.movement;
/*    */ 
/*    */ import mineplex.core.MiniClientPlugin;
/*    */ import mineplex.core.common.util.UtilMath;
/*    */ import mineplex.core.updater.UpdateType;
/*    */ import mineplex.core.updater.event.UpdateEvent;
/*    */ import net.minecraft.server.v1_7_R4.EntityPlayer;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.plugin.java.JavaPlugin;
/*    */ 
/*    */ public class Movement extends MiniClientPlugin<ClientMovement>
/*    */ {
/*    */   public Movement(JavaPlugin plugin)
/*    */   {
/* 17 */     super("Movement", plugin);
/*    */   }
/*    */   
/*    */   @org.bukkit.event.EventHandler
/*    */   public void Update(UpdateEvent event)
/*    */   {
/* 23 */     if (event.getType() == UpdateType.TICK)
/*    */     {
/* 25 */       for (Player cur : getPlugin().getServer().getOnlinePlayers())
/*    */       {
/* 27 */         ClientMovement player = (ClientMovement)Get(cur);
/*    */         
/* 29 */         if ((player.LastLocation != null) && 
/* 30 */           (UtilMath.offset(player.LastLocation, cur.getLocation()) > 0.0D)) {
/* 31 */           player.LastMovement = System.currentTimeMillis();
/*    */         }
/* 33 */         player.LastLocation = cur.getLocation();
/*    */         
/*    */ 
/* 36 */         if (((CraftPlayer)cur).getHandle().onGround) {
/* 37 */           player.LastGrounded = System.currentTimeMillis();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   protected ClientMovement AddPlayer(String player)
/*    */   {
/* 45 */     return new ClientMovement();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\movement\Movement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */