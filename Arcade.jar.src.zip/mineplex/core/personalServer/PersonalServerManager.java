/*     */ package mineplex.core.personalServer;
/*     */ 
/*     */ import java.util.Random;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.jsonchat.ChildJsonMessage;
/*     */ import mineplex.core.common.jsonchat.Color;
/*     */ import mineplex.core.common.jsonchat.JsonMessage;
/*     */ import mineplex.core.common.util.C;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import mineplex.core.itemstack.ItemStackFactory;
/*     */ import mineplex.core.recharge.Recharge;
/*     */ import mineplex.serverdata.Region;
/*     */ import mineplex.serverdata.data.ServerGroup;
/*     */ import mineplex.serverdata.servers.ServerManager;
/*     */ import mineplex.serverdata.servers.ServerRepository;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerInteractEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class PersonalServerManager extends MiniPlugin
/*     */ {
/*     */   private ServerRepository _repository;
/*     */   private CoreClientManager _clientManager;
/*     */   private boolean _us;
/*  37 */   private int _interfaceSlot = 6;
/*     */   private ItemStack _interfaceItem;
/*  39 */   private boolean _giveInterfaceItem = true;
/*     */   
/*     */   public PersonalServerManager(JavaPlugin plugin, CoreClientManager clientManager)
/*     */   {
/*  43 */     super("Personal Server Manager", plugin);
/*     */     
/*  45 */     this._clientManager = clientManager;
/*     */     
/*  47 */     setupConfigValues();
/*     */     
/*  49 */     this._us = plugin.getConfig().getBoolean("serverstatus.us");
/*     */     
/*  51 */     Region region = this._us ? Region.US : Region.EU;
/*  52 */     this._repository = ServerManager.getServerRepository(region);
/*     */     
/*  54 */     this._interfaceItem = ItemStackFactory.Instance.CreateStack(Material.SPECKLED_MELON, (byte)0, 1, C.cGreen + "/hostserver");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onJoin(PlayerJoinEvent event)
/*     */   {
/*  60 */     if (this._giveInterfaceItem)
/*     */     {
/*  62 */       event.getPlayer().getInventory().setItem(this._interfaceSlot, this._interfaceItem);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void openServer(PlayerInteractEvent event)
/*     */   {
/*  69 */     if (this._interfaceItem.equals(event.getPlayer().getItemInHand()))
/*     */     {
/*  71 */       if (!Recharge.Instance.use(event.getPlayer(), "Host Server Melon", 30000L, false, false)) {
/*  72 */         return;
/*     */       }
/*  74 */       if (this._clientManager.Get(event.getPlayer()).GetRank().Has(Rank.LEGEND))
/*     */       {
/*  76 */         showHostMessage(event.getPlayer());
/*     */       }
/*     */       else
/*     */       {
/*  80 */         UtilPlayer.message(event.getPlayer(), F.main("Server", "Only players with " + F.rank(Rank.LEGEND) + C.mBody + "+ can host private servers"));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void showHostMessage(Player player)
/*     */   {
/*  87 */     UtilPlayer.message(player, C.cRed + "------------------------------------------------");
/*  88 */     UtilPlayer.message(player, "This will create a Mineplex Player Server for you.");
/*  89 */     UtilPlayer.message(player, "Here you can play your favorite games with friends!");
/*     */     
/*  91 */     new JsonMessage("Please ").click(mineplex.core.common.jsonchat.ClickEvent.RUN_COMMAND, "/hostserver")
/*  92 */       .hover(mineplex.core.common.jsonchat.HoverEvent.SHOW_TEXT, C.cGray + "Click to Create Server")
/*  93 */       .extra("CLICK HERE").color(Color.GREEN).extra(" to confirm you want to do this.")
/*  94 */       .color(Color.WHITE).send(mineplex.core.common.jsonchat.JsonMessage.MessageType.CHAT_BOX, new Player[] { player });
/*     */     
/*  96 */     UtilPlayer.message(player, C.cRed + "------------------------------------------------");
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/* 102 */     addCommand(new HostServerCommand(this));
/* 103 */     addCommand(new HostEventServerCommand(this));
/*     */   }
/*     */   
/*     */   private void setupConfigValues()
/*     */   {
/*     */     try
/*     */     {
/* 110 */       getPlugin().getConfig().addDefault("serverstatus.us", Boolean.valueOf(true));
/* 111 */       getPlugin().getConfig().set("serverstatus.us", Boolean.valueOf(getPlugin().getConfig().getBoolean("serverstatus.us")));
/*     */       
/* 113 */       getPlugin().saveConfig();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 117 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public void hostServer(Player player, String serverName, boolean eventServer)
/*     */   {
/* 123 */     int ram = 1024;
/* 124 */     int cpu = 1;
/*     */     
/* 126 */     Rank rank = this._clientManager.Get(player).GetRank();
/*     */     
/* 128 */     if ((eventServer) || (rank.Has(Rank.SNR_MODERATOR)) || (rank == Rank.YOUTUBE) || (rank == Rank.TWITCH))
/*     */     {
/* 130 */       ram = 2048;
/* 131 */       cpu = 4;
/*     */     }
/*     */     
/* 134 */     if (eventServer) {
/* 135 */       createGroup(player, "EVENT", ram, cpu, 40, 80, "Event", eventServer);
/*     */     } else {
/* 137 */       createGroup(player, serverName, ram, cpu, 40, 80, "Smash", eventServer);
/*     */     }
/*     */   }
/*     */   
/*     */   private void createGroup(final Player host, final String serverName, final int ram, final int cpu, final int minPlayers, final int maxPlayers, final String games, final boolean event) {
/* 142 */     getPlugin().getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 146 */         for (ServerGroup existingServerGroup : PersonalServerManager.this._repository.getServerGroups(null))
/*     */         {
/* 148 */           if ((existingServerGroup.getPrefix().equalsIgnoreCase(serverName)) || (existingServerGroup.getName().equalsIgnoreCase(serverName)))
/*     */           {
/* 150 */             if (host.getName().equalsIgnoreCase(existingServerGroup.getHost())) {
/* 151 */               host.sendMessage(F.main(PersonalServerManager.this.getName(), "Your server is still being created or already exists.  If you haven't been connected in 20 seconds, type /server " + serverName + "-1."));
/*     */             } else {
/* 153 */               host.sendMessage(C.cRed + "Sorry, but you're not allowed to create a MPS server because you have chosen a name to glitch the system :)");
/*     */             }
/* 155 */             return;
/*     */           }
/*     */         }
/*     */         
/* 159 */         final ServerGroup serverGroup = new ServerGroup(serverName, serverName, host.getName(), ram, cpu, 1, 0, UtilMath.random.nextInt(250) + 19999, true, "arcade.zip", "Arcade.jar", "plugins/Arcade/", minPlayers, maxPlayers, 
/* 160 */           true, false, false, games, "Player", true, event, false, true, false, true, true, false, false, false, false, true, true, true, false, false, "", PersonalServerManager.this._us ? Region.US : Region.EU);
/*     */         
/* 162 */         PersonalServerManager.this.getPlugin().getServer().getScheduler().runTaskAsynchronously(PersonalServerManager.this.getPlugin(), new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 166 */             PersonalServerManager.this._repository.updateServerGroup(serverGroup);
/* 167 */             org.bukkit.Bukkit.getScheduler().runTask(PersonalServerManager.this.getPlugin(), new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 171 */                 this.val$host.sendMessage(F.main(PersonalServerManager.this.getName(), this.val$serverName + "-1 successfully created.  You will be sent to it shortly."));
/* 172 */                 this.val$host.sendMessage(F.main(PersonalServerManager.this.getName(), "If you haven't been connected in 20 seconds, type /server " + this.val$serverName + "-1."));
/*     */               }
/*     */             });
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\personalServer\PersonalServerManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */