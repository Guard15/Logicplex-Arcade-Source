/*    */ package mineplex.core.personalServer;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.recharge.Recharge;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class HostServerCommand
/*    */   extends CommandBase<PersonalServerManager>
/*    */ {
/*    */   public HostServerCommand(PersonalServerManager plugin)
/*    */   {
/* 13 */     super(plugin, Rank.LEGEND, new String[] { "hostserver" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 19 */     if (!Recharge.Instance.use(caller, "Host Server", 30000L, false, false)) {
/* 20 */       return;
/*    */     }
/* 22 */     ((PersonalServerManager)this.Plugin).hostServer(caller, caller.getName(), false);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\personalServer\HostServerCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */