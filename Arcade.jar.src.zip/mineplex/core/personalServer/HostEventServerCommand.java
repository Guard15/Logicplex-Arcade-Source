/*    */ package mineplex.core.personalServer;
/*    */ 
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.recharge.Recharge;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class HostEventServerCommand
/*    */   extends CommandBase<PersonalServerManager>
/*    */ {
/*    */   public HostEventServerCommand(PersonalServerManager plugin)
/*    */   {
/* 13 */     super(plugin, Rank.ADMIN, new String[] { "hostevent" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(Player caller, String[] args)
/*    */   {
/* 19 */     if (!Recharge.Instance.use(caller, "Host Event", 30000L, false, false)) {
/* 20 */       return;
/*    */     }
/* 22 */     ((PersonalServerManager)this.Plugin).hostServer(caller, caller.getName(), true);
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\personalServer\HostEventServerCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */