/*     */ package mineplex.core.blockrestore;
/*     */ 
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ 
/*     */ public class BlockRestoreData
/*     */ {
/*     */   protected Block _block;
/*     */   protected int _fromID;
/*     */   protected byte _fromData;
/*     */   protected int _toID;
/*     */   protected byte _toData;
/*     */   protected long _expireDelay;
/*     */   protected long _epoch;
/*  15 */   protected long _meltDelay = 0L;
/*  16 */   protected long _meltLast = 0L;
/*     */   
/*     */   public BlockRestoreData(Block block, int toID, byte toData, int fromID, byte fromData, long expireDelay, long meltDelay)
/*     */   {
/*  20 */     this._block = block;
/*     */     
/*  22 */     this._fromID = fromID;
/*  23 */     this._fromData = fromData;
/*     */     
/*  25 */     this._toID = toID;
/*  26 */     this._toData = toData;
/*     */     
/*  28 */     this._expireDelay = expireDelay;
/*  29 */     this._epoch = System.currentTimeMillis();
/*     */     
/*  31 */     this._meltDelay = meltDelay;
/*  32 */     this._meltLast = System.currentTimeMillis();
/*     */     
/*  34 */     set();
/*     */   }
/*     */   
/*     */   public boolean expire()
/*     */   {
/*  39 */     if (System.currentTimeMillis() - this._epoch < this._expireDelay) {
/*  40 */       return false;
/*     */     }
/*  42 */     if (melt()) {
/*  43 */       return false;
/*     */     }
/*  45 */     restore();
/*  46 */     return true;
/*     */   }
/*     */   
/*     */   public boolean melt()
/*     */   {
/*  51 */     if ((this._block.getTypeId() != 78) && (this._block.getTypeId() != 80)) {
/*  52 */       return false;
/*     */     }
/*  54 */     if ((this._block.getRelative(BlockFace.UP).getTypeId() == 78) || (this._block.getRelative(BlockFace.UP).getTypeId() == 80))
/*     */     {
/*  56 */       this._meltLast = System.currentTimeMillis();
/*  57 */       return true;
/*     */     }
/*  59 */     if (System.currentTimeMillis() - this._meltLast < this._meltDelay) {
/*  60 */       return true;
/*     */     }
/*  62 */     if (this._block.getTypeId() == 80) {
/*  63 */       this._block.setTypeIdAndData(78, (byte)7, false);
/*     */     }
/*  65 */     byte data = this._block.getData();
/*  66 */     if (data <= 0) {
/*  67 */       return false;
/*     */     }
/*  69 */     this._block.setData((byte)(this._block.getData() - 1));
/*  70 */     this._meltLast = System.currentTimeMillis();
/*  71 */     return true;
/*     */   }
/*     */   
/*     */   public void update(int toIDIn, byte toDataIn)
/*     */   {
/*  76 */     this._toID = toIDIn;
/*  77 */     this._toData = toDataIn;
/*     */     
/*  79 */     set();
/*     */   }
/*     */   
/*     */   public void update(int toID, byte addData, long expireTime)
/*     */   {
/*  84 */     if (toID == 78) {
/*  85 */       if (this._toID == 78) {
/*  86 */         this._toData = ((byte)Math.min(7, this._toData + addData));
/*     */       } else {
/*  88 */         this._toData = addData;
/*     */       }
/*     */     }
/*  91 */     this._toID = toID;
/*     */     
/*  93 */     set();
/*     */     
/*  95 */     this._expireDelay = expireTime;
/*  96 */     this._epoch = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public void update(int toID, byte addData, long expireTime, long meltDelay)
/*     */   {
/* 101 */     if (toID == 78) {
/* 102 */       if (this._toID == 78) {
/* 103 */         this._toData = ((byte)Math.min(7, this._toData + addData));
/*     */       } else {
/* 105 */         this._toData = addData;
/*     */       }
/*     */     }
/* 108 */     this._toID = toID;
/*     */     
/* 110 */     set();
/*     */     
/* 112 */     this._expireDelay = expireTime;
/* 113 */     this._epoch = System.currentTimeMillis();
/* 114 */     if (this._meltDelay < meltDelay) {
/* 115 */       this._meltDelay = ((this._meltDelay + meltDelay) / 2L);
/*     */     }
/*     */   }
/*     */   
/*     */   public void set()
/*     */   {
/* 121 */     if ((this._toID == 78) && (this._toData == 7)) {
/* 122 */       this._block.setTypeIdAndData(80, (byte)0, true);
/*     */     } else {
/* 124 */       this._block.setTypeIdAndData(this._toID, this._toData, true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void restore()
/*     */   {
/* 130 */     this._block.setTypeIdAndData(this._fromID, this._fromData, true);
/*     */   }
/*     */   
/*     */   public void setFromId(int i)
/*     */   {
/* 135 */     this._fromID = i;
/*     */   }
/*     */   
/*     */   public void setFromData(byte i)
/*     */   {
/* 140 */     this._fromData = i;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\blockrestore\BlockRestoreData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */