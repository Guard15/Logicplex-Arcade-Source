/*     */ package mineplex.core.blockrestore;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilMath;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Effect;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPistonExtendEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockRestore
/*     */   extends MiniPlugin
/*     */ {
/*  47 */   private HashMap<Block, BlockRestoreData> _blocks = new HashMap();
/*     */   
/*     */   public BlockRestore(JavaPlugin plugin) {
/*  50 */     super("Block Restore", plugin);
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.LOW)
/*     */   public void BlockBreak(BlockBreakEvent event) {
/*  55 */     if (Contains(event.getBlock())) {
/*  56 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.LOW)
/*     */   public void BlockPlace(BlockPlaceEvent event) {
/*  62 */     if (Contains(event.getBlockPlaced())) {
/*  63 */       event.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler(priority=EventPriority.LOW)
/*     */   public void Piston(BlockPistonExtendEvent event) {
/*  69 */     if (event.isCancelled()) {
/*  70 */       return;
/*     */     }
/*  72 */     Block push = event.getBlock();
/*  73 */     for (int i = 0; i < 13; i++) {
/*  74 */       if ((push = push.getRelative(event.getDirection())).getType() == Material.AIR) {
/*  75 */         return;
/*     */       }
/*  77 */       if (Contains(push)) {
/*  78 */         push.getWorld().playEffect(push.getLocation(), Effect.STEP_SOUND, push.getTypeId());
/*  79 */         event.setCancelled(true);
/*  80 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*  86 */   public void ExpireBlocks(UpdateEvent event) { if (event.getType() != UpdateType.TICK) {
/*  87 */       return;
/*     */     }
/*  89 */     ArrayList<Block> toRemove = new ArrayList();
/*  90 */     for (BlockRestoreData cur2 : this._blocks.values()) {
/*  91 */       if (cur2.expire())
/*  92 */         toRemove.add(cur2._block);
/*     */     }
/*  94 */     for (Block cur : toRemove) {
/*  95 */       this._blocks.remove(cur);
/*     */     }
/*     */   }
/*     */   
/*     */   public void Restore(Block block) {
/* 100 */     if (!Contains(block)) {
/* 101 */       return;
/*     */     }
/* 103 */     ((BlockRestoreData)this._blocks.remove(block)).restore();
/*     */   }
/*     */   
/*     */   public void RestoreAll() {
/* 107 */     for (BlockRestoreData data : this._blocks.values()) {
/* 108 */       data.restore();
/*     */     }
/* 110 */     this._blocks.clear();
/*     */   }
/*     */   
/*     */   public HashSet<Location> RestoreBlockAround(Material type, Location location, int radius) {
/* 114 */     HashSet<Location> restored = new HashSet();
/* 115 */     Iterator<Block> blockIterator = this._blocks.keySet().iterator();
/* 116 */     while (blockIterator.hasNext()) {
/* 117 */       Block block = (Block)blockIterator.next();
/* 118 */       if ((block.getType() == type) && (UtilMath.offset(block.getLocation().add(0.5D, 0.5D, 0.5D), location) <= radius)) {
/* 119 */         restored.add(block.getLocation().add(0.5D, 0.5D, 0.5D));
/* 120 */         ((BlockRestoreData)this._blocks.get(block)).restore();
/* 121 */         blockIterator.remove();
/*     */       } }
/* 123 */     return restored;
/*     */   }
/*     */   
/*     */   public void Add(Block block, int toID, byte toData, long expireTime) {
/* 127 */     Add(block, toID, toData, block.getTypeId(), block.getData(), expireTime);
/*     */   }
/*     */   
/*     */   public void Add(Block block, int toID, byte toData, int fromID, byte fromData, long expireTime) {
/* 131 */     if (!Contains(block)) {
/* 132 */       GetBlocks().put(block, new BlockRestoreData(block, toID, toData, fromID, fromData, expireTime, 0L));
/*     */     } else {
/* 134 */       GetData(block).update(toID, toData, expireTime);
/*     */     }
/*     */   }
/*     */   
/*     */   public void Snow(Block block, byte heightAdd, byte heightMax, long expireTime, long meltDelay, int heightJumps) {
/* 139 */     if (((block.getTypeId() == 78) && (block.getData() >= 7)) || ((block.getTypeId() == 80) && (GetData(block) != null))) {
/* 140 */       GetData(block).update(78, heightAdd, expireTime, meltDelay);
/* 141 */       if (heightJumps > 0) {
/* 142 */         Snow(block.getRelative(BlockFace.UP), heightAdd, heightMax, expireTime, meltDelay, heightJumps - 1);
/*     */       }
/* 144 */       if (heightJumps == -1) {
/* 145 */         Snow(block.getRelative(BlockFace.UP), heightAdd, heightMax, expireTime, meltDelay, -1);
/*     */       }
/* 147 */       return;
/*     */     }
/* 149 */     if ((!UtilBlock.solid(block.getRelative(BlockFace.DOWN))) && (block.getRelative(BlockFace.DOWN).getTypeId() != 78)) {
/* 150 */       return;
/*     */     }
/* 152 */     if ((block.getRelative(BlockFace.DOWN).getTypeId() == 78) && (block.getRelative(BlockFace.DOWN).getData() < 7)) {
/* 153 */       return;
/*     */     }
/* 155 */     if ((block.getRelative(BlockFace.DOWN).getTypeId() == 79) || (block.getRelative(BlockFace.DOWN).getTypeId() == 174)) {
/* 156 */       return;
/*     */     }
/* 158 */     if ((block.getRelative(BlockFace.DOWN).getTypeId() == 44) || (block.getRelative(BlockFace.DOWN).getTypeId() == 126)) {
/* 159 */       return;
/*     */     }
/* 161 */     if (block.getRelative(BlockFace.DOWN).getType().toString().contains("STAIRS")) {
/* 162 */       return;
/*     */     }
/* 164 */     if ((block.getRelative(BlockFace.DOWN).getType().name().toLowerCase().contains("fence")) || (block.getRelative(BlockFace.DOWN).getType().name().toLowerCase().contains("wall"))) {
/* 165 */       return;
/*     */     }
/* 167 */     if ((!UtilBlock.airFoliage(block)) && (block.getTypeId() != 78) && (block.getType() != Material.CARPET)) {
/* 168 */       return;
/*     */     }
/* 170 */     if ((block.getTypeId() == 78) && (block.getData() >= (byte)(heightMax - 1))) {
/* 171 */       heightAdd = 0;
/*     */     }
/* 173 */     if (!Contains(block)) {
/* 174 */       GetBlocks().put(block, new BlockRestoreData(block, 78, (byte)Math.max(0, heightAdd - 1), block.getTypeId(), block.getData(), expireTime, meltDelay));
/*     */     } else {
/* 176 */       GetData(block).update(78, heightAdd, expireTime, meltDelay);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean Contains(Block block) {
/* 181 */     if (GetBlocks().containsKey(block)) {
/* 182 */       return true;
/*     */     }
/* 184 */     return false;
/*     */   }
/*     */   
/*     */   public BlockRestoreData GetData(Block block) {
/* 188 */     if (this._blocks.containsKey(block)) {
/* 189 */       return (BlockRestoreData)this._blocks.get(block);
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */   
/*     */   public HashMap<Block, BlockRestoreData> GetBlocks() {
/* 195 */     return this._blocks;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\blockrestore\BlockRestore.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */