/*     */ package mineplex.core.monitor;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.updater.UpdateType;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ public class LagMeter
/*     */   extends MiniPlugin
/*     */ {
/*     */   private CoreClientManager _clientManager;
/*  23 */   private long _lastRun = -1L;
/*     */   
/*     */   private int _count;
/*     */   private double _ticksPerSecond;
/*     */   private double _ticksPerSecondAverage;
/*     */   private long _lastAverage;
/*  29 */   private long _lastTick = 0L;
/*     */   
/*  31 */   private HashSet<Player> _monitoring = new HashSet();
/*     */   
/*     */   public LagMeter(JavaPlugin plugin, CoreClientManager clientManager)
/*     */   {
/*  35 */     super("LagMeter", plugin);
/*     */     
/*  37 */     this._clientManager = clientManager;
/*  38 */     this._lastRun = System.currentTimeMillis();
/*  39 */     this._lastAverage = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerCommandPreProcess(PlayerCommandPreprocessEvent event)
/*     */   {
/*  45 */     if (this._clientManager.Get(event.getPlayer()).GetRank().Has(Rank.MODERATOR))
/*     */     {
/*  47 */       if (event.getMessage().trim().equalsIgnoreCase("/lag"))
/*     */       {
/*  49 */         sendUpdate(event.getPlayer());
/*  50 */         event.setCancelled(true);
/*     */       }
/*  52 */       else if (event.getMessage().trim().equalsIgnoreCase("/monitor"))
/*     */       {
/*  54 */         if (this._monitoring.contains(event.getPlayer())) {
/*  55 */           this._monitoring.remove(event.getPlayer());
/*     */         } else {
/*  57 */           this._monitoring.add(event.getPlayer());
/*     */         }
/*  59 */         event.setCancelled(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void playerQuit(PlayerQuitEvent event)
/*     */   {
/*  67 */     this._monitoring.remove(event.getPlayer());
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void update(UpdateEvent event)
/*     */   {
/*  73 */     if (event.getType() != UpdateType.SEC) {
/*  74 */       return;
/*     */     }
/*  76 */     long now = System.currentTimeMillis();
/*  77 */     this._ticksPerSecond = (1000.0D / (now - this._lastRun) * 20.0D);
/*     */     
/*  79 */     sendUpdates();
/*     */     
/*  81 */     if (this._count % 30 == 0)
/*     */     {
/*  83 */       this._ticksPerSecondAverage = (30000.0D / (now - this._lastAverage) * 20.0D);
/*  84 */       this._lastAverage = now;
/*     */     }
/*     */     
/*  87 */     this._lastRun = now;
/*     */     
/*  89 */     this._count += 1;
/*     */   }
/*     */   
/*     */   public double getTicksPerSecond()
/*     */   {
/*  94 */     return this._ticksPerSecond;
/*     */   }
/*     */   
/*     */   private void sendUpdates()
/*     */   {
/*  99 */     for (Player player : this._monitoring)
/*     */     {
/* 101 */       sendUpdate(player);
/*     */     }
/*     */   }
/*     */   
/*     */   private void sendUpdate(Player player)
/*     */   {
/* 107 */     player.sendMessage(" ");
/* 108 */     player.sendMessage(" ");
/* 109 */     player.sendMessage(" ");
/* 110 */     player.sendMessage(" ");
/* 111 */     player.sendMessage(" ");
/* 112 */     player.sendMessage(F.main(getName(), ChatColor.GRAY + "Live-------" + ChatColor.YELLOW + String.format("%.00f", new Object[] { Double.valueOf(this._ticksPerSecond) })));
/* 113 */     player.sendMessage(F.main(getName(), ChatColor.GRAY + "Avg--------" + ChatColor.YELLOW + String.format("%.00f", new Object[] { Double.valueOf(this._ticksPerSecondAverage * 20.0D) })));
/* 114 */     player.sendMessage(F.main(getName(), ChatColor.YELLOW + "MEM"));
/* 115 */     player.sendMessage(F.main(getName(), ChatColor.GRAY + "Free-------" + ChatColor.YELLOW + Runtime.getRuntime().freeMemory() / 1048576L + "MB"));
/* 116 */     player.sendMessage(F.main(getName(), new StringBuilder().append(ChatColor.GRAY).append("Max--------").append(ChatColor.YELLOW).append(Runtime.getRuntime().maxMemory() / 1048576L).toString()) + "MB");
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\monitor\LagMeter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */