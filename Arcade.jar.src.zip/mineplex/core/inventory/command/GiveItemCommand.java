/*    */ package mineplex.core.inventory.command;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.core.account.CoreClientManager;
/*    */ import mineplex.core.command.CommandBase;
/*    */ import mineplex.core.common.Rank;
/*    */ import mineplex.core.common.util.Callback;
/*    */ import mineplex.core.common.util.F;
/*    */ import mineplex.core.common.util.UtilPlayer;
/*    */ import mineplex.core.inventory.InventoryManager;
/*    */ import mineplex.core.inventory.data.Item;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GiveItemCommand
/*    */   extends CommandBase<InventoryManager>
/*    */ {
/*    */   public GiveItemCommand(InventoryManager plugin)
/*    */   {
/* 24 */     super(plugin, Rank.ADMIN, new String[] { "giveitem" });
/*    */   }
/*    */   
/*    */ 
/*    */   public void Execute(final Player caller, String[] args)
/*    */   {
/* 30 */     if ((args == null) || (args.length < 3))
/*    */     {
/* 32 */       displayUsage(caller);
/* 33 */       return;
/*    */     }
/*    */     
/* 36 */     final String playerName = args[0];
/* 37 */     final int amount = Integer.parseInt(args[1]);
/* 38 */     String itemNameTemp = "";
/* 39 */     for (int i = 2; i < args.length; i++)
/*    */     {
/* 41 */       itemNameTemp = itemNameTemp + args[i] + " ";
/*    */     }
/*    */     
/* 44 */     itemNameTemp = itemNameTemp.trim();
/*    */     
/* 46 */     final String itemName = itemNameTemp;
/*    */     
/* 48 */     final Item item = ((InventoryManager)this.Plugin).getItem(itemName);
/* 49 */     Player player = UtilPlayer.searchExact(playerName);
/*    */     
/* 51 */     if (item == null)
/*    */     {
/* 53 */       UtilPlayer.message(caller, F.main("Item", "Item with the name " + F.item(itemName) + " not found!"));
/*    */     }
/* 55 */     else if (player != null)
/*    */     {
/* 57 */       ((InventoryManager)this.Plugin).addItemToInventory(player, item.Category, item.Name, amount);
/* 58 */       UtilPlayer.message(caller, F.main("Item", "You gave " + F.elem(new StringBuilder(String.valueOf(amount)).append(" ").append(itemName).toString()) + " to player " + F.name(playerName)));
/* 59 */       UtilPlayer.message(player, F.main("Item", F.name(caller.getName()) + " gave you " + F.elem(new StringBuilder(String.valueOf(amount)).append(" ").append(itemName).toString())));
/*    */     }
/*    */     else
/*    */     {
/* 63 */       ((InventoryManager)this.Plugin).getClientManager().loadClientByName(playerName, new Runnable()
/*    */       {
/*    */         public void run()
/*    */         {
/* 67 */           UUID uuid = ((InventoryManager)GiveItemCommand.this.Plugin).getClientManager().loadUUIDFromDB(playerName);
/*    */           
/* 69 */           if (uuid != null)
/*    */           {
/* 71 */             ((InventoryManager)GiveItemCommand.this.Plugin).addItemToInventoryForOffline(new Callback()
/*    */             {
/*    */               public void run(Boolean success)
/*    */               {
/* 75 */                 UtilPlayer.message(this.val$caller, F.main("Item", "You gave " + F.elem(new StringBuilder(String.valueOf(this.val$amount)).append(" ").append(this.val$itemName).toString()) + " to offline player " + F.name(this.val$playerName)));
/*    */               }
/* 77 */             }, uuid, item.Category, item.Name, amount);
/*    */           }
/*    */           else
/*    */           {
/* 81 */             UtilPlayer.message(caller, F.main("Item", "Player " + F.name(playerName) + " does not exist!"));
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */   }
/*    */   
/*    */   private void displayUsage(Player caller)
/*    */   {
/* 90 */     UtilPlayer.message(caller, F.main("Item", "Usage: " + F.elem("/giveitem <playername> <amount> <item name>")));
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\command\GiveItemCommand.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */