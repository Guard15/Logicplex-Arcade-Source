/*    */ package mineplex.core.inventory.data;
/*    */ 
/*    */ public class Item
/*    */ {
/*    */   public int Id;
/*    */   public String Name;
/*    */   public String Category;
/*    */   
/*    */   public Item(String name, String category)
/*    */   {
/* 11 */     this(-1, name, category);
/*    */   }
/*    */   
/*    */   public Item(int id, String name, String category)
/*    */   {
/* 16 */     this.Id = id;
/* 17 */     this.Name = name;
/* 18 */     this.Category = category;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\data\Item.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */