/*    */ package mineplex.core.inventory.data;
/*    */ 
/*    */ public class Category
/*    */ {
/*    */   public int Id;
/*    */   public String Name;
/*    */   
/*    */   public Category(int id, String name)
/*    */   {
/* 10 */     this.Id = id;
/* 11 */     this.Name = name;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\data\Category.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */