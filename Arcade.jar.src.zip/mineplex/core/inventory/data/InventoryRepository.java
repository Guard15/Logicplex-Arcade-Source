/*     */ package mineplex.core.inventory.data;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mineplex.core.database.DBPool;
/*     */ import mineplex.core.database.RepositoryBase;
/*     */ import mineplex.core.database.ResultSetCallable;
/*     */ import mineplex.core.database.column.Column;
/*     */ import mineplex.core.database.column.ColumnInt;
/*     */ import mineplex.core.database.column.ColumnVarChar;
/*     */ import mineplex.core.inventory.ClientInventory;
/*     */ import mineplex.core.inventory.ClientItem;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ public class InventoryRepository
/*     */   extends RepositoryBase
/*     */ {
/*  20 */   private static String CREATE_INVENTORY_TABLE = "CREATE TABLE IF NOT EXISTS items (id INT NOT NULL AUTO_INCREMENT, name VARCHAR(100), categoryId INT, rarity INT, PRIMARY KEY (id), FOREIGN KEY (categoryId) REFERENCES itemCategories(id), UNIQUE INDEX uniqueNameCategoryIndex (name, categoryId));";
/*  21 */   private static String CREATE_INVENTORY_CATEGORY_TABLE = "CREATE TABLE IF NOT EXISTS itemCategories (id INT NOT NULL AUTO_INCREMENT, name VARCHAR(100), PRIMARY KEY (id), UNIQUE INDEX nameIndex (name));";
/*  22 */   private static String CREATE_INVENTORY_RELATION_TABLE = "CREATE TABLE IF NOT EXISTS accountInventory (id INT NOT NULL AUTO_INCREMENT, accountId INT NOT NULL, itemId INT NOT NULL, count INT NOT NULL, PRIMARY KEY (id), FOREIGN KEY (accountId) REFERENCES accounts(id), FOREIGN KEY (itemId) REFERENCES items(id), UNIQUE INDEX accountItemIndex (accountId, itemId));";
/*     */   
/*  24 */   private static String INSERT_ITEM = "INSERT INTO items (name, categoryId) VALUES (?, ?);";
/*  25 */   private static String RETRIEVE_ITEMS = "SELECT items.id, items.name, itemCategories.name FROM items INNER JOIN itemCategories ON itemCategories.id = items.categoryId;";
/*     */   
/*  27 */   private static String INSERT_CATEGORY = "INSERT INTO itemCategories (name) VALUES (?);";
/*  28 */   private static String RETRIEVE_CATEGORIES = "SELECT id, name FROM itemCategories;";
/*     */   
/*  30 */   private static String INSERT_CLIENT_INVENTORY = "INSERT INTO accountInventory (accountId, itemId, count) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE count=count + VALUES(count);";
/*  31 */   private static String UPDATE_CLIENT_INVENTORY = "UPDATE accountInventory SET count = count + ? WHERE accountId = ? AND itemId = ?;";
/*     */   
/*     */   public InventoryRepository(JavaPlugin plugin)
/*     */   {
/*  35 */     super(plugin, DBPool.ACCOUNT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initialize() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void update() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<Category> retrieveCategories()
/*     */   {
/*  53 */     final List<Category> categories = new ArrayList();
/*     */     
/*  55 */     executeQuery(RETRIEVE_CATEGORIES, new ResultSetCallable()
/*     */     {
/*     */       public void processResultSet(ResultSet resultSet) throws SQLException
/*     */       {
/*  59 */         while (resultSet.next())
/*     */         {
/*  61 */           categories.add(new Category(resultSet.getInt(1), resultSet.getString(2))); } } }, new Column[0]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  66 */     return categories;
/*     */   }
/*     */   
/*     */   public void addItem(String name, int categoryId)
/*     */   {
/*  71 */     executeUpdate(INSERT_ITEM, new Column[] { new ColumnVarChar("name", 100, name), new ColumnInt("categoryId", categoryId) });
/*     */   }
/*     */   
/*     */   public void addCategory(String name)
/*     */   {
/*  76 */     executeUpdate(INSERT_CATEGORY, new Column[] { new ColumnVarChar("name", 100, name) });
/*     */   }
/*     */   
/*     */   public List<Item> retrieveItems()
/*     */   {
/*  81 */     final List<Item> items = new ArrayList();
/*     */     
/*  83 */     executeQuery(RETRIEVE_ITEMS, new ResultSetCallable()
/*     */     {
/*     */       public void processResultSet(ResultSet resultSet) throws SQLException
/*     */       {
/*  87 */         while (resultSet.next())
/*     */         {
/*  89 */           items.add(new Item(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3))); } } }, new Column[0]);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  94 */     return items;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean incrementClientInventoryItem(int accountId, int itemId, int count)
/*     */   {
/* 100 */     if (executeUpdate(UPDATE_CLIENT_INVENTORY, new Column[] { new ColumnInt("count", count), new ColumnInt("id", accountId), new ColumnInt("itemid", itemId) }) < 1)
/*     */     {
/*     */ 
/* 103 */       return executeUpdate(INSERT_CLIENT_INVENTORY, new Column[] { new ColumnInt("id", accountId), new ColumnInt("itemid", itemId), new ColumnInt("count", count) }) > 0;
/*     */     }
/*     */     
/* 106 */     return true;
/*     */   }
/*     */   
/*     */   public ClientInventory loadClientInformation(ResultSet resultSet) throws SQLException
/*     */   {
/* 111 */     ClientInventory clientInventory = new ClientInventory();
/*     */     
/* 113 */     while (resultSet.next())
/*     */     {
/* 115 */       clientInventory.addItem(new ClientItem(new Item(resultSet.getString(1), resultSet.getString(2)), resultSet.getInt(3)));
/*     */     }
/*     */     
/* 118 */     return clientInventory;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\data\InventoryRepository.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */