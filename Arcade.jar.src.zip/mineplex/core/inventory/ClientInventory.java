/*    */ package mineplex.core.inventory;
/*    */ 
/*    */ import mineplex.core.common.util.NautHashMap;
/*    */ 
/*    */ public class ClientInventory
/*    */ {
/*  7 */   public NautHashMap<String, ClientItem> Items = new NautHashMap();
/*    */   
/*    */   public void addItem(ClientItem item)
/*    */   {
/* 11 */     if (!this.Items.containsKey(item.Item.Name)) {
/* 12 */       this.Items.put(item.Item.Name, new ClientItem(item.Item, 0));
/*    */     }
/* 14 */     ((ClientItem)this.Items.get(item.Item.Name)).Count += item.Count;
/*    */   }
/*    */   
/*    */   public void removeItem(ClientItem item)
/*    */   {
/* 19 */     if (!this.Items.containsKey(item.Item.Name)) {
/* 20 */       return;
/*    */     }
/* 22 */     ((ClientItem)this.Items.get(item.Item.Name)).Count -= item.Count;
/*    */     
/* 24 */     if (((ClientItem)this.Items.get(item.Item.Name)).Count == 0) {
/* 25 */       this.Items.remove(item.Item.Name);
/*    */     }
/*    */   }
/*    */   
/*    */   public int getItemCount(String name) {
/* 30 */     return this.Items.containsKey(name) ? ((ClientItem)this.Items.get(name)).Count : 0;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\ClientInventory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */