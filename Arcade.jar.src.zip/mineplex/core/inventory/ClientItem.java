/*    */ package mineplex.core.inventory;
/*    */ 
/*    */ import mineplex.core.inventory.data.Item;
/*    */ 
/*    */ public class ClientItem
/*    */ {
/*    */   public Item Item;
/*    */   public int Count;
/*    */   
/*    */   public ClientItem(Item item, int count)
/*    */   {
/* 12 */     this.Item = item;
/* 13 */     this.Count = count;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\ClientItem.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */