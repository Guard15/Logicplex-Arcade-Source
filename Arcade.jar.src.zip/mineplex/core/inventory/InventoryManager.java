/*     */ package mineplex.core.inventory;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.MiniDbClientPlugin;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.common.util.Callback;
/*     */ import mineplex.core.common.util.NautHashMap;
/*     */ import mineplex.core.inventory.data.Category;
/*     */ import mineplex.core.inventory.data.InventoryRepository;
/*     */ import mineplex.core.inventory.data.Item;
/*     */ import mineplex.core.updater.event.UpdateEvent;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class InventoryManager extends MiniDbClientPlugin<ClientInventory>
/*     */ {
/*  27 */   private static Object _inventoryLock = new Object();
/*     */   
/*     */   private InventoryRepository _repository;
/*     */   
/*  31 */   private NautHashMap<String, Item> _items = new NautHashMap();
/*  32 */   private NautHashMap<String, Category> _categories = new NautHashMap();
/*     */   
/*  34 */   private NautHashMap<Player, NautHashMap<String, NautHashMap<String, Integer>>> _inventoryQueue = new NautHashMap();
/*     */   
/*     */   public InventoryManager(JavaPlugin plugin, CoreClientManager clientManager)
/*     */   {
/*  38 */     super("Inventory Manager", plugin, clientManager);
/*     */     
/*  40 */     this._repository = new InventoryRepository(plugin);
/*     */     
/*  42 */     Bukkit.getServer().getScheduler().runTaskLaterAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*  46 */         InventoryManager.this.updateItems();
/*  47 */         InventoryManager.this.updateCategories();
/*     */       }
/*  49 */     }, 20L);
/*     */   }
/*     */   
/*     */   private void updateItems()
/*     */   {
/*  54 */     List<Item> items = this._repository.retrieveItems();
/*     */     
/*  56 */     synchronized (_inventoryLock)
/*     */     {
/*  58 */       for (Item item : items)
/*     */       {
/*  60 */         this._items.put(item.Name, item);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateCategories()
/*     */   {
/*  67 */     List<Category> categories = this._repository.retrieveCategories();
/*     */     
/*  69 */     synchronized (_inventoryLock)
/*     */     {
/*  71 */       for (Category category : categories)
/*     */       {
/*  73 */         this._categories.put(category.Name, category);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void addItemToInventory(Player player, String category, String item, int count)
/*     */   {
/*  80 */     if (this._items.containsKey(item))
/*     */     {
/*  82 */       ((ClientInventory)Get(player)).addItem(new ClientItem((Item)this._items.get(item), count));
/*     */     }
/*     */     
/*  85 */     if (!this._inventoryQueue.containsKey(player)) {
/*  86 */       this._inventoryQueue.put(player, new NautHashMap());
/*     */     }
/*  88 */     if (!((NautHashMap)this._inventoryQueue.get(player)).containsKey(category)) {
/*  89 */       ((NautHashMap)this._inventoryQueue.get(player)).put(category, new NautHashMap());
/*     */     }
/*  91 */     int totalAmount = count;
/*     */     
/*  93 */     if (((NautHashMap)((NautHashMap)this._inventoryQueue.get(player)).get(category)).containsKey(item)) {
/*  94 */       totalAmount += ((Integer)((NautHashMap)((NautHashMap)this._inventoryQueue.get(player)).get(category)).get(item)).intValue();
/*     */     }
/*  96 */     ((NautHashMap)((NautHashMap)this._inventoryQueue.get(player)).get(category)).put(item, Integer.valueOf(totalAmount));
/*     */   }
/*     */   
/*     */   public void addItemToInventory(final Callback<Boolean> callback, final Player player, String category, final String item, final int count)
/*     */   {
/* 101 */     addItemToInventoryForOffline(new Callback()
/*     */     {
/*     */       public void run(Boolean success)
/*     */       {
/* 105 */         if (!success.booleanValue())
/*     */         {
/* 107 */           System.out.println("Add item to Inventory FAILED for " + player.getName());
/*     */           
/* 109 */           if (InventoryManager.this._items.containsKey(item))
/*     */           {
/* 111 */             ((ClientInventory)InventoryManager.this.Get(player)).addItem(new ClientItem((Item)InventoryManager.this._items.get(item), -count));
/*     */           }
/*     */         }
/*     */         
/* 115 */         if (callback != null)
/* 116 */           callback.run(success);
/*     */       }
/* 118 */     }, player.getUniqueId(), category, item, count);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean validCategory(String category)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 25	mineplex/core/inventory/InventoryManager:_inventoryLock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_2
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 40	mineplex/core/inventory/InventoryManager:_categories	Lmineplex/core/common/util/NautHashMap;
/*     */     //   10: aload_1
/*     */     //   11: invokevirtual 139	mineplex/core/common/util/NautHashMap:containsKey	(Ljava/lang/Object;)Z
/*     */     //   14: aload_2
/*     */     //   15: monitorexit
/*     */     //   16: ireturn
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: athrow
/*     */     // Line number table:
/*     */     //   Java source line #124	-> byte code offset #0
/*     */     //   Java source line #126	-> byte code offset #6
/*     */     //   Java source line #124	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	20	0	this	InventoryManager
/*     */     //   0	20	1	category	String
/*     */     //   4	14	2	Ljava/lang/Object;	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	16	17	finally
/*     */     //   17	19	17	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean validItem(String item)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: getstatic 25	mineplex/core/inventory/InventoryManager:_inventoryLock	Ljava/lang/Object;
/*     */     //   3: dup
/*     */     //   4: astore_2
/*     */     //   5: monitorenter
/*     */     //   6: aload_0
/*     */     //   7: getfield 38	mineplex/core/inventory/InventoryManager:_items	Lmineplex/core/common/util/NautHashMap;
/*     */     //   10: aload_1
/*     */     //   11: invokevirtual 139	mineplex/core/common/util/NautHashMap:containsKey	(Ljava/lang/Object;)Z
/*     */     //   14: aload_2
/*     */     //   15: monitorexit
/*     */     //   16: ireturn
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: athrow
/*     */     // Line number table:
/*     */     //   Java source line #132	-> byte code offset #0
/*     */     //   Java source line #134	-> byte code offset #6
/*     */     //   Java source line #132	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	20	0	this	InventoryManager
/*     */     //   0	20	1	item	String
/*     */     //   4	14	2	Ljava/lang/Object;	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	16	17	finally
/*     */     //   17	19	17	finally
/*     */   }
/*     */   
/*     */   public Item getItem(String itemName)
/*     */   {
/* 140 */     Item item = null;
/*     */     
/* 142 */     for (Map.Entry<String, Item> entry : this._items.entrySet())
/*     */     {
/* 144 */       String name = (String)entry.getKey();
/*     */       
/* 146 */       if (name.equalsIgnoreCase(itemName)) {
/* 147 */         item = (Item)entry.getValue();
/*     */       }
/*     */     }
/* 150 */     return item;
/*     */   }
/*     */   
/*     */   public void addItemToInventoryForOffline(final Callback<Boolean> callback, final UUID uuid, final String category, final String item, final int count)
/*     */   {
/* 155 */     Bukkit.getServer().getScheduler().runTaskAsynchronously(getPlugin(), new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 159 */         synchronized (InventoryManager._inventoryLock)
/*     */         {
/* 161 */           if (!InventoryManager.this._categories.containsKey(category))
/*     */           {
/* 163 */             InventoryManager.this._repository.addCategory(category);
/* 164 */             System.out.println("InventoryManager Adding Category : " + category);
/*     */           }
/*     */         }
/*     */         
/* 168 */         InventoryManager.this.updateCategories();
/*     */         
/* 170 */         synchronized (InventoryManager._inventoryLock)
/*     */         {
/* 172 */           if (!InventoryManager.this._items.containsKey(item))
/*     */           {
/* 174 */             InventoryManager.this._repository.addItem(item, ((Category)InventoryManager.this._categories.get(category)).Id);
/* 175 */             System.out.println("InventoryManager Adding Item : " + item);
/*     */           }
/*     */         }
/*     */         
/* 179 */         InventoryManager.this.updateItems();
/*     */         
/* 181 */         synchronized (InventoryManager._inventoryLock)
/*     */         {
/* 183 */           final boolean success = InventoryManager.this._repository.incrementClientInventoryItem(InventoryManager.this.ClientManager.getCachedClientAccountId(uuid), ((Item)InventoryManager.this._items.get(item)).Id, count);
/*     */           
/* 185 */           if (callback != null)
/*     */           {
/* 187 */             Bukkit.getServer().getScheduler().runTask(InventoryManager.this.getPlugin(), new Runnable()
/*     */             {
/*     */               public void run()
/*     */               {
/* 191 */                 this.val$callback.run(Boolean.valueOf(success));
/*     */               }
/*     */             });
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   @org.bukkit.event.EventHandler
/*     */   public void updateInventoryQueue(UpdateEvent event)
/*     */   {
/* 203 */     if (event.getType() != mineplex.core.updater.UpdateType.SEC) {
/* 204 */       return;
/*     */     }
/* 206 */     for (final Player player : this._inventoryQueue.keySet()) {
/*     */       Iterator localIterator3;
/* 208 */       for (Iterator localIterator2 = ((NautHashMap)this._inventoryQueue.get(player)).keySet().iterator(); localIterator2.hasNext(); 
/*     */           
/* 210 */           localIterator3.hasNext())
/*     */       {
/* 208 */         String category = (String)localIterator2.next();
/*     */         
/* 210 */         localIterator3 = ((NautHashMap)((NautHashMap)this._inventoryQueue.get(player)).get(category)).keySet().iterator(); continue;final String item = (String)localIterator3.next();
/*     */         
/* 212 */         final int count = ((Integer)((NautHashMap)((NautHashMap)this._inventoryQueue.get(player)).get(category)).get(item)).intValue();
/*     */         
/* 214 */         addItemToInventoryForOffline(new Callback()
/*     */         {
/*     */           public void run(Boolean success)
/*     */           {
/* 218 */             if (!success.booleanValue())
/*     */             {
/* 220 */               System.out.println("Add item to Inventory FAILED for " + player);
/*     */               
/* 222 */               if (InventoryManager.this._items.containsKey(item))
/*     */               {
/* 224 */                 ((ClientInventory)InventoryManager.this.Get(player)).addItem(new ClientItem((Item)InventoryManager.this._items.get(item), -count));
/*     */               }
/*     */             }
/*     */           }
/* 228 */         }, player.getUniqueId(), category, item, count);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 233 */       ((NautHashMap)this._inventoryQueue.get(player)).clear();
/*     */     }
/*     */     
/*     */ 
/* 237 */     this._inventoryQueue.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected ClientInventory AddPlayer(String player)
/*     */   {
/* 244 */     return new ClientInventory();
/*     */   }
/*     */   
/*     */ 
/*     */   public void addCommands()
/*     */   {
/* 250 */     addCommand(new mineplex.core.inventory.command.GiveItemCommand(this));
/*     */   }
/*     */   
/*     */   public void processLoginResultSet(String playerName, int accountId, ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 256 */     Set(playerName, this._repository.loadClientInformation(resultSet));
/*     */   }
/*     */   
/*     */ 
/*     */   public String getQuery(int accountId, String uuid, String name)
/*     */   {
/* 262 */     return "SELECT items.name, ic.name as category, count FROM accountInventory AS ai INNER JOIN items ON items.id = ai.itemId INNER JOIN itemCategories AS ic ON ic.id = items.categoryId WHERE ai.accountId = '" + accountId + "';";
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\inventory\InventoryManager.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */