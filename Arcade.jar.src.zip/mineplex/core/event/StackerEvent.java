/*    */ package mineplex.core.event;
/*    */ 
/*    */ import org.bukkit.entity.Entity;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ public class StackerEvent
/*    */   extends Event
/*    */ {
/* 11 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Entity _entity;
/*    */   
/* 15 */   private boolean _cancelled = false;
/*    */   
/*    */   public StackerEvent(Entity entity)
/*    */   {
/* 19 */     this._entity = entity;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 24 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 29 */     return handlers;
/*    */   }
/*    */   
/*    */   public Entity getEntity()
/*    */   {
/* 34 */     return this._entity;
/*    */   }
/*    */   
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 39 */     this._cancelled = cancel;
/*    */   }
/*    */   
/*    */   public boolean isCancelled()
/*    */   {
/* 44 */     return this._cancelled;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\event\StackerEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */