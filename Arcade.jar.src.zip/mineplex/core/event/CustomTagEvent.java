/*    */ package mineplex.core.event;
/*    */ 
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CustomTagEvent
/*    */   extends Event
/*    */ {
/* 13 */   private static final HandlerList handlers = new HandlerList();
/*    */   
/*    */   private Player _player;
/*    */   private int _entityId;
/*    */   private String _customName;
/*    */   
/*    */   public CustomTagEvent(Player player, int entityId, String customName)
/*    */   {
/* 21 */     this._player = player;
/* 22 */     this._entityId = entityId;
/* 23 */     this._customName = customName;
/*    */   }
/*    */   
/*    */   public Player getPlayer()
/*    */   {
/* 28 */     return this._player;
/*    */   }
/*    */   
/*    */   public String getCustomName()
/*    */   {
/* 33 */     return this._customName;
/*    */   }
/*    */   
/*    */   public void setCustomName(String customName)
/*    */   {
/* 38 */     this._customName = customName;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers()
/*    */   {
/* 43 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList()
/*    */   {
/* 48 */     return handlers;
/*    */   }
/*    */   
/*    */   public int getEntityId()
/*    */   {
/* 53 */     return this._entityId;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\event\CustomTagEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */