package mineplex.core.account;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface ILoginProcessor
{
  public abstract String getName();
  
  public abstract void processLoginResultSet(String paramString, int paramInt, ResultSet paramResultSet)
    throws SQLException;
  
  public abstract String getQuery(int paramInt, String paramString1, String paramString2);
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\ILoginProcessor.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */