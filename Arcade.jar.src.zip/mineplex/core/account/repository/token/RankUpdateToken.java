package mineplex.core.account.repository.token;

public class RankUpdateToken
{
  public String Name;
  public String Rank;
  public boolean Perm;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\RankUpdateToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */