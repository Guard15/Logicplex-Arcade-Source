package mineplex.core.account.repository.token;

public class DonorRequestToken
{
  public String name;
  public String uuid;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\DonorRequestToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */