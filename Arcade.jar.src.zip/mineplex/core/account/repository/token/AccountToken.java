/*    */ package mineplex.core.account.repository.token;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccountToken
/*    */ {
/*    */   public int AccountId;
/*    */   public String Name;
/*    */   public Rank Rank;
/*    */   public int LoginCount;
/*    */   public long LastLogin;
/*    */   public long TotalPlayingTime;
/* 17 */   public HashSet<String> IpAdddresses = new HashSet();
/*    */   public boolean Banned;
/*    */   public String Reason;
/*    */   public int BlueGems;
/*    */   public int GreenGems;
/*    */   public List<Integer> SalesPackageIds;
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\AccountToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */