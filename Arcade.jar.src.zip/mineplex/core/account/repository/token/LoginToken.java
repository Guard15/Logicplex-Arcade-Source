/*   */ package mineplex.core.account.repository.token;
/*   */ 
/*   */ 
/*   */ public class LoginToken
/*   */ {
/*   */   public String Name;
/*   */   
/* 8 */   public String IpAddress = "0.0.0.0";
/* 9 */   public String MacAddress = "00-00-00-00-00-00-00-00";
/*   */   public String Uuid;
/*   */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\LoginToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */