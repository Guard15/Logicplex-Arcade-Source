package mineplex.core.account.repository.token;

public class ClientToken
{
  public int AccountId;
  public String Name;
  public String Rank;
  public boolean RankPerm;
  public String RankExpire;
  public int EconomyBalance;
  public AccountToken AccountToken;
  public long LastLogin;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\ClientToken.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */