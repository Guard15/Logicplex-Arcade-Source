package mineplex.core.account.repository.token;

public class Rank
{
  public int RankId;
  public String Name;
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\repository\token\Rank.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */