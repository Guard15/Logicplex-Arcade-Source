/*    */ package mineplex.core.account;
/*    */ 
/*    */ import java.util.UUID;
/*    */ import mineplex.serverdata.data.Data;
/*    */ 
/*    */ 
/*    */ public class AccountCache
/*    */   implements Data
/*    */ {
/*    */   private UUID _uuid;
/*    */   private Integer _id;
/*    */   
/*    */   public AccountCache(UUID uuid, int id)
/*    */   {
/* 15 */     this._uuid = uuid;
/* 16 */     this._id = Integer.valueOf(id);
/*    */   }
/*    */   
/*    */   public UUID getUUID() {
/* 20 */     return this._uuid;
/*    */   }
/*    */   
/*    */   public int getId() {
/* 24 */     return this._id.intValue();
/*    */   }
/*    */   
/*    */   public String getDataId()
/*    */   {
/* 29 */     return this._uuid.toString();
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\AccountCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */