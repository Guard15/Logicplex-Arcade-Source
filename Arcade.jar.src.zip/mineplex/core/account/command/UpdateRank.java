/*     */ package mineplex.core.account.command;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import mineplex.core.account.CoreClient;
/*     */ import mineplex.core.account.CoreClientManager;
/*     */ import mineplex.core.account.repository.AccountRepository;
/*     */ import mineplex.core.command.CommandBase;
/*     */ import mineplex.core.common.Rank;
/*     */ import mineplex.core.common.util.Callback;
/*     */ import mineplex.core.common.util.F;
/*     */ import mineplex.core.common.util.UUIDFetcher;
/*     */ import mineplex.core.common.util.UtilPlayer;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateRank
/*     */   extends CommandBase<CoreClientManager>
/*     */ {
/*     */   public UpdateRank(CoreClientManager plugin)
/*     */   {
/*  35 */     super(plugin, Rank.ADMIN, new Rank[] { Rank.JNR_DEV }, new String[] { "updateRank" });
/*     */   }
/*     */   
/*     */   public void Execute(final Player caller, String[] args)
/*     */   {
/*  40 */     boolean testServer = ((CoreClientManager)this.Plugin).getPlugin().getConfig().getString("serverstatus.group").equalsIgnoreCase("Testing");
/*  41 */     if ((((CoreClientManager)this.Plugin).Get(caller).GetRank() == Rank.JNR_DEV) && (!testServer)) {
/*  42 */       F.main(((CoreClientManager)this.Plugin).getName(), F.elem(Rank.JNR_DEV.GetTag(true, true)) + "s are only permitted to set ranks on test servers!");
/*  43 */       return;
/*     */     }
/*  45 */     if (args == null) {
/*  46 */       UtilPlayer.message(caller, F.main(((CoreClientManager)this.Plugin).getName(), "/" + this.AliasUsed + " joeschmo MODERATOR"));
/*     */     } else {
/*  48 */       if (args.length == 0) {
/*  49 */         UtilPlayer.message(caller, F.main(((CoreClientManager)this.Plugin).getName(), "Player argument missing."));
/*  50 */         return;
/*     */       }
/*  52 */       final String playerName = args[0];
/*  53 */       Rank tempRank = null;
/*     */       try {
/*  55 */         tempRank = Rank.valueOf(args[1]);
/*     */       }
/*     */       catch (Exception ex) {
/*  58 */         UtilPlayer.message(caller, F.main(((CoreClientManager)this.Plugin).getName(), ChatColor.RED + ChatColor.BOLD + "Invalid rank!"));
/*  59 */         return;
/*     */       }
/*  61 */       final Rank rank = tempRank;
/*  62 */       if ((rank == Rank.ADMIN) || (rank == Rank.YOUTUBE) || (rank == Rank.TWITCH) || (rank == Rank.MODERATOR) || (rank == Rank.HELPER) || (rank == Rank.ALL) || (rank == Rank.MAPDEV) || (rank == Rank.SNR_MODERATOR) || (rank == Rank.JNR_DEV) || (rank == Rank.DEVELOPER)) {
/*  63 */         if ((!testServer) && (rank.Has(Rank.ADMIN)) && (!((CoreClientManager)this.Plugin).hasRank(caller, Rank.LT))) {
/*  64 */           UtilPlayer.message(caller, F.main(((CoreClientManager)this.Plugin).getName(), ChatColor.RED + ChatColor.BOLD + "Insufficient privileges!"));
/*  65 */           return;
/*     */         }
/*  67 */         ((CoreClientManager)this.Plugin).getRepository().matchPlayerName(new Callback()
/*     */         {
/*     */           public void run(List<String> matches)
/*     */           {
/*  71 */             boolean matchedExact = false;
/*  72 */             for (String match : matches) {
/*  73 */               if (match.equalsIgnoreCase(playerName))
/*  74 */                 matchedExact = true;
/*     */             }
/*  76 */             if (matchedExact) {
/*  77 */               Iterator<String> matchIterator = matches.iterator();
/*  78 */               while (matchIterator.hasNext()) {
/*  79 */                 if (!((String)matchIterator.next()).equalsIgnoreCase(playerName))
/*  80 */                   matchIterator.remove();
/*     */               }
/*     */             }
/*  83 */             UtilPlayer.searchOffline(matches, new Callback()
/*     */             {
/*     */               public void run(final String target)
/*     */               {
/*  87 */                 if (target == null) {
/*  88 */                   return;
/*     */                 }
/*  90 */                 UUID uuid = ((CoreClientManager)UpdateRank.this.Plugin).loadUUIDFromDB(this.val$playerName);
/*  91 */                 if (uuid == null) {
/*  92 */                   uuid = UUIDFetcher.getUUIDOf(this.val$playerName);
/*     */                 }
/*  94 */                 ((CoreClientManager)UpdateRank.this.Plugin).getRepository().saveRank(new Callback()
/*     */                 {
/*     */                   public void run(Rank rank)
/*     */                   {
/*  98 */                     this.val$caller.sendMessage(F.main(((CoreClientManager)UpdateRank.this.Plugin).getName(), target + "'s rank has been updated to " + rank.Name + "!"));
/*     */                   }
/* 100 */                 }, target, uuid, this.val$rank, true);
/*     */               }
/*     */               
/* 103 */             }, caller, playerName, true);
/*     */           }
/*     */           
/* 106 */         }, playerName);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\command\UpdateRank.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */