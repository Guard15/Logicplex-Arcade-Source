/*    */ package mineplex.core.account.event;
/*    */ 
/*    */ import org.bukkit.craftbukkit.libs.com.google.gson.stream.JsonWriter;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientWebRequestEvent
/*    */   extends Event
/*    */ {
/* 17 */   private static final HandlerList handlers = new HandlerList();
/*    */   private JsonWriter _writer;
/*    */   
/*    */   public ClientWebRequestEvent(JsonWriter writer) {
/* 21 */     this._writer = writer;
/*    */   }
/*    */   
/*    */   public JsonWriter GetJsonWriter() {
/* 25 */     return this._writer;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 29 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 33 */     return handlers;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\event\ClientWebRequestEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */