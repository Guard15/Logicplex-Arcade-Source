/*    */ package mineplex.core.account.event;
/*    */ 
/*    */ import mineplex.core.account.CoreClient;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GetClientEvent
/*    */   extends Event
/*    */ {
/* 18 */   private static final HandlerList handlers = new HandlerList();
/*    */   private String _name;
/*    */   private CoreClient _client;
/*    */   
/*    */   public GetClientEvent(String name) {
/* 23 */     this._name = name;
/*    */   }
/*    */   
/*    */   public GetClientEvent(Player player) {
/* 27 */     this._name = player.getName();
/*    */   }
/*    */   
/*    */   public CoreClient GetClient() {
/* 31 */     return this._client;
/*    */   }
/*    */   
/*    */   public void SetClient(CoreClient client) {
/* 35 */     this._client = client;
/*    */   }
/*    */   
/*    */   public void SetName(String name) {
/* 39 */     this._name = name;
/*    */   }
/*    */   
/*    */   public String GetName() {
/* 43 */     return this._name;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 47 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 51 */     return handlers;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\event\GetClientEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */