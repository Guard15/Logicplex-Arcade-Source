/*    */ package mineplex.core.account.event;
/*    */ 
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClientUnloadEvent
/*    */   extends Event
/*    */ {
/* 15 */   private static final HandlerList handlers = new HandlerList();
/*    */   private String _name;
/*    */   
/*    */   public ClientUnloadEvent(String name) {
/* 19 */     this._name = name;
/*    */   }
/*    */   
/*    */   public String GetName() {
/* 23 */     return this._name;
/*    */   }
/*    */   
/*    */   public HandlerList getHandlers() {
/* 27 */     return handlers;
/*    */   }
/*    */   
/*    */   public static HandlerList getHandlerList() {
/* 31 */     return handlers;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\event\ClientUnloadEvent.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */