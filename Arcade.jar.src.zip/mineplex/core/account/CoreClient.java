/*    */ package mineplex.core.account;
/*    */ 
/*    */ import mineplex.core.common.Rank;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CoreClient
/*    */ {
/* 13 */   private int _accountId = -1;
/*    */   private String _name;
/*    */   private Player _player;
/*    */   private Rank _rank;
/*    */   
/*    */   public CoreClient(Player player) {
/* 19 */     this._player = player;
/* 20 */     this._name = player.getName();
/*    */   }
/*    */   
/*    */   public CoreClient(String name) {
/* 24 */     this._name = name;
/*    */   }
/*    */   
/*    */   public String GetPlayerName() {
/* 28 */     return this._name;
/*    */   }
/*    */   
/*    */   public Player GetPlayer() {
/* 32 */     return this._player;
/*    */   }
/*    */   
/*    */   public void SetPlayer(Player player) {
/* 36 */     this._player = player;
/*    */   }
/*    */   
/*    */   public int getAccountId() {
/* 40 */     return this._accountId;
/*    */   }
/*    */   
/*    */   public void Delete() {
/* 44 */     this._name = null;
/* 45 */     this._player = null;
/*    */   }
/*    */   
/*    */   public void setAccountId(int accountId) {
/* 49 */     this._accountId = accountId;
/*    */   }
/*    */   
/*    */   public Rank GetRank() {
/* 53 */     return this._rank;
/*    */   }
/*    */   
/*    */   public void SetRank(Rank rank) {
/* 57 */     this._rank = rank;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\account\CoreClient.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */