/*     */ package mineplex.core.map;
/*     */ 
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import javax.imageio.ImageIO;
/*     */ import mineplex.core.MiniPlugin;
/*     */ import mineplex.core.common.util.UtilBlock;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import net.minecraft.server.v1_7_R4.EntityItemFrame;
/*     */ import net.minecraft.server.v1_7_R4.PersistentCollection;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.BlockFace;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.entity.Hanging;
/*     */ import org.bukkit.entity.ItemFrame;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.HandlerList;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.map.MapRenderer;
/*     */ import org.bukkit.map.MapView;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockMap
/*     */   implements Listener
/*     */ {
/*  42 */   private HashMap<ItemFrame, MapView> _maps = new HashMap();
/*     */   
/*     */   public BlockMap(MiniPlugin plugin, String imageUrl, Block corner1, Block corner2)
/*     */   {
/*  46 */     this(plugin, imageUrl, corner1, corner2, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BlockMap(MiniPlugin plugin, String imageUrl, Block corner1, Block corner2, BlockFace facingDirection)
/*     */   {
/*     */     try
/*     */     {
/*  55 */       PersistentCollection collection = ((CraftWorld)corner1.getWorld()).getHandle().worldMaps;
/*  56 */       Field f = collection.getClass().getDeclaredField("a");
/*  57 */       f.setAccessible(true);
/*  58 */       f.set(collection, null);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  62 */       ex.printStackTrace();
/*     */     }
/*     */     
/*  65 */     plugin.registerEvents(this);
/*     */     
/*     */ 
/*     */ 
/*  69 */     int bX = Math.min(corner1.getX(), corner2.getX());
/*  70 */     int bY = Math.min(corner1.getY(), corner2.getY());
/*  71 */     int bZ = Math.min(corner1.getZ(), corner2.getZ());
/*  72 */     int tX = Math.max(corner1.getX(), corner2.getX());
/*  73 */     int tY = Math.max(corner1.getY(), corner2.getY());
/*  74 */     int tZ = Math.max(corner1.getZ(), corner2.getZ());
/*     */     int y;
/*  76 */     for (int x = bX; x <= tX; x++)
/*     */     {
/*  78 */       for (y = bY; y <= tY; y++)
/*     */       {
/*  80 */         for (int z = bZ; z <= tZ; z++)
/*     */         {
/*  82 */           Block b = corner1.getWorld().getBlockAt(x, y, z);
/*     */           
/*  84 */           if (!UtilBlock.airFoliage(b))
/*     */           {
/*  86 */             b.setType(Material.AIR);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  93 */     for (Hanging hanging : corner1.getWorld().getEntitiesByClass(Hanging.class))
/*     */     {
/*  95 */       Location loc = hanging.getLocation();
/*     */       
/*  97 */       if ((loc.getX() >= bX) && (loc.getX() <= tX))
/*     */       {
/*  99 */         if ((loc.getY() >= bY) && (loc.getY() <= tY))
/*     */         {
/* 101 */           if ((loc.getZ() >= bZ) && (loc.getZ() <= tZ))
/*     */           {
/* 103 */             hanging.remove();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 110 */     if (facingDirection == null)
/*     */     {
/* 112 */       facingDirection = getImageFace(corner1, corner2);
/*     */     }
/*     */     
/*     */ 
/* 116 */     Block corner = new Location(
/*     */     
/* 118 */       corner1.getWorld(), 
/*     */       
/* 120 */       Math.min(corner1.getX(), corner2.getX()), 
/*     */       
/* 122 */       Math.min(corner1.getY(), corner2.getY()), 
/*     */       
/* 124 */       Math.min(corner1.getZ(), corner2.getZ()))
/*     */       
/* 126 */       .getBlock();
/*     */     
/*     */ 
/* 129 */     int x = corner2.getX() - corner1.getX();
/* 130 */     int z = corner2.getZ() - corner1.getZ();
/*     */     
/*     */ 
/* 133 */     int width = Math.max(Math.abs(x), Math.abs(z)) + 1;
/*     */     
/*     */ 
/* 136 */     int height = Math.abs(corner1.getY() - corner2.getY()) + 1;
/*     */     
/* 138 */     corner = corner.getRelative(facingDirection.getOppositeFace());
/*     */     
/*     */ 
/* 141 */     BufferedImage image = loadImage(imageUrl);
/*     */     
/* 143 */     if (image == null)
/*     */     {
/* 145 */       throw new IllegalArgumentException("Cannot load image at '" + imageUrl + "'");
/*     */     }
/*     */     
/*     */ 
/* 149 */     image = toBufferedImage(image.getScaledInstance(width * 128, height * 128, 4), image.getType());
/*     */     
/*     */ 
/* 152 */     boolean reversed = (facingDirection.getModZ() > 0) || (facingDirection.getModX() < 0);
/*     */     
/*     */ 
/* 155 */     BufferedImage[] imgs = cutIntoPieces(image, width, height, !reversed);
/*     */     
/* 157 */     drawImage(imgs, corner, Math.abs(x), height - 1, Math.abs(z), facingDirection);
/*     */   }
/*     */   
/*     */   private BufferedImage[] cutIntoPieces(BufferedImage image, int width, int height, boolean reversed)
/*     */   {
/* 162 */     BufferedImage[] pieces = new BufferedImage[width * height];
/* 163 */     int count = 0;
/*     */     
/* 165 */     for (int x1 = 0; x1 < width; x1++)
/*     */     {
/* 167 */       int x = reversed ? width - 1 - x1 : x1;
/*     */       
/* 169 */       for (int y = 0; y < height; y++)
/*     */       {
/*     */ 
/* 172 */         pieces[count] = new BufferedImage(128, 128, image.getType());
/*     */         
/*     */ 
/* 175 */         Graphics2D gr = pieces[(count++)].createGraphics();
/*     */         
/* 177 */         gr.drawImage(image, 0, 0, 128, 128, x * 128, y * 128, x * 128 + 128, y * 128 + 128, null);
/*     */         
/* 179 */         gr.dispose();
/*     */       }
/*     */     }
/*     */     
/* 183 */     return pieces;
/*     */   }
/*     */   
/*     */   private void drawImage(BufferedImage[] images, Block cornerBlock, int xSize, int ySize, int zSize, BlockFace direction)
/*     */   {
/* 188 */     int count = 0;
/*     */     
/*     */ 
/* 191 */     for (int x = 0; x <= xSize; x++)
/*     */     {
/* 193 */       for (int z = 0; z <= zSize; z++)
/*     */       {
/* 195 */         for (int y = ySize; y >= 0; y--)
/*     */         {
/*     */ 
/* 198 */           Block b = cornerBlock.getRelative(x, y, z);
/*     */           
/* 200 */           setItemFrame(b, direction, images[(count++)]);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private BlockFace getImageFace(Block c1, Block c2)
/*     */   {
/* 212 */     Block b = c1.getWorld().getBlockAt(
/*     */     
/* 214 */       Math.min(c1.getX(), c2.getX()) + (c1.getX() + c2.getX()) / 2, 
/*     */       
/* 216 */       Math.min(c1.getY(), c2.getY()) + (c1.getY() + c2.getY()) / 2, 
/*     */       
/* 218 */       Math.min(c1.getZ(), c2.getZ()) + (c1.getZ() + c2.getZ()) / 2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 223 */     boolean xOk = c1.getX() == c2.getX();
/* 224 */     boolean zOk = c1.getZ() == c2.getZ();
/*     */     
/* 226 */     for (int x = -1; x <= 1; x++)
/*     */     {
/* 228 */       for (int z = -1; z <= 1; z++)
/*     */       {
/* 230 */         if ((x != z) && ((x == 0) || (z == 0)))
/*     */         {
/* 232 */           Block b1 = b.getRelative(x, 0, z);
/*     */           
/* 234 */           if (UtilBlock.solid(b1))
/*     */           {
/* 236 */             BlockFace face = b1.getFace(b);
/*     */             
/* 238 */             if (((face.getModX() != 0) && (xOk)) || ((face.getModZ() != 0) && (zOk)))
/*     */             {
/* 240 */               return face;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 247 */     return xOk ? BlockFace.EAST : BlockFace.NORTH;
/*     */   }
/*     */   
/*     */   private MapView getMap(World world, BufferedImage image)
/*     */   {
/* 252 */     MapView map = Bukkit.createMap(world);
/*     */     
/* 254 */     for (MapRenderer r : map.getRenderers())
/*     */     {
/* 256 */       map.removeRenderer(r);
/*     */     }
/*     */     
/* 259 */     map.addRenderer(new ImageMapRenderer(image));
/*     */     
/* 261 */     return map;
/*     */   }
/*     */   
/*     */   private ItemStack getMapItem(MapView map)
/*     */   {
/* 266 */     ItemStack item = new ItemStack(Material.MAP);
/*     */     
/* 268 */     item.setDurability(map.getId());
/*     */     
/* 270 */     return item;
/*     */   }
/*     */   
/*     */   private BufferedImage loadImage(String file)
/*     */   {
/* 275 */     File f = new File(file);
/* 276 */     BufferedImage image = null;
/*     */     
/*     */     try
/*     */     {
/* 280 */       if (!f.exists())
/*     */       {
/* 282 */         image = ImageIO.read(URI.create(file).toURL().openStream());
/*     */       }
/*     */       else
/*     */       {
/* 286 */         image = ImageIO.read(f);
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 291 */       e.printStackTrace();
/*     */     }
/*     */     
/* 294 */     return image;
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onJoin(PlayerJoinEvent event)
/*     */   {
/* 300 */     for (MapView map : this._maps.values())
/*     */     {
/* 302 */       event.getPlayer().sendMap(map);
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove()
/*     */   {
/* 308 */     HandlerList.unregisterAll(this);
/*     */     
/* 310 */     for (ItemFrame itemFrame : this._maps.keySet())
/*     */     {
/* 312 */       itemFrame.remove();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setItemFrame(Block block, BlockFace face, BufferedImage image)
/*     */   {
/* 318 */     if (!UtilBlock.solid(block))
/*     */     {
/* 320 */       block.setType(Material.QUARTZ_BLOCK);
/*     */     }
/*     */     
/* 323 */     ItemFrame itemFrame = spawnItemFrame(block, face);
/*     */     
/* 325 */     MapView map = getMap(block.getWorld(), image);
/*     */     
/* 327 */     this._maps.put(itemFrame, map);
/*     */     
/* 329 */     ItemStack mapItem = getMapItem(map);
/*     */     
/* 331 */     itemFrame.setItem(mapItem);
/*     */     Player[] arrayOfPlayer;
/* 333 */     int j = (arrayOfPlayer = UtilServer.getPlayers()).length; for (int i = 0; i < j; i++) { Player player = arrayOfPlayer[i];
/*     */       
/* 335 */       player.sendMap(map);
/*     */     } }
/*     */   
/*     */   private ItemFrame spawnItemFrame(Block block, BlockFace bf) { int dir;
/*     */     int dir;
/*     */     int dir;
/*     */     int dir;
/* 342 */     switch (bf)
/*     */     {
/*     */     case EAST_NORTH_EAST: 
/*     */     default: 
/* 346 */       dir = 0;
/* 347 */       break;
/*     */     case EAST_SOUTH_EAST: 
/* 349 */       dir = 1;
/* 350 */       break;
/*     */     case DOWN: 
/* 352 */       dir = 2;
/* 353 */       break;
/*     */     case EAST: 
/* 355 */       dir = 3;
/*     */     }
/*     */     
/*     */     
/* 359 */     WorldServer world = ((CraftWorld)block.getWorld()).getHandle();
/*     */     
/* 361 */     EntityItemFrame entity = new EntityItemFrame(world, block.getX(), block.getY(), block.getZ(), dir);
/*     */     
/* 363 */     entity.setDirection(dir);
/*     */     
/* 365 */     world.addEntity(entity);
/*     */     
/* 367 */     return (ItemFrame)entity.getBukkitEntity();
/*     */   }
/*     */   
/*     */   private BufferedImage toBufferedImage(Image img, int imageType)
/*     */   {
/* 372 */     if ((img instanceof BufferedImage))
/*     */     {
/* 374 */       return (BufferedImage)img;
/*     */     }
/*     */     
/*     */ 
/* 378 */     BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), imageType);
/*     */     
/*     */ 
/* 381 */     Graphics2D bGr = bimage.createGraphics();
/* 382 */     bGr.drawImage(img, 0, 0, null);
/* 383 */     bGr.dispose();
/*     */     
/*     */ 
/* 386 */     return bimage;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\map\BlockMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */