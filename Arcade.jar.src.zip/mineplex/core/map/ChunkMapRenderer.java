/*     */ package mineplex.core.map;
/*     */ 
/*     */ import java.util.AbstractMap.SimpleEntry;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import net.minecraft.server.v1_7_R4.Block;
/*     */ import net.minecraft.server.v1_7_R4.Blocks;
/*     */ import net.minecraft.server.v1_7_R4.Chunk;
/*     */ import net.minecraft.server.v1_7_R4.Material;
/*     */ import net.minecraft.server.v1_7_R4.MaterialMapColor;
/*     */ import net.minecraft.server.v1_7_R4.MathHelper;
/*     */ import net.minecraft.server.v1_7_R4.WorldMap;
/*     */ import net.minecraft.server.v1_7_R4.WorldServer;
/*     */ import net.minecraft.util.com.google.common.collect.HashMultiset;
/*     */ import net.minecraft.util.com.google.common.collect.Multisets;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.craftbukkit.v1_7_R4.CraftWorld;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.map.MapCanvas;
/*     */ import org.bukkit.map.MapRenderer;
/*     */ import org.bukkit.map.MapView;
/*     */ 
/*     */ public class ChunkMapRenderer extends MapRenderer
/*     */ {
/*     */   private final WorldMap worldmap;
/*  26 */   private byte[] colors = new byte[2097152];
/*     */   
/*     */   public ChunkMapRenderer(WorldMap worldMap)
/*     */   {
/*  30 */     super(false);
/*  31 */     this.worldmap = worldMap;
/*     */   }
/*     */   
/*     */   public void setupMap(World world)
/*     */   {
/*  36 */     int i = 1 << this.worldmap.scale;
/*  37 */     int j = this.worldmap.centerX;
/*  38 */     int k = this.worldmap.centerZ;
/*  39 */     int l = MathHelper.floor(0.0D) / i + 64;
/*  40 */     int i1 = MathHelper.floor(0.0D) / i + 64;
/*  41 */     int j1 = 128 / i;
/*     */     
/*  43 */     for (int k1 = l - j1 + 1; k1 < l + j1; k1++)
/*     */     {
/*  45 */       int l1 = 255;
/*  46 */       int i2 = 0;
/*  47 */       double d0 = 0.0D;
/*     */       
/*  49 */       for (int j2 = i1 - j1 - 1; j2 < i1 + j1; j2++)
/*     */       {
/*  51 */         if ((k1 >= 0) && (j2 >= -1) && (k1 < 128) && (j2 < 128))
/*     */         {
/*  53 */           int k2 = k1 - l;
/*  54 */           int l2 = j2 - i1;
/*  55 */           boolean flag = k2 * k2 + l2 * l2 > (j1 - 2) * (j1 - 2);
/*  56 */           int i3 = (j / i + k1 - 64) * i;
/*  57 */           int j3 = (k / i + j2 - 64) * i;
/*  58 */           HashMultiset hashmultiset = HashMultiset.create();
/*  59 */           Chunk chunk = ((CraftWorld)world).getHandle().getChunkAtWorldCoords(i3, j3);
/*     */           
/*  61 */           if (!chunk.isEmpty())
/*     */           {
/*  63 */             int k3 = i3 & 0xF;
/*  64 */             int l3 = j3 & 0xF;
/*  65 */             int i4 = 0;
/*  66 */             double d1 = 0.0D;
/*     */             
/*  68 */             for (int j4 = 0; j4 < i; j4++)
/*     */             {
/*  70 */               for (int k4 = 0; k4 < i; k4++)
/*     */               {
/*  72 */                 int l4 = chunk.b(j4 + k3, k4 + l3) + 1;
/*  73 */                 Block block = Blocks.AIR;
/*  74 */                 int i5 = 0;
/*     */                 
/*  76 */                 if (l4 > 1)
/*     */                 {
/*     */                   do
/*     */                   {
/*  80 */                     l4--;
/*  81 */                     block = chunk.getType(j4 + k3, l4, k4 + l3);
/*  82 */                     i5 = chunk.getData(j4 + k3, l4, k4 + l3);
/*     */                   }
/*  84 */                   while ((block.f(i5) == MaterialMapColor.b) && (l4 > 0));
/*     */                   
/*  86 */                   if ((l4 > 0) && (block.getMaterial().isLiquid()))
/*     */                   {
/*  88 */                     int j5 = l4 - 1;
/*     */                     Block block1;
/*     */                     do
/*     */                     {
/*  92 */                       block1 = chunk.getType(j4 + k3, j5--, k4 + l3);
/*  93 */                       i4++;
/*     */                     }
/*  95 */                     while ((j5 > 0) && (block1.getMaterial().isLiquid()));
/*     */                   }
/*     */                 }
/*     */                 
/*  99 */                 d1 += l4 / (i * i);
/* 100 */                 hashmultiset.add(block.f(i5));
/*     */               }
/*     */             }
/*     */             
/* 104 */             i4 /= i * i;
/* 105 */             double d2 = (d1 - d0) * 4.0D / (i + 4) + ((k1 + j2 & 0x1) - 0.5D) * 0.4D;
/* 106 */             byte b0 = 1;
/*     */             
/* 108 */             if (d2 > 0.6D)
/*     */             {
/* 110 */               b0 = 2;
/*     */             }
/*     */             
/* 113 */             if (d2 < -0.6D)
/*     */             {
/* 115 */               b0 = 0;
/*     */             }
/*     */             
/* 118 */             MaterialMapColor materialmapcolor = (MaterialMapColor)net.minecraft.util.com.google.common.collect.Iterables.getFirst(
/* 119 */               Multisets.copyHighestCountFirst(hashmultiset), MaterialMapColor.b);
/*     */             
/* 121 */             if (materialmapcolor == MaterialMapColor.n)
/*     */             {
/* 123 */               d2 = i4 * 0.1D + (k1 + j2 & 0x1) * 0.2D;
/* 124 */               b0 = 1;
/* 125 */               if (d2 < 0.5D)
/*     */               {
/* 127 */                 b0 = 2;
/*     */               }
/*     */               
/* 130 */               if (d2 > 0.9D)
/*     */               {
/* 132 */                 b0 = 0;
/*     */               }
/*     */             }
/*     */             
/* 136 */             d0 = d1;
/* 137 */             if ((j2 >= 0) && (k2 * k2 + l2 * l2 < j1 * j1) && ((!flag) || ((k1 + j2 & 0x1) != 0)))
/*     */             {
/* 139 */               byte b1 = this.colors[(k1 + j2 * 128)];
/* 140 */               byte b2 = (byte)(materialmapcolor.M * 4 + b0);
/*     */               
/* 142 */               if (b1 != b2)
/*     */               {
/* 144 */                 if (l1 > j2)
/*     */                 {
/* 146 */                   l1 = j2;
/*     */                 }
/*     */                 
/* 149 */                 if (i2 < j2)
/*     */                 {
/* 151 */                   i2 = j2;
/*     */                 }
/*     */                 
/* 154 */                 this.colors[(k1 + j2 * 128)] = b2;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 161 */       if (l1 <= i2) {
/* 162 */         this.worldmap.flagDirty(k1, l1, i2);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void render(MapView view, MapCanvas canvas, Player player)
/*     */   {
/* 169 */     int scale = 1 << this.worldmap.scale;
/* 170 */     byte i = 30;
/*     */     
/* 172 */     HashMap<Map.Entry, Byte> map = new HashMap();
/*     */     
/* 174 */     for (int mapX = 0; mapX < 128; mapX++)
/*     */     {
/* 176 */       for (int mapZ = 0; mapZ < 128; mapZ++)
/*     */       {
/* 178 */         byte color = 0;
/*     */         
/* 180 */         int bX = this.worldmap.centerX + (mapX - 64) * scale & 0xF;
/* 181 */         int bZ = this.worldmap.centerZ + (mapZ - 64) * scale & 0xF;
/*     */         
/* 183 */         if ((bX == 0) || (bX == 15) || (bZ == 0) || (bZ == 15))
/*     */         {
/* 185 */           Map.Entry<Integer, Integer> entry = new AbstractMap.SimpleEntry(Integer.valueOf((mapX - bX) / 16), Integer.valueOf((mapZ - bZ) / 16));
/*     */           
/* 187 */           if (!map.containsKey(entry))
/*     */           {
/* 189 */             map.put(entry, Byte.valueOf(i++));
/*     */           }
/*     */           
/* 192 */           color = ((Byte)map.get(entry)).byteValue();
/*     */         }
/*     */         else
/*     */         {
/* 196 */           color = this.colors[(mapZ * 128 + mapX)];
/*     */         }
/*     */         
/* 199 */         canvas.setPixel(mapX, mapZ, color);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\map\ChunkMapRenderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */