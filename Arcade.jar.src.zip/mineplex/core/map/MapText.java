/*     */ package mineplex.core.map;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.imageio.ImageIO;
/*     */ import mineplex.core.common.util.UtilServer;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.map.MapRenderer;
/*     */ import org.bukkit.map.MapView;
/*     */ 
/*     */ public class MapText
/*     */ {
/*  23 */   private static HashMap<Character, BufferedImage> _characters = new HashMap();
/*     */   
/*     */   private void loadCharacters()
/*     */   {
/*     */     try
/*     */     {
/*  29 */       InputStream inputStream = getClass().getResourceAsStream("ascii.png");
/*  30 */       BufferedImage image = ImageIO.read(inputStream);
/*     */       
/*  32 */       char[] text = 
/*  33 */         {
/*  34 */         ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', 
/*  35 */         '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
/*  36 */         'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', 
/*  37 */         '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 
/*  38 */         't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~' };
/*     */       
/*     */ 
/*  41 */       int x = 0;
/*  42 */       int y = 16;
/*     */       char[] arrayOfChar1;
/*  44 */       int j = (arrayOfChar1 = text).length; for (int i = 0; i < j; i++) { char c = arrayOfChar1[i];
/*     */         
/*  46 */         grab(Character.valueOf(c), image, x, y);
/*     */         
/*  48 */         if (x < 120)
/*     */         {
/*  50 */           x += 8;
/*     */         }
/*     */         else
/*     */         {
/*  54 */           x = 0;
/*  55 */           y += 8;
/*     */         }
/*     */       }
/*     */       
/*  59 */       inputStream.close();
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  63 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void grab(Character character, BufferedImage image, int imageX, int imageY)
/*     */   {
/*  69 */     BufferedImage newImage = image.getSubimage(imageX, imageY, 8, 8);
/*     */     
/*  71 */     int width = character.charValue() == ' ' ? 4 : 0;
/*     */     
/*  73 */     if (width == 0)
/*     */     {
/*  75 */       for (int x = 0; x < 8; x++)
/*     */       {
/*  77 */         width++;
/*  78 */         boolean foundNonTrans = false;
/*     */         
/*  80 */         for (int y = 0; y < 8; y++)
/*     */         {
/*  82 */           int pixel = newImage.getRGB(x, y);
/*     */           
/*  84 */           if (pixel >> 24 != 0)
/*     */           {
/*  86 */             foundNonTrans = true;
/*  87 */             break;
/*     */           }
/*     */         }
/*     */         
/*  91 */         if (!foundNonTrans) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  98 */     newImage = newImage.getSubimage(0, 0, width, 8);
/*     */     
/* 100 */     _characters.put(character, newImage);
/*     */   }
/*     */   
/*     */   private ArrayList<String> split(String text)
/*     */   {
/* 105 */     ArrayList<String> returns = new ArrayList();
/* 106 */     int lineWidth = 0;
/* 107 */     String current = "";
/*     */     String[] arrayOfString;
/* 109 */     int j = (arrayOfString = text.split("(?<= )")).length; for (int i = 0; i < j; i++) { String word = arrayOfString[i];
/*     */       
/* 111 */       int length = 0;
/*     */       char[] arrayOfChar;
/* 113 */       int m = (arrayOfChar = word.toCharArray()).length; for (int k = 0; k < m; k++) { char c = arrayOfChar[k];
/*     */         
/* 115 */         length += ((BufferedImage)_characters.get(Character.valueOf(c))).getWidth();
/*     */       }
/*     */       
/* 118 */       if (lineWidth + length >= 127)
/*     */       {
/* 120 */         lineWidth = 0;
/* 121 */         returns.add(current);
/* 122 */         current = "";
/*     */       }
/*     */       
/* 125 */       current = current + word;
/* 126 */       lineWidth += length;
/*     */     }
/*     */     
/* 129 */     returns.add(current);
/*     */     
/* 131 */     return returns;
/*     */   }
/*     */   
/*     */   public ItemStack getMap(boolean sendToServer, String... text)
/*     */   {
/* 136 */     if (_characters.isEmpty())
/*     */     {
/* 138 */       loadCharacters();
/*     */     }
/*     */     
/* 141 */     BufferedImage image = new BufferedImage(128, 128, 1);
/* 142 */     Graphics g = image.getGraphics();
/* 143 */     int height = 1;
/*     */     String[] arrayOfString;
/* 145 */     int j = (arrayOfString = text).length; Object localObject; String line; for (int i = 0; i < j; i++) { String string = arrayOfString[i];
/*     */       
/* 147 */       for (localObject = split(string).iterator(); ((Iterator)localObject).hasNext();) { line = (String)((Iterator)localObject).next();
/*     */         
/* 149 */         int length = 1;
/*     */         char[] arrayOfChar;
/* 151 */         int m = (arrayOfChar = line.toCharArray()).length; for (int k = 0; k < m; k++) { char c = arrayOfChar[k];
/*     */           
/* 153 */           BufferedImage img = (BufferedImage)_characters.get(Character.valueOf(c));
/*     */           
/* 155 */           if (img == null)
/*     */           {
/* 157 */             System.out.print("Error: '" + c + "' has no image associated");
/*     */           }
/*     */           else
/*     */           {
/* 161 */             g.drawImage(img, length, height, null);
/*     */             
/* 163 */             length += img.getWidth();
/*     */           }
/*     */         }
/* 166 */         height += 8;
/*     */       }
/*     */     }
/*     */     
/* 170 */     MapView map = Bukkit.createMap((org.bukkit.World)Bukkit.getWorlds().get(0));
/*     */     
/* 172 */     for (MapRenderer r : map.getRenderers())
/*     */     {
/* 174 */       map.removeRenderer(r);
/*     */     }
/*     */     
/* 177 */     map.addRenderer(new ImageMapRenderer(image));
/*     */     
/* 179 */     ItemStack item = new ItemStack(Material.MAP);
/*     */     
/* 181 */     item.setDurability(map.getId());
/*     */     
/* 183 */     if (sendToServer)
/*     */     {
/* 185 */       line = (localObject = UtilServer.getPlayers()).length; for (String str1 = 0; str1 < line; str1++) { Player player = localObject[str1];
/* 186 */         player.sendMap(map);
/*     */       }
/*     */     }
/* 189 */     return item;
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\map\MapText.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */