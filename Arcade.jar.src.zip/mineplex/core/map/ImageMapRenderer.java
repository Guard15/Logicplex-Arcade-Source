/*    */ package mineplex.core.map;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.map.MapCanvas;
/*    */ import org.bukkit.map.MapRenderer;
/*    */ import org.bukkit.map.MapView;
/*    */ 
/*    */ public class ImageMapRenderer
/*    */   extends MapRenderer
/*    */ {
/*    */   private BufferedImage _image;
/* 13 */   private boolean _first = true;
/*    */   
/*    */   public ImageMapRenderer(BufferedImage image)
/*    */   {
/* 17 */     this._image = image;
/*    */   }
/*    */   
/*    */ 
/*    */   public void render(MapView view, MapCanvas canvas, Player player)
/*    */   {
/* 23 */     if ((this._image != null) && (this._first))
/*    */     {
/* 25 */       canvas.drawImage(0, 0, this._image);
/*    */       
/* 27 */       this._first = false;
/*    */     }
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\map\ImageMapRenderer.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */