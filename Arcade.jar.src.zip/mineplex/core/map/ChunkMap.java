/*    */ package mineplex.core.map;
/*    */ 
/*    */ import java.util.List;
/*    */ import net.minecraft.server.v1_7_R4.WorldMap;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.Material;
/*    */ import org.bukkit.inventory.ItemStack;
/*    */ import org.bukkit.map.MapRenderer;
/*    */ import org.bukkit.map.MapView;
/*    */ 
/*    */ public class ChunkMap
/*    */ {
/*    */   public ItemStack getItem(Location loc)
/*    */   {
/* 16 */     MapView map = Bukkit.createMap((org.bukkit.World)Bukkit.getWorlds().get(0));
/*    */     
/* 18 */     for (MapRenderer r : map.getRenderers())
/*    */     {
/* 20 */       map.removeRenderer(r);
/*    */     }
/*    */     
/* 23 */     ItemStack item = new ItemStack(Material.MAP);
/*    */     
/* 25 */     item.setDurability(map.getId());
/*    */     
/* 27 */     WorldMap worldMap = new WorldMap("map_" + map.getId());
/*    */     
/* 29 */     ChunkMapRenderer renderer = new ChunkMapRenderer(worldMap);
/*    */     
/* 31 */     map.addRenderer(renderer);
/*    */     
/* 33 */     worldMap.scale = 3;
/* 34 */     worldMap.centerX = loc.getBlockX();
/* 35 */     worldMap.centerZ = loc.getBlockZ();
/* 36 */     worldMap.c();
/*    */     
/* 38 */     renderer.setupMap(loc.getWorld());
/*    */     
/* 40 */     return item;
/*    */   }
/*    */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\mineplex\core\map\ChunkMap.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       0.7.1
 */