/*     */ package com.google.gson;
/*     */ 
/*     */ import com.google.gson.internal.ConstructorConstructor;
/*     */ import com.google.gson.internal.Excluder;
/*     */ import com.google.gson.internal.Primitives;
/*     */ import com.google.gson.internal.Streams;
/*     */ import com.google.gson.internal.bind.ArrayTypeAdapter;
/*     */ import com.google.gson.internal.bind.CollectionTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.DateTypeAdapter;
/*     */ import com.google.gson.internal.bind.JsonTreeReader;
/*     */ import com.google.gson.internal.bind.JsonTreeWriter;
/*     */ import com.google.gson.internal.bind.MapTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.ObjectTypeAdapter;
/*     */ import com.google.gson.internal.bind.ReflectiveTypeAdapterFactory;
/*     */ import com.google.gson.internal.bind.SqlDateTypeAdapter;
/*     */ import com.google.gson.internal.bind.TimeTypeAdapter;
/*     */ import com.google.gson.internal.bind.TypeAdapters;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import com.google.gson.stream.MalformedJsonException;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Type;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Gson
/*     */ {
/*     */   static final boolean DEFAULT_JSON_NON_EXECUTABLE = false;
/*     */   private static final String JSON_NON_EXECUTABLE_PREFIX = ")]}'\n";
/* 110 */   private final ThreadLocal<Map<TypeToken<?>, FutureTypeAdapter<?>>> calls = new ThreadLocal()
/*     */   {
/*     */     protected Map<TypeToken<?>, Gson.FutureTypeAdapter<?>> initialValue() {
/* 113 */       return new HashMap();
/*     */     }
/*     */   };
/*     */   
/* 117 */   private final Map<TypeToken<?>, TypeAdapter<?>> typeTokenCache = Collections.synchronizedMap(new HashMap());
/*     */   
/*     */   private final List<TypeAdapterFactory> factories;
/*     */   
/*     */   private final ConstructorConstructor constructorConstructor;
/*     */   
/*     */   private final boolean serializeNulls;
/*     */   
/*     */   private final boolean htmlSafe;
/*     */   private final boolean generateNonExecutableJson;
/*     */   private final boolean prettyPrinting;
/* 128 */   final JsonDeserializationContext deserializationContext = new JsonDeserializationContext()
/*     */   {
/*     */     public <T> T deserialize(JsonElement json, Type typeOfT) throws JsonParseException {
/* 131 */       return (T)Gson.this.fromJson(json, typeOfT);
/*     */     }
/*     */   };
/*     */   
/* 135 */   final JsonSerializationContext serializationContext = new JsonSerializationContext() {
/*     */     public JsonElement serialize(Object src) {
/* 137 */       return Gson.this.toJsonTree(src);
/*     */     }
/*     */     
/* 140 */     public JsonElement serialize(Object src, Type typeOfSrc) { return Gson.this.toJsonTree(src, typeOfSrc); }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Gson()
/*     */   {
/* 179 */     this(Excluder.DEFAULT, FieldNamingPolicy.IDENTITY, Collections.emptyMap(), false, false, false, true, false, false, LongSerializationPolicy.DEFAULT, Collections.emptyList());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   Gson(Excluder excluder, FieldNamingStrategy fieldNamingPolicy, Map<Type, InstanceCreator<?>> instanceCreators, boolean serializeNulls, boolean complexMapKeySerialization, boolean generateNonExecutableGson, boolean htmlSafe, boolean prettyPrinting, boolean serializeSpecialFloatingPointValues, LongSerializationPolicy longSerializationPolicy, List<TypeAdapterFactory> typeAdapterFactories)
/*     */   {
/* 191 */     this.constructorConstructor = new ConstructorConstructor(instanceCreators);
/* 192 */     this.serializeNulls = serializeNulls;
/* 193 */     this.generateNonExecutableJson = generateNonExecutableGson;
/* 194 */     this.htmlSafe = htmlSafe;
/* 195 */     this.prettyPrinting = prettyPrinting;
/*     */     
/* 197 */     List<TypeAdapterFactory> factories = new ArrayList();
/*     */     
/*     */ 
/* 200 */     factories.add(TypeAdapters.STRING_FACTORY);
/* 201 */     factories.add(TypeAdapters.INTEGER_FACTORY);
/* 202 */     factories.add(TypeAdapters.BOOLEAN_FACTORY);
/* 203 */     factories.add(TypeAdapters.BYTE_FACTORY);
/* 204 */     factories.add(TypeAdapters.SHORT_FACTORY);
/* 205 */     factories.add(TypeAdapters.newFactory(Long.TYPE, Long.class, longAdapter(longSerializationPolicy)));
/*     */     
/* 207 */     factories.add(TypeAdapters.newFactory(Double.TYPE, Double.class, doubleAdapter(serializeSpecialFloatingPointValues)));
/*     */     
/* 209 */     factories.add(TypeAdapters.newFactory(Float.TYPE, Float.class, floatAdapter(serializeSpecialFloatingPointValues)));
/*     */     
/* 211 */     factories.add(excluder);
/* 212 */     factories.add(TypeAdapters.NUMBER_FACTORY);
/* 213 */     factories.add(TypeAdapters.CHARACTER_FACTORY);
/* 214 */     factories.add(TypeAdapters.STRING_BUILDER_FACTORY);
/* 215 */     factories.add(TypeAdapters.STRING_BUFFER_FACTORY);
/* 216 */     factories.add(TypeAdapters.JSON_ELEMENT_FACTORY);
/* 217 */     factories.add(ObjectTypeAdapter.FACTORY);
/*     */     
/*     */ 
/* 220 */     factories.addAll(typeAdapterFactories);
/*     */     
/*     */ 
/* 223 */     factories.add(TypeAdapters.newFactory(BigDecimal.class, TypeAdapters.BIG_DECIMAL));
/* 224 */     factories.add(TypeAdapters.newFactory(BigInteger.class, TypeAdapters.BIG_INTEGER));
/* 225 */     factories.add(new CollectionTypeAdapterFactory(this.constructorConstructor));
/* 226 */     factories.add(TypeAdapters.URL_FACTORY);
/* 227 */     factories.add(TypeAdapters.URI_FACTORY);
/* 228 */     factories.add(TypeAdapters.UUID_FACTORY);
/* 229 */     factories.add(TypeAdapters.LOCALE_FACTORY);
/* 230 */     factories.add(TypeAdapters.INET_ADDRESS_FACTORY);
/* 231 */     factories.add(TypeAdapters.BIT_SET_FACTORY);
/* 232 */     factories.add(DateTypeAdapter.FACTORY);
/* 233 */     factories.add(TypeAdapters.CALENDAR_FACTORY);
/* 234 */     factories.add(TimeTypeAdapter.FACTORY);
/* 235 */     factories.add(SqlDateTypeAdapter.FACTORY);
/* 236 */     factories.add(TypeAdapters.TIMESTAMP_FACTORY);
/* 237 */     factories.add(new MapTypeAdapterFactory(this.constructorConstructor, complexMapKeySerialization));
/* 238 */     factories.add(ArrayTypeAdapter.FACTORY);
/* 239 */     factories.add(TypeAdapters.ENUM_FACTORY);
/* 240 */     factories.add(TypeAdapters.CLASS_FACTORY);
/* 241 */     factories.add(new ReflectiveTypeAdapterFactory(this.constructorConstructor, fieldNamingPolicy, excluder));
/*     */     
/*     */ 
/* 244 */     this.factories = Collections.unmodifiableList(factories);
/*     */   }
/*     */   
/*     */   private TypeAdapter<Number> doubleAdapter(boolean serializeSpecialFloatingPointValues) {
/* 248 */     if (serializeSpecialFloatingPointValues) {
/* 249 */       return TypeAdapters.DOUBLE;
/*     */     }
/* 251 */     new TypeAdapter() {
/*     */       public Double read(JsonReader in) throws IOException {
/* 253 */         if (in.peek() == JsonToken.NULL) {
/* 254 */           in.nextNull();
/* 255 */           return null;
/*     */         }
/* 257 */         return Double.valueOf(in.nextDouble());
/*     */       }
/*     */       
/* 260 */       public void write(JsonWriter out, Number value) throws IOException { if (value == null) {
/* 261 */           out.nullValue();
/* 262 */           return;
/*     */         }
/* 264 */         double doubleValue = value.doubleValue();
/* 265 */         Gson.this.checkValidFloatingPoint(doubleValue);
/* 266 */         out.value(value);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private TypeAdapter<Number> floatAdapter(boolean serializeSpecialFloatingPointValues) {
/* 272 */     if (serializeSpecialFloatingPointValues) {
/* 273 */       return TypeAdapters.FLOAT;
/*     */     }
/* 275 */     new TypeAdapter() {
/*     */       public Float read(JsonReader in) throws IOException {
/* 277 */         if (in.peek() == JsonToken.NULL) {
/* 278 */           in.nextNull();
/* 279 */           return null;
/*     */         }
/* 281 */         return Float.valueOf((float)in.nextDouble());
/*     */       }
/*     */       
/* 284 */       public void write(JsonWriter out, Number value) throws IOException { if (value == null) {
/* 285 */           out.nullValue();
/* 286 */           return;
/*     */         }
/* 288 */         float floatValue = value.floatValue();
/* 289 */         Gson.this.checkValidFloatingPoint(floatValue);
/* 290 */         out.value(value);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private void checkValidFloatingPoint(double value) {
/* 296 */     if ((Double.isNaN(value)) || (Double.isInfinite(value))) {
/* 297 */       throw new IllegalArgumentException(value + " is not a valid double value as per JSON specification. To override this" + " behavior, use GsonBuilder.serializeSpecialDoubleValues() method.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private TypeAdapter<Number> longAdapter(LongSerializationPolicy longSerializationPolicy)
/*     */   {
/* 304 */     if (longSerializationPolicy == LongSerializationPolicy.DEFAULT) {
/* 305 */       return TypeAdapters.LONG;
/*     */     }
/* 307 */     new TypeAdapter() {
/*     */       public Number read(JsonReader in) throws IOException {
/* 309 */         if (in.peek() == JsonToken.NULL) {
/* 310 */           in.nextNull();
/* 311 */           return null;
/*     */         }
/* 313 */         return Long.valueOf(in.nextLong());
/*     */       }
/*     */       
/* 316 */       public void write(JsonWriter out, Number value) throws IOException { if (value == null) {
/* 317 */           out.nullValue();
/* 318 */           return;
/*     */         }
/* 320 */         out.value(value.toString());
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> TypeAdapter<T> getAdapter(TypeToken<T> type)
/*     */   {
/* 333 */     TypeAdapter<?> cached = (TypeAdapter)this.typeTokenCache.get(type);
/* 334 */     if (cached != null) {
/* 335 */       return cached;
/*     */     }
/*     */     
/* 338 */     Map<TypeToken<?>, FutureTypeAdapter<?>> threadCalls = (Map)this.calls.get();
/*     */     
/* 340 */     FutureTypeAdapter<T> ongoingCall = (FutureTypeAdapter)threadCalls.get(type);
/* 341 */     if (ongoingCall != null) {
/* 342 */       return ongoingCall;
/*     */     }
/*     */     
/* 345 */     FutureTypeAdapter<T> call = new FutureTypeAdapter();
/* 346 */     threadCalls.put(type, call);
/*     */     try {
/* 348 */       for (TypeAdapterFactory factory : this.factories) {
/* 349 */         TypeAdapter<T> candidate = factory.create(this, type);
/* 350 */         if (candidate != null) {
/* 351 */           call.setDelegate(candidate);
/* 352 */           this.typeTokenCache.put(type, candidate);
/* 353 */           return candidate;
/*     */         }
/*     */       }
/* 356 */       throw new IllegalArgumentException("GSON cannot handle " + type);
/*     */     } finally {
/* 358 */       threadCalls.remove(type);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> TypeAdapter<T> getDelegateAdapter(TypeAdapterFactory skipPast, TypeToken<T> type)
/*     */   {
/* 409 */     boolean skipPastFound = false;
/*     */     
/* 411 */     for (TypeAdapterFactory factory : this.factories) {
/* 412 */       if (!skipPastFound) {
/* 413 */         if (factory == skipPast) {
/* 414 */           skipPastFound = true;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 419 */         TypeAdapter<T> candidate = factory.create(this, type);
/* 420 */         if (candidate != null)
/* 421 */           return candidate;
/*     */       }
/*     */     }
/* 424 */     throw new IllegalArgumentException("GSON cannot serialize " + type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> TypeAdapter<T> getAdapter(Class<T> type)
/*     */   {
/* 434 */     return getAdapter(TypeToken.get(type));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonElement toJsonTree(Object src)
/*     */   {
/* 451 */     if (src == null) {
/* 452 */       return JsonNull.INSTANCE;
/*     */     }
/* 454 */     return toJsonTree(src, src.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonElement toJsonTree(Object src, Type typeOfSrc)
/*     */   {
/* 474 */     JsonTreeWriter writer = new JsonTreeWriter();
/* 475 */     toJson(src, typeOfSrc, writer);
/* 476 */     return writer.get();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toJson(Object src)
/*     */   {
/* 493 */     if (src == null) {
/* 494 */       return toJson(JsonNull.INSTANCE);
/*     */     }
/* 496 */     return toJson(src, src.getClass());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toJson(Object src, Type typeOfSrc)
/*     */   {
/* 515 */     StringWriter writer = new StringWriter();
/* 516 */     toJson(src, typeOfSrc, writer);
/* 517 */     return writer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toJson(Object src, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/* 535 */     if (src != null) {
/* 536 */       toJson(src, src.getClass(), writer);
/*     */     } else {
/* 538 */       toJson(JsonNull.INSTANCE, writer);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toJson(Object src, Type typeOfSrc, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/*     */     try
/*     */     {
/* 560 */       JsonWriter jsonWriter = newJsonWriter(Streams.writerForAppendable(writer));
/* 561 */       toJson(src, typeOfSrc, jsonWriter);
/*     */     } catch (IOException e) {
/* 563 */       throw new JsonIOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toJson(Object src, Type typeOfSrc, JsonWriter writer)
/*     */     throws JsonIOException
/*     */   {
/* 574 */     TypeAdapter<?> adapter = getAdapter(TypeToken.get(typeOfSrc));
/* 575 */     boolean oldLenient = writer.isLenient();
/* 576 */     writer.setLenient(true);
/* 577 */     boolean oldHtmlSafe = writer.isHtmlSafe();
/* 578 */     writer.setHtmlSafe(this.htmlSafe);
/* 579 */     boolean oldSerializeNulls = writer.getSerializeNulls();
/* 580 */     writer.setSerializeNulls(this.serializeNulls);
/*     */     try {
/* 582 */       adapter.write(writer, src);
/*     */     } catch (IOException e) {
/* 584 */       throw new JsonIOException(e);
/*     */     } finally {
/* 586 */       writer.setLenient(oldLenient);
/* 587 */       writer.setHtmlSafe(oldHtmlSafe);
/* 588 */       writer.setSerializeNulls(oldSerializeNulls);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toJson(JsonElement jsonElement)
/*     */   {
/* 600 */     StringWriter writer = new StringWriter();
/* 601 */     toJson(jsonElement, writer);
/* 602 */     return writer.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toJson(JsonElement jsonElement, Appendable writer)
/*     */     throws JsonIOException
/*     */   {
/*     */     try
/*     */     {
/* 615 */       JsonWriter jsonWriter = newJsonWriter(Streams.writerForAppendable(writer));
/* 616 */       toJson(jsonElement, jsonWriter);
/*     */     } catch (IOException e) {
/* 618 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private JsonWriter newJsonWriter(Writer writer)
/*     */     throws IOException
/*     */   {
/* 627 */     if (this.generateNonExecutableJson) {
/* 628 */       writer.write(")]}'\n");
/*     */     }
/* 630 */     JsonWriter jsonWriter = new JsonWriter(writer);
/* 631 */     if (this.prettyPrinting) {
/* 632 */       jsonWriter.setIndent("  ");
/*     */     }
/* 634 */     jsonWriter.setSerializeNulls(this.serializeNulls);
/* 635 */     return jsonWriter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void toJson(JsonElement jsonElement, JsonWriter writer)
/*     */     throws JsonIOException
/*     */   {
/* 643 */     boolean oldLenient = writer.isLenient();
/* 644 */     writer.setLenient(true);
/* 645 */     boolean oldHtmlSafe = writer.isHtmlSafe();
/* 646 */     writer.setHtmlSafe(this.htmlSafe);
/* 647 */     boolean oldSerializeNulls = writer.getSerializeNulls();
/* 648 */     writer.setSerializeNulls(this.serializeNulls);
/*     */     try {
/* 650 */       Streams.write(jsonElement, writer);
/*     */     } catch (IOException e) {
/* 652 */       throw new JsonIOException(e);
/*     */     } finally {
/* 654 */       writer.setLenient(oldLenient);
/* 655 */       writer.setHtmlSafe(oldHtmlSafe);
/* 656 */       writer.setSerializeNulls(oldSerializeNulls);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(String json, Class<T> classOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 678 */     Object object = fromJson(json, classOfT);
/* 679 */     return (T)Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(String json, Type typeOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 702 */     if (json == null) {
/* 703 */       return null;
/*     */     }
/* 705 */     StringReader reader = new StringReader(json);
/* 706 */     T target = fromJson(reader, typeOfT);
/* 707 */     return target;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(Reader json, Class<T> classOfT)
/*     */     throws JsonSyntaxException, JsonIOException
/*     */   {
/* 729 */     JsonReader jsonReader = new JsonReader(json);
/* 730 */     Object object = fromJson(jsonReader, classOfT);
/* 731 */     assertFullConsumption(object, jsonReader);
/* 732 */     return (T)Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(Reader json, Type typeOfT)
/*     */     throws JsonIOException, JsonSyntaxException
/*     */   {
/* 756 */     JsonReader jsonReader = new JsonReader(json);
/* 757 */     T object = fromJson(jsonReader, typeOfT);
/* 758 */     assertFullConsumption(object, jsonReader);
/* 759 */     return object;
/*     */   }
/*     */   
/*     */   private static void assertFullConsumption(Object obj, JsonReader reader) {
/*     */     try {
/* 764 */       if ((obj != null) && (reader.peek() != JsonToken.END_DOCUMENT)) {
/* 765 */         throw new JsonIOException("JSON document was not fully consumed.");
/*     */       }
/*     */     } catch (MalformedJsonException e) {
/* 768 */       throw new JsonSyntaxException(e);
/*     */     } catch (IOException e) {
/* 770 */       throw new JsonIOException(e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(JsonReader reader, Type typeOfT)
/*     */     throws JsonIOException, JsonSyntaxException
/*     */   {
/* 784 */     boolean isEmpty = true;
/* 785 */     boolean oldLenient = reader.isLenient();
/* 786 */     reader.setLenient(true);
/*     */     try {
/* 788 */       reader.peek();
/* 789 */       isEmpty = false;
/* 790 */       TypeAdapter<T> typeAdapter = getAdapter(TypeToken.get(typeOfT));
/* 791 */       return (T)typeAdapter.read(reader);
/*     */     }
/*     */     catch (EOFException e)
/*     */     {
/*     */       Object localObject1;
/*     */       
/* 797 */       if (isEmpty) {
/* 798 */         return null;
/*     */       }
/* 800 */       throw new JsonSyntaxException(e);
/*     */     } catch (IllegalStateException e) {
/* 802 */       throw new JsonSyntaxException(e);
/*     */     }
/*     */     catch (IOException e) {
/* 805 */       throw new JsonSyntaxException(e);
/*     */     } finally {
/* 807 */       reader.setLenient(oldLenient);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(JsonElement json, Class<T> classOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 828 */     Object object = fromJson(json, classOfT);
/* 829 */     return (T)Primitives.wrap(classOfT).cast(object);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T> T fromJson(JsonElement json, Type typeOfT)
/*     */     throws JsonSyntaxException
/*     */   {
/* 852 */     if (json == null) {
/* 853 */       return null;
/*     */     }
/* 855 */     return (T)fromJson(new JsonTreeReader(json), typeOfT);
/*     */   }
/*     */   
/*     */   static class FutureTypeAdapter<T> extends TypeAdapter<T> {
/*     */     private TypeAdapter<T> delegate;
/*     */     
/*     */     public void setDelegate(TypeAdapter<T> typeAdapter) {
/* 862 */       if (this.delegate != null) {
/* 863 */         throw new AssertionError();
/*     */       }
/* 865 */       this.delegate = typeAdapter;
/*     */     }
/*     */     
/*     */     public T read(JsonReader in) throws IOException {
/* 869 */       if (this.delegate == null) {
/* 870 */         throw new IllegalStateException();
/*     */       }
/* 872 */       return (T)this.delegate.read(in);
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, T value) throws IOException {
/* 876 */       if (this.delegate == null) {
/* 877 */         throw new IllegalStateException();
/*     */       }
/* 879 */       this.delegate.write(out, value);
/*     */     }
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 885 */     StringBuilder sb = new StringBuilder("{").append("serializeNulls:").append(this.serializeNulls).append("factories:").append(this.factories).append(",instanceCreators:").append(this.constructorConstructor).append("}");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 890 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\Gson.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */