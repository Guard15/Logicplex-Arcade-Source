/*     */ package com.google.gson.stream;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonWriter
/*     */   implements Closeable
/*     */ {
/* 138 */   private static final String[] REPLACEMENT_CHARS = new String[''];
/* 139 */   static { for (int i = 0; i <= 31; i++) {
/* 140 */       REPLACEMENT_CHARS[i] = String.format("\\u%04x", new Object[] { Integer.valueOf(i) });
/*     */     }
/* 142 */     REPLACEMENT_CHARS[34] = "\\\"";
/* 143 */     REPLACEMENT_CHARS[92] = "\\\\";
/* 144 */     REPLACEMENT_CHARS[9] = "\\t";
/* 145 */     REPLACEMENT_CHARS[8] = "\\b";
/* 146 */     REPLACEMENT_CHARS[10] = "\\n";
/* 147 */     REPLACEMENT_CHARS[13] = "\\r";
/* 148 */     REPLACEMENT_CHARS[12] = "\\f";
/* 149 */     HTML_SAFE_REPLACEMENT_CHARS = (String[])REPLACEMENT_CHARS.clone();
/* 150 */     HTML_SAFE_REPLACEMENT_CHARS[60] = "\\u003c";
/* 151 */     HTML_SAFE_REPLACEMENT_CHARS[62] = "\\u003e";
/* 152 */     HTML_SAFE_REPLACEMENT_CHARS[38] = "\\u0026";
/* 153 */     HTML_SAFE_REPLACEMENT_CHARS[61] = "\\u003d";
/* 154 */     HTML_SAFE_REPLACEMENT_CHARS[39] = "\\u0027";
/*     */   }
/*     */   
/*     */ 
/*     */   private static final String[] HTML_SAFE_REPLACEMENT_CHARS;
/*     */   private final Writer out;
/* 160 */   private final List<JsonScope> stack = new ArrayList();
/*     */   
/* 162 */   public JsonWriter(Writer out) { this.stack.add(JsonScope.EMPTY_DOCUMENT);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */     this.separator = ":";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     this.serializeNulls = true;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */     if (out == null) {
/* 191 */       throw new NullPointerException("out == null");
/*     */     }
/* 193 */     this.out = out;
/*     */   }
/*     */   
/*     */ 
/*     */   private String indent;
/*     */   
/*     */   private String separator;
/*     */   
/*     */   private boolean lenient;
/*     */   
/*     */   public final void setIndent(String indent)
/*     */   {
/* 205 */     if (indent.length() == 0) {
/* 206 */       this.indent = null;
/* 207 */       this.separator = ":";
/*     */     } else {
/* 209 */       this.indent = indent;
/* 210 */       this.separator = ": ";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean htmlSafe;
/*     */   
/*     */ 
/*     */   private String deferredName;
/*     */   
/*     */ 
/*     */   private boolean serializeNulls;
/*     */   
/*     */ 
/*     */   public final void setLenient(boolean lenient)
/*     */   {
/* 227 */     this.lenient = lenient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isLenient()
/*     */   {
/* 234 */     return this.lenient;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setHtmlSafe(boolean htmlSafe)
/*     */   {
/* 245 */     this.htmlSafe = htmlSafe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isHtmlSafe()
/*     */   {
/* 253 */     return this.htmlSafe;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setSerializeNulls(boolean serializeNulls)
/*     */   {
/* 261 */     this.serializeNulls = serializeNulls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean getSerializeNulls()
/*     */   {
/* 269 */     return this.serializeNulls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter beginArray()
/*     */     throws IOException
/*     */   {
/* 279 */     writeDeferredName();
/* 280 */     return open(JsonScope.EMPTY_ARRAY, "[");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter endArray()
/*     */     throws IOException
/*     */   {
/* 289 */     return close(JsonScope.EMPTY_ARRAY, JsonScope.NONEMPTY_ARRAY, "]");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter beginObject()
/*     */     throws IOException
/*     */   {
/* 299 */     writeDeferredName();
/* 300 */     return open(JsonScope.EMPTY_OBJECT, "{");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter endObject()
/*     */     throws IOException
/*     */   {
/* 309 */     return close(JsonScope.EMPTY_OBJECT, JsonScope.NONEMPTY_OBJECT, "}");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private JsonWriter open(JsonScope empty, String openBracket)
/*     */     throws IOException
/*     */   {
/* 317 */     beforeValue(true);
/* 318 */     this.stack.add(empty);
/* 319 */     this.out.write(openBracket);
/* 320 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JsonWriter close(JsonScope empty, JsonScope nonempty, String closeBracket)
/*     */     throws IOException
/*     */   {
/* 329 */     JsonScope context = peek();
/* 330 */     if ((context != nonempty) && (context != empty)) {
/* 331 */       throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */     }
/* 333 */     if (this.deferredName != null) {
/* 334 */       throw new IllegalStateException("Dangling name: " + this.deferredName);
/*     */     }
/*     */     
/* 337 */     this.stack.remove(this.stack.size() - 1);
/* 338 */     if (context == nonempty) {
/* 339 */       newline();
/*     */     }
/* 341 */     this.out.write(closeBracket);
/* 342 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private JsonScope peek()
/*     */   {
/* 349 */     int size = this.stack.size();
/* 350 */     if (size == 0) {
/* 351 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 353 */     return (JsonScope)this.stack.get(size - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void replaceTop(JsonScope topOfStack)
/*     */   {
/* 360 */     this.stack.set(this.stack.size() - 1, topOfStack);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter name(String name)
/*     */     throws IOException
/*     */   {
/* 370 */     if (name == null) {
/* 371 */       throw new NullPointerException("name == null");
/*     */     }
/* 373 */     if (this.deferredName != null) {
/* 374 */       throw new IllegalStateException();
/*     */     }
/* 376 */     if (this.stack.isEmpty()) {
/* 377 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 379 */     this.deferredName = name;
/* 380 */     return this;
/*     */   }
/*     */   
/*     */   private void writeDeferredName() throws IOException {
/* 384 */     if (this.deferredName != null) {
/* 385 */       beforeName();
/* 386 */       string(this.deferredName);
/* 387 */       this.deferredName = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter value(String value)
/*     */     throws IOException
/*     */   {
/* 398 */     if (value == null) {
/* 399 */       return nullValue();
/*     */     }
/* 401 */     writeDeferredName();
/* 402 */     beforeValue(false);
/* 403 */     string(value);
/* 404 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter nullValue()
/*     */     throws IOException
/*     */   {
/* 413 */     if (this.deferredName != null) {
/* 414 */       if (this.serializeNulls) {
/* 415 */         writeDeferredName();
/*     */       } else {
/* 417 */         this.deferredName = null;
/* 418 */         return this;
/*     */       }
/*     */     }
/* 421 */     beforeValue(false);
/* 422 */     this.out.write("null");
/* 423 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter value(boolean value)
/*     */     throws IOException
/*     */   {
/* 432 */     writeDeferredName();
/* 433 */     beforeValue(false);
/* 434 */     this.out.write(value ? "true" : "false");
/* 435 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter value(double value)
/*     */     throws IOException
/*     */   {
/* 446 */     if ((Double.isNaN(value)) || (Double.isInfinite(value))) {
/* 447 */       throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
/*     */     }
/* 449 */     writeDeferredName();
/* 450 */     beforeValue(false);
/* 451 */     this.out.append(Double.toString(value));
/* 452 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter value(long value)
/*     */     throws IOException
/*     */   {
/* 461 */     writeDeferredName();
/* 462 */     beforeValue(false);
/* 463 */     this.out.write(Long.toString(value));
/* 464 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JsonWriter value(Number value)
/*     */     throws IOException
/*     */   {
/* 475 */     if (value == null) {
/* 476 */       return nullValue();
/*     */     }
/*     */     
/* 479 */     writeDeferredName();
/* 480 */     String string = value.toString();
/* 481 */     if ((!this.lenient) && ((string.equals("-Infinity")) || (string.equals("Infinity")) || (string.equals("NaN"))))
/*     */     {
/* 483 */       throw new IllegalArgumentException("Numeric values must be finite, but was " + value);
/*     */     }
/* 485 */     beforeValue(false);
/* 486 */     this.out.append(string);
/* 487 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 495 */     if (this.stack.isEmpty()) {
/* 496 */       throw new IllegalStateException("JsonWriter is closed.");
/*     */     }
/* 498 */     this.out.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 507 */     this.out.close();
/*     */     
/* 509 */     int size = this.stack.size();
/* 510 */     if ((size > 1) || ((size == 1) && (this.stack.get(size - 1) != JsonScope.NONEMPTY_DOCUMENT))) {
/* 511 */       throw new IOException("Incomplete document");
/*     */     }
/* 513 */     this.stack.clear();
/*     */   }
/*     */   
/*     */   private void string(String value) throws IOException {
/* 517 */     String[] replacements = this.htmlSafe ? HTML_SAFE_REPLACEMENT_CHARS : REPLACEMENT_CHARS;
/* 518 */     this.out.write("\"");
/* 519 */     int last = 0;
/* 520 */     int length = value.length();
/* 521 */     for (int i = 0; i < length; i++) {
/* 522 */       char c = value.charAt(i);
/*     */       String replacement;
/* 524 */       if (c < '') {
/* 525 */         String replacement = replacements[c];
/* 526 */         if (replacement == null)
/*     */           continue;
/*     */       } else { String replacement;
/* 529 */         if (c == ' ') {
/* 530 */           replacement = "\\u2028";
/* 531 */         } else { if (c != ' ') continue;
/* 532 */           replacement = "\\u2029";
/*     */         }
/*     */       }
/*     */       
/* 536 */       if (last < i) {
/* 537 */         this.out.write(value, last, i - last);
/*     */       }
/* 539 */       this.out.write(replacement);
/* 540 */       last = i + 1;
/*     */     }
/* 542 */     if (last < length) {
/* 543 */       this.out.write(value, last, length - last);
/*     */     }
/* 545 */     this.out.write("\"");
/*     */   }
/*     */   
/*     */   private void newline() throws IOException {
/* 549 */     if (this.indent == null) {
/* 550 */       return;
/*     */     }
/*     */     
/* 553 */     this.out.write("\n");
/* 554 */     for (int i = 1; i < this.stack.size(); i++) {
/* 555 */       this.out.write(this.indent);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void beforeName()
/*     */     throws IOException
/*     */   {
/* 564 */     JsonScope context = peek();
/* 565 */     if (context == JsonScope.NONEMPTY_OBJECT) {
/* 566 */       this.out.write(44);
/* 567 */     } else if (context != JsonScope.EMPTY_OBJECT) {
/* 568 */       throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */     }
/* 570 */     newline();
/* 571 */     replaceTop(JsonScope.DANGLING_NAME);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void beforeValue(boolean root)
/*     */     throws IOException
/*     */   {
/* 584 */     switch (peek()) {
/*     */     case NONEMPTY_DOCUMENT: 
/* 586 */       if (!this.lenient) {
/* 587 */         throw new IllegalStateException("JSON must have only one top-level value.");
/*     */       }
/*     */     
/*     */ 
/*     */     case EMPTY_DOCUMENT: 
/* 592 */       if ((!this.lenient) && (!root)) {
/* 593 */         throw new IllegalStateException("JSON must start with an array or an object.");
/*     */       }
/*     */       
/* 596 */       replaceTop(JsonScope.NONEMPTY_DOCUMENT);
/* 597 */       break;
/*     */     
/*     */     case EMPTY_ARRAY: 
/* 600 */       replaceTop(JsonScope.NONEMPTY_ARRAY);
/* 601 */       newline();
/* 602 */       break;
/*     */     
/*     */     case NONEMPTY_ARRAY: 
/* 605 */       this.out.append(',');
/* 606 */       newline();
/* 607 */       break;
/*     */     
/*     */     case DANGLING_NAME: 
/* 610 */       this.out.append(this.separator);
/* 611 */       replaceTop(JsonScope.NONEMPTY_OBJECT);
/* 612 */       break;
/*     */     }
/*     */     
/* 615 */     throw new IllegalStateException("Nesting problem: " + this.stack);
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\stream\JsonWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */