package com.google.gson.stream;

 enum JsonScope
{
  EMPTY_ARRAY,  NONEMPTY_ARRAY,  EMPTY_OBJECT,  DANGLING_NAME,  NONEMPTY_OBJECT,  EMPTY_DOCUMENT,  NONEMPTY_DOCUMENT,  CLOSED;
  
  private JsonScope() {}
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\stream\JsonScope.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */