package com.google.gson.stream;

public enum JsonToken
{
  BEGIN_ARRAY,  END_ARRAY,  BEGIN_OBJECT,  END_OBJECT,  NAME,  STRING,  NUMBER,  BOOLEAN,  NULL,  END_DOCUMENT;
  
  private JsonToken() {}
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\stream\JsonToken.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */