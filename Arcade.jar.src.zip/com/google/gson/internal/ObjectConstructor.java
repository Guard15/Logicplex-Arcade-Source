package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\internal\ObjectConstructor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */