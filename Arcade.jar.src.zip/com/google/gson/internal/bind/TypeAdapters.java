/*     */ package com.google.gson.internal.bind;
/*     */ 
/*     */ import com.google.gson.Gson;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonIOException;
/*     */ import com.google.gson.JsonNull;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonPrimitive;
/*     */ import com.google.gson.JsonSyntaxException;
/*     */ import com.google.gson.TypeAdapter;
/*     */ import com.google.gson.TypeAdapterFactory;
/*     */ import com.google.gson.annotations.SerializedName;
/*     */ import com.google.gson.internal.LazilyParsedNumber;
/*     */ import com.google.gson.reflect.TypeToken;
/*     */ import com.google.gson.stream.JsonReader;
/*     */ import com.google.gson.stream.JsonToken;
/*     */ import com.google.gson.stream.JsonWriter;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.BitSet;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TypeAdapters
/*     */ {
/*  61 */   public static final TypeAdapter<Class> CLASS = new TypeAdapter()
/*     */   {
/*     */     public void write(JsonWriter out, Class value) throws IOException {
/*  64 */       throw new UnsupportedOperationException("Attempted to serialize java.lang.Class: " + value.getName() + ". Forgot to register a type adapter?");
/*     */     }
/*     */     
/*     */     public Class read(JsonReader in) throws IOException
/*     */     {
/*  69 */       throw new UnsupportedOperationException("Attempted to deserialize a java.lang.Class. Forgot to register a type adapter?");
/*     */     }
/*     */   };
/*     */   
/*  73 */   public static final TypeAdapterFactory CLASS_FACTORY = newFactory(Class.class, CLASS);
/*     */   
/*  75 */   public static final TypeAdapter<BitSet> BIT_SET = new TypeAdapter() {
/*     */     public BitSet read(JsonReader in) throws IOException {
/*  77 */       if (in.peek() == JsonToken.NULL) {
/*  78 */         in.nextNull();
/*  79 */         return null;
/*     */       }
/*     */       
/*  82 */       BitSet bitset = new BitSet();
/*  83 */       in.beginArray();
/*  84 */       int i = 0;
/*  85 */       JsonToken tokenType = in.peek();
/*  86 */       while (tokenType != JsonToken.END_ARRAY) {
/*     */         boolean set;
/*  88 */         switch (TypeAdapters.32.$SwitchMap$com$google$gson$stream$JsonToken[tokenType.ordinal()]) {
/*     */         case 1: 
/*  90 */           set = in.nextInt() != 0;
/*  91 */           break;
/*     */         case 2: 
/*  93 */           set = in.nextBoolean();
/*  94 */           break;
/*     */         case 3: 
/*  96 */           String stringValue = in.nextString();
/*     */           try {
/*  98 */             set = Integer.parseInt(stringValue) != 0;
/*     */           } catch (NumberFormatException e) {
/* 100 */             throw new JsonSyntaxException("Error: Expecting: bitset number value (1, 0), Found: " + stringValue);
/*     */           }
/*     */         
/*     */ 
/*     */         default: 
/* 105 */           throw new JsonSyntaxException("Invalid bitset value type: " + tokenType);
/*     */         }
/* 107 */         if (set) {
/* 108 */           bitset.set(i);
/*     */         }
/* 110 */         i++;
/* 111 */         tokenType = in.peek();
/*     */       }
/* 113 */       in.endArray();
/* 114 */       return bitset;
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, BitSet src) throws IOException {
/* 118 */       if (src == null) {
/* 119 */         out.nullValue();
/* 120 */         return;
/*     */       }
/*     */       
/* 123 */       out.beginArray();
/* 124 */       for (int i = 0; i < src.length(); i++) {
/* 125 */         int value = src.get(i) ? 1 : 0;
/* 126 */         out.value(value);
/*     */       }
/* 128 */       out.endArray();
/*     */     }
/*     */   };
/*     */   
/* 132 */   public static final TypeAdapterFactory BIT_SET_FACTORY = newFactory(BitSet.class, BIT_SET);
/*     */   
/* 134 */   public static final TypeAdapter<Boolean> BOOLEAN = new TypeAdapter()
/*     */   {
/*     */     public Boolean read(JsonReader in) throws IOException {
/* 137 */       if (in.peek() == JsonToken.NULL) {
/* 138 */         in.nextNull();
/* 139 */         return null; }
/* 140 */       if (in.peek() == JsonToken.STRING)
/*     */       {
/* 142 */         return Boolean.valueOf(Boolean.parseBoolean(in.nextString()));
/*     */       }
/* 144 */       return Boolean.valueOf(in.nextBoolean());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Boolean value) throws IOException {
/* 148 */       if (value == null) {
/* 149 */         out.nullValue();
/* 150 */         return;
/*     */       }
/* 152 */       out.value(value.booleanValue());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */   public static final TypeAdapter<Boolean> BOOLEAN_AS_STRING = new TypeAdapter() {
/*     */     public Boolean read(JsonReader in) throws IOException {
/* 162 */       if (in.peek() == JsonToken.NULL) {
/* 163 */         in.nextNull();
/* 164 */         return null;
/*     */       }
/* 166 */       return Boolean.valueOf(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Boolean value) throws IOException {
/* 170 */       out.value(value == null ? "null" : value.toString());
/*     */     }
/*     */   };
/*     */   
/* 174 */   public static final TypeAdapterFactory BOOLEAN_FACTORY = newFactory(Boolean.TYPE, Boolean.class, BOOLEAN);
/*     */   
/*     */ 
/* 177 */   public static final TypeAdapter<Number> BYTE = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 180 */       if (in.peek() == JsonToken.NULL) {
/* 181 */         in.nextNull();
/* 182 */         return null;
/*     */       }
/*     */       try {
/* 185 */         int intValue = in.nextInt();
/* 186 */         return Byte.valueOf((byte)intValue);
/*     */       } catch (NumberFormatException e) {
/* 188 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 193 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 197 */   public static final TypeAdapterFactory BYTE_FACTORY = newFactory(Byte.TYPE, Byte.class, BYTE);
/*     */   
/*     */ 
/* 200 */   public static final TypeAdapter<Number> SHORT = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 203 */       if (in.peek() == JsonToken.NULL) {
/* 204 */         in.nextNull();
/* 205 */         return null;
/*     */       }
/*     */       try {
/* 208 */         return Short.valueOf((short)in.nextInt());
/*     */       } catch (NumberFormatException e) {
/* 210 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 215 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 219 */   public static final TypeAdapterFactory SHORT_FACTORY = newFactory(Short.TYPE, Short.class, SHORT);
/*     */   
/*     */ 
/* 222 */   public static final TypeAdapter<Number> INTEGER = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 225 */       if (in.peek() == JsonToken.NULL) {
/* 226 */         in.nextNull();
/* 227 */         return null;
/*     */       }
/*     */       try {
/* 230 */         return Integer.valueOf(in.nextInt());
/*     */       } catch (NumberFormatException e) {
/* 232 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 237 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 241 */   public static final TypeAdapterFactory INTEGER_FACTORY = newFactory(Integer.TYPE, Integer.class, INTEGER);
/*     */   
/*     */ 
/* 244 */   public static final TypeAdapter<Number> LONG = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 247 */       if (in.peek() == JsonToken.NULL) {
/* 248 */         in.nextNull();
/* 249 */         return null;
/*     */       }
/*     */       try {
/* 252 */         return Long.valueOf(in.nextLong());
/*     */       } catch (NumberFormatException e) {
/* 254 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 259 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 263 */   public static final TypeAdapter<Number> FLOAT = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 266 */       if (in.peek() == JsonToken.NULL) {
/* 267 */         in.nextNull();
/* 268 */         return null;
/*     */       }
/* 270 */       return Float.valueOf((float)in.nextDouble());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 274 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 278 */   public static final TypeAdapter<Number> DOUBLE = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 281 */       if (in.peek() == JsonToken.NULL) {
/* 282 */         in.nextNull();
/* 283 */         return null;
/*     */       }
/* 285 */       return Double.valueOf(in.nextDouble());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException {
/* 289 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 293 */   public static final TypeAdapter<Number> NUMBER = new TypeAdapter()
/*     */   {
/*     */     public Number read(JsonReader in) throws IOException {
/* 296 */       JsonToken jsonToken = in.peek();
/* 297 */       switch (TypeAdapters.32.$SwitchMap$com$google$gson$stream$JsonToken[jsonToken.ordinal()]) {
/*     */       case 4: 
/* 299 */         in.nextNull();
/* 300 */         return null;
/*     */       case 1: 
/* 302 */         return new LazilyParsedNumber(in.nextString());
/*     */       }
/* 304 */       throw new JsonSyntaxException("Expecting number, got: " + jsonToken);
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Number value) throws IOException
/*     */     {
/* 309 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 313 */   public static final TypeAdapterFactory NUMBER_FACTORY = newFactory(Number.class, NUMBER);
/*     */   
/* 315 */   public static final TypeAdapter<Character> CHARACTER = new TypeAdapter()
/*     */   {
/*     */     public Character read(JsonReader in) throws IOException {
/* 318 */       if (in.peek() == JsonToken.NULL) {
/* 319 */         in.nextNull();
/* 320 */         return null;
/*     */       }
/* 322 */       String str = in.nextString();
/* 323 */       if (str.length() != 1) {
/* 324 */         throw new JsonSyntaxException("Expecting character, got: " + str);
/*     */       }
/* 326 */       return Character.valueOf(str.charAt(0));
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Character value) throws IOException {
/* 330 */       out.value(value == null ? null : String.valueOf(value));
/*     */     }
/*     */   };
/*     */   
/* 334 */   public static final TypeAdapterFactory CHARACTER_FACTORY = newFactory(Character.TYPE, Character.class, CHARACTER);
/*     */   
/*     */ 
/* 337 */   public static final TypeAdapter<String> STRING = new TypeAdapter()
/*     */   {
/*     */     public String read(JsonReader in) throws IOException {
/* 340 */       JsonToken peek = in.peek();
/* 341 */       if (peek == JsonToken.NULL) {
/* 342 */         in.nextNull();
/* 343 */         return null;
/*     */       }
/*     */       
/* 346 */       if (peek == JsonToken.BOOLEAN) {
/* 347 */         return Boolean.toString(in.nextBoolean());
/*     */       }
/* 349 */       return in.nextString();
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, String value) throws IOException {
/* 353 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 357 */   public static final TypeAdapter<BigDecimal> BIG_DECIMAL = new TypeAdapter() {
/*     */     public BigDecimal read(JsonReader in) throws IOException {
/* 359 */       if (in.peek() == JsonToken.NULL) {
/* 360 */         in.nextNull();
/* 361 */         return null;
/*     */       }
/*     */       try {
/* 364 */         return new BigDecimal(in.nextString());
/*     */       } catch (NumberFormatException e) {
/* 366 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, BigDecimal value) throws IOException {
/* 371 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 375 */   public static final TypeAdapter<BigInteger> BIG_INTEGER = new TypeAdapter() {
/*     */     public BigInteger read(JsonReader in) throws IOException {
/* 377 */       if (in.peek() == JsonToken.NULL) {
/* 378 */         in.nextNull();
/* 379 */         return null;
/*     */       }
/*     */       try {
/* 382 */         return new BigInteger(in.nextString());
/*     */       } catch (NumberFormatException e) {
/* 384 */         throw new JsonSyntaxException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, BigInteger value) throws IOException {
/* 389 */       out.value(value);
/*     */     }
/*     */   };
/*     */   
/* 393 */   public static final TypeAdapterFactory STRING_FACTORY = newFactory(String.class, STRING);
/*     */   
/* 395 */   public static final TypeAdapter<StringBuilder> STRING_BUILDER = new TypeAdapter()
/*     */   {
/*     */     public StringBuilder read(JsonReader in) throws IOException {
/* 398 */       if (in.peek() == JsonToken.NULL) {
/* 399 */         in.nextNull();
/* 400 */         return null;
/*     */       }
/* 402 */       return new StringBuilder(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, StringBuilder value) throws IOException {
/* 406 */       out.value(value == null ? null : value.toString());
/*     */     }
/*     */   };
/*     */   
/* 410 */   public static final TypeAdapterFactory STRING_BUILDER_FACTORY = newFactory(StringBuilder.class, STRING_BUILDER);
/*     */   
/*     */ 
/* 413 */   public static final TypeAdapter<StringBuffer> STRING_BUFFER = new TypeAdapter()
/*     */   {
/*     */     public StringBuffer read(JsonReader in) throws IOException {
/* 416 */       if (in.peek() == JsonToken.NULL) {
/* 417 */         in.nextNull();
/* 418 */         return null;
/*     */       }
/* 420 */       return new StringBuffer(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, StringBuffer value) throws IOException {
/* 424 */       out.value(value == null ? null : value.toString());
/*     */     }
/*     */   };
/*     */   
/* 428 */   public static final TypeAdapterFactory STRING_BUFFER_FACTORY = newFactory(StringBuffer.class, STRING_BUFFER);
/*     */   
/*     */ 
/* 431 */   public static final TypeAdapter<URL> URL = new TypeAdapter()
/*     */   {
/*     */     public URL read(JsonReader in) throws IOException {
/* 434 */       if (in.peek() == JsonToken.NULL) {
/* 435 */         in.nextNull();
/* 436 */         return null;
/*     */       }
/* 438 */       String nextString = in.nextString();
/* 439 */       return "null".equals(nextString) ? null : new URL(nextString);
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, URL value) throws IOException {
/* 443 */       out.value(value == null ? null : value.toExternalForm());
/*     */     }
/*     */   };
/*     */   
/* 447 */   public static final TypeAdapterFactory URL_FACTORY = newFactory(URL.class, URL);
/*     */   
/* 449 */   public static final TypeAdapter<URI> URI = new TypeAdapter()
/*     */   {
/*     */     public URI read(JsonReader in) throws IOException {
/* 452 */       if (in.peek() == JsonToken.NULL) {
/* 453 */         in.nextNull();
/* 454 */         return null;
/*     */       }
/*     */       try {
/* 457 */         String nextString = in.nextString();
/* 458 */         return "null".equals(nextString) ? null : new URI(nextString);
/*     */       } catch (URISyntaxException e) {
/* 460 */         throw new JsonIOException(e);
/*     */       }
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, URI value) throws IOException {
/* 465 */       out.value(value == null ? null : value.toASCIIString());
/*     */     }
/*     */   };
/*     */   
/* 469 */   public static final TypeAdapterFactory URI_FACTORY = newFactory(URI.class, URI);
/*     */   
/* 471 */   public static final TypeAdapter<InetAddress> INET_ADDRESS = new TypeAdapter()
/*     */   {
/*     */     public InetAddress read(JsonReader in) throws IOException {
/* 474 */       if (in.peek() == JsonToken.NULL) {
/* 475 */         in.nextNull();
/* 476 */         return null;
/*     */       }
/*     */       
/* 479 */       return InetAddress.getByName(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, InetAddress value) throws IOException {
/* 483 */       out.value(value == null ? null : value.getHostAddress());
/*     */     }
/*     */   };
/*     */   
/* 487 */   public static final TypeAdapterFactory INET_ADDRESS_FACTORY = newTypeHierarchyFactory(InetAddress.class, INET_ADDRESS);
/*     */   
/*     */ 
/* 490 */   public static final TypeAdapter<UUID> UUID = new TypeAdapter()
/*     */   {
/*     */     public UUID read(JsonReader in) throws IOException {
/* 493 */       if (in.peek() == JsonToken.NULL) {
/* 494 */         in.nextNull();
/* 495 */         return null;
/*     */       }
/* 497 */       return UUID.fromString(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, UUID value) throws IOException {
/* 501 */       out.value(value == null ? null : value.toString());
/*     */     }
/*     */   };
/*     */   
/* 505 */   public static final TypeAdapterFactory UUID_FACTORY = newFactory(UUID.class, UUID);
/*     */   
/* 507 */   public static final TypeAdapterFactory TIMESTAMP_FACTORY = new TypeAdapterFactory()
/*     */   {
/*     */     public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 510 */       if (typeToken.getRawType() != Timestamp.class) {
/* 511 */         return null;
/*     */       }
/*     */       
/* 514 */       final TypeAdapter<Date> dateTypeAdapter = gson.getAdapter(Date.class);
/* 515 */       new TypeAdapter() {
/*     */         public Timestamp read(JsonReader in) throws IOException {
/* 517 */           Date date = (Date)dateTypeAdapter.read(in);
/* 518 */           return date != null ? new Timestamp(date.getTime()) : null;
/*     */         }
/*     */         
/*     */         public void write(JsonWriter out, Timestamp value) throws IOException {
/* 522 */           dateTypeAdapter.write(out, value);
/*     */         }
/*     */       };
/*     */     }
/*     */   };
/*     */   
/* 528 */   public static final TypeAdapter<Calendar> CALENDAR = new TypeAdapter()
/*     */   {
/*     */     private static final String YEAR = "year";
/*     */     private static final String MONTH = "month";
/*     */     private static final String DAY_OF_MONTH = "dayOfMonth";
/*     */     private static final String HOUR_OF_DAY = "hourOfDay";
/*     */     private static final String MINUTE = "minute";
/*     */     private static final String SECOND = "second";
/*     */     
/*     */     public Calendar read(JsonReader in) throws IOException {
/* 538 */       if (in.peek() == JsonToken.NULL) {
/* 539 */         in.nextNull();
/* 540 */         return null;
/*     */       }
/* 542 */       in.beginObject();
/* 543 */       int year = 0;
/* 544 */       int month = 0;
/* 545 */       int dayOfMonth = 0;
/* 546 */       int hourOfDay = 0;
/* 547 */       int minute = 0;
/* 548 */       int second = 0;
/* 549 */       while (in.peek() != JsonToken.END_OBJECT) {
/* 550 */         String name = in.nextName();
/* 551 */         int value = in.nextInt();
/* 552 */         if ("year".equals(name)) {
/* 553 */           year = value;
/* 554 */         } else if ("month".equals(name)) {
/* 555 */           month = value;
/* 556 */         } else if ("dayOfMonth".equals(name)) {
/* 557 */           dayOfMonth = value;
/* 558 */         } else if ("hourOfDay".equals(name)) {
/* 559 */           hourOfDay = value;
/* 560 */         } else if ("minute".equals(name)) {
/* 561 */           minute = value;
/* 562 */         } else if ("second".equals(name)) {
/* 563 */           second = value;
/*     */         }
/*     */       }
/* 566 */       in.endObject();
/* 567 */       return new GregorianCalendar(year, month, dayOfMonth, hourOfDay, minute, second);
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Calendar value) throws IOException
/*     */     {
/* 572 */       if (value == null) {
/* 573 */         out.nullValue();
/* 574 */         return;
/*     */       }
/* 576 */       out.beginObject();
/* 577 */       out.name("year");
/* 578 */       out.value(value.get(1));
/* 579 */       out.name("month");
/* 580 */       out.value(value.get(2));
/* 581 */       out.name("dayOfMonth");
/* 582 */       out.value(value.get(5));
/* 583 */       out.name("hourOfDay");
/* 584 */       out.value(value.get(11));
/* 585 */       out.name("minute");
/* 586 */       out.value(value.get(12));
/* 587 */       out.name("second");
/* 588 */       out.value(value.get(13));
/* 589 */       out.endObject();
/*     */     }
/*     */   };
/*     */   
/* 593 */   public static final TypeAdapterFactory CALENDAR_FACTORY = newFactoryForMultipleTypes(Calendar.class, GregorianCalendar.class, CALENDAR);
/*     */   
/*     */ 
/* 596 */   public static final TypeAdapter<Locale> LOCALE = new TypeAdapter()
/*     */   {
/*     */     public Locale read(JsonReader in) throws IOException {
/* 599 */       if (in.peek() == JsonToken.NULL) {
/* 600 */         in.nextNull();
/* 601 */         return null;
/*     */       }
/* 603 */       String locale = in.nextString();
/* 604 */       StringTokenizer tokenizer = new StringTokenizer(locale, "_");
/* 605 */       String language = null;
/* 606 */       String country = null;
/* 607 */       String variant = null;
/* 608 */       if (tokenizer.hasMoreElements()) {
/* 609 */         language = tokenizer.nextToken();
/*     */       }
/* 611 */       if (tokenizer.hasMoreElements()) {
/* 612 */         country = tokenizer.nextToken();
/*     */       }
/* 614 */       if (tokenizer.hasMoreElements()) {
/* 615 */         variant = tokenizer.nextToken();
/*     */       }
/* 617 */       if ((country == null) && (variant == null))
/* 618 */         return new Locale(language);
/* 619 */       if (variant == null) {
/* 620 */         return new Locale(language, country);
/*     */       }
/* 622 */       return new Locale(language, country, variant);
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, Locale value) throws IOException
/*     */     {
/* 627 */       out.value(value == null ? null : value.toString());
/*     */     }
/*     */   };
/*     */   
/* 631 */   public static final TypeAdapterFactory LOCALE_FACTORY = newFactory(Locale.class, LOCALE);
/*     */   
/* 633 */   public static final TypeAdapter<JsonElement> JSON_ELEMENT = new TypeAdapter() {
/*     */     public JsonElement read(JsonReader in) throws IOException {
/* 635 */       switch (TypeAdapters.32.$SwitchMap$com$google$gson$stream$JsonToken[in.peek().ordinal()]) {
/*     */       case 3: 
/* 637 */         return new JsonPrimitive(in.nextString());
/*     */       case 1: 
/* 639 */         String number = in.nextString();
/* 640 */         return new JsonPrimitive(new LazilyParsedNumber(number));
/*     */       case 2: 
/* 642 */         return new JsonPrimitive(Boolean.valueOf(in.nextBoolean()));
/*     */       case 4: 
/* 644 */         in.nextNull();
/* 645 */         return JsonNull.INSTANCE;
/*     */       case 5: 
/* 647 */         JsonArray array = new JsonArray();
/* 648 */         in.beginArray();
/* 649 */         while (in.hasNext()) {
/* 650 */           array.add(read(in));
/*     */         }
/* 652 */         in.endArray();
/* 653 */         return array;
/*     */       case 6: 
/* 655 */         JsonObject object = new JsonObject();
/* 656 */         in.beginObject();
/* 657 */         while (in.hasNext()) {
/* 658 */           object.add(in.nextName(), read(in));
/*     */         }
/* 660 */         in.endObject();
/* 661 */         return object;
/*     */       }
/*     */       
/*     */       
/*     */ 
/*     */ 
/* 667 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, JsonElement value) throws IOException
/*     */     {
/* 672 */       if ((value == null) || (value.isJsonNull())) {
/* 673 */         out.nullValue();
/* 674 */       } else if (value.isJsonPrimitive()) {
/* 675 */         JsonPrimitive primitive = value.getAsJsonPrimitive();
/* 676 */         if (primitive.isNumber()) {
/* 677 */           out.value(primitive.getAsNumber());
/* 678 */         } else if (primitive.isBoolean()) {
/* 679 */           out.value(primitive.getAsBoolean());
/*     */         } else {
/* 681 */           out.value(primitive.getAsString());
/*     */         }
/*     */       }
/* 684 */       else if (value.isJsonArray()) {
/* 685 */         out.beginArray();
/* 686 */         for (JsonElement e : value.getAsJsonArray()) {
/* 687 */           write(out, e);
/*     */         }
/* 689 */         out.endArray();
/*     */       }
/* 691 */       else if (value.isJsonObject()) {
/* 692 */         out.beginObject();
/* 693 */         for (Map.Entry<String, JsonElement> e : value.getAsJsonObject().entrySet()) {
/* 694 */           out.name((String)e.getKey());
/* 695 */           write(out, (JsonElement)e.getValue());
/*     */         }
/* 697 */         out.endObject();
/*     */       }
/*     */       else {
/* 700 */         throw new IllegalArgumentException("Couldn't write " + value.getClass());
/*     */       }
/*     */     }
/*     */   };
/*     */   
/* 705 */   public static final TypeAdapterFactory JSON_ELEMENT_FACTORY = newFactory(JsonElement.class, JSON_ELEMENT);
/*     */   
/*     */   private static final class EnumTypeAdapter<T extends Enum<T>> extends TypeAdapter<T>
/*     */   {
/* 709 */     private final Map<String, T> nameToConstant = new HashMap();
/* 710 */     private final Map<T, String> constantToName = new HashMap();
/*     */     
/*     */     public EnumTypeAdapter(Class<T> classOfT) {
/*     */       try {
/* 714 */         for (T constant : (Enum[])classOfT.getEnumConstants()) {
/* 715 */           String name = constant.name();
/* 716 */           SerializedName annotation = (SerializedName)classOfT.getField(name).getAnnotation(SerializedName.class);
/* 717 */           if (annotation != null) {
/* 718 */             name = annotation.value();
/*     */           }
/* 720 */           this.nameToConstant.put(name, constant);
/* 721 */           this.constantToName.put(constant, name);
/*     */         }
/*     */       } catch (NoSuchFieldException e) {
/* 724 */         throw new AssertionError();
/*     */       }
/*     */     }
/*     */     
/* 728 */     public T read(JsonReader in) throws IOException { if (in.peek() == JsonToken.NULL) {
/* 729 */         in.nextNull();
/* 730 */         return null;
/*     */       }
/* 732 */       return (Enum)this.nameToConstant.get(in.nextString());
/*     */     }
/*     */     
/*     */     public void write(JsonWriter out, T value) throws IOException {
/* 736 */       out.value(value == null ? null : (String)this.constantToName.get(value));
/*     */     }
/*     */   }
/*     */   
/* 740 */   public static final TypeAdapterFactory ENUM_FACTORY = newEnumTypeHierarchyFactory();
/*     */   
/*     */   public static TypeAdapterFactory newEnumTypeHierarchyFactory() {
/* 743 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 746 */         Class<? super T> rawType = typeToken.getRawType();
/* 747 */         if ((!Enum.class.isAssignableFrom(rawType)) || (rawType == Enum.class)) {
/* 748 */           return null;
/*     */         }
/* 750 */         if (!rawType.isEnum()) {
/* 751 */           rawType = rawType.getSuperclass();
/*     */         }
/* 753 */         return new TypeAdapters.EnumTypeAdapter(rawType);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactory(TypeToken<TT> type, final TypeAdapter<TT> typeAdapter)
/*     */   {
/* 760 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 763 */         return typeToken.equals(this.val$type) ? typeAdapter : null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public static <TT> TypeAdapterFactory newFactory(Class<TT> type, final TypeAdapter<TT> typeAdapter)
/*     */   {
/* 770 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 773 */         return typeToken.getRawType() == this.val$type ? typeAdapter : null;
/*     */       }
/*     */       
/* 776 */       public String toString() { return "Factory[type=" + this.val$type.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public static <TT> TypeAdapterFactory newFactory(Class<TT> unboxed, final Class<TT> boxed, final TypeAdapter<? super TT> typeAdapter)
/*     */   {
/* 783 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 786 */         Class<? super T> rawType = typeToken.getRawType();
/* 787 */         return (rawType == this.val$unboxed) || (rawType == boxed) ? typeAdapter : null;
/*     */       }
/*     */       
/* 790 */       public String toString() { return "Factory[type=" + boxed.getName() + "+" + this.val$unboxed.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static <TT> TypeAdapterFactory newFactoryForMultipleTypes(Class<TT> base, final Class<? extends TT> sub, final TypeAdapter<? super TT> typeAdapter)
/*     */   {
/* 798 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 801 */         Class<? super T> rawType = typeToken.getRawType();
/* 802 */         return (rawType == this.val$base) || (rawType == sub) ? typeAdapter : null;
/*     */       }
/*     */       
/* 805 */       public String toString() { return "Factory[type=" + this.val$base.getName() + "+" + sub.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static <TT> TypeAdapterFactory newTypeHierarchyFactory(Class<TT> clazz, final TypeAdapter<TT> typeAdapter)
/*     */   {
/* 813 */     new TypeAdapterFactory()
/*     */     {
/*     */       public <T> TypeAdapter<T> create(Gson gson, TypeToken<T> typeToken) {
/* 816 */         return this.val$clazz.isAssignableFrom(typeToken.getRawType()) ? typeAdapter : null;
/*     */       }
/*     */       
/* 819 */       public String toString() { return "Factory[typeHierarchy=" + this.val$clazz.getName() + ",adapter=" + typeAdapter + "]"; }
/*     */     };
/*     */   }
/*     */ }


/* Location:              F:\Server\MIN-1\plugins\Arcade.jar!\com\google\gson\internal\bind\TypeAdapters.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */